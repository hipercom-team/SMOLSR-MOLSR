//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

struct interfaces {
  unsigned int int_addr;                /* interface address */
  unsigned int int_bAddr;               /* broadcast address */
  int   int_index;                      /* interface index */
  char  *int_name;			/* from kernel if structure */
  struct interfaces *next;
};

int get_system_interfaces(struct interfaces **listIface);

ip_addr  get_iface_broadcast_by_addr(struct interfaces *Ifaces,ip_addr *ifaceAddr);

int get_iface_index_by_addr(struct interfaces *Ifaces,ip_addr *ifaceAddr);

ip_addr get_iface_addr_by_name(struct interfaces *Ifaces,char *ifName);

ip_addr get_iface_addr_by_index(struct interfaces *Ifaces,int index);

void free_interfaces(struct interfaces *Ifaces);

void print_interfaces(struct interfaces *Ifaces);
