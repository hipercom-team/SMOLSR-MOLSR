//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
struct igmpProcMLine
{
  unsigned long multiaddr;
  unsigned long expires;
  //    struct timer_list timer;
  short tm_running;
  short reporter;
  int users;
  struct igmpProcMLine *next;
};

struct igmpProcIface
{
  char    name[IFNAMSIZ]; 
  int     ifindex;    
  int     mc_count; 
  struct igmpProcMLine *mlist;
  struct igmpProcIface *next;
};


struct igmpProcIface *get_igmp_info();
void freeIgmpContent(struct igmpProcIface *igmpProcContent);
