//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#define NEW_SOURCE     61
#define LEAVE_SOURCE   62

#define SOURCE_LOCAL_HOLD_TIME  15

struct SourceLocal_entry {
  struct          SourceLocal_entry *srcLocal_forw;
  struct          SourceLocal_entry *srcLocal_back;
  u_int32_t       srcLocal_hash;
  ip_addr         srcLocal_addr;
  ip_addr         srcLocal_group;	
  struct timeval  srcLocal_timer;	
};


struct SourceLocalhash {
  struct SourceLocal_entry *srcLocal_forw;
  struct SourceLocal_entry *srcLocal_back;
};

extern struct SourceLocalhash       sourceLocaltable[];

extern struct timeval hold_time_sourceLocal;
extern double sourceLocal_hold_time ;
void mdfp_delete_SourceLocal_table(struct SourceLocal_entry *);

struct SourceLocal_entry *mdfp_insert_SourceLocal_table(struct message_header *);

struct SourceLocal_entry 
*mdfp_lookup_SourceLocal_table(struct message_header *);

void mdfp_release_SourceLocal_table();

void mdfp_time_out_SourceLocal_table();

int mdfp_process_localSource_updates(struct message_header *msgh);

void mdfp_tell_MOLSR_NewLeave_localSource(struct SourceLocal_entry * srcLocal_message,unsigned int type);

void mdf_tell_MOLSR_localSourceContent();
