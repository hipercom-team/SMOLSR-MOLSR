//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _ADDRESS_H
#define _ADDRESS_H

//---------------------------------------------------------------------------

#include "base.h"

#include <vector>
#include "mystream.h"
#include <map>

#if defined(SYSTEMwindows) || defined(SYSTEMcygwin) || defined(SYSTEMopnet)
#else /*!SYSTEMwindows*/

#ifndef UNDER_CE
//XXX why defined || doesn't work?
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif

#endif /*SYSTEMwindows*/


#include "general.h"
#include "log.h"

class AddressFactory;

typedef void* RawAddress;

/// Address is used as a FlyWeight pattern.
/// This class should be passed by value
class Address 
{
public:
  Address(AddressFactory* aFactory, RawAddress address);
  Address() : factory(NULL), addressIndex(-1) {}

  bool isNull() const
  { return factory == NULL; }
  
  // NOTE: this does not order lexicographically
  // null address comparison: nullAddr "<" anyAddr
  //                          nullAddr "is not <" nullAddr
  bool isLessThan(const Address& other) const
  { 
    //if(other.factory==NULL)
    //return true;
    
    if ((isNull()) || other.isNull())
      return (isNull()) && !other.isNull();
     
    assert( factory == other.factory ); 
    return addressIndex < other.addressIndex;
  }

  /// Returns the size of the address when in networking format
  int getNetSize() const;

  /// Write the address in networking order and format, in the first
  /// bytes of data. The number of bytes which are written is
  /// given by the method getNetSize()
  void toNet(void* data) const;

  /// Return the maximum size of the address when written in human-readable
  /// form (including room for the final (char)0)
  int getMaxTextSize() const;
  
  /// Write the address in human-readable format, in the first
  /// bytes of data, and add a trailer (char)0. 
  /// The number of bytes which are written is less or equal to the number
  /// given by the method getMaxTextSize()
  void toText(char* data) const;
  
  /// Return true if and only if the other address is the same as this
  /// address.
  bool isSame(Address other) const
  { 
#if 0
    if(!(factory) && (other.factory))
      return false;
#endif
    if(isNull() || other.isNull())
      return (isNull() == other.isNull());
    assert(factory == other.factory); // if not you should compare content
    return addressIndex == other.addressIndex;
  }

  bool operator == (Address other) const
  { return isSame(other); }

  // Specific method
  RawAddress getRawAddress() const;

  void write(ostream& out) const;
  
protected:
  AddressFactory* factory;
  int addressIndex;

  friend class AddressFactory;
};

extern string toText(Address address);

/// This class is in charge of creating the addresses
class AddressFactory
{
public:
  AddressFactory(int anAddressSize)
    : addressSize(anAddressSize), addressType(UnknownAddress) { }

  /// Return the size of the address when in networking format.
  /// It will be the same as IPv4Address::getNetSize()
  int getAddressSize()
  { return addressSize; }

  /// Takes the first bytes (the exact number is given by method
  /// getAddressSize()) as an address in networking order and return
  /// it as an IPv4Address
  Address peekAddress(void* data)
  { return Address(this, data); }

  /// Takes a null terminated string and return the address
  virtual Address parseAddress(char* textString)
  { 
#if !defined(SYSTEMwindows) && !defined(SYSTEMcygwin) && !defined(SYSTEMopnet)
    octet * addr_clone;
    octet * addr;
    int af_type;
    void * inaddr;

    if(addressSize==4) {
      af_type=AF_INET;
      inaddr=(in_addr *)malloc(sizeof(in_addr));
      addr=(octet *) &(((in_addr*)inaddr)->s_addr);
    } else if(addressSize==16) {
      af_type=AF_INET6;
      inaddr=(in6_addr*)malloc(sizeof(in6_addr));
      addr=((in6_addr*) inaddr)->s6_addr;
    } else{
      Fatal("XXX: unimplemented: need to express failure");
    } 
    addr_clone=(octet*)malloc(addressSize*sizeof(octet));
    inet_pton(af_type,textString,inaddr);
    memcpy(addr_clone,addr,addressSize);
    free(inaddr);
    return Address(this,addr_clone); //XXX:leak?
#else
    Fatal("XXX: unimplemented: need to express failure");
    return Address();
#endif
  }

  Address getNullAddress() 
  { return Address(); } // unconfigured address
  
  virtual ~AddressFactory()
  {
    for(unsigned int i=0;i<addressVector.size();i++)
      delete [] (addressVector[i]);
  }

  void setAddressType(string strAddressType)
  {
    if(strAddressType == "plugin-address") {
      addressType = PluginAddress;
    } else {
      Fatal("Unknown address type: " << strAddressType);
    }
  }

protected:

#ifdef MORE_OPT
  typedef std::pair<RawAddress, int> FullRawAddress;

  struct RawAddressLess {
    bool operator() (const FullRawAddress& a1, const FullRawAddress& a2) const{
      assert( a1.second == a2.second );
      bool result = memcmp(a1.first, a2.first, /*addressSize*/ a1.second) < 0;
      return result;
    }
  };


  typedef std::map<FullRawAddress, int, RawAddressLess> RawAddressMap;
  typedef std::map<FullRawAddress, int, RawAddressLess>::iterator 
  RawAddressMapIterator;

  RawAddressMap rawAddressMap;

#endif

  int addAddress(RawAddress address)
  {
    int result = _lookUpAddress(address);
    if(result<0) {
      result = addressVector.size();
      octet* addressClone = new octet [addressSize];
      memcpy(addressClone, address, addressSize);
      addressVector.push_back(addressClone);
#ifdef MORE_OPT
      rawAddressMap[FullRawAddress(addressClone, addressSize)] = result;
#endif
    }
    return result;
  }


  int _lookUpAddress(RawAddress address)
  {
#ifdef MORE_OPT
    RawAddressMapIterator it = rawAddressMap.find
      (FullRawAddress(address, addressSize));
    if (it != rawAddressMap.end())
      return (*it).second;
    else return -1;
#else
    for(unsigned int i=0;i<addressVector.size();i++)
      if (!memcmp(address, addressVector[i], addressSize)) 
	return i;
    return -1;
#endif
  }

  RawAddress getAddress(int addressIndex) 
  { 
    assert(0<=addressIndex && addressIndex<(int)addressVector.size());
    return addressVector[addressIndex]; 
  } 

  virtual void write(ostream& out, const Address& address)
  {
    if (addressSize == 4) { // XXX: not pretty
      octet* data = (octet*)address.getRawAddress();
      out << (int)data[0] << "." << (int)data[1] << "."
	  << (int)data[2] << "." << (int)data[3];
    } else if (addressSize == 16) { // XXX
      //octet* data = (octet*)address.getRawAddress();
      out << "(ipv6 addr)";
    } else {
      const int MulticastNodeIdx = 0xfffe; // XXX see simulation_plugee_support
      unsigned int nodeIdx = *(unsigned int*) address.getRawAddress();
      unsigned int ifaceIdx = ((unsigned int*) address.getRawAddress())[1];
      if (nodeIdx == (unsigned int)MulticastNodeIdx) {
	out << "gm" << ifaceIdx;
      } else if ((nodeIdx)<=26 && (ifaceIdx)<10) {
	out << (char)('A'+(nodeIdx)) << (char)('0'+(ifaceIdx));
      } else {
	out << "N" << (nodeIdx) << "I" << (ifaceIdx);
      }
    }
  }

  virtual void toText(const Address& address, char* data)
  { strcpy(data, "(some address)"); }

  int addressSize;
  enum {
    UnknownAddress,
    PluginAddress
  } addressType;
  std::vector<octet*> addressVector;

  friend class Address;
};

//typedef Address Address;
//typedef AddressFactory AddressFactory;

ostream& operator << (ostream& out, const Address& address);

//---------------------------------------------------------------------------

template<class Value, class CXXIterator>
class IteratorAdapter
{
public:
  IteratorAdapter(CXXIterator aStart, CXXIterator aStop) :
    current(aStart), stop(aStop) { }
    
  Value getCurrent() { return *current; }
  void next() { current++; }  
  bool isDone() { return current == stop; }

  //--------------------------------------------------
  // Functions for C++ compatibility
  Value operator * () { return getCurrent(); }
  void operator ++ () { next(); }
  //bool operator != (const IsIterationEnd& marker) { return !isDone(); }

  CXXIterator current;
  CXXIterator stop;
};

struct AddressLess {
  
  bool operator() (const Address& a1, const Address& a2) const {
#ifdef MORE_OPT
    return a1.isLessThan(a2);
#endif
    // this was not efficient:
    int size = a1.getNetSize();
    octet* d1 = new octet[size];
    octet* d2 = new octet[size];
    a1.toNet(d1);
    a2.toNet(d2);
    bool result = memcmp(d1, d2, size) < 0;
    delete [] d1;
    delete [] d2;
    return result;
  }
};


// Access is log(N) here
template<typename Value>
class AddressMap
{
public:
  

  void add(Address address, Value value)
  { data[address] = value; }

  Value* get(Address address)
  {
    typename std::map<Address, Value, AddressLess>::iterator 
      it = data.find(address);
    if (it != data.end())
      return &((*it).second); // XXX!: check isn't ref to temporary
    else return NULL; // not found
  }

  Value get(Address address, Value defaultValue)
  { 
    Value* result = get(address);
    if (result != NULL) 
      return *result;
    else return defaultValue;
  }

  Value* getPtr(Address address, Value* defaultValue)
  { 
    Value* result = get(address);
    if (result != NULL) return result;
    else return defaultValue;
  }

  void erase(Address address)
  { data.erase(address); }

  typedef typename std::map<Address, Value, AddressLess> InternalMap;
  typedef IteratorAdapter< std::pair<Address,Value>, 
			   typename InternalMap::iterator> Iterator;

  Iterator getIter()
  { return Iterator(data.begin(), data.end()); }

protected:
  InternalMap data;
};
extern Address NullAddress;

//---------------------------------------------------------------------------

#endif // _ADDRESS_H
