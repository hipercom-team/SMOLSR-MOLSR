//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             , projet Hipercom, INRIA Rocquencourt
//  Copyright 2003 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#error This file has been obsoleted

#ifndef _OLSR_DAEMON_H
#define _OLSR_DAEMON_H

//---------------------------------------------------------------------------

#include "base.h"

#include <list>
#include "system_network.h"

//---------------------------------------------------------------------------

/// The system configuration. This is very different from the OLSR Protocol
/// configuration (for instance, in a simulator, the OLSR Protocol
/// configuration is still valid, but the configuration file specifying the
/// interfaces is irrelevant).
/// This could include debugging levels, etc...
class SystemConfig
{
public:
  std::list<IfaceInfo*>* olsrIfaceInfoList;
};

//---------------------------------------------------------------------------

/// The main class for the OLSR Daemon, performing most initialisation
/// and magic in "run()". Note that in a simulator, this class isn't used
class OLSRDaemon
{
public:
  /// read the system configuration
  SystemConfig* readSystemConfig(char* fileName);

  /// read the protocol configuration
  ProtocolConfig* readProtocolConfig(char* fileName);

  /// run the daemon
  void run();
};

//---------------------------------------------------------------------------

#endif // _OLSR_DAEMON_H
