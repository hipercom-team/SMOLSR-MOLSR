//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

#include "base.h"
#include "address.h"
#include "packet.h"
#include <sys/socket.h>
#include <scheduler_unix.h>
#include <netinet/in.h> 
#include "network_generic.h"
#include "scheduler_generic.h"
#include "scheduler_unix.h"
#include "mdfp_generic.h"
typedef void* SockoptPointer;
//---------------------------------------------------------------------------
class IOScheduler;
//---------------------------------------------------------------------------

class IUDPCom
{
public:
 
  virtual void open()=0;

  virtual int sendUDPCom(int sd, void* data, int dataSize,
			  sockaddr_in& sendAddr);
  //virtual void _sendUDPCom();

  virtual int recvUDPCom(int sd, void* data, int dataSize,
			 sockaddr_in& recvAddress)
  {
    socklen_t socketSize = sizeof(recvAddress);
    int status = recvfrom(sd, data, dataSize, /*flags*/ 0,
			  (struct sockaddr*)&recvAddress, &socketSize);
    if(status <0) { // XXX: warning
      Warn("error in recvfrom: " << strerror(errno));
      return status;
    } else {
      return status;
    }
  }
  virtual int getSockFd()
  {
    
    int sockFd= socket(PF_INET, SOCK_DGRAM, 0);
    if (sockFd < 0)
      Fatal("Cannot create socket: " << strerror(errno));
    else
      return sockFd;
  }
  virtual void setReuseAddrSock(int sockFd)
  {
    int on = 1;
    if (setsockopt(sockFd, SOL_SOCKET, SO_REUSEADDR, (SockoptPointer)&on, 
		   sizeof(on)) < 0)
      Fatal("Cannot setsockopt SO_REUSEADDR on  socket:" << strerror(errno));
  }
  virtual void bindSock(int sockFd, sockaddr * ipv4Addr)
  {
    if (bind(sockFd, ipv4Addr, sizeof(sockaddr)) <0)
      Fatal("Cannot bind socket: " << strerror(errno));
  }
  virtual void initSockAddr(sockaddr_in *ipv4Addr,unsigned int addr ,int port)
  {
    memset(ipv4Addr,0,sizeof(sockaddr_in));
    ipv4Addr->sin_family = AF_INET;
    ipv4Addr->sin_addr.s_addr = addr;
    ipv4Addr->sin_port = port;
  }
  
  int acceptSocket;
  int sendSocket;
  int portIn;
  int portOut;
  sockaddr_in ipv4AddrIn;
  sockaddr_in ipv4AddrOut; 
};
class LinuxIPv4LowLevel ;

class MDFPCom: public IMDFP, public IUDPCom, public IFdHandler
{
public:
  
  MDFPCom (Node *anode,IScheduler* ascheduler, int aPortIn, int aPortOut):node(anode)
  {portIn=aPortIn; portOut=aPortOut;
  scheduler=dynamic_cast<IOScheduler*>(ascheduler);
  }
  
  virtual ~MDFPCom(){}
 
 
  //IFdHandler methods
  virtual FileDescriptor getFileDescriptor() {return acceptSocket ;}
  virtual bool waitingForInput(){return true;}
  virtual bool waitingForOutput() {return false;}
  virtual bool waitingForExcept() {return false;}
  
  virtual void handleExcept() {Fatal("Impossible handleExcept");}
  
  
  
  virtual void handleOutput() { Fatal("Impossible handleOutput");}
  
  virtual void handleInput() {
    
  
    processRecvMDFPInformation();
  }
  
  //IUDPCom methods
  
  virtual void open()
  {
    initSockAddr(&ipv4AddrIn,htonl(INADDR_LOOPBACK), htons(portIn));
    initSockAddr(&ipv4AddrOut,htonl(INADDR_LOOPBACK), htons(portOut));
    acceptSocket = getSockFd();    
    sendSocket = acceptSocket;//getSockFd();
      setReuseAddrSock(acceptSocket);
      //setReuseAddrSock(sendSocket);
    
    bindSock(acceptSocket, (sockaddr*)&ipv4AddrIn);    
  }
  
  //Own methods
  void start();

 
  void mdfpPackAndSend(Message *midMessage,Message *mcTreeMessage);
  void sendMDFPInformation(MemoryBlock* packet);
  void processRecvMDFPInformation();
  
  void parseMDFPPacket(MemoryBlock *rawPacket, Address stdRecvAddress);
 
  void parseMDFPMessage(Message *message);
protected:
  IOScheduler *scheduler;
  Node *node;
};

