//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
#include "base.h"
#include "address.h"

#include <list>
using std::list;
#include "tuple.h"

//---------------------------------------------------------------------------
class MolsrNode;

//---------------------------------------------------------------------------
#define removeAndDeleteExpiredMacro(mapName,tupleTime) \
TupleIterator it = getIter();\
  while(!it.isDone()) {\
      if (it.getCurrent()->getExpireTime(currentTime) <= currentTime) \
        {\
	  if(it.getCurrent()->tupleTime <=currentTime)\
	    it.removeAndDeleteCurrentAndDoNext();\
	  else{\
		 std::map<Address,Time,AddressLess>::iterator \
		 itMap=it.getCurrent()->mapName.begin();\
	         while(itMap !=it.getCurrent()->mapName.end())\
                   if(itMap->second<=currentTime){\
		     cout <<"Inside the while"<< endl;\
                     std::map<Address,Time,AddressLess>::iterator itMapTemp=itMap;\
                     itMapTemp++; \
                     it.getCurrent()->mapName.erase(itMap);\
	             itMap=itMapTemp;}\
                   else itMap++; \
                 it.next();\
               }\
         } \
       else it.next();\
}


//---------------------------------------------------------------------------
#define getExpireTimeMacro(mapName,tupleTime)\
Time timeValue=tupleTime;\
    for(std::map<Address,Time,AddressLess>::iterator \
	  it=mapName.begin(); it !=mapName.end(); it++)\
      if(it->second<=timeValue)\
	timeValue=it->second;\
    return timeValue; 
//---------------------------------------------------------------------------
class MCTuple : public ITuple
{
public:
  Address MT_source_addr;
  Address MT_group_addr;
  Address MT_parent_addr;
  // add a reference to the iface to use for example Iface* iface;
  Time    MT_source_time;
  std::map<Address,Time,AddressLess> MT_list_sons;
  // This function returns the minimum timeOut between the source and
  // the list of the sons
  virtual Time getExpireTime(Time currentTime) { 
    getExpireTimeMacro(MT_list_sons,MT_source_time);   
  } 
// This entry must be deleted if the parent is no more reachable, or the source has disappeared from the routing table
  virtual void update() { /* nothing to do (XXX: check this) */ }
  virtual ~MCTuple() {}
  
};

class MCTreeSet : public BasicTupleSet<MCTuple>  //or OptimizedBasicTupleSet
{
public:
  MCTreeSet(MolsrNode* aNode) : node(aNode) { }
  
  virtual void write(std::ostream& out);
 

 virtual void removeAndDeleteExpired(Time currentTime){
    removeAndDeleteExpiredMacro(MT_list_sons,MT_source_time);
 }

 MCTuple* findFirst(Address group)
  {
    Search(MCTuple,
	   (current->MT_group_addr == group));
  }

  MCTuple* findFirst(Address source,Address group)
  {
    Search(MCTuple,
	   (current->MT_source_addr == source)
		    && (current->MT_group_addr == group));
  }


  MCTuple* findFirst(Address source,Address group, Address parent)
  {
    Search(MCTuple,
	   (current->MT_source_addr == source)
		    && (current->MT_group_addr == group)
	            && (current->MT_parent_addr == parent));
  }
  // Son* findSon(MCTuple* mcTuple,Address sonAddress)
  //{return NULL;}
 
protected:
  virtual void notifyRemoval(MCTuple* tuple) { }
  virtual void notifyAddition(MCTuple* tuple) { }
 MolsrNode* node;
  
};


//---------------------------------------------------------------------------


class MCLocal : public ITuple
{
public:
  Address L_source_addr;
  std::map<Address,Time,AddressLess> L_group_n_timeout;
  Time L_time_out;   // This time out  is checked

  virtual Time getExpireTime(Time currentTime) { 
    getExpireTimeMacro(L_group_n_timeout,L_time_out);
 } //This  entry must be deleted if  the time out expires. i.e the local node is not sending multicast data anymore!!  this can be detected if the multicast socket is closed, or the timeout has expired since the last multicast packet sent by this source

  virtual void update() { /* nothing to do (XXX: check this) */ }
  //update the timeout  if the source is still sending multicast data  
  virtual ~MCLocal() {}
};


class MCLocalSet : public BasicTupleSet<MCLocal> //or OptimizedBasicTupleSet
{
public:
  
  MCLocalSet(MolsrNode* aNode) : node(aNode) { }

  virtual void write(std::ostream& out);


  virtual void removeAndDeleteExpired(Time currentTime){
     removeAndDeleteExpiredMacro(L_group_n_timeout,L_time_out);
  }

  MCLocal* findFirst(Address source)
  {

     Search(MCLocal,
	   (current->L_source_addr == source));
    
  }

  MCLocal* findFirst(Address source,Address group);
  bool addSourceClientEntry(Address localClientAddress, Address groupAddress, Time timeOut);
  bool deleteSourceClientEntry(Address localClientAddress, Address groupAddress);
 
protected:
  MolsrNode* node;
   virtual void notifyRemoval(MCLocal* tuple) { }

  virtual void notifyAddition(MCLocal* tuple) { } 
};

//---------------------------------------------------------------------------
template class BasicTupleSet<MCLocal>;
template class BasicTupleSet<MCTuple>;

template class BasicTupleSetIterator<MCLocal>;
template class BasicTupleSetIterator<MCTuple>;
