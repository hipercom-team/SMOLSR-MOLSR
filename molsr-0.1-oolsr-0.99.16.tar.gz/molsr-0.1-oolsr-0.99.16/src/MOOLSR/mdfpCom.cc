//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
#include "base.h"
#include "mdfpCom.h"
#include "scheduler_generic.h"
#include "scheduler_unix.h"
#include "node.h"
#include "system_linux.h"
#include "system_linux_ipv4.h"
#include "packet.h"
#include "molsrNode.h"


//---------------------------------------------------------------------------


int IUDPCom::sendUDPCom(int sd, void* data, int dataSize,
			 sockaddr_in& sendAddr)
{
  if(sendto(sd, data, dataSize, 0, (sockaddr*)&sendAddr,sizeof(sendAddr)) <0)
    Warn(" sendto: " << strerror(errno) );// XXX: not fatal
  return 1;
}



//---------------------------------------------------------------------------
void MDFPCom::mdfpPackAndSend(Message* midMessage, Message* mcTreeMessage)
{
  PacketBuffer buffer ;
  int maximumMessageSize=32000;
  MemoryBlock* newBlock=NULL;
  IMessageContent* newMessageContent = NULL;

  buffer.pushUInt16(0); //the MDFP Header packet
  buffer.pushUInt16(0); 
  //  int initialPos = buffer.getPosition();
  midMessage->content->header = midMessage;
  //Packing MID message
  assert(midMessage->content != NULL);
  assert(midMessage->packedContent == NULL);

  //XXXXXXX
  //PacketManager* pM=node->getPacketManager();
  //XXXXXXX
  IMessageHandler* handler = (node->getPacketManager())->getMessageHandler(midMessage->messageType);
  assert(handler != NULL);

  
  handler->packMessageContent(midMessage->content, maximumMessageSize,
  			      newBlock, newMessageContent);
  

  buffer.packBlock(newBlock);
  //Packing MCTree Message
  if(mcTreeMessage)
    {
      mcTreeMessage->content->header = mcTreeMessage;
      assert(mcTreeMessage->content != NULL);
      assert(mcTreeMessage->packedContent == NULL);
      handler = (node->getPacketManager())->getMessageHandler(mcTreeMessage->messageType);
      assert(handler != NULL);
      
      handler->packMessageContent(mcTreeMessage->content, maximumMessageSize,
				  newBlock, newMessageContent);


      buffer.packBlock(newBlock);
    }

  buffer.rewind();
  
  int size = buffer.size();
  buffer.pushUInt16(size);
  buffer.rewind();
  MemoryBlock* packet = buffer.popBlock(buffer.size());
  
  sendMDFPInformation(packet);
}
//---------------------------------------------------------------------------
void MDFPCom::sendMDFPInformation(MemoryBlock* packet)
{

  sendUDPCom(sendSocket, packet->data, packet->size,ipv4AddrOut);
  
  delete packet; // XXX: check memory is freed
}

//---------------------------------------------------------------------------
void MDFPCom::processRecvMDFPInformation()
{
  
  
  
  octet buffer[65536]; // XXX: not inline
  sockaddr_in  recvAddress;
  
  int maxSize = sizeof(buffer);
  int status=recvUDPCom(acceptSocket, buffer, maxSize, recvAddress);
  
  if(status > 0) 
    { // XXX: what if == 0, closed?
      // buffer[status]='\0';
      //cout << " les data : " << buffer << endl;
      MemoryBlock* packet = NULL;
      
      LinuxAddressFactory<LinuxIPv4LowLevel>* addressFactory;
      addressFactory=dynamic_cast<LinuxAddressFactory<LinuxIPv4LowLevel>*>(node->getAddressFactory());
      Address stdRecvAddress = addressFactory->makeAddress(recvAddress);
      
      
      packet = new MemoryBlock(buffer, status, true);
      //processMDFPPacket(packet, stdRecvAddress);
      parseMDFPPacket(packet, stdRecvAddress);
      //delete packet;
      
    }
}
//---------------------------------------------------------------------------
void MDFPCom::parseMDFPPacket(MemoryBlock *rawPacket, Address stdRecvAddress)
{
  PacketBuffer packet(*rawPacket, node->getAddressFactory());
  delete rawPacket; rawPacket = NULL;
  std::list<Message*> messageList;
  int packetSequenceNumber;
  node->getPacketManager()->parsePacket(packet, messageList, packetSequenceNumber,
		stdRecvAddress, NullAddress); 
  
   
    for(std::list<Message*>::iterator it=messageList.begin();
	it!=messageList.end();it++) 
      {
	Message* message = *it;
	parseMDFPMessage(message);
	
      }
    //XXX we should put the try catch here again
    for(std::list<Message*>::iterator it = messageList.begin();
	it!=messageList.end();it++)
      delete (*it);
    return;
}

//---------------------------------------------------------------------------
void MDFPCom::parseMDFPMessage(Message *message)
{
  IMessageHandler* handler =node->getPacketManager()->getMessageHandler(message->messageType);

  if (handler != NULL) 
    {
      handler->processMessage(message);
    }
  
  //delete message;
}
//---------------------------------------------------------------------------
void MDFPCom::start()
{
  open();
  scheduler->addFdHandler(this, NULL); 
}
//---------------------------------------------------------------------------
