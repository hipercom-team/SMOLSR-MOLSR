//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Adokoe Plakoo, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//     $Id: node_link_monitoring.cc,v 1.16 2005/07/01 14:16:39 plakoo Exp $
//---------------------------------------------------------------------------
// This file implements the link monitoring to enhance the robustness
// of the link sensing mechanism
//---------------------------------------------------------------------------

#include "node.h"

void HeardIfaceTuple::updateExpireTime(Time currentTime)
{
  H_time = currentTime + node->getHeardIfaceExpireTime();
}


bool HeardIfaceTuple::getLinkPending()
{
  bool result = true;

  if (node->getProtocolConfig()->useSignalMonitoring && 
      node->getProtocolConfig()->useHysteresisMonitoring)

    result = ( (H_signalMonitoringInfo.linkPending == false) && 
               (H_hysteresisMonitoringInfo.linkPending == false) ) ?
             false : true;

  else 
    if (!node->getProtocolConfig()->useSignalMonitoring)

      result = H_hysteresisMonitoringInfo.linkPending;

    else
      if (!node->getProtocolConfig()->useHysteresisMonitoring)

	result = H_signalMonitoringInfo.linkPending;

  return result;
}

//-----------------------------------------------------------------------------

Time HeardIfaceTuple::getLostTime()
{

  if (node->getProtocolConfig()->useSignalMonitoring && 
      node->getProtocolConfig()->useHysteresisMonitoring)
    {
      if ( getLinkPending() )
	return myMax(H_signalMonitoringInfo.lostTime,
		     H_hysteresisMonitoringInfo.lostTime);
      else 
	return myMin(H_signalMonitoringInfo.lostTime,
		     H_hysteresisMonitoringInfo.lostTime);
    }
  else
    return node->getProtocolConfig()->useSignalMonitoring ?
      H_signalMonitoringInfo.lostTime : H_hysteresisMonitoringInfo.lostTime;

}

//-----------------------------------------------------------------------------

void HeardIfaceTuple::
setLinkQualityByHysteresis(int currentPacketSequenceNumber)
{

  double hysteresisScaling = node->getHysteresisScaling();

#define InstabilityRule(quality) \
 ( 1 - node->getHysteresisScaling() ) * quality

#define StabilityRule(quality) \
 ( 1 - node->getHysteresisScaling() ) * quality + hysteresisScaling

  if (H_hysteresisMonitoringInfo.linkQuality == 0) /* Initialization */
    H_hysteresisMonitoringInfo.linkQuality = hysteresisScaling;

  /* Packet Sequence Number wraparound case */
  if ( currentPacketSequenceNumber < H_last_packetSequenceNumber &&
       (_ansnGreater(currentPacketSequenceNumber, H_last_packetSequenceNumber))
     )
    {
      if ( (H_last_packetSequenceNumber != MaxPacketSequenceNumber - 1) || 
	   (currentPacketSequenceNumber != 0) )
	{
	  int nb_lost = MaxPacketSequenceNumber - 1 \
	    - H_last_packetSequenceNumber + currentPacketSequenceNumber;
	  
	  while (nb_lost)
	    { 
	      H_hysteresisMonitoringInfo.linkQuality = 
		InstabilityRule(H_hysteresisMonitoringInfo.linkQuality);
	      nb_lost--;
	    }
	}

	H_hysteresisMonitoringInfo.linkQuality = 
	  StabilityRule(H_hysteresisMonitoringInfo.linkQuality);
    }
  else 
    {
      if (currentPacketSequenceNumber > H_last_packetSequenceNumber) 
	{
	  if (currentPacketSequenceNumber != H_last_packetSequenceNumber + 1)
	    {
	      int nb_lost = currentPacketSequenceNumber - \
		H_last_packetSequenceNumber - 1;
	      
	      while (nb_lost > 0)
		{ 
		  H_hysteresisMonitoringInfo.linkQuality =
		    InstabilityRule(H_hysteresisMonitoringInfo.linkQuality);
		  nb_lost--;
		}
	    }
	  
	  H_hysteresisMonitoringInfo.linkQuality = 
	    StabilityRule(H_hysteresisMonitoringInfo.linkQuality);

	}
      else // The node probably restarted.
	if ( (H_last_packetSequenceNumber != currentPacketSequenceNumber) )
	  // If the link entry did not expire before the node restarted, 
	  // re-init these fields.
	  {
	    H_hysteresisMonitoringInfo.linkQuality = hysteresisScaling;
	    H_last_packetSequenceNumber = -1;
	  }
    }
}

//-----------------------------------------------------------------------------

void HeardIfaceTuple::setLinkPending(MonitoringInfo& aMonitoringInfo, 
				     double highThreshold, double lowThreshold)
{
  Time currentTime = node->getCurrentTime();

  if ( aMonitoringInfo.linkQuality > highThreshold ) 
    {
      aMonitoringInfo.linkPending = false; 
      aMonitoringInfo.lostTime = currentTime - 1; 
      aMonitoringInfo.stateChanged = true;
    } 
  
  if ( aMonitoringInfo.linkQuality < lowThreshold ) 
    {
      aMonitoringInfo.linkPending = true; 
      aMonitoringInfo.lostTime = aMonitoringInfo.lostTime 
	+ node->getProtocolConfig()->NEIGHB_HOLD_TIME; 
      aMonitoringInfo.stateChanged = true;
    }  
}

//-----------------------------------------------------------------------------

void HeardIfaceTuple::setLinkQuality(int currentPacketSequenceNumber, int signal)
{

  if (currentPacketSequenceNumber > -1)
    {
      if (node->getProtocolConfig()->useHysteresisMonitoring) 
	{
	  setLinkQualityByHysteresis(currentPacketSequenceNumber);
	  setLinkPending(H_hysteresisMonitoringInfo,
			 node->getHysteresisThresholdHigh(),
			 node->getHysteresisThresholdLow());
	}
    }
  else
    if (node->getProtocolConfig()->useSignalMonitoring) 
      {
	H_signalMonitoringInfo.linkQuality = signal;
	setLinkPending(H_signalMonitoringInfo,
		       node->getSignalThresholdHigh(),
		       node->getSignalThresholdLow());
      }

  if (currentPacketSequenceNumber > -1)
    if ( _ansnGreater(currentPacketSequenceNumber,
		      H_last_packetSequenceNumber) )
      H_last_packetSequenceNumber = currentPacketSequenceNumber;

  if (H_hysteresisMonitoringInfo.stateChanged ||
      H_signalMonitoringInfo.stateChanged) 
    {
      updateAssociatedLinkTuple();
      H_hysteresisMonitoringInfo.stateChanged = false;
      H_signalMonitoringInfo.stateChanged = false;
    }
}

//-----------------------------------------------------------------------------

void HeardIfaceTuple::updateAssociatedLinkTuple()
{
  LinkTuple* linkTuple = 
    node->linkSet.findFirst_SendAndReceiveIfaceAddress(H_remote_iface_addr,
						       H_local_iface_addr);
  
  if (linkTuple) linkTuple->updateWithLinkMonitoring(this);
}

//---------------------------------------------------------------------------

void HeardIfaceTuple::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();
  out << H_remote_iface_addr << "@" << H_local_iface_addr;
  out << " #" << H_last_packetSequenceNumber;

  out << " s(" << H_signalMonitoringInfo.linkQuality;
  out << "," << (H_signalMonitoringInfo.linkPending ? "pending," : "");
  writeExpireTime(out, currentTime, H_signalMonitoringInfo.lostTime);
  out << ")";

  out << " q(" << H_hysteresisMonitoringInfo.linkQuality;
  out << "," << (H_hysteresisMonitoringInfo.linkPending ? "pending," : "");
  writeExpireTime(out, currentTime, H_hysteresisMonitoringInfo.lostTime);
  out << ")";
}

//---------------------------------------------------------------------------

void HeardIfaceSet::write(ostream& out)
{
  bool isFirst = true;
  for(HeardIfaceSet::TupleIterator it = getIter(); !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    HeardIfaceTuple* l = it.getCurrent();
    l->write(out);
  }
}

//---------------------------------------------------------------------------
