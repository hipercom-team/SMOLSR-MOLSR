#! /bin/sh



if [ "$2" = "" ] ; then
  exit 1
fi

for i in *.cc ; do
  cp $i /tmp/$i && sed s/$1/$2/g < /tmp/$i > $i
done

(cd ../include &&
for i in *.h ; do
  cp $i /tmp/$i && sed s/$1/$2/g < /tmp/$i > $i
done
)
