//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include <sys/time.h>
#include <stdio.h>

#include "general.h"

//---------------------------------------------------------------------------

 /// Draw a random number (double) between 0 (incl.) and maxValue (excl.)
double drawDouble(double maxValue)
{ return drand48()*maxValue; }

double getTimeOfDay()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec/1e6;
}

//---------------------------------------------------------------------------
