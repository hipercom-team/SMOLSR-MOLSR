//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// with some parts from olsrdv7, olsr_python_extension.py
//---------------------------------------------------------------------------

#include <list>
#include <string>
using std::list;
using std::string;

#include "http_support.h"
#include "node.h"

//---------------------------------------------------------------------------

typedef pair<string,string> StringPair;

string strReplace(string data, string before, string after);


string HTMLReplyHeader =
"<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n"
"<html>\n"
"\n"
"<head><title>@<TITLE>@</title></head>\n"
"\n"
"<!-- Layout from http://www.python.org/ page, which comes from ht2html -->\n"
"<body bgcolor=\"#@<BGCOLOR>@\" text=\"#000000\"\n"
"      marginwidth=\"0\" marginheight=\"0\"\n"
"      link=\"#008800\"  vlink=\"#11401a\"\n"
"      alink=\"#ff0000\">\n"
"\n"
"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n"
"<!-- start of banner row -->\n"
"<tr>\n"
"<!-- start of corner cells -->\n"
"<td width=\"150\" valign=\"middle\" bgcolor=\"#003366\">\n"
"<center>\n"
"<a href=\"./\">\n"
"@<CORNER>@\n" // <- the html in the corner
"</a></center></td>\n"
"<td width=\"15\" bgcolor=\"#99ccff\">&nbsp;&nbsp;</td><!--spacer-->\n"
"<!-- end of corner cells -->\n"
"\n"
"<!-- start of banner -->\n"
"<td width=\"90%\" bgcolor=\"#99ccff\">\n"
"<!-- start of site links table -->\n"
"<table width=\"100%\" border=\"0\"\n"
"cellspacing=\"0\" cellpadding=\"0\"\n"
"       bgcolor=\"#ffffff\">\n"
"<tr>\n"
"@<BANNERLINKLIST>@\n" // <- the html in the banner
"</tr>\n"
"</table><!-- end of site links table -->\n"
"</td><!-- end of banner -->\n"
"</tr><!-- end of banner row -->\n"
"<tr><!-- start of sidebar/body row -->\n"
"\n"
"<!-- start of sidebar cells -->\n"
"<td width=\"150\" valign=\"top\" bgcolor=\"#99ccff\">\n"
"<!-- start of sidebar table -->\n"
"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\"\n"
"       bgcolor=\"#ffffff\">\n"
"@<SIDELINKLIST>@\n" // <- the html on the side
"\n"
"\n"
"</table><!-- end of sidebar table -->\n"
"\n"
"</td>\n"
"<td width=\"15\">&nbsp;&nbsp;</td><!--spacer-->\n"
"<!-- end of sidebar cell -->\n"
"<!-- start of body cell -->\n"
"<td valign=\"top\" width=\"90%\"><br>\n";

string HTMLBannerLink = 
"<td bgcolor=\"#99ccff\" align=\"center\">\n"
"@<DATA>@\n"
"</td>\n";

string HTTPMovedReply = 
"HTTP/1.0 302 Moved Temporarily\n"
"Location: %s\n"
"Content-Type: text/html\n"
"\n"
"<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n"
"<HTML><HEAD>\n"
"<TITLE>302 Moved Temporarily</TITLE>\n"
"</HEAD><BODY>\n"
"<H1>Moved Temporarily</H1>\n"
"The document has moved <A HREF=\"@<LOCATION>@\">here</A>.<P>\n"
"</BODY></HTML>\n";

string HTMLSideTitle = 
"<tr><td bgcolor=\"#003366\"><b><font color=\"#ffffff\">\n"
"@<DATA>@\n"
"</font></b></td></tr>\n";

string HTMLSideLink = 
"<tr><td bgcolor=\"#99ccff\">\n"
"@<DATA>@\n"
"</td></tr>\n";

string HTMLLogoImg
  = "<img src=\"/serve/mprlogo4.png\" border=\"0\">";
string HTMLBannerImg
  = "<img src=\"/serve/oolsrd-plain2.png\" border=\"0\">";
string HTMLRouteDescrImg
  = "<img src=\"/serve/Route-descr.png\" text=\"\" border=\"0\">";

string HTTPReplyHeader = 
  "HTTP/1.1 200 OK\nContent-Type: text/html\r\n\r\n";

string HTTPReplyTemplate = 
  "HTTP/1.1 200 OK\nContent-Type: @<ACTUALTYPE>@\r\n\r\n";

static string TableBGColor = "#99ccff";

static string CREDITS = 
"<h1>Credits</h1> \n"
"<h2>Developers</h2> <ul>\n"
"<li>C&eacute;dric Adjih</li>\n"
"<li>Marc Badel</li>\n"
"<li>Nicolas Grzeskowiak</li>\n"
"<li>Anis Laouiti</li>\n"
"<li>Paul Muhlethaler</li>\n"
"<li>Adokoe Plakoo</li>\n"
"<li>Yasser Toor</li>\n"
"</ul>\n"
"<h2>Contributors</h2>\n<ul>\n"
"<li>G&eacute;raud Allard</li>\n"
"<li>Saadi Boudjit</li>\n"
"<li>Dang Quan Nguyen</li>\n"
"</ul>\n"
"<h2>Support</h2>\n<ul>\n"
"<li>Philippe Jacquet</li>\n"
"</ul>\n"
;


string htmlReprTuple(list<string>& fieldList, bool inHeader = false)
{
  string start, stop;;
  if (inHeader) {
    start = "<th>";
    stop = "</th>";
  } else { 
    start = "<td bgcolor=\"#ffffff\" align=\"center\">";
    stop = "</td>";
  }
  string result = "";
  for (std::list<std::string>::iterator it = fieldList.begin(); it != fieldList.end();
       it++) {
    result += start+ (*it) + stop;
  }
  return result+"\n";
}

string reprTableToHTMLTable(string tableName, Node* node)
{
  //string result = "<h1>Table '%s'</h1>\n" % tableName
  string result = "";
  if (tableName == "Route") 
    result += "<center>" + HTMLRouteDescrImg + "</center>";

  result += "<table border=\"1\" bgcolor=\"" + TableBGColor 
    +"\" width=\"100%%\">\n";

  vector<vector<string>*>* infoList = node->getTableContent(tableName);
  if (infoList == NULL)
    return ""; // The table doesn't exist

  if (!infoList->empty()) {
    vector< string >* content = (*infoList)[0];
    ostringstream tmp; 
    tmp << (content->size());
    result += "<tr><th bgcolor=\"#003366\" fgcolor=\"#ffffff\" colspan=\""
      + tmp.str() + "\"><font color=\"#ffffff\">"
      + tableName + "</font></tr>\n";
    list<string> headerNameList;
    for (std::vector<string>::iterator it = content->begin();
	 it != content->end(); it++)
      headerNameList.push_back((*it));
    content = NULL;

    result += "<tr>"+htmlReprTuple(headerNameList, true)+"</tr>\n";

    std::vector<vector<string>*>::iterator it = infoList->begin();
    it++;
    for (;it != infoList->end(); it++) {
      vector< string >* content = (*it);
      list<string> fieldNameList;
      for (std::vector<string>::iterator it = content->begin();
	   it != content->end(); it++)
	fieldNameList.push_back((*it));
      result += "<tr>"+htmlReprTuple(fieldNameList, false)+"</tr>\n";
      delete content;
    }
    
  } else {

    result += "<tr><th bgcolor=\"#003366\" fgcolor=\"#ffffff\" colspan=\"1"
      "\"><font color=\"#ffffff\">"
      + tableName + "</font></tr>\n";
    result += "<tr><td>-</td></tr>";
  }
  delete infoList;
  result += "</table>\n";
  return result;
}

string fixColor(string data)
{
  string result = data;
  string::size_type pos = 0;
  string pattern = "color=\"#";
  for (;;) {
    pos = result.find(pattern, pos);
    if (pos == string::npos)
      return result;
    pos += pattern.length();
    char tmp1 = result[pos+2];
    char tmp2 = result[pos+3];
    result[pos+2] = result[pos+4];
    result[pos+3] = result[pos+5];
    result[pos+4] = tmp1;
    result[pos+5] = tmp2;
  }
}


string sideTitle(string text)
{ return strReplace(HTMLSideTitle, "@<DATA>@", text); }

string sideLink(string text)
{ return strReplace(HTMLSideLink, "@<DATA>@", text); }

string getHTMLReplyHeader(Node* node, 
			  string title = "OOLSR Daemon management",
			  string color = "ffffff")
{
  vector<string>* tableListPtr = node->getTableNameList();
  vector<string>& tableList = *tableListPtr;
  string tmp0
    = strReplace(HTMLReplyHeader, 
		 "@<BANNERLINKLIST>@",
		 strReplace(HTMLBannerLink,
			    "@<DATA>@",
			    HTMLBannerImg));
  string tmp1 = strReplace(strReplace(tmp0, "@<TITLE>@", title),
			   "@<BGCOLOR>@", color);
  string side = 
    sideLink("<a href=\"/\">Main</a>")
    +sideTitle("Tables");
  
#if 0
  side +=
    sideLink("<a href=\"/internal/table/neighbor.html\">Neighbor</a>")
    +sideLink("<a href=\"/internal/table/topology.html\">Topology</a>")
    +sideLink("<a href=\"/internal/table/neighbor2.html\">Two hops</a>")
    +sideLink("<a href=\"/internal/table/route.html\">Route</a>")
    +sideLink("<a href=\"/internal/table/mpr.html\">MPR&amp;MPRS</a>")
    +sideLink("<a href=\"/internal/table/mid.html\">MID</a>")
    +sideLink("<a href=\"/internal/table/gateway.html\">Gateway</a>");
#endif
  
  for (std::vector<string>::iterator it = tableList.begin(); 
       it != tableList.end(); it++) {
    side += sideLink("<a href=\"/internal/table/"
		     + (*it) + ".html\">"+ (*it) + "</a>");
  }

  side +=
    sideLink("<a href=\"/internal/table/all.html\">All</a>")    
    +sideTitle("Internals")
    +sideLink("<a href=\"/action/reset-stat\">Reset stat.</a>")
    //#+sideLink("<a href="/info/config">Config</a>")
    //+sideLink("<a href=\"/info/system\">System</a>")
    //+sideLink("<a href=\"/action/TestAuth\">Test Auth: 'admin'/'o'</a>")
    //#+sideLink("<a href=\"/info/table\">Raw tables</a>")
    //+sideLink("<a href=\"/info/exception\">Exceptions</a>")
    //#+sideTitle(\"Command\")
    //#+sideLink("<a href=\"/restart\">Restart</a>")
#if 0
    +sideTitle("Management")
    +sideLink("<a href=\"/internal/stat\">Stat</a>")    
    +sideLink("<a href=\"/internal/clock\">Clock</a>")
    +sideLink("<a href=\"/internal/capture\">Capture</a>")
    +sideLink("<a href=\"/internal/report\">Reporting</a>")
    +sideLink("<a href=\"/internal/attach\">Attachment</a>")
#endif
    +sideTitle("External links")
    +sideLink("<a href=\"http://hipercom.inria.fr/olsr/\">"
	      "OLSR Page</a>")
    +sideLink("<a href=\"http://hipercom.inria.fr/OOLSR/\">OOLSR Page</a>");
#if 0
    +sideLink("<a href=\"http://www.acme.com/software/thttpd/thttpd.html\">"
	      "thttpd page</a>");
#endif	
      
  string tmp2 = strReplace(tmp1, "@<SIDELINKLIST>@", side);
  string tmp3 = strReplace(tmp2, "@<CORNER>@", HTMLLogoImg);
  delete tableListPtr;
  return tmp3;
}

// Return empty string if the tableName doesn't exist
string getTableAsHTML(Node* node, string tableName)
{
  if (tableName == "all") {
    string result = ""; 
    vector<string>* tableList = node->getTableNameList();
    for (std::vector<string>::iterator it = tableList->begin();
	 it != tableList->end(); it++)
      result += "<h1>" + (*it) + "</h1>\n" + reprTableToHTMLTable(*it, node);
    delete tableList;
    return result;
  } else {
    return reprTableToHTMLTable(tableName, node);
  }
}

//---------------------------------------------------------------------------

bool parseAuthError(string data, string& error, string message)
{
  error = "HTTP Authentication data error: ";
  error += message;
  error += " in: '";
  error += data;
  error += "'";
  return false;
}

class HTTPAuthHeader
{
public:
  string username;
  string realm;
  string nonce;
  string uri;
  string response;
  string algorithm; //-- only md5 or md5-sess is supported
  string cnonce;
  string opaque;
  string qop;
  string nonceCount;
  bool stale;
};

// This is according to RFC 2617, more or less (section 3.2.2)
// Note: XXX: this doesn't parse the "quoted-string" correctly
// but I hope ",", and "\"" will not be included in quoted-string
bool parseAuthHeader(string data, string& error, HTTPAuthHeader& result)
{
  string impossibleStr = "\"=,<IMPOSSIBLE 32234>"; // used to mark field
  // which were not set.
  result.username = impossibleStr;
  result.realm = impossibleStr;
  result.nonce = impossibleStr;
  result.uri = impossibleStr;
  result.response = impossibleStr;
  result.algorithm = "md5";
  result.cnonce = "";
  result.opaque = "";
  result.qop = "";
  result.nonceCount = "";
  result.stale = false;

  error = "";
  if (!stringStartsWith(data, "Digest"))
    return parseAuthError(data, error,
			  "authentication data doesn't start with 'Digest'");
  string current = data;
  current.erase(0, strlen("Digest"));
  string tmp1 = strReplace(current, "\t", " ");
  vector<string> tokenTable = stringSplit(tmp1, ",");
  for (unsigned int i=0; i<tokenTable.size(); i++) {
    string token = tokenTable[i];
    vector<string> tokenElement; // = stringSplit(token, "=");
    string::size_type pos = token.find("=");
    if (pos > 0) {
      tokenElement.push_back( token.substr(0, pos) );
      tokenElement.push_back( token.substr(pos+1, token.length()-(pos+1)) );
    } else {
      //if (tokenElement.size() != 2)
      return parseAuthError(data, error,
			    "token isn't <name>=<value>: '" + token +"'");
    }
    string name = stringStrip(tokenElement[0], " \t");
    string value = stringStrip(stringStrip(tokenElement[1], " \t"), "\"");

    if (name == "username") result.username = value;
    else if (name == "realm") result.realm = value;
    else if (name == "nonce") result.nonce = value;
    else if (name == "response") result.response = value;
    else if (name == "algorithm") {
      value = stringLower(value);
      if (value != "md5" && value != "md5-sess")
	return parseAuthError(data, error, "unknown algorithm '"+value);
      result.algorithm = value;
    } else if (name == "cnonce") result.cnonce = value;
    else if (name == "opaque") result.opaque = value;
    else if (name == "qop") result.qop = stringLower(value);
    else if (name == "nc") result.nonceCount = value;
    else if (name == "uri") result.uri = value;
    else if (name == "stale") {
      value = stringLower(value);
      if (value != "true" && value != "false") {
	return parseAuthError(data, error,
	 "Authentication data syntax problem, token 'stale' is neither"
			      " 'true' nor 'false'");
      }
      result.stale = (value == "true");
    } else { /* do nothing */ }
  }

  if (result.username == impossibleStr)
    return parseAuthError(data, error, "no field 'username'");
  else if (result.realm == impossibleStr)
    return parseAuthError(data, error, "no field 'realm'");
  else if (result.nonce == impossibleStr)
    return parseAuthError(data, error, "no field 'nonce'");
  else if (result.uri == impossibleStr)
    return parseAuthError(data, error, "no field 'uri'");
  else if (result.response == impossibleStr)
    return parseAuthError(data, error, "no field 'response'");

  if (result.response.length() != 32) 
    return parseAuthError(data, error, "'response' isn't a 32LHEX");
  
  if (result.nonceCount.length() != 8)
    return parseAuthError(data, error, "'nc' isn't a 8LHEX");

  return true;
}

// See: DigestCalcHA1(...) in RFC 2617
string computeAuthDigestHA1(HTTPAuthHeader& info, string password)
{
  string data = info.username + ":" + info.realm + ":" + password;
  if (info.algorithm == "md5-sess") {
    string tmpData = getHexMD5(data); // RFC2617 code does: 'getMD5(data)' here
                                      // instead, which is WRONG.
    tmpData += ":" + info.nonce + ":" + info.cnonce;
    return getHexMD5(tmpData);
  } else return getHexMD5(data);
}

// See: DigestCalcResponse(...) in RFC 2617
string computeAuthDigest(HTTPAuthHeader& info, string method, string ha1HexStr)
{
  string data = method + 
    ":" + info.uri;
  if (info.qop == "auth-int") {
    data += ":" + string("XXX - not supported! should be H(entity body)");
  }
  string ha2HexStr = getHexMD5(data);  
  string response = ha1HexStr + ":" + info.nonce + ":";
  if (info.qop != "") {
    response += info.nonceCount + ":" + info.cnonce + ":" + info.qop + ":";
  }
  response += ha2HexStr;
  return getHexMD5(response);
}

string makeHTMLErrorTemplate(Node* node)
{
  string htmlErrorTemplate = 
    getHTMLReplyHeader(node, "%d %s", "cc9999")
    + "<H2>%d %s</H2>";
  return fixColor(htmlErrorTemplate);
}

//---------------------------------------------------------------------------

class ProtocolHTTPVisitor : public IHTTPConnectionVisitor
{
public:
  ProtocolHTTPVisitor(Node* aNode) : node(aNode) {}

  virtual void visit(IHTTPConnection* connection)
  {
    string url = connection->getURL();
    if (url == "/")
      serveIndex(connection);
    else if (url == "/credits.html")
      serveCredits(connection);
    else if (stringStartsWith(url, "/internal/table/"))
      serveTable(connection);
    else if (stringStartsWith(url, "/action/"))
      serveAction(connection);
    else if (stringStartsWith(url, "/serve/")) {
      if (!serveInlineFile(connection))
	connection->serveFile();
    } else connection->send404Error();
  }

  bool serveInlineFile(IHTTPConnection* connection)
  {
    extern int wwwInlineFileCount;
    extern int wwwInlineFileSize[];
    extern unsigned char* wwwInlineFileData[];
    extern char* wwwInlineFileName[];

    if (!stringStartsWith(connection->getURL().c_str(), "/serve/"))
      return false;

    string fileName = connection->getURL();
    fileName.erase(0, strlen("/serve/"));
    for (int i=0; i<wwwInlineFileCount;i++) {
      if (fileName == wwwInlineFileName[i]) {
	string type = "application/octet-stream";
	if (stringEndsWith(fileName, ".htm")) type = "text/html";
	else if (stringEndsWith(fileName, ".html")) type = "text/html";
	else if (stringEndsWith(fileName, ".gif")) type = "image/gif";
	else if (stringEndsWith(fileName, ".png")) type = "image/png";
	else if (stringEndsWith(fileName, ".jpg")) type = "image/jpg";
	string output = strReplace(HTTPReplyTemplate, "@<ACTUALTYPE>@", type);
	string moreOutput ((char*)wwwInlineFileData[i], wwwInlineFileSize[i]);
	connection->write(output + moreOutput);
	connection->close();
	return true;
      }
    }
    return false;
  }

  void serveTable(IHTTPConnection* connection)
  {
    string url = connection->getURL();
    string tableName = strReplace(url, "/internal/table/", "");
    tableName = strReplace(tableName, ".html", "");
    string tableHTML = getTableAsHTML(node, tableName);
    if (tableHTML == "") 
      connection->send404Error();
    else {
      string output = HTTPReplyHeader +
	getHTMLReplyHeader(node) + tableHTML;
      connection->write(fixColor(output));
      connection->close();      
    }
  }

  void serveIndex(IHTTPConnection* connection)
  {
    string output = HTTPReplyHeader +
      getHTMLReplyHeader(node) + "<h1>OOLSR Daemon HTTP interface</h1>\n";
    connection->write( fixColor(output) );
    connection->close();
  }

  void serveCredits(IHTTPConnection* connection)
  {
    string output = HTTPReplyHeader +
      getHTMLReplyHeader(node) + CREDITS;
    connection->write( fixColor(output) );
    connection->close();
  }

  void serveAction(IHTTPConnection* connection)
  {
    string output = HTTPReplyHeader +
      getHTMLReplyHeader(node) + "<h1>ACTION</h1>";

#define AUTH "WWW-Authenticate: Digest realm=\"admin\",nonce=\"astupidnonceyoubet\",opaque=\"isthisopaqueforsure\",stale=false,algorithm=MD5-sess,qop=\"auth\""

    string url = connection->getURL();
    string actionName = strReplace(url, "/action/", "");

#ifdef WITH_STAT
    if (actionName == "reset-stat") {
      node->resetStatistic();
      serveIndex(connection);
      return;
    } else if (actionName == "exit") {
      serveIndex(connection);
      exit(EXIT_SUCCESS);
    }
#endif

    string authInfo = connection->getAuthentication();
    if (authInfo == "") 
      connection->sendAuthenticate(AUTH);
    else {
      HTTPAuthHeader authHeader;
      string error;
      bool ok = parseAuthHeader(authInfo, error, authHeader);

      if (!ok) {
	connection->sendError(400, "Bad Request", error);
	return;
      }
      
      output += "<em>Authentication info</em>:<br>";
      output += authInfo;
      output += "<br><em>Computation</em>:<br>";

      string password = "o";

      string ha1Hex = computeAuthDigestHA1(authHeader, password);
      string digestHex = computeAuthDigest(authHeader, "GET", ha1Hex);
      output += "HA1 digest=" + ha1Hex + "<br>DIGEST=" + digestHex;


      connection->write(fixColor(output));
      connection->close();
    }
  }

  //void serveError(IHTTPConnection* connection)

protected:
  Node* node;
};

//---------------------------------------------------------------------------
