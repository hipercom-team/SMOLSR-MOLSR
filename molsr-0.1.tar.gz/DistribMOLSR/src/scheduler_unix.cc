//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// See also: olsrdv5/main/unix_io_scheduler.c
//---------------------------------------------------------------------------
// Windows: cygwin select vs. windows select:
// One cannot mix select of cygwin with sockets created by Windows
// functions, and vice versa, so one must be really careful:
// Whichever is used is determined by whether windows.h/winsock2.h are
// included or not in the file.
//---------------------------------------------------------------------------

#include "base.h"

#if defined(SYSTEMlinux) || defined(SYSTEMcygwin)
#include <sys/select.h>
#include <errno.h>
#endif // SYSTEMlinux || SYSTEMcygwin

#ifdef SYSTEMwindows
#include <winsock2.h>
#include <windows.h>
#endif // SYSTEMwindows



#if defined(SYSTEMcygwin)
#include <sys/signal.h> // for cygwin
#endif

#include "log.h"
#include "scheduler_generic.h"
#include "scheduler_unix.h"


//---------------------------------------------------------------------------

typedef std::pair<IFdHandler*,void*> HandlerInfo;
typedef  std::list< HandlerInfo > HandlerList;


#include <map>

Time IOScheduler::getTime()
{ 
#if 0 //XXX
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec/1e6;
#endif
  return getTimeOfDay();
} 

void IOScheduler::addFdHandler(IFdHandler* fdHandler, void* data)
{ handlerList.push_back( HandlerInfo(fdHandler, data) ); }

void IOScheduler::write(ostream& out)
{ scheduler->write(out); }

void IOScheduler::waitForIO(Time maxTime)
{
  int j;
  fd_set fdSet[3]; // (note: in cygwin/winsock2, this is not a bitmap)
  int maxFD = -1;
  int status;
  //sigset_t sigset;
  //struct { IFdHandler* handler; } handlerTable [FD_SETSIZE][3];
  std::map<FileDescriptor, IFdHandler*> handlerTable[3];

  const int Input = 0, Output = 1, Except = 2;

  // update the "lastFD"

#define ADD_HANDLER(x,h) do { \
       FileDescriptor fd = h->getFileDescriptor(); \
       if(fd>maxFD) maxFD = fd; \
       FD_SET(fd, &(fdSet[x])); \
   handlerTable[x].insert(std::pair<FileDescriptor, IFdHandler*>(fd, h)); \
    } while(0)

  // set fd_set/s 
  maxFD = 0;
  for(j=0;j<3;j++) {
    FD_ZERO(&(fdSet[j]));
    for(HandlerList::iterator it = handlerList.begin();
	it!= handlerList.end(); it++) 
      {
	IFdHandler* handler = (*it).first;
	if (j == Input) {
	  if (handler->waitingForInput())
	    ADD_HANDLER(Input, handler);
	} else if (j == Output) {
	  if (handler->waitingForOutput()) 
	    ADD_HANDLER(Output, handler);
	} else if (j == Except) {
	  if (handler->waitingForExcept())
	    ADD_HANDLER(Except, handler);
	} else Fatal("Impossible select set index");
      }
  }

  /* select */
  struct timeval tv;
  tv.tv_sec = (unsigned int)maxTime;
  tv.tv_usec = (unsigned int) ((maxTime - tv.tv_sec)*(1e6 - 1));
  assert( tv.tv_usec < 1000000 );
  status = select(maxFD+1, fdSet+0, fdSet+1, fdSet+2, &tv);

  if (status < 0) {
#ifndef UNDER_CE
    if (errno != EINTR) // XXX: check for cygwin/Windows
#endif
      Warn("select:" << strerror(errno));
  } else if (status > 0) {
    for(j=0;j<3;j++) {
      for(std::map<FileDescriptor, IFdHandler*>::iterator it 
	    = handlerTable[j].begin(); it != handlerTable[j].end(); it++) {
	//for(i=0;i<FD_SETSIZE;i++) { // XXX: not optimized
	if(FD_ISSET((*it).first, &(fdSet[j]))) {
	  IFdHandler* handler = (*it).second;
          assert( handler != NULL );
	  if(j == Input) handler->handleInput();
	  else if (j == Output) handler->handleOutput();
	  else if (j == Except) handler->handleExcept();
	  else Fatal("Impossible select set index");
          FD_CLR((*it).first, &(fdSet[j]));
        }
      }
    }
  }
  //return status != 0; /* time out */
}

//---------------------------------------------------------------------------


