#---------------------------------------------------------------------------
#                                OOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
#  Copyright 2004 Institut National de Recherche en Informatique et
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

import sys, os

#for i in range(XXX):
#  print XXX

outputFileName = sys.argv[1]
dirName = sys.argv[2]

f = open(outputFileName, "w")

f.write(
"""
//---------------------------------------------------------------------------
//                                OOLSR
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//  AUTOMATICALLY GENERATED - DO NOT EDIT OR YOUR CHANGES WILL BE LOST
//---------------------------------------------------------------------------


"""
)

fileList = []

index = 0

for fileName in os.listdir(dirName):
  if fileName == "CVS": continue
  longFileName = sys.argv[2]+"/"+fileName
  g = open(longFileName)
  data = g.read()
  g.close()
  
  f.write("""static unsigned char fileData%d[%s] = {\n""" % (index, len(data)))
  for i in range(len(data)):
    if i != 0:
      if i%8 == 0:
        f.write(",\n")
      else: f.write(",")
    f.write("0x%02x" % ord(data[i]))
  f.write("\n};");
  fileList.append(("fileData%d" % index, len(data), fileName))
  index += 1

f.write("""

int wwwInlineFileCount = %d;

int wwwInlineFileSize[] = {
%s
};

unsigned char* wwwInlineFileData[] = {
%s
};

char* wwwInlineFileName[] = {
%s
};


""" %
(len(fileList),
 ",".join(["%s"%x[1] for x in fileList]),
 ",".join([x[0] for x in fileList]),
 ",".join([repr(x[2]).replace("'",'"') for x in fileList])))
  
f.close()

#---------------------------------------------------------------------------
