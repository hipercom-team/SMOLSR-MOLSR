
//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//--------------------------------------------------------------------------- 
#include "molsrNode.h"
#include "general.h"
#include "node.h"
#include "tuple.h"
#include "network_generic.h"
#include "scheduler_generic.h"
#include "scheduler_unix.h"
#include "system_linux.h"
//#include "molsrMdfpMsg.h"
#include <typeinfo>
#include <algorithm> //stl algorithms class library

//--------------------------------------------------------------------------- 
void MolsrNode::sourceClaimImmediatGeneration(Address localSourceAddress, Address groupAddress)
{
  if(!protocolConfig->MOLSRMODE)
  return;
  
  SourceClaimMessage* scMessage= new SourceClaimMessage;
  scMessage->source_addr=localSourceAddress;
  scMessage->list_group_addr.push_back(groupAddress);
  
  Message* message = new Message
    (SC_MESSAGE, 
     toMantissaExponentByte(protocolConfig->SC_HOLD_TIME), 
     getMainAddress(), // Originator 
     MaxTTL, // ttl, 
     0); // hop vcount, 
  
  message->content = scMessage;
  message->maxTime = getCurrentTime();
  
  packetManager->sendMessageToAll(message);
}
//--------------------------------------------------------------------------- 
void  MolsrNode::eventSourceClaimGeneration()
{


  updateCurrentTime();
  preEvent("gen-SourceClaim");
  // reschedule  XXX: refs 
  // adds SC_INTERVAL
  double minDelay = protocolConfig->SC_INTERVAL - protocolConfig->MAXJITTER;

  if(minDelay <0) minDelay = 0;
  NodeMethod method=(NodeMethod)(&MolsrNode::eventSourceClaimGeneration);
  
  addGenerationEvent(getCurrentTime() + minDelay,
		     getCurrentTime() + protocolConfig->SC_INTERVAL,
		     method, "gen-SourceClaim");

  if(!protocolConfig->MOLSRMODE)
  return;

  for(MCLocalSet::TupleIterator itSource = localSourceTable.getIter();
      !itSource.isDone(); itSource.next()) 
    {
      SourceClaimMessage* scMessage= new SourceClaimMessage;
      MCLocal* localSource=itSource.getCurrent();
      scMessage->source_addr=localSource->L_source_addr;

      // for(std::list< std::pair<Address,Time> >::iterator 
      for(std::map<Address,Time,AddressLess>::iterator 
	    itGroup = localSource->L_group_n_timeout.begin(); 
	  itGroup != localSource->L_group_n_timeout.end(); itGroup++)
	{
	  scMessage->list_group_addr.push_back(itGroup->first);
	}
      
      Message* message = new Message
	(SC_MESSAGE, 
	 toMantissaExponentByte(protocolConfig->SC_HOLD_TIME), 
	 getMainAddress(), // Originator 
	 MaxTTL, // ttl, 
	 0); // hop vcount, 
      
      message->content = scMessage;
      message->maxTime = getCurrentTime();
      
      packetManager->sendMessageToAll(message);
    }

 

  postEvent("gen-SourceClaim");
}

//--------------------------------------------------------------------------- 
void MolsrNode::processSourceClaimMessage(SourceClaimMessage * message)
{
  if(!protocolConfig->MOLSRMODE)
    return;
  
  Message* header = message->header;
  bool mcTreeTableChange=false;
  
  Time currentTime = getCurrentTime();
  Time validityTime = header->getValidityTime();
  
  Address sendMainAddress = ifaceToMainAddress(header->sendIfaceAddress);
  if (!isSymmetricNeighbor(sendMainAddress))     
    return; 
  
  for( std::list<Address>::iterator it= message->list_group_addr.begin();
       it!=message->list_group_addr.end(); it++)
    {
      MCTuple* mcTuple;
      if(mcTuple=mcTreeTable.findFirst(message->source_addr,(*it)))
	{	  
	  mcTuple->MT_source_time=currentTime + validityTime;
	  
	}
      else
	{
	  //If this node is a multicast Client do the following,
	  // if(!localClientTable.findFirst(message->source_addr,(*it)))
	  // {
	      mcTuple= new  MCTuple;
	      mcTuple->MT_source_addr=message->source_addr;
	      mcTuple->MT_group_addr=(*it);
	      //mcTuple->MT_parent_addr=NULL; This is initialized by zero by default
	      mcTuple->MT_source_time=currentTime + validityTime;
	      //mcTuple->MT_list_sons=; The list is initilized with the new constructor
	      mcTreeTable.add(mcTuple);
	      mcTreeTableChange=true;
	      //If this node is a multicast Client do the following,
	      if(localClientTable.findFirst(message->source_addr,(*it)))
		{
		  RoutingTuple *routingTuple;
		  routingTuple= currentRoutingTable->findFirst_Destination(mcTuple->MT_source_addr);
		  if(routingTuple)
		    {
		      mcTuple->MT_parent_addr= routingTuple->R_next_addr;
		      confirmParentLeaveImmediatGeneration(mcTuple,CP_MESSAGE,protocolConfig->CP_INTERVAL,protocolConfig->CP_HOLD_TIME);
		      
		    }
		}
	}     
      mcTuple->update();     
    }
   if(mcTreeTableChange)
      D(*log,lRoute,getRealTime() 
      << " [MOLSR MCtreeTable change due to SourceClaim message ] " 
      << getMainAddress()
      << ": " << mcTreeTable << endl);
}
//---------------------------------------------------------------------------
void MolsrNode::confirmParentLeaveImmediatGeneration(MCTuple* mcTuple,MessageType msgType, double msgInterval, double msgHoldTime)
{
if(!protocolConfig->MOLSRMODE)
  return;

  //updateCurrentTime();
  //double minDelay = msgInterval - protocolConfig->MAXJITTER;
  
  ConfParentLeaveMessage* cpMessage= new ConfParentLeaveMessage;
  ParentTree* parent=new ParentTree;
  RoutingTuple *routingTuple;

  if(!(mcTuple->MT_parent_addr.isNull()))
    {
      parent->parent_addr=mcTuple->MT_parent_addr;
      parent->group_addr=mcTuple->MT_group_addr;
      parent->source_addr=mcTuple->MT_source_addr;
      
      cpMessage->parent_list.push_back((*parent));
            
      Message* message = new Message
	(msgType, 
	 toMantissaExponentByte(msgHoldTime), 
	 getMainAddress(), // Originator 
	 1, // MaxTTLttl, 
	 0); // hop vcount, 
      
      message->content = cpMessage;
      message->maxTime = getCurrentTime();
      
      if (cpMessage->parent_list.size() == 0) 
	
	delete message;
      
      else
	{
	  routingTuple= currentRoutingTable->findFirst_Destination(mcTuple->MT_parent_addr);
	  if(routingTuple)
	    packetManager->sendMessage(Node::getIfaceByAddress(routingTuple->R_iface_addr),message);
	  else
	    delete message;
	}   
    }
  else
    delete cpMessage;

  delete parent; 
}
//---------------------------------------------------------------------------
void MolsrNode::eventConfirmParentGeneration()
{

  
  updateCurrentTime();
  preEvent("gen-ConfirmParent");
  // reschedule  XXX: refs 
  // add CP_INTERVAL
  double minDelay = protocolConfig->CP_INTERVAL - protocolConfig->MAXJITTER;
  NodeMethod method=(NodeMethod)&MolsrNode::eventConfirmParentGeneration;
  if(minDelay <0) minDelay = 0;
  addGenerationEvent(getCurrentTime() + minDelay,
		     getCurrentTime() + protocolConfig->CP_INTERVAL,
		     method, "gen-ConfirmParent");

  
if(!protocolConfig->MOLSRMODE)
  return;

  ConfParentLeaveMessage* cpMessage;
  ParentTree* parent=new ParentTree;
  RoutingTuple *routingTuple;
  std::map<Address,IMessageContent*,AddressLess> listMsg;

  for(MCTreeSet::TupleIterator it = mcTreeTable.getIter();
      !it.isDone(); it.next()) 
    {
      MCTuple* mcTuple=it.getCurrent();
      if(!(mcTuple->MT_parent_addr.isNull()))
	{
	  //1- get the local interface to reach the parent_addr
	  //2- if it does not exist a message being built to this iface, 
	  //   Then create a new one
	  parent->parent_addr=mcTuple->MT_parent_addr;
	  parent->group_addr=mcTuple->MT_group_addr;
	  parent->source_addr=mcTuple->MT_source_addr;
	 
	 
	  routingTuple= currentRoutingTable->findFirst_Destination(mcTuple->MT_parent_addr);
	  if(routingTuple)
	    {
	      if(listMsg.find(routingTuple->R_iface_addr)==listMsg.end())
		{ 
		  cpMessage= new ConfParentLeaveMessage;
		  listMsg[routingTuple->R_iface_addr]=(IMessageContent *)cpMessage;
		}
	      else
		{
		  cpMessage= (ConfParentLeaveMessage*)listMsg[routingTuple->R_iface_addr];
		}

	      cpMessage->parent_list.push_back((*parent));
	     
	    }
	}
    }



  for(std::map<Address,IMessageContent*,AddressLess>::iterator it=listMsg.begin(); it!=listMsg.end();it++)
    {
      Message* message = new Message
	(CP_MESSAGE, 
	 toMantissaExponentByte(protocolConfig->CP_HOLD_TIME), 
	 getMainAddress(), // Originator 
	 1, // MaxTTLttl, 
	 0); // hop vcount, 
      
      //message->content = cpMessage;
      message->content = it->second;
      message->maxTime = getCurrentTime();
          
      if (cpMessage->parent_list.size() == 0) 
	{
	  delete message;
	}
      else
	packetManager->sendMessage(Node::getIfaceByAddress(it->first),message);
    }

  listMsg.clear();
  delete parent;
  postEvent("gen-ConfirmParent");
}


//--------------------------------------------------------------------------- 

void MolsrNode::processConfirmParentMessage(ConfParentLeaveMessage * message)
{

if(!protocolConfig->MOLSRMODE)
  return;

 bool mcTreeTableChange=false;

 Message* header = message->header;

 Time currentTime = getCurrentTime();
 Time validityTime = header->getValidityTime();

 Address sendMainAddress = ifaceToMainAddress(header->sendIfaceAddress);
 if (!isSymmetricNeighbor(sendMainAddress))     
   return; 
 for( std::list<ParentTree>::iterator it= message->parent_list.begin();
      it!=message->parent_list.end(); it++)
    {
      if (header->recvIfaceAddress== it->parent_addr)
	// The message is processed by the right parent
	{

	  MCTuple* mcTuple;
	  if(NULL==(mcTuple=mcTreeTable.findFirst(it->source_addr,it->group_addr)))
	    {
	      //mcTuple= new  MCTuple;
	      //mcTuple->MT_source_addr=it->source_addr;
	      //mcTuple->MT_group_addr=it->group_addr;
	      ////mcTuple->MT_parent_addr=NULL;
	      //mcTuple->MT_source_time=currentTime + validityTime;
	      ////mcTuple->MT_list_sons=; The list is initilized with the new constructor
	      //mcTreeTable.add(mcTuple); 
	      //mcTreeTableChange=true;

	       D(*log, lRoute,getRealTime() 
		 << " [MOLSR ConfParent destined to this node, but no corresponding tuple in the MCtreeTable: unchanged ] " 
		 << getMainAddress()
		 << ": " << mcTreeTable << endl);
	    }
	  else
	    {
	      //This will create the entry if it does not exist
	      mcTuple->MT_list_sons[sendMainAddress]=currentTime + validityTime;
	      
	      if(mcTuple->MT_parent_addr.isNull())
		{
		  // set parent addr to the next hop to reach
		  // if the parent address is still null (no route from routing table)
		  // do not send a confirm parent or the source is in the local node !!
		  RoutingTuple *routingTuple;
		  routingTuple= currentRoutingTable->findFirst_Destination(mcTuple->MT_source_addr);
		  if(routingTuple)
		    {
		      mcTuple->MT_parent_addr= routingTuple->R_next_addr;
		      confirmParentLeaveImmediatGeneration(mcTuple,CP_MESSAGE,protocolConfig->CP_INTERVAL,protocolConfig->CP_HOLD_TIME);
		      mcTreeTableChange=true;
		    }
		}	
	    }      
	}
    }

 if(mcTreeTableChange)
   D(*log, lRoute,getRealTime() 
     << " [MOLSR MCtreeTable change due to ConfParent message ] " 
     << getMainAddress()
     << ": " << mcTreeTable << endl);
 
}

//--------------------------------------------------------------------------- 
void MolsrNode::processLeaveMessage(ConfParentLeaveMessage * message)
{

  if(!protocolConfig->MOLSRMODE)
  return;

  bool mcTreeTableChange=false;
  Message* header = message->header;
  
  Time currentTime = getCurrentTime();
  Time validityTime = header->getValidityTime();
  
  Address sendMainAddress = ifaceToMainAddress(header->sendIfaceAddress);
  
  //XXX probably not necessary !!!
  if (!isSymmetricNeighbor(sendMainAddress))     
    return; 
  
  
  for( std::list<ParentTree>::iterator it= message->parent_list.begin();
       it!=message->parent_list.end(); it++)
    {
      if (header->recvIfaceAddress== it->parent_addr)
	// The message is processed by the right parent
	{

	  MCTuple* mcTuple;
	  if(NULL!=(mcTuple=mcTreeTable.findFirst(it->source_addr,it->group_addr)))
	    {
	      //std::list<Son>::iterator son;
	      //Son *son;
	      //if(NULL!=(son=mcTreeTable.findSon(mcTuple,sendMainAddress)))
	      //{
		  //delete this son
	      //  mcTuple->MT_list_sons.erase(son);
		  
		  
	      //}
	      if(mcTuple->MT_list_sons.find(sendMainAddress)!=mcTuple->MT_list_sons.end())
		{
		  mcTuple->MT_list_sons.erase(sendMainAddress);
		  mcTreeTableChange=true;
		}
	      
	      if ((mcTuple->MT_list_sons.empty())&& (!localClientTable.findFirst(it->source_addr,it->group_addr)))
		{
		  confirmParentLeaveImmediatGeneration(mcTuple,LEAVE_MESSAGE,protocolConfig->LEAVE_INTERVAL,protocolConfig->LEAVE_HOLD_TIME);

		  //delete the current entry ?? 
		  //XXXXXor put the parent address  to NULL address
		  //mcTreeTable.removeAndDelete(mcTuple);
		  mcTuple->MT_parent_addr=NullAddress;
		}
	    }
	}
    }
 if(mcTreeTableChange)
   D(*log, lRoute,getRealTime() 
     << " [MOLSR MCtreeTable change due to Leave message ] " 
     << getMainAddress()
     << ": " << mcTreeTable << endl);
}
//---------------------------------------------------------------------------
Message* MolsrNode::generateSMOLSRInformationForMDFP()
{
  RoutingTuple *routingTuple;
  MCTreeEntryMessage msgItem;// = new  MCTreeEntryMessage;
  MCTreeMessage *msg= new MCTreeMessage;


  for(MPRSelectorSet::TupleIterator itMprS = mprSelectorSet.getIter();
	!itMprS.isDone(); itMprS.next()) {
      MPRSelectorTuple* mprSelectorTuple = itMprS.getCurrent();
      msgItem.parentAddr=mprSelectorTuple->MS_addr;
      msg->entry_list.push_back(msgItem);
    }

  if(msg->entry_list.size()>0)
    {
      
      Message* message = new Message
	(SMOLSRMSG, 
	 toMantissaExponentByte(getProtocolConfig()->CP_HOLD_TIME), 
	 getMainAddress(), // Originator 
	 MaxTTL, // ttl, 
	 0); // hop vcount, 
      
      message->content = msg;
      message->maxTime = getCurrentTime();
      message->messageSequenceNumber=0;
      return message;
    }    
  
  
  delete msg;
  return NULL;
  
}
//---------------------------------------------------------------------------

Message* MolsrNode::generateMIDInformationForMDFP()
{
  if (getAddressList()->size() > 0) 
    { // @@XXX: only MID if there is more than
      MIDMessage* midMessage= new MIDMessage;
      
      for(std::list<Address>::iterator it = getAddressList()->begin();
	  it != getAddressList()->end(); it++) {
	if( !((*it)== getMainAddress()))
	  midMessage->addressList.push_back((*it));
      }
      
      Message* message = new Message
	(MID_MESSAGE, 
	 toMantissaExponentByte(getProtocolConfig()->MID_HOLD_TIME), 
	 getMainAddress(), // Originator 
	 MaxTTL, // ttl, 
	 0); // hop vcount, 
      
      message->content = midMessage;
      message->maxTime = getCurrentTime();
      message->messageSequenceNumber=0;
      return message;
    }
  return NULL;
}
//---------------------------------------------------------------------------
Message* MolsrNode::generateMCTREEInformationForMDFP()
{
  RoutingTuple *routingTuple;
  MCTreeEntryMessage msgItem;// = new  MCTreeEntryMessage;
  MCTreeMessage *msg= new MCTreeMessage;
  
  for(MCTreeSet::TupleIterator itTuple = mcTreeTable.getIter();
      !itTuple.isDone(); itTuple.next()) 
    {
      MCTuple* mcTuple=itTuple.getCurrent();
      if(!(mcTuple->MT_parent_addr.isNull()))
	msgItem.parentAddr = mcTuple->MT_parent_addr;
      else
	msgItem.parentAddr=mcTuple->MT_source_addr;
      msgItem.sourceAddr = mcTuple->MT_source_addr;
      msgItem.groupAddr = mcTuple->MT_group_addr;
      
      for(std::map<Address,Time,AddressLess>::iterator itSon = mcTuple->MT_list_sons.begin();itSon != mcTuple->MT_list_sons.end();itSon++)
	{
	  routingTuple= currentRoutingTable->findFirst_Destination(itSon->first);
	  if(routingTuple)
	    {
	      msgItem.ifaceAddr=routingTuple->R_iface_addr;
	      if((msg->entry_list.end())==(find(msg->entry_list.begin(),msg->entry_list.end(),msgItem)))
		{
		  msg->entry_list.push_back(msgItem);
		}
	    }
	}
    }


  if(msg->entry_list.size()>0)
    {

       Message* message = new Message
	(MCTREE, 
	 toMantissaExponentByte(getProtocolConfig()->CP_HOLD_TIME), 
	 getMainAddress(), // Originator 
	 MaxTTL, // ttl, 
	 0); // hop vcount, 
      
      message->content = msg;
      message->maxTime = getCurrentTime();
      message->messageSequenceNumber=0;
      return message;
    }    
  
    
  delete msg;
  return NULL;
    
}
//---------------------------------------------------------------------------
void MolsrNode::generateInformationForMDFP()
{
  updateCurrentTime();
  preEvent("gen-mdfpInfo");
  //// reschedule  XXX: refs
  double minDelay = getProtocolConfig()->HELLO_INTERVAL - protocolConfig->MAXJITTER;;

  NodeMethod method=(NodeMethod)&MolsrNode::generateInformationForMDFP;
  if(minDelay <0) minDelay = 0;
  addGenerationEvent(getCurrentTime() + minDelay,
  		     getCurrentTime() + protocolConfig->HELLO_INTERVAL,
  		     method, "mdfpInfo-generation");

  
    // put this to 0 to avoid generating 
    // a sequence number to this packet
  
  Message* midMessage=generateMIDInformationForMDFP();
  Message* mcTreeMessage;
  if(!protocolConfig->MOLSRMODE)
    mcTreeMessage=generateSMOLSRInformationForMDFP();
  else
    mcTreeMessage=generateMCTREEInformationForMDFP();
  
  //mdfpCom->mdfpPackAndSend(midMessage,mcTreeMessage);
 

 
   mdfp->mdfpPackAndSend(midMessage,mcTreeMessage);
    //delete message; // XXXX
  

   postEvent("gen-mdfpInfo");
}





//--------------------------------------------------------------------------- 
void  MolsrNode::startSourceClaimBase()
{
  Time delay = _startDelay(0, protocolConfig->SC_INTERVAL);
  NodeMethod method=(NodeMethod)(&MolsrNode::eventSourceClaimGeneration);
  addGenerationEvent(delay, delay,method,"SourceClaim-generation");
}
//--------------------------------------------------------------------------- 
void  MolsrNode::startConfirmParentBase()
{
  Time delay = _startDelay(0, protocolConfig->CP_INTERVAL);
  NodeMethod method=(NodeMethod)(&MolsrNode::eventConfirmParentGeneration);
  addGenerationEvent(delay, delay,method ,"ConfirmParent-generation");
}
//--------------------------------------------------------------------------- 
void MolsrNode::startMDFPInformationGeneration()
{
  Time delay = _startDelay(0, protocolConfig->HELLO_INTERVAL);
  NodeMethod method=(NodeMethod)&MolsrNode::generateInformationForMDFP;
  addGenerationEvent(delay,delay,method, "mdfpInfo-generation");
}
//---------------------------------------------------------------------------
bool MCLocalSet::addSourceClientEntry(Address addressSource, Address groupAddress, Time timeOut)
{
  MCLocal*  mcLocalTuple;
  bool newMcLocalTuple =false;
  // mcLocalTuple=findFirst(addressSource,groupAddress);
  mcLocalTuple=findFirst(addressSource);
  if(!mcLocalTuple)
    {
      mcLocalTuple= new  MCLocal;
      mcLocalTuple->L_source_addr= addressSource;
      mcLocalTuple->L_time_out=node->getCurrentTime() + timeOut;
      this->add(mcLocalTuple);
      newMcLocalTuple =true;
        
    }
  
  if(mcLocalTuple->L_group_n_timeout.find(groupAddress)==mcLocalTuple->L_group_n_timeout.end())
    newMcLocalTuple =true;
    
  mcLocalTuple->L_group_n_timeout[groupAddress]= node->getCurrentTime() + timeOut;
  return (newMcLocalTuple);
}
//--------------------------------------------------------------------------- 
 bool MCLocalSet::deleteSourceClientEntry(Address localClientAddress, Address groupAddress)
{
   MCLocal*  mcLocalTuple;
   
   
   mcLocalTuple=findFirst(localClientAddress, groupAddress);
  
   if(mcLocalTuple)
    {           
      mcLocalTuple->L_group_n_timeout.erase(groupAddress);

      if(!mcLocalTuple->L_group_n_timeout.size()>0)
	this->removeAndDelete(mcLocalTuple);
      return true;
    }  
   return false;
}
//--------------------------------------------------------------------------- 
void MolsrNode::updateMCTreeTable()
{
  bool mcTreeTableChange=false;
  for(MCTreeSet::TupleIterator it = mcTreeTable.getIter();
      !it.isDone(); it.next()) 
    {
      MCTuple *mcTuple=it.getCurrent();
      RoutingTuple *routingTuple;
        if(!isOneOfOurIfaceAddress(mcTuple->MT_source_addr))
	 //If source is one of our interface, the parent is always NULL address
	 //There is nothing to do in this case
	 {     
	   if((mcTuple->MT_list_sons.size()>0)||
	      (localClientTable.findFirst(mcTuple->MT_source_addr,mcTuple->MT_group_addr)))
	     {
	       
	       routingTuple= currentRoutingTable->findFirst_Destination(mcTuple->MT_source_addr);
	       //Routing table does not contain route to local interfaces!!
	       if(routingTuple)
		 //There is route to the source
		 {
		   if(!(mcTuple->MT_parent_addr==routingTuple->R_next_addr))
		     {
		       //We may send a Leave to the previous parent before updating this entry (if it is reachable)
		       mcTuple->MT_parent_addr=routingTuple->R_next_addr;
		       confirmParentLeaveImmediatGeneration(mcTuple,CP_MESSAGE,protocolConfig->CP_INTERVAL,protocolConfig->CP_HOLD_TIME);
		       mcTreeTableChange=true;
		     }	  
		 }
	       else
		 {
		   routingTuple=currentRoutingTable->findFirst_Destination(mcTuple->MT_parent_addr);
		   if(routingTuple)
		     {
		       if(routingTuple->R_next_addr==routingTuple->R_dest_addr)
			 {
			   //The parent is still within reach
			   confirmParentLeaveImmediatGeneration(mcTuple,LEAVE_MESSAGE,protocolConfig->LEAVE_INTERVAL,protocolConfig->LEAVE_HOLD_TIME);
			 }
		     }
		   
		   mcTuple->MT_parent_addr=NullAddress; //XXX  NULL address !!!
		   //This entry will be deleted when it times out
		   mcTreeTableChange=true;
		   
		 }
	       
	     }
	 } 
    }

  if(mcTreeTableChange)
    D(*log, lRoute,getRealTime() 
      << " [MOLSR MCtreeTable change due to routingTable update] " 
      << getMainAddress()
      << ": " << mcTreeTable << endl);
}


//--------------------------------------------------------------------------- 

 void MolsrNode::computeRoutingTable()
{
  
  Node::computeRoutingTable();
 if(!protocolConfig->MOLSRMODE)
  return; 
  updateMCTreeTable();
  
}
//--------------------------------------------------------------------------- 
void MolsrNode::start()
{
  Node::start();
  D(*log, lMulticast,
    getRealTime() << " [MOLSR- config] " << getMainAddress() << endl);
  
  MolsrNode::startSourceClaimBase();
  MolsrNode::startConfirmParentBase();
  //MDFPCom
  if(mdfp)
    MolsrNode::startMDFPInformationGeneration();
  //MDFPCom
  // XXXX shoud we uncomment this ?
  //scheduleNextJitterStrategyEvent(true);
  
}
//--------------------------------------------------------------------------- 
 void  MolsrNode::processLocalClientMulticastJoin(Address localClientAddress, Address groupAddress)
{
  if(localClientTable.addSourceClientEntry(localClientAddress, groupAddress, TimeNever))
    {

      MCTuple* mcTuple;
      if(mcTuple=mcTreeTable.findFirst(groupAddress))
	{
	  RoutingTuple *routingTuple;
	  routingTuple= currentRoutingTable->findFirst_Destination(mcTuple->MT_source_addr);
	  if(routingTuple)
	    {
	      mcTuple->MT_parent_addr= routingTuple->R_next_addr;
	      confirmParentLeaveImmediatGeneration(mcTuple,CP_MESSAGE,protocolConfig->CP_INTERVAL,protocolConfig->CP_HOLD_TIME);
	      
	    }
	}
      D(*log, lRoute,getRealTime() 
	<< "[MOLSR MCtreeTable change due to new local Client join]" 
	<< getMainAddress()
	<< ": " << mcTreeTable << endl);
    }

}
//--------------------------------------------------------------------------- 
void  MolsrNode::processLocalMulticastSource(Address localSourceAddress, Address groupAddress)
{
  bool mcTreeTableChange=false;
  D(*log,lRoute,getRealTime() 
	   << "[New local Source join]" 
	   << getMainAddress()
	   << " Source=" <<localSourceAddress << " Group=" <<groupAddress  << endl);
  if(localSourceTable.addSourceClientEntry(localSourceAddress, groupAddress, TimeNever))
    {
      
      MCTuple* mcTuple;
       if(NULL==(mcTuple=mcTreeTable.findFirst(localSourceAddress,groupAddress)))
      {
	mcTuple= new  MCTuple;
	mcTuple->MT_source_addr=localSourceAddress;
	mcTuple->MT_group_addr=groupAddress;
	//mcTuple->MT_parent_addr=NULL;
	mcTuple->MT_source_time=TimeNever;
	//mcTuple->MT_list_sons=; The list is initilized with the new constructor
	mcTreeTable.add(mcTuple); 
	mcTreeTableChange=true;
      }

       sourceClaimImmediatGeneration(localSourceAddress,groupAddress);
       if(mcTreeTableChange)
	 D(*log,lRoute,getRealTime() 
	   << "[MOLSR MCtreeTable change due to new local Source join]" 
	   << getMainAddress()
	   << ": " << mcTreeTable << endl);
       else
	 D(*log,lRoute,getRealTime() 
	   << "[MOLSR MCtreeTable update failes due to new local Source join]" 
	   << getMainAddress()
	   << " Source=" <<localSourceAddress << " Group=" <<groupAddress  << endl);
    }
}
//--------------------------------------------------------------------------- 
void  MolsrNode::processLocalClientMulticastLeave(Address localClientAddress, Address groupAddress)
{
 bool mcTreeTableChange=false;

 if(localClientTable.deleteSourceClientEntry(localClientAddress, groupAddress))
   {
     for(MCTreeSet::TupleIterator it = mcTreeTable.getIter();
	 !it.isDone(); it.next()) 
       {
	 MCTuple* mcTuple=it.getCurrent();
	 
	 
	 if(mcTuple->MT_group_addr==groupAddress)
	   { 
	     //if it is a local client remove the corresponding entry if
	     // there is no sons and send a leave message!!
	     if(mcTuple->MT_list_sons.empty())
	       {
		 confirmParentLeaveImmediatGeneration(mcTuple,LEAVE_MESSAGE,protocolConfig->LEAVE_INTERVAL,protocolConfig->LEAVE_HOLD_TIME);
		 if(!localSourceTable.findFirst(localClientAddress, groupAddress))
		    {
		      mcTreeTable.removeAndDelete(mcTuple);
		      mcTreeTableChange=true;
		    }
	       }
	   }
	 
       }
     if(mcTreeTableChange)
       D(*log,lRoute,getRealTime() 
	 << "[MOLSR MCtreeTable change due to local Client leave]" 
	 << getMainAddress()
	 << ": " << mcTreeTable << endl);
     
   }
}
//--------------------------------------------------------------------------- 
void MolsrNode::processLocalMulticastSourceLeave(Address localSourceAddress, Address groupAddress)
{
  if(localSourceTable.deleteSourceClientEntry(localSourceAddress, groupAddress))
    {

      MCTuple* mcTuple;
      if(mcTuple=mcTreeTable.findFirst(localSourceAddress, groupAddress))
	{
	  
	  // confirmParentLeaveImmediatGeneration(mcTuple,LEAVE_MESSAGE,protocolConfig->LEAVE_INTERVAL,protocolConfig->LEAVE_HOLD_TIME);
	  //Delete this entry if it is a local source
	  mcTreeTable.removeAndDelete(mcTuple);
	
      D(*log, lRoute,getRealTime() 
	<< "[MOLSR MCtreeTable change due to new local Source leave]" 
	<< getMainAddress()
	<< ": " << mcTreeTable << endl);
	}
    }
}

//--------------------------------------------------------------------------- 
void MolsrNode::processLeaveNewLocalSrcClientMessage(LeaveNewLocalSrcClientMessage* message)
{
  Message* header = message->header;
  for( std::list<LeaveNewLocalSrcClientEntryMessage>::iterator 
	 it= message->entry_list.begin();
       it!=message->entry_list.end(); it++)
    {


      switch (header->messageType)
	{
	case NEWLOCALCLIENT:
	  processLocalClientMulticastJoin(it->srcCli, it->group);
	  break;
	case NEWLOCALSOURCE:
	  processLocalMulticastSource(it->srcCli, it->group);
	  break;
	case LEAVELOCALCLIENT:
	  processLocalClientMulticastLeave(it->srcCli, it->group);
	  break;
	case LEAVELOCALSOURCE:
	  processLocalMulticastSourceLeave(it->srcCli, it->group);
	  break;
	default:
	  break;
	}
    }
}

//--------------------------------------------------------------------------- 
void MolsrNode::performTupleExpiration()
{
  D(*log, lRoute, "[performTupleExpiration - MOLSR]" << endl);
  D(*log, lRoute, "[performTupleExpiration function]" << endl 
    << getRealTime() << " [ MOLSR - mcTreeTable] " << getMainAddress()
    << ": " << mcTreeTable << endl);
  
  Node::performTupleExpiration();
  //XXX To finish look into node_general.cc
  
  Time clock = getCurrentTime(); 
 

  mcTreeTable.removeAndDeleteExpired(clock);
  localSourceTable.removeAndDeleteExpired(clock);
  localSourceTable.removeAndDeleteExpired(clock);
}
//--------------------------------------------------------------------------- 
void MolsrNode::getNextExpireTime(Time& nextExpireTime, bool& hasExpireTime)
{
  Node::getNextExpireTime(nextExpireTime,hasExpireTime);
  //XXX To finish look into node_general.cc

  updateMinExpireTime(currentTime,nextExpireTime, hasExpireTime, mcTreeTable);
  updateMinExpireTime(currentTime,nextExpireTime, hasExpireTime, localSourceTable);
  updateMinExpireTime(currentTime,nextExpireTime, hasExpireTime, localClientTable);
}
//--------------------------------------------------------------------------- 
#ifdef WITH_MULTICAST_ENCAPSULATION
bool MolsrNode::shouldForwardEMMessage(EMMessage* message)
{
  Message* header = message->header;
  
  // header->originatorAddress;
  //header->sendIfaceAddress;
  //message->destinationAddress;
  //  Address parentAddress=nullAddress;
  //if(isOneOfOurIfaceAddress())
  // parentAddress =header->sendIfaceAddress;
  //XXX check if the sendIfaceAddress is put to NULL when originating the packet
  
  
  D(*log, lRoute, "[Should Forward Processing -begin]" << endl 
    << getRealTime() << " [ MOLSR - mcTreeTable] " << getMainAddress()
    << ": " << mcTreeTable << endl);
  
  MCTuple*mcTuple=mcTreeTable.findFirst(header->originatorAddress,message->destinationAddress,header->sendIfaceAddress);
  D(*log, lRoute,"Originator=" << header->originatorAddress
    << ", Group Multicast=" << message->destinationAddress
    <<", Parent Address=" << header->sendIfaceAddress << endl);
  D(*log, lRoute, "MOLSR should forward:");
  
  if(mcTuple)
    {
      if(mcTuple->MT_list_sons.size()>0)
	{
	 
	  D(*log, lRoute,"Yes" << endl
	    << "[Should Forward Processing -end]" << endl);
	  return true;
	}
    }
  
  D(*log, lRoute, "No" << endl
    << "[Should Forward Processind -end]" << endl);
  return false;
}
#endif
//--------------------------------------------------------------------------- 
void MolsrNode::configure(IScheduler* aBaseScheduler, 
			  AddressFactory* aAddressFactory,
			  PacketManager* aPacketManager,
			  INetworkConfigurator* aNetworkConfigurator,
			  ProtocolConfig* aProtocolConfig,
			  std::vector<ISystemIface*>& aSystemIfaceList,
			  Log* aLog)
{
  Node::configure(aBaseScheduler, 
		  aAddressFactory,
		  aPacketManager,
		  aNetworkConfigurator,
		  aProtocolConfig,
		  aSystemIfaceList,
		  aLog);
  
   SourceClaimMessageHandler*  sourceClaimMsgHand = new SourceClaimMessageHandler(this);
  ConfParentLeaveMessageHandler* ConfPLMsgHand= new ConfParentLeaveMessageHandler(this);

  packetManager->addMessageHandler(SC_MESSAGE,sourceClaimMsgHand);
  packetManager->addMessageHandler(CP_MESSAGE,ConfPLMsgHand);
  packetManager->addMessageHandler(LEAVE_MESSAGE,ConfPLMsgHand);
 

  //-------MDFPCom
  if(mdfp) //mdfp is not used for simuation and equal to NULL 
    {
      MCTreeHandler* MCTreeHand = new MCTreeHandler(this);
      
      LeaveNewLocalSrcClientHandler* LeaveNewLocalSrcClientHand= new LeaveNewLocalSrcClientHandler(this);
      
      packetManager->addMessageHandler(MCTREE,MCTreeHand);
      packetManager->addMessageHandler(SMOLSRMSG,MCTreeHand);
      packetManager->addMessageHandler(NEWLOCALCLIENT,LeaveNewLocalSrcClientHand);
      packetManager->addMessageHandler(NEWLOCALSOURCE,LeaveNewLocalSrcClientHand);
      packetManager->addMessageHandler(LEAVELOCALCLIENT,LeaveNewLocalSrcClientHand);
      packetManager->addMessageHandler(LEAVELOCALSOURCE,LeaveNewLocalSrcClientHand);
      
      //IOScheduler *ioScheduler;
      //ioScheduler=dynamic_cast<IOScheduler*>(aBaseScheduler);
      //mdfpCom =new MDFPCom(this,ioScheduler,2700,2699);
      //mdfpCom =new MDFPCom(this,aBaseScheduler,2700,2699);
      //mdfpCom->start();
      
      mdfp->start();
    }
      //-------MDFPCom
}
//--------------------------------------------------------------------------- 
void MolsrNode::logState(ostream& out)
{
   Node::logState(out);
  
  out << getRealTime() << " [MOLSR state-begin] " << getMainAddress()
      << endl;
  
  out << getRealTime() << " [MOLSR - mcTreeTable] " << getMainAddress()
      << ": " << mcTreeTable << endl;

  out << getRealTime() << " [MOLSR - localClientTable] " << getMainAddress()
      << ": " << localClientTable << endl;
  
  out << getRealTime() << " [MOLSR - localSourceTable] " << getMainAddress()
      << ": " << localSourceTable << endl;
  
  out << getRealTime() << " [MOLSR state-end] " << getMainAddress()
      << endl;
}
