//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//--------------------------------------------------------------------------- 
#include "molsrNode.h"
#include "general.h"
#include "node.h"
#include "tuple.h"




//--------------------------------------------------------------------------- 
void SourceClaimSpecification::process(Node* node, MessageContent* m)
{
  MolsrNode *molsrNode= dynamic_cast<MolsrNode*>(node);
  molsrNode->processSourceClaimMessage(m);
}
//--------------------------------------------------------------------------- 
void ConfParentLeaveSpecification::process(Node* node, MessageContent* m)
{
  MolsrNode *molsrNode= dynamic_cast<MolsrNode*>(node);
  
  if(m->header->messageType==CP_MESSAGE)
    molsrNode->processConfirmParentMessage(m);

  if(m->header->messageType==LEAVE_MESSAGE)
    molsrNode->processLeaveMessage(m);
}

//--------------------------------------------------------------------------- 
