//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Adokoe Plakoo, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//     $Id: iwevent_client.cc,v 1.15 2005/07/20 10:58:41 plakoo Exp $
//---------------------------------------------------------------------------

#ifdef LINK_IWEVENT_MONITORING
#ifndef UNDER_CE
#include <sys/types.h>
#include <sys/stat.h>
#endif
#ifndef SYSTEMwindows
#include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>

#ifndef UNDER_CE
#include <errno.h>
#endif

#include <scheduler_simulation.h>
#include <scheduler_unix.h>

#if defined(SYSTEMcygwin) || defined(SYSTEMlinux)
#include <sys/socket.h>
#include <sys/ioctl.h>
#endif

#ifndef SYSTEMwindows
#include <sys/select.h>
#include <netinet/in.h> // Linux
//#include <linux/netlink.h>
#include <asm/types.h>
#include <linux/rtnetlink.h>
#include <linux/wireless.h>
#include <fcntl.h>
//typedef void* SockoptPointer;
#endif


#ifdef SYSTEMwindows
#include <winsock2.h>
#ifndef SHUT_RDWR
#define SHUT_RDWR SD_BOTH
#define SHUT_RD SD_RECEIVE
#endif // !defined(SHUT_RDWR)
//typedef char* SockoptPointer;
//typedef int socklen_t;
#endif // !defined(SYSTEMwindows)

#include "node.h"
#include "iwevent_client.h"
#include "iwevent_support.h"
#include "node_link_monitoring.h"

//---------------------------------------------------------------------------
#define IW_MAX_PRIV_DEF	128
#define NL_BUFSIZE 2048
//---------------------------------------------------------------------------

//class Node;
class IfaceWirelessEvent;

class IweventClient : public IIweventClient, public IFdHandler
{
public:

  int netlinkSocket;

  IweventClient(Node* aNode): scheduler(NULL), node(aNode) { }

  virtual void open(IOScheduler* aScheduler, void* data);
 
  void start()
  { 
    configureCaptureIoctl();
   // if ( configureCaptureIoctl() )
    //  scheduler->addFdHandler(this, NULL); 
  }

  // IFdHandler methods
  virtual FileDescriptor getFileDescriptor() 
  { return netlinkSocket; }

  virtual bool waitingForInput() { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; }
  virtual void handleOutput() { Fatal("Impossible handleOutput"); }
  virtual void handleExcept() { Fatal("Impossible handleExcept"); }
  virtual void handleInput();

  int configureCaptureIoctl();
  int configureIfaceCaptureIoctl(OLSRIface* iface);
  int retrieveIfaceWirelessEvent();
  void processIfaceWirelessEvent();

  virtual ~IweventClient() { deleteIfaceWirelessEventList(); }

protected:
  unsigned char inputBuffer[NL_BUFSIZE];
  unsigned int  inputLength;
  list<IfaceWirelessEvent*> ifaceWirelessEventList;
  IOScheduler*  scheduler;
  Node* node;
  void deleteIfaceWirelessEventList();

};


void IweventClient::open(IOScheduler* aScheduler, void* data)
  {
    if (node->getProtocolConfig()->useSignalMonitoring )
      {
	assert( scheduler == NULL );
	scheduler = aScheduler;
	
	sockaddr_nl netlinkAddr;
	memset( &netlinkAddr, 0, sizeof(netlinkAddr) );
	netlinkAddr.nl_family = AF_NETLINK;
	netlinkAddr.nl_groups = RTMGRP_LINK;
	
	netlinkSocket = socket(PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	
	if (netlinkSocket < 0)
	  Fatal("Cannot create NetLink socket: " << strerror(errno));
	
	// Set the socket in non-blocking mode.

	int flags = fcntl(netlinkSocket, F_GETFL);

	if ( fcntl(netlinkSocket, F_SETFL, flags | O_NONBLOCK) < 0 )
	  Fatal("Cannot make the socket non blocking: "
		<< strerror(errno));

	if (bind(netlinkSocket, 
		 (sockaddr*)&netlinkAddr, sizeof(netlinkAddr)) <0)
	  Fatal("Cannot bind NetLink socket: " << strerror(errno));
	
	start();
      }
  }

//---------------------------------------------------------------------------

void IweventClient::handleInput() 
  { 
   struct sockaddr_nl src_addr;
   socklen_t addr_length;

    if (node->getProtocolConfig()->useSignalMonitoring )
      {
	// I tried a simple loop but Iwevent packets don't stop arriving
	for (int i = 0 ;i < 20; i++) {
	  inputLength = 0;
	  memset(inputBuffer, 0, sizeof(inputBuffer));
	  
	  inputLength = recvfrom(netlinkSocket, inputBuffer, 
				 sizeof(inputBuffer), MSG_DONTWAIT,
				 (struct sockaddr*)&src_addr, &addr_length);
	  
	  if (inputLength <= 0) 
	    {
	      if (inputLength < 0)
		Warn("Error in recvfrom: " << strerror(errno));
	      
	      inputLength = 0;
//	      return;
	      break;
	    }
	  
	  retrieveIfaceWirelessEvent();
	  processIfaceWirelessEvent();
	  deleteIfaceWirelessEventList();
	}
      }
  }

//---------------------------------------------------------------------------
   
int IweventClient::configureCaptureIoctl() 
  {
    std::list<OLSRIface*>* ifaceList = node->getIfaceList();
    int result = 0;

    for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
	it != ifaceList->end(); it++) 
      
      if ( configureIfaceCaptureIoctl( *it ) == 0 ) result++;
    
    return result;
  }

//---------------------------------------------------------------------------
   
int IweventClient::configureIfaceCaptureIoctl(OLSRIface* iface)
{

  struct iwreq wrq;
  int skfd;
  struct iw_priv_args priv[IW_MAX_PRIV_DEF];
  u_char buffer[NL_BUFSIZE];
  int subCmdPos = -1;
  int cmdPos = -1;
  int subcmd = 0;
  int offset = 0;

  memset(priv, 0, sizeof(priv));

  memset(&wrq, 0, sizeof(struct iwreq));
  strncpy(wrq.ifr_name, iface->getName().c_str(), IFNAMSIZ);

  wrq.u.data.pointer = (caddr_t) priv;
  wrq.u.data.length = IW_MAX_PRIV_DEF;
  wrq.u.data.flags = 0;

  skfd = iface->getSignalFileDescriptor();

  if (ioctl(skfd, SIOCGIWPRIV, &wrq) < 0) 
    {
      Warn( " Retrieve list of private ioctls on " 
	    << iface->getName().c_str() << " : " << strerror(errno) );
      return -1;
    }

  //Look for "capture" sub-ioctl

  while ((++subCmdPos < wrq.u.data.length) && 
	 strcmp(priv[subCmdPos].name, "capture"));

  if (subCmdPos == wrq.u.data.length) 
    {
      Warn( "Unable to find capture sub-ioctl on " <<
	    iface->getName().c_str() );
      return -1;
    }

  // Look for "capture" ioctl

  if (priv[subCmdPos].cmd < SIOCDEVPRIVATE) 
    {
      // A real ioctl is declared with SAME ARGUMENTS 
      // as in the sub-ioctl declaration and a NULL NAME.
      while ( (++cmdPos < wrq.u.data.length) && 
	      ( (priv[cmdPos].name[0] != '\0') ||
		(priv[cmdPos].set_args != priv[subCmdPos].set_args) ||
		(priv[cmdPos].get_args != priv[subCmdPos].get_args) ) );
        
      if (cmdPos == wrq.u.data.length) 
	{
	  Warn( "Unable to find capture ioctl on " <<
		iface->getName().c_str() );
	  return -1;
	}

      subcmd = priv[subCmdPos].cmd;
      offset = sizeof(__u32);
    }

  if ( (priv[cmdPos].set_args & IW_PRIV_TYPE_MASK) != IW_PRIV_TYPE_INT ) 
    {
      Warn( "Capture parameter doesn't match integer type on " <<
	    iface->getName().c_str() );
      return -1;
    }

  int nargs = (priv[cmdPos].set_args & IW_PRIV_SIZE_MASK);
  if (nargs != 1) 
    {
      Warn( "Capture ioctl expects more than one parameter on " <<
	    iface->getName().c_str() );
      return -1;
    }

    // Build the Set request
    memset(&wrq, 0, sizeof(struct iwreq));
    strncpy(wrq.ifr_name, iface->getName().c_str(), IFNAMSIZ);

    int value = HOSTAP_CAPTURE_TARGET_OLSR;
    wrq.u.data.length = nargs; 
    ( (__s32 *) buffer )[0] = (__s32) value;
   
    assert(offset != 0);
    wrq.u.mode = subcmd;
    memcpy(wrq.u.name + offset, buffer, IFNAMSIZ - offset);

    // Send the request.
    if (ioctl(skfd, priv[cmdPos].cmd, &wrq) < 0) 
      {
	Warn( " Capture call on " 
	      << iface->getName().c_str() << ": " << strerror(errno) );
	return -1;
      }

    return 0;
}

//---------------------------------------------------------------------------

class WirelessEventData;

class IfaceWirelessEvent
{
public:
  int captureOptions;

  IfaceWirelessEvent(Node* aNode, int ifIndex): node(aNode) 
  { iface = node->getIfaceByIndex(ifIndex); }

  void retrieveWirelessEventData();
  void processSignalInfos();

protected:
  Node* node;
  OLSRIface* iface;
  void * rtattributes;
  int rtattrSize;
  list<WirelessEventData*> wirelessEventDataList;

  int setCaptureOptions();
  void deleteWirelessEventDataList();
  friend class IweventClient;
};

//---------------------------------------------------------------------------

class SignalInfos;

class WirelessEventData
{
public:

  WirelessEventData(Node* aNode): node(aNode) { }
  SignalInfos* retrieveSignalInfos(int captureOption, Address& ifaceAddress);

protected:
  Node* node;
  char data[HOSTAP_CAPTURE_MAX];
  int dataSize;
  friend class IfaceWirelessEvent;
};

//---------------------------------------------------------------------------

class SignalInfos
{
public:

  unsigned char srcEthAddr[ETH_ALEN];
  unsigned char dstEthAddr[ETH_ALEN];

  Address srcIpAddr;
  Address dstIpAddr;

  signed char    signal;
  signed char    noise;
  unsigned short rate;
  unsigned int   mac_time;
  unsigned int   sequence;

  SignalInfos(Node* aNode): node(aNode) { }
  void updateHeardIfaceSet();

protected:
  Node* node;
};

//---------------------------------------------------------------------------

void SignalInfos::updateHeardIfaceSet()
{
  HeardIfaceTuple* heardIfaceTuple = 
    node->heardIfaceSet.findThisLink(srcIpAddr, dstIpAddr); 

  bool shouldAdd = false;

  if (heardIfaceTuple == NULL)
    {
      heardIfaceTuple = new HeardIfaceTuple(node, srcIpAddr, dstIpAddr, -1);
      heardIfaceTuple->H_last_packetSequenceNumber = 
	heardIfaceTuple->H_SignalInit_packetSequenceNumber;
      shouldAdd = true;
    }

  Time currentTime = node->getCurrentTime();
  heardIfaceTuple->updateExpireTime(currentTime);

  heardIfaceTuple->setLinkQuality(-1, signal);

  if (shouldAdd) node->heardIfaceSet.add(heardIfaceTuple);
}

//---------------------------------------------------------------------------

SignalInfos*  WirelessEventData::retrieveSignalInfos(int captureOption,
						     Address& ifaceAddress)
{
  SignalInfos* signalInfos;
  hostap_capture_olsr_t* olsrInfo;
  hostap_capture_header_t header;
  AddressFactory* addressFactory;
  Address srcAddress;

  switch (captureOption & HOSTAP_CAPTURE_TARGET_MASK) 
    {
    case HOSTAP_CAPTURE_TARGET_OLSR:
     
      if ((captureOption & HOSTAP_CAPTURE_ASCII) == 0) 
	{
	  olsrInfo = (hostap_capture_olsr_t*)data;
	  header = olsrInfo->header;

	  addressFactory = node->getAddressFactory();

	  srcAddress = Address(addressFactory, &olsrInfo->src);

	  if (node->getprotocolConfigIsIpv6() != olsrInfo->isIPv6)
	    return NULL;

	  // Discard infos on packets from this node
	  if ( node->ifaceToMainAddress(srcAddress) == 
	       node->getMainAddress() )

	    return NULL;
	   
	  signalInfos = new SignalInfos(node);
	  if ( !signalInfos )
	    Fatal("Out of memory");
	  
	  signalInfos->signal = header.signal;
	  signalInfos->noise = header.noise;
	  signalInfos->rate = header.rate;
	  signalInfos->mac_time = header.mac_time;
	  signalInfos->sequence = header.sequence;

	  signalInfos->srcIpAddr = srcAddress;

	  signalInfos->dstIpAddr = ifaceAddress;

	}

      
      return signalInfos;

    default:  
      
      return NULL;
    }
}

//---------------------------------------------------------------------------

/** 
 * Wireless event are encapsulated in the IFLA_WIRELESS field of
 * a RTM_NEWLINK message.
 */

void IfaceWirelessEvent::retrieveWirelessEventData()
{
  struct rtattr*    rtattrInfo;
  struct iw_event*  iweventInfo;
  int len;

  WirelessEventData* wirelessEventData;

  rtattrInfo = (struct rtattr*)rtattributes;
  len = rtattrSize;

  while ( RTA_OK(rtattrInfo, len) )
    {

    if (rtattrInfo->rta_type == IFLA_WIRELESS)
      {
	iweventInfo = (struct iw_event*) RTA_DATA(rtattrInfo);

	if ( iweventInfo->cmd == IWEVCUSTOM )
	  {
	    wirelessEventData = new WirelessEventData(node);

	    if ( !wirelessEventData )
	      Fatal("Out of memory");

	    /* skip iw_event and iw_point's headers (4+8 bytes) */
	    wirelessEventData->dataSize = iweventInfo->len - IW_EV_POINT_LEN;

	    memcpy(wirelessEventData->data, 
		   (char *)iweventInfo + IW_EV_POINT_LEN, 
		   wirelessEventData->dataSize);

	    wirelessEventDataList.push_back(wirelessEventData);
	  }
      }

    rtattrInfo = RTA_NEXT(rtattrInfo, len);
  }

}

//---------------------------------------------------------------------------

void IfaceWirelessEvent::processSignalInfos()
{
  SignalInfos* signalInfos;
  Address ifaceAddress = iface->getAddress();

  if ( setCaptureOptions() >= 0 )  // Maybe differentiation between wireless
                                   // and non-wireless interface 
                                   // would be better.

    {
      for(std::list<WirelessEventData*>::iterator 
	    it = wirelessEventDataList.begin();
	  it != wirelessEventDataList.end(); it++)
	{
	  signalInfos = (*it)->retrieveSignalInfos(captureOptions,
						   ifaceAddress);
	  if (signalInfos != NULL)
	    {
	      signalInfos->updateHeardIfaceSet();
	      delete signalInfos;
	    }
	}
    }
  
}

//---------------------------------------------------------------------------

int IfaceWirelessEvent::setCaptureOptions()
{
  struct iwreq wrq;
  int skfd;
  struct iw_priv_args priv[IW_MAX_PRIV_DEF];
  u_char buffer[NL_BUFSIZE];
  int subCmdPos = -1;
  int subcmd = 0;
  int cmdPos = -1;
  int offset = 0;

  memset(priv, 0, sizeof(priv));

  memset(&wrq, 0, sizeof(struct iwreq));
  strncpy(wrq.ifr_name, iface->getName().c_str(), IFNAMSIZ);

  wrq.u.data.pointer = (caddr_t) priv;
  wrq.u.data.length = IW_MAX_PRIV_DEF;
  wrq.u.data.flags = 0;

  assert(iface != NULL);
  skfd = iface->getSignalFileDescriptor();

  if (ioctl(skfd, SIOCGIWPRIV, &wrq) < 0) 
    {
      Warn( " Retrieve list of private ioctls on " 
	    << iface->getName().c_str() << ":"<< strerror(errno) );
      return -1;
    }

  //Look for "getcapture" sub-ioctl

  while ((++subCmdPos < wrq.u.data.length) && 
	 strcmp(priv[subCmdPos].name, "getcapture"));

  if (subCmdPos == wrq.u.data.length) 
    {
      Warn( "Unable to find getcapture sub-ioctl on "  
	    << iface->getName().c_str() );
      return -1;
    }

  //Look for "getcapture" ioctl

  if (priv[subCmdPos].cmd < SIOCDEVPRIVATE) 
    {
      // A real ioctl is declared with SAME ARGUMENTS 
      // as in the sub-ioctl declaration and a NULL NAME.
      while ( (++cmdPos < wrq.u.data.length) && 
	      ( (priv[cmdPos].name[0] != '\0') ||
		(priv[cmdPos].set_args != priv[subCmdPos].set_args) ||
		(priv[cmdPos].get_args != priv[subCmdPos].get_args) ) );
        
      if (cmdPos == wrq.u.data.length) 
	{
	  Warn( "Unable to find getcapture ioctl on "
		<< iface->getName().c_str() );
	  return -1;
	}

      subcmd = priv[subCmdPos].cmd;
      offset = sizeof(__u32);
    }

  if ( (priv[cmdPos].get_args & IW_PRIV_TYPE_MASK) != IW_PRIV_TYPE_INT ) 
    {
      Warn( "Getcapture parameter doesn't match integer type on " 
	    << iface->getName().c_str() );
      return -1;
    }

  int nargs = (priv[cmdPos].get_args & IW_PRIV_SIZE_MASK);
  if (nargs != 1) 
    {
      Warn( "Getcapture ioctl returns more than one parameter on "
	    << iface->getName().c_str() );
      return -1;
    }

    // Build the Get request
    memset(&wrq, 0, sizeof(struct iwreq));
    strncpy(wrq.ifr_name, iface->getName().c_str(), IFNAMSIZ);

    wrq.u.data.length = 0L;     
    assert(offset != 0);
    wrq.u.mode = subcmd;

    // Send the request.
    if (ioctl(skfd, priv[cmdPos].cmd, &wrq) < 0) 
      {
	Warn( " Getcapture call on " 
	      << iface->getName().c_str() << " : " << strerror(errno) );
	return -1;
      }

    memcpy(buffer, wrq.u.name, IFNAMSIZ);

    //retrieve the returned value
    captureOptions = ( (__s32 *) buffer )[0];

    return 0;
}

//---------------------------------------------------------------------------

void IfaceWirelessEvent::deleteWirelessEventDataList()
{
  for(std::list<WirelessEventData*>::iterator 
	it = wirelessEventDataList.begin();
      it != wirelessEventDataList.end(); it++) 

    delete *it;

  wirelessEventDataList.clear();
}

//---------------------------------------------------------------------------

void IweventClient::deleteIfaceWirelessEventList()
{
  for(std::list<IfaceWirelessEvent*>::iterator 
	it = ifaceWirelessEventList.begin();
      it != ifaceWirelessEventList.end(); it++) 

    delete *it;

  ifaceWirelessEventList.clear();
}

//---------------------------------------------------------------------------

/** 
 * Wireless events are carried through the rtnetlink socket to user space.
 * They are encapsulated in the IFLA_WIRELESS field of a RTM_NEWLINK message.
 */

int IweventClient::retrieveIfaceWirelessEvent()
{
  struct nlmsghdr* nlmsg;
  struct nlmsgerr* nlerr;
  struct ifinfomsg* ifInfo;
  int ifIndex;
  int len;
  
  IfaceWirelessEvent* ifaceWirelessEvent;

  nlmsg = (struct nlmsghdr*)inputBuffer;
  
  while ( NLMSG_OK(nlmsg, inputLength) )
    {
      switch (nlmsg->nlmsg_type) {
	
      case NLMSG_DONE:
	
	return 0;
	
      case NLMSG_ERROR:
	
	nlerr = (struct nlmsgerr*)NLMSG_DATA(nlmsg);
	if (nlmsg->nlmsg_len < NLMSG_LENGTH( sizeof(struct nlmsgerr) ))
	  Warn("Error troncated");
	else {
	  errno = nlerr->error;
	  Warn("Error in RTNETLINK msg: " << strerror(errno));
	}
	
	return -1;
	
      case RTM_NEWLINK:
	
	break;
	
      default:

	nlmsg = NLMSG_NEXT(nlmsg, inputLength);
	continue;  //go to while
	
      }
      
      len = NLMSG_PAYLOAD(nlmsg, 0);
      
      ifInfo = (struct ifinfomsg*)NLMSG_DATA(nlmsg);
      ifIndex = ifInfo->ifi_index;
      
      ifaceWirelessEvent = new IfaceWirelessEvent(node, ifIndex);
      if ( !ifaceWirelessEvent )
	Fatal("Out of memory");

      // Is this iinterface using by OLSR?
      if ( ifaceWirelessEvent->iface != NULL )
	{
      
	  ifaceWirelessEvent->rtattributes = (char*)ifInfo +
	    sizeof(struct ifinfomsg);
	  ifaceWirelessEvent->rtattrSize = len - sizeof(struct ifinfomsg);
	  
	  ifaceWirelessEventList.push_back(ifaceWirelessEvent);
	}
      else
	delete ifaceWirelessEvent;
	  
      nlmsg = NLMSG_NEXT(nlmsg, inputLength);
    }
  
   return 0;
}

//---------------------------------------------------------------------------

void IweventClient::processIfaceWirelessEvent()
{
  for(std::list<IfaceWirelessEvent*>::iterator 
	it = ifaceWirelessEventList.begin();
      it != ifaceWirelessEventList.end(); it++) 
    {
      (*it)->retrieveWirelessEventData();
      (*it)->processSignalInfos();
      (*it)->deleteWirelessEventDataList();
    }
}

//---------------------------------------------------------------------------

IIweventClient* makeIWEVENTClient(Node* node)
{ return new IweventClient(node); }

//---------------------------------------------------------------------------
#endif
