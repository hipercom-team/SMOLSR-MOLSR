//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             , projet Hipercom, INRIA Rocquencourt
//  Copyright 2003 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#error This file is not yet used

#ifndef _PACKET_BUFFER_H
#define _PACKET_BUFFER_H

//---------------------------------------------------------------------------



//---------------------------------------------------------------------------

#endif // _PACKET_BUFFER_H
