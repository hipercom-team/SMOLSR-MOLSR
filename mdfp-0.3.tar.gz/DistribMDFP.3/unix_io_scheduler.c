//-------------------------------------------------------------------*- c -*-
////                                SMOLSR
////         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
////          
////  Copyright 2003-2004 Institut National de Recherche en Informatique et
////  en Automatique.  All rights reserved.  Distributed only with permission.
////---------------------------------------------------------------------------
/*
 * This Copyright notice is in French. An English summary is given
 * but the referee text is the French one.
 *
 * Copyright (c) 2000, 2001, 2002, 2003 
 *     Adokoe.Plakoo@inria.fr, INRIA Rocquencourt,
 *     Anis.Laouiti@inria.fr, INRIA Rocquencourt.
 *     Cedric.Adjih@inria.fr, INRIA Rocquencourt.
 *
 * Ce logiciel informatique est disponible aux conditions
 * usuelles dans la recherche, c'est-�-dire qu'il peut
 * �tre utilis�, copi�, modifi�, distribu� � l'unique
 * condition que ce texte soit conserv� afin que
 * l'origine de ce logiciel soit reconnue.
 * Le nom de l'Institut National de Recherche en Informatique
 * et en Automatique (INRIA), ou d'une personne morale
 * ou physique ayant particip� � l'�laboration de ce logiciel ne peut
 * �tre utilis� sans son accord pr�alable explicite.
 * 
 * Ce logiciel est fourni tel quel sans aucune garantie,
 * support ou responsabilit� d'aucune sorte.
 * Certaines parties de ce logiciel sont d�riv�es de sources developpees par
 * University of California, Berkeley et ses contributeurs couvertes 
 * par des copyrights.
 * This software is available with usual "research" terms
 * with the aim of retain credits of the software. 
 * Permission to use, copy, modify and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and the name of INRIA, or any contributor not be used in advertising
 * or publicity pertaining to this material without the prior explicit
 * permission. The software is provided "as is" without any
 * warranties, support or liabilities of any kind.
 * This product includes software developed by the University of
 * California, Berkeley and its contributors protected by copyrights.
 *
 *	
 */


#include <assert.h>
#include <malloc.h>


#include <stdio.h>
#include <sys/time.h>


#include <time.h>
#include <signal.h>

//#include "olsr_base.h"   

#include "unix_io_scheduler.h"

#define FATAL(x) do { assert( x == "failed" ); } while(0)

extern void olsr_syslog(char*); /*XXX: in #include */

#if 0
static double tv_to_double(struct timeval tv)
{
  return (double)tv.tv_sec+(double)tv.tv_usec/1000000.0;
}

double get_clock()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv_to_double(tv);
}
#endif

int get_errno() { return errno; }

OLSRTime get_clock()
{ 
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv;
}

void ioscheduler_init(IOScheduler *self)
{
  self->count = 0;
  self->iteration_count = 0;
  self->entry = NULL;
  self->should_block_alarm = 0;
  self->last_clock = get_clock();
}

IOEntryID ioscheduler_add(IOScheduler *self, IOSchedulerEntry entry)
{
  IOEntryID result = self->count;
  int index = -1;
  int i;
  assert(entry.type != IOEntryNone);
  
  for(i=0;i<self->count;i++) {
    if (self->entry[i].type == IOEntryNone) {
      index = i;
      break;
    }
  }
  
  if (index<0) {
    if (self->count == 0) {
      self->entry = (IOSchedulerEntry*) malloc( sizeof(IOSchedulerEntry) );
    } else {
      self->entry = (IOSchedulerEntry*) 
	realloc(self->entry, (self->count+1)*sizeof(IOSchedulerEntry) );
    }
    self->count++;
  } else {
    result = index;
  }
    
  self->entry[result] = entry;
  self->entry[result].creation_iteration_count = self->iteration_count;
  return result;
}

void ioscheduler_remove(IOScheduler *self, IOEntryID entry_id)
{
  assert(entry_id < self->count);
  assert(self->entry[entry_id].type != IOEntryNone);
  self->entry[entry_id].type = IOEntryNone;
}


/*---------------------------------------------------------------------------*/
/* Note:
   'iteration_count' stuff is needed for the following case:
   - an entry is removed during the processing loop
   - an entry is added during the processing loop, with the same entry_id
     as the previous entry
*/
int ioscheduler_schedule(IOScheduler *self, OLSRTime* time_out)
{
  int i,j;
  fd_set set[3];
  int maxFD = -1;
  int status;
  sigset_t sigset;

  /* update the "lastFD" */
  for(i=0;i<self->count;i++) {

    IOSchedulerEntry *entry = &(self->entry[i]);
    if(entry->type == IOEntryFD) {
      for (j=0;j<3;j++)
	entry->lastFD[j] = entry->fd[j];
    } else if (entry->type == IOEntryPoll) {
      for (j=0;j<3;j++) 
	if (entry->getFDFunc[j] == NULL)
	  entry->lastFD[j] = IOEntryNoFD;
	else entry->lastFD[j] = entry->getFDFunc[j](entry);
    } else if (entry->type == IOEntryNone) {
      for(j=0;j<3;j++)
	entry->lastFD[j] = IOEntryNoFD;
    } else FATAL("Impossible");
  }

  /* set fd_set/s */
  maxFD = 0;
  for(j=0;j<3;j++) {
    FD_ZERO(&(set[j]));
    for (i=0;i<self->count;i++) {
      int fd = self->entry[i].lastFD[j];
      if (fd!=IOEntryNoFD) { 
	FD_SET(fd, &(set[j]));
	if (fd>maxFD) maxFD = fd;
      }
    }
  }

  /* select */
  status = select(maxFD+1, set+0, set+1, set+2, time_out);
  self->last_clock = get_clock();
  if (status < 0) {
    if (get_errno() != EINTR) 
      {	
	//olsr_syslog("select: %m");
      }
  } else if (status > 0) {
    self->iteration_count++;
    ioscheduler_start_processing(self, &sigset);

    for(j=0;j<3;j++) 
      {
	for(i=0;i<self->count;i++) 
	  {
	    IOSchedulerEntry *entry = &(self->entry[i]);
	    int fd = entry->lastFD[j];
	    if (entry->creation_iteration_count<self->iteration_count 
		&& entry->type != IOEntryNone
		&& fd!=IOEntryNoFD && fd<=maxFD && FD_ISSET(fd, &(set[j]))) 
	      {
		FD_CLR(fd, &(set[j]));
		assert( entry->callBackFunc[j] != NULL );
		entry->callBackFunc[j](entry);
	      }
	  }
      }
    
    ioscheduler_stop_processing(self, &sigset);
  }
  return status != 0; /* time out */
}

void ioscheduler_start_processing(IOScheduler *self, sigset_t* osigset)
{

  sigset_t sigset;
  if(self->should_block_alarm) {
    sigemptyset(&sigset);
    sigaddset(&sigset, SIGALRM);
    sigaddset(&sigset, SIGPIPE); /* XXX: check this */
    sigprocmask(SIG_BLOCK, &sigset, osigset);
    sigaddset(osigset, SIGPIPE); /* XXX!!! kludge */
  }

}

void ioscheduler_stop_processing(IOScheduler *self, sigset_t* sigset)
{


  if(self->should_block_alarm)
		sigprocmask(SIG_SETMASK, sigset, NULL);


}

void ioscheduler_entry_init(IOSchedulerEntry* self, int type)
{
  int i;
  assert(type == IOEntryFD || type == IOEntryPoll);
  self->type = type;
  for(i=0;i<3;i++) {
    self->fd[i] = IOEntryNoFD;
    self->lastFD[i] = IOEntryNoFD; /* for when created in callbacks */
    self->callBackFunc[i] = NULL;
    self->getFDFunc[i] = NULL;
  }
}

/*---------------------------------------------------------------------------*/
