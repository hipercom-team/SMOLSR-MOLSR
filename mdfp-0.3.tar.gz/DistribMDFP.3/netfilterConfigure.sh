#sh!
#Comment the following line if the ip_queue is compiled within the kernel
modprobe ip_queue

#Delete previous rules 
iptables --flush

iptables -A OUTPUT -d 224.0.0.0/4 -p udp -j QUEUE
iptables -A INPUT  -d 127.0.0.1 -j QUEUE

BROADCASTADD1=192.168.3.255
iptables -A INPUT  -d $BROADCASTADD1 -p udp -j QUEUE

# Add broadcast addresses corresponding to the attached interfaces
# and uncomment the adequate lines

#BROADCASTADD2=128.93.255.255
#iptables -A INPUT  -d $BROADCASTADD2 -p udp -j QUEUE

#BROADCASTADD3=255.255.255.255
#iptables -A INPUT  -d $BROADCASTADD3 -p udp -j QUEUE
