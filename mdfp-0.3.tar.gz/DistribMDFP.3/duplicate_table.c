//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
/*
 * This Copyright notice is in French. An English summary is given
 * but the referee text is the French one.
 *
 * Copyright (c) 2000, 2001, 2002, 2003
 *   Adokoe.Plakoo@inria.fr, INRIA Rocquencourt,
 *   Anis.Laouiti@inria.fr, INRIA Rocquencourt.
 *   Cedric.Adjih@inria.fr, INRIA Rocquencourt.
 *
 * Ce logiciel informatique est disponible aux conditions
 * usuelles dans la recherche, c'est-�-dire qu'il peut
 * �tre utilis�, copi�, modifi�, distribu� � l'unique
 * condition que ce texte soit conserv� afin que
 * l'origine de ce logiciel soit reconnue.
 * Le nom de l'Institut National de Recherche en Informatique
 * et en Automatique (INRIA), ou d'une personne morale
 * ou physique ayant particip� � l'�laboration de ce logiciel ne peut
 * �tre utilis� sans son accord pr�alable explicite.
 * 
 * Ce logiciel est fourni tel quel sans aucune garantie,
 * support ou responsabilit� d'aucune sorte.
 * Certaines parties de ce logiciel sont d�riv�es de sources developpees par
 * University of California, Berkeley et ses contributeurs couvertes 
 * par des copyrights.
 * This software is available with usual "research" terms
 * with the aim of retain credits of the software. 
 * Permission to use, copy, modify and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and the name of INRIA, or any contributor not be used in advertising
 * or publicity pertaining to this material without the prior explicit
 * permission. The software is provided "as is" without any
 * warranties, support or liabilities of any kind.
 * This product includes software developed by the University of
 * California, Berkeley and its contributors protected by copyrights.
 *
 *	$Id: duplicate_table.c,v 1.3 2004/11/05 15:16:58 laouiti Exp $
 */

/*
 * Routing table management daemon.
 */




#include "definition.h"

struct duplicatehash              duplicatetable[HASHSIZE];
struct timeval hold_time_duplicate;
double duplicate_hold_time    = DUPLICATE_HOLD_TIME;

/*------------------------------------------------------------------------*/


void mdfp_delete_duplicate_table(struct duplicate_entry *dup_entry)
{

  //char action[200];

  // sprintf(action, "MSG Seq Num %d REMOVED FROM DUPLI-TABLE.\n MSG Originator",
  //  dup_entry->duplicate_seq);

  //  TRACE_ACTION(action, &dup_entry->duplicate_addr, (Iface *)NULL, 
  //       &dup_entry->duplicate_timer);
  
  mdfp_remque((struct mdfp_qelem *)dup_entry);
  free((void *)dup_entry);

}


/*------------------------------------------------------------------------*/


void mdfp_insert_duplicate_table(struct message_header *message)
{
  u_int32_t hash;
  struct duplicatehash   *dup_hash;
  struct duplicate_entry *dup_message;
  //char action[200];
  
  dup_message = (struct duplicate_entry *)malloc(sizeof(*dup_message));

  dup_message->duplicate_seq = message->msg_seq_number;
  memcpy(&dup_message->duplicate_addr, &message->originator, 
	 sizeof(message->originator));  
  timeradd(&globalVar.now, &hold_time_duplicate, &dup_message->duplicate_timer);

  mdfp_hashing(&dup_message->duplicate_addr, &hash);
  dup_message->duplicate_hash = hash;
  dup_hash = &duplicatetable[hash & HASHMASK];

  //sprintf(action, "MSG Seq Num %d INSERTED IN DUPLI-TABLE.\n Originator",
  //	  dup_message->duplicate_seq);

  // TRACE_ACTION(action, &dup_message->duplicate_addr, (Iface *)NULL, 
  //	       &dup_message->duplicate_timer);

  mdfp_insque((struct mdfp_qelem *)dup_message, 
	      (struct mdfp_qelem *)dup_hash);

  /*  if (schedule_dup_del) {
      schedule_dup_del = 0;
      schedule_event(DUPLI_DEL, &events_head);
      }
  */
}


/*------------------------------------------------------------------------*/


struct duplicate_entry \
 *mdfp_lookup_src_duplicate_table(struct message_header *message)
{
  struct duplicate_entry *dup_message;
  struct duplicatehash   *dup_hash;
  u_int32_t               hash;

  mdfp_hashing(&message->source_addr, &hash);
  
  dup_hash = &duplicatetable[hash & HASHMASK];
  
  for(dup_message = dup_hash->duplicate_forw;
      dup_message != (struct duplicate_entry *)dup_hash;
      dup_message = dup_message->duplicate_forw)
    {
      
      if(dup_message->duplicate_hash != hash)
	continue;

      if ( (!memcmp(&dup_message->duplicate_addr, &message->source_addr,
		     sizeof(message->source_addr)) )
	  &&(dup_message->duplicate_seq == message->msg_seq_number) )

	  return (dup_message);
    }
  return (NULL);
}


/*------------------------------------------------------------------------*/


struct duplicate_entry \
 *mdfp_lookup_duplicate_table(struct message_header *message)
{
  struct duplicate_entry *dup_message;
  struct duplicatehash   *dup_hash;
  u_int32_t               hash;

  mdfp_hashing(&message->originator, &hash);
  
  dup_hash = &duplicatetable[hash & HASHMASK];
  
  for(dup_message = dup_hash->duplicate_forw;
      dup_message != (struct duplicate_entry *)dup_hash;
      dup_message = dup_message->duplicate_forw)
    {
      
      if(dup_message->duplicate_hash != hash)
	continue;

      if ( (!memcmp(&dup_message->duplicate_addr, &message->originator,
		     sizeof(message->originator)) )
	  &&(dup_message->duplicate_seq == message->msg_seq_number) )

	  return (dup_message);
    }
  return (NULL);
}


/*------------------------------------------------------------------------*/


void mdfp_release_duplicate_table()
{
  u_int8_t               index;
  struct duplicatehash   *dup_hash;
  struct duplicate_entry *dup_message;
  struct duplicate_entry *dup_message_tmp;

  for(index = 0; index < HASHSIZE; index++)
    {
      dup_hash = &duplicatetable[index];
      dup_message = dup_hash->duplicate_forw;
      while(dup_message != (struct duplicate_entry *)dup_hash)
	{
	  dup_message_tmp = dup_message;
	  dup_message = dup_message->duplicate_forw;
	  mdfp_delete_duplicate_table(dup_message_tmp);
	}
    }
}


/*------------------------------------------------------------------------*/


void mdfp_time_out_duplicate_table()
{
  u_int8_t               index;
  struct duplicatehash   *dup_hash;
  struct duplicate_entry *dup_message;
  struct duplicate_entry *dup_message_tmp;
  // struct timeval          nearest_timer;
  // int                     existing_elem = 0;

  // TRACE_ACTION(" ######### DUPLICATE TIME OUT.", NULL, NULL, NULL);

  //timeradd(&globalVar.now, &hold_time_duplicate, &nearest_timer);
  
  for(index = 0; index < HASHSIZE; index++)
    {
      dup_hash = &duplicatetable[index];
      dup_message = dup_hash->duplicate_forw;
      while(dup_message != (struct duplicate_entry *)dup_hash)
	{

	  if( mdfp_timed_out(&dup_message->duplicate_timer) )
	    {
	      dup_message_tmp = dup_message;
	      dup_message = dup_message->duplicate_forw;
	      mdfp_delete_duplicate_table(dup_message_tmp);
	    }
	  else
	    {
	      //      if( timercmp(&nearest_timer, &dup_message->duplicate_timer, >) )
	      //      memcpy(&nearest_timer, &dup_message->duplicate_timer,
	      //       sizeof(nearest_timer));
	      dup_message = dup_message->duplicate_forw;
	    }
	    
	  //existing_elem = 1;
	}
    }

  /* if( !existing_elem )
     schedule_dup_del = 1;
     else {
     struct timeval tp;
     timersub(&nearest_timer, &globalVar.now, &tp);
     
     schedule_event_with_timer(DUPLI_DEL, &tp, &events_head);
     }
  */

  // TRACE_ACTION("           END TIME OUT. #########", NULL, NULL, NULL);

}


/*------------------------------------------------------------------------*/
