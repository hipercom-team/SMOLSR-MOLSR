//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
#include "definition.h"
struct ClientLocal_Entry *clientLocaltable=NULL;


void mdfp_release_ClientLocal_list(struct ClientLocal_Entry *clientList)
{
struct ClientLocal_Entry *tmpClient;
struct ClientLocal_Entry *client;

 client=clientList;
 while(client)
   {
     tmpClient=client->next;
     free(client);
     client=tmpClient;     	
   }
}
//---------------------------------------------------------------------------
int mdfp_find_Client_list(struct ClientLocal_Entry *client,struct ClientLocal_Entry *clientList)
{
 struct ClientLocal_Entry *tmpClient;
 tmpClient=clientList;
 while(tmpClient)
   {
     if((client->cliLocal_addr==tmpClient->cliLocal_addr)
	&&(client->cliLocal_group==tmpClient->cliLocal_group))
       return 1;
     tmpClient=tmpClient->next;	
   }
 return 0;
}
//---------------------------------------------------------------------------
struct ClientLocal_Entry *mdfp_extract_ClientLocal_diff(struct ClientLocal_Entry *clientList1,struct ClientLocal_Entry *clientList2)
{
  //gets elements from  clientList1 which does not exist in clientList2
  struct ClientLocal_Entry *diffClientList=NULL;
  struct ClientLocal_Entry *tmpClient;
  struct ClientLocal_Entry *diffClient=NULL;

  tmpClient=clientList1;
  
  while(tmpClient)
    {
      if(!mdfp_find_Client_list(tmpClient,clientList2))
	{
	  diffClient=(struct ClientLocal_Entry *)malloc(sizeof(struct ClientLocal_Entry));

	  diffClient->cliLocal_addr=tmpClient->cliLocal_addr;
	  diffClient->cliLocal_group=tmpClient->cliLocal_group;

	  diffClient->next=diffClientList;
	  diffClientList=diffClient;
	}
      tmpClient=tmpClient->next;
    }
  return diffClientList;
}

//---------------------------------------------------------------------------
struct  ClientLocal_Entry *mdfp_get_localClients()
{
  struct igmpProcIface *igmpProcContent;
  struct igmpProcIface *igmpIface;
  struct igmpProcMLine *igmpIfaceGroup;
  struct ClientLocal_Entry *currentClientList=NULL;
  struct ClientLocal_Entry *clientItem;
  
  ip_addr ifaceAddr;
  igmpProcContent=get_igmp_info();
  if (igmpProcContent)
    {
      igmpIface=igmpProcContent;
      while(igmpIface)
	{
	  ifaceAddr=get_iface_addr_by_index(globalCom.configuredIfaces,igmpIface->ifindex);
	  if(olsr_configured_iface(&ifaceAddr))
	    {
	      igmpIfaceGroup=igmpIface->mlist;
	      while(igmpIfaceGroup)
		{
		  clientItem=(struct ClientLocal_Entry *)malloc(sizeof(struct ClientLocal_Entry));
		  clientItem->cliLocal_addr=ifaceAddr;
		  clientItem->cliLocal_group=igmpIfaceGroup->multiaddr;
		  clientItem->next=currentClientList;
		  currentClientList=clientItem;
		  
		  igmpIfaceGroup=igmpIfaceGroup->next;
		}
	    }
	  igmpIface=igmpIface->next;
	}
      freeIgmpContent(igmpProcContent);
      return (currentClientList);
    }
  
  return (NULL);
}
//---------------------------------------------------------------------------
int fill_local_mdfp_header(struct mdfp *mdfpPacket,int packLen,unsigned int type)
{
  struct MDFPMsg *mdfpMsg;

  mdfpPacket->packseqnum=0;
  mdfpPacket->packlen=htons(packLen);
  
  
  mdfpMsg=mdfpPacket->msg;
  mdfpMsg->msgtype=type;
  mdfpMsg->res[0]=0;
  mdfpMsg->msgsize=htons(packLen-globalMDFP.phSize);//(globalMDFP.mhSize+globalMDFP.phSize)); //HEADER 
  
  mdfpMsg->ttl=1; 
  mdfpMsg->hopcnt=0;
  mdfpMsg->msgseqnum=0;
  
  if(globalMDFP.molsrInfo.mainAddress)    
    memcpy(&mdfpMsg->origaddr,globalMDFP.molsrInfo.mainAddress,sizeof(ip_addr));
  else
    return 0;
  
  return 1;

}
//---------------------------------------------------------------------------
int get_clientList_size(struct  ClientLocal_Entry *clientList)
{
  struct ClientLocal_Entry *clientItem;
  int newLeaveMsgSize=0;
  clientItem=clientList;

  while(clientItem)
    {
      clientItem=clientItem->next;
      newLeaveMsgSize++;
    }
return (newLeaveMsgSize);
}
//---------------------------------------------------------------------------
void mdfp_tell_MOLSR_NewLeave_localClient(struct  ClientLocal_Entry *clientList,unsigned int type)
{
  int newLeaveMsgSize;
  struct mdfp *mdfpPacket;
  unsigned int packLen;
  struct MDFPMsg *mdfpMsg;
  struct LeaveNewLocalSrcClient *clientMsg;
  struct ClientLocal_Entry *clientItem;
  if(!clientList)
    return;
  
  newLeaveMsgSize=sizeof(struct LeaveNewLocalSrcClient)*(get_clientList_size(clientList));
  packLen=globalMDFP.mhSize+globalMDFP.phSize+newLeaveMsgSize;
  mdfpPacket=(struct mdfp *)malloc(packLen);
  
  if(!fill_local_mdfp_header(mdfpPacket,packLen,type))
    {
      free(mdfpPacket);
      return;
    }
  
  mdfpMsg=mdfpPacket->msg;
  clientMsg=(struct LeaveNewLocalSrcClient*)mdfpMsg->payload;
  clientItem=clientList;

  while(clientItem)
    {
      clientMsg->srcCli=clientItem->cliLocal_addr;
      clientMsg->group=clientItem->cliLocal_group;
      clientMsg++;
      clientItem=clientItem->next;
    }

 send_to_network( globalCom.olsrComSocket,(char *)mdfpPacket,packLen,globalCom.olsrComAddressTo);
}
//---------------------------------------------------------------------------
void mdfp_process_localClient_updates()
{
  struct  ClientLocal_Entry *currentClientList;
  struct  ClientLocal_Entry *leaveClientList;
  struct  ClientLocal_Entry *newClientList;

  currentClientList=mdfp_get_localClients();

  //leaveClientList=mdfp_extract_ClientLocal_diff(currentClientList,clientLocaltable);
  //newClientList=mdfp_extract_ClientLocal_diff(clientLocaltable,currentClientList);

  newClientList=mdfp_extract_ClientLocal_diff(currentClientList,clientLocaltable);
  leaveClientList=mdfp_extract_ClientLocal_diff(clientLocaltable,currentClientList);
  if(globalMDFP.molsrInfo.mainAddress)
    {
      mdfp_tell_MOLSR_NewLeave_localClient(leaveClientList,LEAVE_CLIENT);
      mdfp_tell_MOLSR_NewLeave_localClient(newClientList,NEW_CLIENT);
    }
  mdfp_release_ClientLocal_list(leaveClientList);
  mdfp_release_ClientLocal_list(newClientList);
  mdfp_release_ClientLocal_list(clientLocaltable);

  clientLocaltable=currentClientList;
}

//---------------------------------------------------------------------------
void mdfp_tell_MOLSR_localClientContent()
{

 mdfp_tell_MOLSR_NewLeave_localClient(clientLocaltable,NEW_CLIENT);
}

//---------------------------------------------------------------------------
