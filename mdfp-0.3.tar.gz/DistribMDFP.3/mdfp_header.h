//-------------------------------------------------------------------*- c -*-
////                                MDFP
////         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
////          
////  Copyright 2003-2004 Institut National de Recherche en Informatique et
////  en Automatique.  All rights reserved.  Distributed only with permission.
////---------------------------------------------------------------------------
//
/*
 * Hello message informations
 */

#define     HOPCNT_MAX              16      /* maximum hops number */



#define DATA_MULTICAST_MESSAGE      32

#define MSG_RESERVED       1
#define HELLO_RESERVED     2
#define MSG_TC_RESERVED    2

#define IFACE_MSG               3 //41
#define MCTREE_MSG              31//42
#define SMOLSR_MSG              32
 
#define NBS_SYM                 2               /* bi-directional link */

struct linkinfo {
  smolsr_u8_t    link_type;            /* link type */
  smolsr_u8_t    link_interface_num;   /* interface number */
  smolsr_u16_t   link_size;            /* link msg size measured from 
					the beginning of this struct
					to its end including
					following addresses. */
  smolsr_ip_addr link_neigh_interf_addr[1]; /* neighbor interface  
					     address (variable length)*/
};


struct hellomsg {
  smolsr_u8_t    hell_res[HELLO_RESERVED];/* padding   */
  smolsr_u8_t    hell_willing;            /* "willingness" of the sender
					   to act as a multipoint relay.
					*/
  smolsr_u8_t   hell_nb_add_interf;       /* number of additional 
					   MANET interfaces. */
  smolsr_ip_addr hell_interf_addr[1];     /* additional MANET interface 
					   address (variable length) */
  struct linkinfo hell_link_info[1];    /* (variable length) */
};


/*
 * Topology Control message informations.
 */
/* tcmsg is already  declared in  linux/rtnetlink.h  so we use tcmsg_ instead*/
struct tcmsg_ {
  smolsr_u16_t   tc_mssn;                 /* mpr selector sequence 
					   number. It's incremented 
					   evry time a node detectes 
					   a change in its MPR 
					   selector set */
  smolsr_u8_t    tc_res[MSG_TC_RESERVED];     /* pad to 32-bit boundary  */
  smolsr_ip_addr tc_advertized_link[1];	/* mprs address 
					 (variable length)*/
};
/*------------------------------------------------------------------------*/
struct MCTreeEntry {
  ip_addr ifaceAddr;            /* The address of the outgoing iface */
  ip_addr parentAddr;
  ip_addr sourceAddr;
  ip_addr groupAddr;
  
};

struct LeaveNewLocalSrcClient{
  ip_addr srcCli;
  ip_addr group;

};

struct MDFPMsg {

  u_int8_t    msgtype;           /* msg type set to DATA_MULTICAST*/
  
  u_int8_t    res[MSG_RESERVED]; /* pad to 32-bit boundary */
  
  u_int16_t   msgsize;           /* msg size measured from
				    the beginning of this
				    struct to its end */
  ip_addr     origaddr;	         /* Originator address of 
				    the message */
  u_int8_t    ttl;               /* time to live. Maximum
				    number of hops a message
				    will be retransitted */
  u_int8_t    hopcnt;            /* hop count. Number of hops
				    a message has attained */
  u_int16_t   msgseqnum;         /* msg sequence number */
  
  
  char payload[0];               /* the encapsulated packet or the
				    set of information send by MOLSR */
};

struct mdfp {
   u_int16_t    packlen;	 /* packet length */
   u_int16_t	packseqnum;	 /* packet sequence number */
  struct MDFPMsg msg[1];
};




