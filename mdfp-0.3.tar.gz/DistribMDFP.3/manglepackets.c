//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "definition.h"

#define BUFSIZE 2048
#define PORT_MDFP 1699

struct global_MDFP globalMDFP;
struct global_Com  globalCom;
struct global_Var  globalVar;


/*---------------------------------------------------------------------------*/
void dump_data(void* data, int size)
{
  int i=0;
  for(i=0;i<size;i++) {
    if ((i%16)==0 && i>0) printf("\n");
    printf("%02x ", ((unsigned char*)data)[i]);
  }
  printf("\n");
}

/*---------------------------------------------------------------------------*/
void dump_molsr_information()
{
  int i;
  
  if(globalVar.trace)
    {
      fprintf(globalVar.traceFD," %ld - [RECEIVED MOLSR INFORMATION]:",globalVar.now.tv_sec);
      fprintf(globalVar.traceFD,"Main Address= %s ;",
	      inet_ntoa(*( (struct in_addr *) globalMDFP.molsrInfo.mainAddress)));
      
      fprintf(globalVar.traceFD,"Other OLSR-MOLSR interfaces ("); 
      for(i=0;i<globalMDFP.molsrInfo.ifaceNumber;i++)
	{
	  fprintf(globalVar.traceFD,"-InterfaceAddress: %s ",
		  inet_ntoa(*( (struct in_addr *) &globalMDFP.molsrInfo.listIface[i])));
	}
      fprintf(globalVar.traceFD,");");
      
      
      fprintf(globalVar.traceFD,"MC Tree table (");
      for(i=0;i<globalMDFP.molsrInfo.mcEntryNumber;i++)
	{
	  fprintf(globalVar.traceFD,"["); 
	  fprintf(globalVar.traceFD,"MulticastGroup=%s,",
		  inet_ntoa(*( (struct in_addr *) &globalMDFP.molsrInfo.mcTreeTable[i].groupAddr))); 
	  fprintf(globalVar.traceFD,"SourceAddress=%s,",
		  inet_ntoa(*( (struct in_addr *) &globalMDFP.molsrInfo.mcTreeTable[i].sourceAddr))); 
	  fprintf(globalVar.traceFD,"ParentAddress=%s,",
		  inet_ntoa(*( (struct in_addr *) &globalMDFP.molsrInfo.mcTreeTable[i].parentAddr))); 
	  fprintf(globalVar.traceFD,"OutgoingInterface=%s",
		  inet_ntoa(*( (struct in_addr *) &globalMDFP.molsrInfo.mcTreeTable[i].ifaceAddr))); 
	  fprintf(globalVar.traceFD,"]"); 
	}
      fprintf(globalVar.traceFD,")\n");
    
    }
}
/*---------------------------------------------------------------------------*/
void destroy_handle(struct ipq_handle *handle)
{
  /*
    destroys the ipq handle
   */
  ipq_perror("Error");
  ipq_destroy_handle(handle);
  exit(1);
}

/*---------------------------------------------------------------------------*/
int check_ttl(char *data)

{
 struct iphdr *ipHeader;
 
  
  ipHeader=(struct  iphdr *)data;
  if(ipHeader->ttl>0)
    return 1;
  else
    return 0;
  
}
/*---------------------------------------------------------------------------*/
struct sockaddr * get_sockaddr(unsigned int port,const char * addrString)
{
  /*
    returns a socket address initilized with port value and the ip address
    corresponding to addrString
   */
  struct sockaddr_in *address;
  address=(struct sockaddr_in *)malloc(sizeof(struct sockaddr_in));
  address->sin_family = AF_INET;
  address->sin_port = htons(port);
  address->sin_addr.s_addr = inet_addr(addrString); //0.0.0.0 for INADDR_ANY 
  return ((struct sockaddr *)address);
}

/*---------------------------------------------------------------------------*/
int open_socket(struct sockaddr * address)
{
  /*
    opens a socket and bind it to address
   */
  int sockFd;
  int on = 1;

  if ( (sockFd=socket(PF_INET,SOCK_DGRAM,0))<0)
    
    {
      fprintf(stderr,"Error in openening socket \n");
      return (-1);
    }

  // setsockopt(sockFd,SOL_SOCKET, SO_REUSEPORT,&on, sizeof (on));
  setsockopt(sockFd,SOL_SOCKET, SO_REUSEADDR,&on, sizeof (on));

  if (fcntl(sockFd, F_SETFL, O_NONBLOCK) == -1)
    {
      fprintf(stderr,"Error in fcntf \n");
    }

  if (bind(sockFd,(struct sockaddr *) address,sizeof(struct sockaddr))< 0)
    {
      fprintf(stderr,"Error in binding socket \n");
      close(sockFd);
      exit (-1);
      return (-1);
    }
  return(sockFd);
}

/*---------------------------------------------------------------------------*/
void print_packet_info(ipq_packet_msg_t *m)
{
  /*
    prints some information about the ip packet contained in m
  */
  struct iphdr *ipHeader;
  struct udphdr   *udpHeader;
  
  ipHeader=(struct  iphdr *)m->payload;
  udpHeader=(struct udphdr *)((char *)ipHeader+sizeof(struct iphdr));
  printf("packetsize %d\n",m->data_len);
  printf("UDP checksum is %d\n",udpHeader->check);
  printf("Source Address %s:%d\n",inet_ntoa( *( (struct in_addr *) &ipHeader->saddr)), ntohs(udpHeader->source));
  printf("Destination Address %s:%d\n",inet_ntoa( *( (struct in_addr *) &ipHeader->daddr ) ), ntohs(udpHeader->dest) );
  
}
/*---------------------------------------------------------------------------*/
void fill_mdfp_header(struct mdfp *mdfpPacket,unsigned int msgSize,struct message_header *msgHeader)
{
  /*
    fills the mdfp_header
  */

  struct MDFPMsg *mdfpMsg;
  
  mdfpPacket->packseqnum=htons(globalMDFP.packseqnum++);
  mdfpPacket->packlen=htons(msgSize);

  mdfpMsg=mdfpPacket->msg;
  mdfpMsg->msgtype=DATA_MULTICAST_MESSAGE;
  mdfpMsg->res[0]=0;
  mdfpMsg->msgsize=htons(msgSize-(globalMDFP.mhSize+globalMDFP.phSize)); //HEADER 
  memcpy(&mdfpMsg->origaddr,&msgHeader->originator,sizeof(ip_addr));
  mdfpMsg->ttl=HOPCNT_MAX; 
  mdfpMsg->hopcnt=0;
  mdfpMsg->msgseqnum=htons(globalMDFP.msgseqnum++);
  
  
}
/*---------------------------------------------------------------------------*/
int encapsulate_packet (int sockFd,char * payload,int len ,struct sockaddr *address,struct message_header *msgHeader)
{
  /*
    encapsulates a packet in an MDFP message
   */

  char *buffer; 
  struct mdfp  *mdfp_msg;
  int msgSize;
  int generatedPacket=0;

  if(debug>=3) 
    {
      printf("Encapsulate packet, before:\n");
      dump_data(payload, len);
    }

  /*
    add the MDFP msg header and check if the global size
  */
  msgSize= (globalMDFP.mhSize+globalMDFP.phSize) +len; //HEADER+len
  if (msgSize > MAXMSGSIZE)
    {
      fprintf(stderr, "Message size exceeds the maximum allowed size %d\n",msgSize);
      return(-1);
    }

  buffer=(char *) malloc(msgSize); 
  mdfp_msg= (struct mdfp *)buffer;
  fill_mdfp_header(mdfp_msg,msgSize,msgHeader);
  memcpy(&mdfp_msg->msg->payload,payload,len);

  //if(sendto(sockFd ,payload,len,0,address,sizeof(struct sockaddr))<0)
  // perror("sendto");
  // XXX: Cedric: change this, bug???, was:
  //send_to_network(sockFd, payload,len,address);
  if(debug>=3) 
    {
      printf("Encapsulate packet, after:\n");
      dump_data(buffer, msgSize);
      printf("----\n");
    }

  if(globalVar.forwardingMode==MOLSRMODE)
    generatedPacket=mdfp_multicast_routing(sockFd, buffer,msgSize,address,msgHeader);
  else
    mdfp_smolsr_routing(sockFd, buffer,msgSize,address,msgHeader);

  free(buffer);
  return(generatedPacket);
}
/*---------------------------------------------------------------------------*/
int mdfp_multicast_routing(int sockFd, char *payload, int len, struct sockaddr *address,struct message_header *msgHeader)
{
  /*
    send packet for sons on corresponding interfaces given by MCTree table
  */
  int i;
  int generatedPacket=0;
  struct msghdr packet;
  struct  iovec iovsend[1];
  ip_addr parent=0;
  

//  if(!olsr_configured_iface(&msgHeader->originator))
 //   parent=msgHeader->source_addr;

  memset(&packet,0,sizeof(struct msghdr));

  packet.msg_name=address;
  packet.msg_namelen=sizeof(struct sockaddr);
  iovsend[0].iov_base=payload;
  iovsend[0].iov_len=len;
  packet.msg_iov=iovsend;
  packet.msg_iovlen=1;
  
 
  
  for(i=0;i<globalMDFP.molsrInfo.mcEntryNumber;i++)
    {
      
      if((globalMDFP.molsrInfo.mcTreeTable[i].sourceAddr==msgHeader->originator)&&
	 (globalMDFP.molsrInfo.mcTreeTable[i].groupAddr==msgHeader->destination_addr)&&
//	 (globalMDFP.molsrInfo.mcTreeTable[i].parentAddr==parent))
	(globalMDFP.molsrInfo.mcTreeTable[i].parentAddr==msgHeader->source_addr))
	{
	  ((struct sockaddr_in *)address)->sin_addr.s_addr=get_iface_broadcast_by_addr(globalCom.configuredIfaces,&globalMDFP.molsrInfo.mcTreeTable[i].ifaceAddr); 

	  if( sendmsg(sockFd,&packet,0)<0)
	    {
	      perror("sendmsg");
	    }
	  else
	    generatedPacket=1;
	}
    }
  return(generatedPacket);
}

/*---------------------------------------------------------------------------*/
int mdfp_smolsr_routing(int sockFd, char *payload, int len, struct sockaddr *address,struct message_header *msgHeader)
{
  /*
    send packet for sons on corresponding interfaces given by MCTree table
  */
  int i;
  int generatedPacket=0;
  struct msghdr packet;
  struct  iovec iovsend[1];
  ip_addr parent=0;
  

//  if(!olsr_configured_iface(&msgHeader->originator))
 //   parent=msgHeader->source_addr;

  memset(&packet,0,sizeof(struct msghdr));

  packet.msg_name=address;
  packet.msg_namelen=sizeof(struct sockaddr);
  iovsend[0].iov_base=payload;
  iovsend[0].iov_len=len;
  packet.msg_iov=iovsend;
  packet.msg_iovlen=1;
  
  for(i=0;i<globalMDFP.molsrInfo.ifaceNumber;i++)
    {       
      ((struct sockaddr_in *)address)->sin_addr.s_addr=get_iface_broadcast_by_addr(globalCom.configuredIfaces,globalMDFP.molsrInfo.listIface[i]); 
      
      if( sendmsg(sockFd,&packet,0)<0)
	{
	  perror("sendmsg");
	}
      else
	generatedPacket=1;
    }
  
  ((struct sockaddr_in *)address)->sin_addr.s_addr=get_iface_broadcast_by_addr(globalCom.configuredIfaces,globalMDFP.molsrInfo.mainAddress); 
  
  if( sendmsg(sockFd,&packet,0)<0)
    {
      perror("sendmsg");
    }
  else
    generatedPacket=1;
  
  
  return(generatedPacket);
}
/*---------------------------------------------------------------------------*/
int send_to_network(int sockFd, char *payload, int len, struct sockaddr *address)
{
  
  int i;
  struct msghdr packet;
  struct  iovec iovsend[1];
  ip_addr parent=0;
  
  memset(&packet,0,sizeof(struct msghdr));

  packet.msg_name=address;
  packet.msg_namelen=sizeof(struct sockaddr);
  iovsend[0].iov_base=payload;
  iovsend[0].iov_len=len;
  packet.msg_iov=iovsend;
  packet.msg_iovlen=1;
  
 
  if( sendmsg(sockFd,&packet,0)<0)
    {
      perror("sendmsg");
    }
	    
  return(0);
}
/*---------------------------------------------------------------------------*/
void time_out_olsr_info()
{
  /*
    discards stalled  OLSR/MOLSR information (main address, interfaces,...)
   */
  if(mdfp_timed_out(&globalMDFP.molsrInfo.timeOut))
    {
      init_global_molsr_information();
    }
}
/*---------------------------------------------------------------------------*/
void init_schedule_time_out(struct timeval *period)
{
  /*
    initilizes the schedule timeout
  */
  gettimeofday(&globalVar.now, NULL);
  timeradd(&globalVar.now,period,&globalVar.nextTimeOutEvent);
  globalVar.schedulerTimeOut=*period;
}
/*---------------------------------------------------------------------------*/
int process_schedule_time_out(int status)
{
  /*
    if timeout expires:
          - delete the obsolete duplicate entries
	  - check the validity of the olsr information
	  - check the /proc/net/igmp file to find the 
	  membership updates
    else
          - adjust the timeout to remaining time
   */

  if(status==0) /*timeout of the scheduler */
    { 
      mdfp_time_out_duplicate_table();
      mdfp_time_out_SourceLocal_table();          
      mdfp_process_localClient_updates();
      time_out_olsr_info();     
      init_schedule_time_out(&globalVar.timerPeriod);
    }
  else
    
    {
      
      gettimeofday(&globalVar.now, NULL);
      if(timercmp(&globalVar.nextTimeOutEvent,&globalVar.now , >) )
	{
	  timersub(&globalVar.nextTimeOutEvent,&globalVar.now,&globalVar.schedulerTimeOut);
	}
      else
	{
	  globalVar.nextTimeOutEvent=globalVar.now; 
	  timerclear(&globalVar.schedulerTimeOut);
	}
      }
  
	
  return 0;
}
/*---------------------------------------------------------------------------*/
int encapsulate_forward(int sockFd,struct mdfp *mdfpPacket,int len ,struct sockaddr *address,struct message_header *msgHeader)
{
  /*
    forward the encapsulated packet after updating the mdfp message header
  */
  struct  MDFPMsg* mdfpMsg;


 /*modify the MDFP Header and forward the message */
  mdfpPacket->packseqnum=htons(globalMDFP.packseqnum++);

  mdfpMsg=mdfpPacket->msg;
  
  mdfpMsg->hopcnt=msgHeader->hop_count;
  mdfpMsg->ttl=msgHeader->ttl;
  
  
  //sendto(sockFd ,(char *)mdfpPacket,len,0,address,sizeof(struct sockaddr));
 
  if(globalVar.forwardingMode==MOLSRMODE)
    mdfp_multicast_routing(sockFd, (char *)mdfpPacket,len,address,msgHeader);
  else
    mdfp_smolsr_routing(sockFd,(char *)mdfpPacket,len,address,msgHeader);
  
  return(0);
}
/*---------------------------------------------------------------------------*/
int ipip_encapsulation(ipq_packet_msg_t *m, char **data)
{
  /*
    Add an ip header in order to send this packet locally (loopback address)
  */
  int len=0;
  struct iphdr * ipipHeader;
  struct iphdr *ipHeader;
 
  len=sizeof(struct iphdr) + m->data_len;
  ipHeader=(struct  iphdr *)m->payload;

  ipipHeader=(struct iphdr *)malloc(len);
  
  memcpy(ipipHeader,ipHeader,sizeof(struct iphdr));
  
  memcpy(ipipHeader,ipHeader,sizeof(struct iphdr));
  ipipHeader->daddr=htonl(INADDR_LOOPBACK);
  //ipipHeader->daddr=inet_addr("127.0.0.1");
  ipipHeader->check=0;
	    
	    
  ipipHeader->tot_len=htons(len);
  ipipHeader->protocol=IPPROTO_IPIP;

  ipipHeader->check=(unsigned short)in_cksum((unsigned short *)ipipHeader,sizeof(struct iphdr));
  
  memcpy(ipipHeader+1,m->payload,m->data_len);

  *data =(char *)ipipHeader;
  return(len);
}
/*---------------------------------------------------------------------------*/
int decapsulate_packet(char **mdfp_msg,ipq_packet_msg_t *m, char **data_packet)
{
  char *data;
  char *msg;
  int len=0;
  

  /*
    extract and copy data from the ipq_packet_msg given in the header
  */

  if(debug>=3) 
    {
      printf("Decapsulate packet, before:\n");
      dump_data(m->payload, m->data_len);
    }

  
  data=(char *)((char *)m->payload+sizeof(struct udphdr)+sizeof(struct iphdr));
  len=m->data_len - (sizeof(struct udphdr)+sizeof(struct iphdr));
  msg=(char *)malloc(len);
  /* XXX: CA: changed (bug???), was: */
  /*memcpy(mdfp_msg,data,len);*/ /* copy of the message body + MDFP Header */
  memcpy(msg,data,len);
  *mdfp_msg=msg;		     

  data=(char *)((char *)m->payload+sizeof(struct udphdr)+sizeof(struct iphdr))+(globalMDFP.mhSize+globalMDFP.phSize);
  //  len=m->data_len - (sizeof(struct udphdr)+sizeof(struct iphdr)+HEADER);

  m->data_len=len-(globalMDFP.mhSize+globalMDFP.phSize);//len- HEADER

  *data_packet = data; /* data_packet pointing to message body without MDFP Header*/
  // m->payload=data;

  if(debug>=3) 
    {
      printf("Decapsulate packet, after:\n");
      dump_data(data, m->data_len);
      printf("----\n");
    }


  return len;   
  
}
/*---------------------------------------------------------------------------*/
int local_multicast_packet(ipq_packet_msg_t *m,char **data)
{
  /*
    checks whether the incoming packet si an IPIP  and destined to multicast 
    group
   */
  struct  iphdr *ipHeader;
 
  ipHeader=(struct  iphdr *)m->payload;
  if(ipHeader->protocol==IPPROTO_IPIP)
    {
      if(ipHeader->daddr==inet_addr("127.0.0.1"))
	{
	  ipHeader++;
	  if (check_destination((char *)ipHeader))
	    {
	      *data =(char *) ipHeader;
	      return (1);/* XXXX Return the size of the packet  */
	    }
	}
    }
  return (0);
}
/*---------------------------------------------------------------------------*/
int check_udp_port(ipq_packet_msg_t *m,unsigned int port)
{
  /*
    check wether the packet is a udp  if its source and destination port are 
    the one specified in the argument
  */
  struct iphdr *ipHeader;
  struct udphdr   *udpHeader;
  
  ipHeader=(struct  iphdr *)m->payload;
  
  if(ipHeader->protocol==IPPROTO_UDP)
    {    
      udpHeader=(struct udphdr *)((char *)ipHeader+sizeof(struct iphdr));

      if(debug>=4) {
	printf("UDP Packet: ");
	print_packet_info(m);
      } else if (debug>=5) {
	printf("UDPPacket: dest port=%d (vs %d)\n", ntohs(udpHeader->dest),
	       port);
      }
 
      if((udpHeader->source ==htons(port))&&(udpHeader->dest ==htons(port)))
	return(1);
    }
  return(0);
}
/*---------------------------------------------------------------------------*/
int check_src(char *data)
{
/*
  checks if the packets are the one we look for, src address 
  must be one of OLSR configured interfaces.
  The hook NF_IP_LOCAL_OUT is called before taking the routing decision. 
  But, Netfilter calls the routing code to determine 
  the source address before calling the hook NF_IP_LOCAL_OUT.
*/

  struct iphdr *ipHeader;
 
  
  ipHeader=(struct  iphdr *)data;
  
  if(olsr_configured_iface(&ipHeader->saddr))
    {
       return(1);
    }
  else
    {     
      return(0);      
    }
}
/*---------------------------------------------------------------------------*/
int check_destination(char *data)
{
  /*check if the packets are the one we look for, destination address 
    is a  multicast address*/
 struct iphdr *ipHeader;
 
  
  ipHeader=(struct  iphdr *)data;
  
  if(IN_CLASSD(ntohl(ipHeader->daddr)))
    {    
      return(1);
    }
  else
    {     
      return(0);      
    }
}
/*---------------------------------------------------------------------------*/
int encapsulate_multicast_data_from_attached_node(ipq_packet_msg_t *m)
{
  //  if(globalMDFP.molsrInfo.mainAddress==NULL)
  //  return (status = ipq_set_verdict(globalCom.handle, m->packet_id, NF_ACCEPT,0 , NULL));
  //else
  // if((check_src(m->payload))&&(check_destination(m->payload)))
  //   {

  //    } 
}
/*---------------------------------------------------------------------------*/
void nf_ip_local_out_process(ipq_packet_msg_t *m)
{
  /*
    process the outgoing packet captured by netfilter
   */
  int status;
  int len;
  int generatedPacket=0;
  char * data;
  struct message_header msgh;

  /*check if the packets are the one we look for, destination address 
    is a  multicast address*/
  if(globalMDFP.molsrInfo.mainAddress==NULL)
    status = ipq_set_verdict(globalCom.handle, m->packet_id, NF_ACCEPT,0 , NULL);
  else
    
    if((check_src(m->payload))&&(check_destination(m->payload))&&check_ttl(m->payload))
      {
	len=ipip_encapsulation(m,&data);
	
	status = ipq_set_verdict(globalCom.handle, m->packet_id, NF_ACCEPT,len , data);
	free(data);
	//printf("process local out \n");
	ip_header_extraction(&msgh,m);
	
	mdfp_process_localSource_updates(&msgh);
	
	generatedPacket=encapsulate_packet(globalCom.sockFd,m->payload,m->data_len,globalCom.addressTo,&msgh);
	
	if((globalVar.trace)&&(generatedPacket>0))
	  {
	   
	    trace_message_header(globalVar.traceFD,NULL,"G");
	  }
      }
    else
      {
	status = ipq_set_verdict(globalCom.handle, m->packet_id, NF_ACCEPT,0 , NULL);
      }
  
  if (status < 0)
    {
      fprintf(stderr, "NF_IP_LOCAL_OUT: ipq_set_verdict error \n");
    }
}
/*---------------------------------------------------------------------------*/
void nf_ip_local_in_process(ipq_packet_msg_t *m)
{
  /*
    process the incoming packet captured by netfilter
   */
  int status;
  unsigned int mdfp_msg_len;  /*type size_t */
  char *mdfp_msg;
  char * data;

  struct message_header msgh;
  int parseRes;
  
  if(local_multicast_packet(m,&data))    
    {
     
      status=ipq_set_verdict(globalCom.handle, m->packet_id,  NF_ACCEPT,m->data_len , data);
    }
  else
    //This node is relaying a multicast trafic on behalf attached node
    //if(strcmp(globalCom.multiInIfaceName,m->indev_name)==0)
    //status=encapsulate_multicast_data_from_attached_node(m);
    //else
    
    /*check that the packet are coming from the S_MOLSR port and are coming from an OLSR interface*/
    if((check_udp_port(m,PORT_MDFP))&&(globalMDFP.molsrInfo.mainAddress!=NULL))
      {
	gettimeofday(&globalVar.now,NULL);
	mdfp_header_extraction(&msgh,m);
	parseRes=mdfp_parser(&msgh);
	if(parseRes)
	  {
	    mdfp_msg_len=decapsulate_packet(&mdfp_msg,m,&data);
	    status=ipq_set_verdict(globalCom.handle, m->packet_id,  NF_ACCEPT,m->data_len , data);
	    if(parseRes==2)
	      encapsulate_forward(globalCom.sockFd,(struct mdfp *)mdfp_msg,mdfp_msg_len ,globalCom.addressTo,&msgh);
	    
	    free(mdfp_msg);
	  }
	else
	  {
	    status = ipq_set_verdict(globalCom.handle, m->packet_id, NF_DROP,0 , NULL);
	  }
	
      }
    else
      {
	status = ipq_set_verdict(globalCom.handle, m->packet_id, NF_ACCEPT,0 , NULL);
      }

  if(status <0)
    {
      fprintf(stderr, "NF_IP_LOCAL_IN: ipq_set_verdict error \n");
      //destroy_handle(globalCom.handle);
    }
}
/*---------------------------------------------------------------------------*/
void netfilter_call_back(IOSchedulerEntry *entry)
{
  /*
    process a received data from the netfilter socket
  */

  int status;
  unsigned char buf[BUFSIZE];
  ipq_packet_msg_t *m;

  status = ipq_read(globalCom.handle, buf, BUFSIZE, 0);
 
  if (status < 0)
    {
      fprintf(stderr, "Error in getting message from the IP_QUEUE\n");
      //destroy_handle(globalCom.handle);
    }
  switch (ipq_message_type(buf)) 
    {
    case NLMSG_ERROR:
      fprintf(stderr, "Received error message %d\n",
	      ipq_get_msgerr(buf));
      break;
      
    case IPQM_PACKET: 
      
      m = ipq_get_packet(buf);
     
      switch(m->hook) 
	{
	case NF_IP_LOCAL_OUT:

	  nf_ip_local_out_process(m);
	  
	  break;
	  
	case NF_IP_LOCAL_IN:
	  nf_ip_local_in_process(m);
	  
	  break;
	  
	default:
	  fprintf(stderr, "Hook not processed by this daemon\n");
	  
	  status = ipq_set_verdict(globalCom.handle, m->packet_id, NF_ACCEPT,0 , NULL);
	  /*
	    Other packets should be accepted without modification
	  */
	      if (status < 0)
		{
		  fprintf(stderr, "NF_IP_LOCAL_OUT: ipq_set_verdict error \n");
		  //destroy_handle(globalCom.handle);
		}
	      break;
	} /*end of switch m->hook */
      
      break;
      
      
    default:
      fprintf(stderr, "Unknown message type!\n");
      break;
    }
}
/*---------------------------------------------------------------------------*/
void inOutSocket_call_back(IOSchedulerEntry* entry)
{
  /* We don't expect to receive data from this socket a part from the packet
   we broadcast and we should ignore*/
}
/*---------------------------------------------------------------------------*/
void olsrComSocket_call_back(IOSchedulerEntry* entry)
{
  /*
    process received data from OLSR/MOLSR
   */

  /*
    The daemon extract the needed information from  IFACE_MSG and MCTREE_MSG
    received from OLSR/MOLSR such as the main and the list of configured 
    interfaces, and the content of the MCTREE table 
  */

  socklen_t   fromlen = sizeof(struct sockaddr_in);
  struct sockaddr_in address;
  u_int16_t dataSize=0;
  
  struct mdfp *message;
  struct MDFPMsg *msgHeader;

  dataSize=recvfrom(globalCom.olsrComSocket,globalMDFP.buffer,MAXMSGSIZE,MSG_TRUNC,(struct sockaddr *)&address,&fromlen);
  message=(struct mdfp *)globalMDFP.buffer;
  //port verification coming from OLSR/MOLSR port for example otherwise return
  if((dataSize>0)&&(dataSize<MAXMSGSIZE))
    {
      if((dataSize!=ntohs(message->packlen))||(ntohs(message->packseqnum)!=0))
	return;
      msgHeader=(struct MDFPMsg *)((char *)message+globalMDFP.phSize);
      init_global_molsr_information();
      while(((char *)msgHeader)<((char *)message+dataSize))
	{
	  
	  extract_iface_inf_from_olsr_packet(msgHeader);
	  
	  msgHeader=(struct MDFPMsg *)((char *)msgHeader+ntohs(msgHeader->msgsize));
	}
      /* set the hold time */
    timeradd(&globalMDFP.molsrInfo.timeOut,&globalMDFP.molsrInfo.holdTime,&globalMDFP.molsrInfo.timeOut);   
    dump_molsr_information();
     }
  else
    {
      //Error
      fprintf(stderr,"Size error in received packet from OLSR\n");
    }
  return;
}
/*---------------------------------------------------------------------------*/
void init_ioscheduler(IOScheduler *ioscheduler)
{
  
  IOSchedulerEntry entry;
 

   ioscheduler_entry_init(&entry, IOEntryFD);
   entry.fd[IORead] = globalCom.handle->fd;
   entry.callBackFunc[IORead] = netfilter_call_back;
   entry.data = (void*) globalCom.handle->fd;
   
   ioscheduler_add(ioscheduler, entry);

   //ioscheduler_entry_init(&entry, IOEntryFD);
   //entry.fd[IORead] = globalCom.sockFd;
   //entry.callBackFunc[IORead] = inOutSocket_call_back;
   //entry.data = (void*) globalCom.sockFd;
   
   //ioscheduler_add(ioscheduler, entry);


   ioscheduler_entry_init(&entry, IOEntryFD);
   entry.fd[IORead] = globalCom.olsrComSocket;
   entry.callBackFunc[IORead] =  olsrComSocket_call_back;
   entry.data = (void*) globalCom.olsrComSocket;
   
   ioscheduler_add(ioscheduler, entry);

  
}

/*---------------------------------------------------------------------------*/
void run_main_event_loop(IOScheduler *ioscheduler)
{
  int status;

  init_schedule_time_out(&globalVar.timerPeriod);
  
  for(;;) 
    {
      
      status=ioscheduler_schedule(ioscheduler, &globalVar.schedulerTimeOut);	
      process_schedule_time_out(status);     
    }
}

/*---------------------------------------------------------------------------*/
void mdfp_release_tables()
{
  
    mdfp_release_duplicate_table();
    
}
/*---------------------------------------------------------------------------*/
void mdfp_init_tables()
{
  
  u_int16_t index;
  
  
  for(index = 0; index < HASHSIZE; index++)
    {     
    
      duplicatetable[index].duplicate_forw = 
	(struct duplicate_entry *)&duplicatetable[index];
      duplicatetable[index].duplicate_back = 
	(struct duplicate_entry *)&duplicatetable[index];

      sourceLocaltable[index].srcLocal_forw =
	(struct SourceLocal_entry *)&sourceLocaltable[index];
      
      sourceLocaltable[index].srcLocal_back =
	(struct SourceLocal_entry *)&sourceLocaltable[index];

    }
  
}
/*------------------------------------------------------------------------*/
void mdfp_init_timers_var()
{
  mdfp_init_timer(duplicate_hold_time * 1000,&hold_time_duplicate);
  mdfp_init_timer(sourceLocal_hold_time * 1000,&hold_time_sourceLocal);
  mdfp_init_timer(TIMER_PERIOD * 1000, &globalVar.timerPeriod);
  mdfp_init_timer(OLSR_IFACE_INFO_HOLD_TIME * 1000,&globalMDFP.molsrInfo.holdTime);
  
}
/*------------------------------------------------------------------------*/
void init_global_molsr_information()
{
  globalMDFP.molsrInfo.mainAddress=NULL;
  globalMDFP.molsrInfo.listIface=NULL;
  globalMDFP.molsrInfo.mcTreeTable=NULL;
  
  globalMDFP.molsrInfo.ifaceNumber=0;
  globalMDFP.molsrInfo.mcEntryNumber=0;
  
  gettimeofday(&globalMDFP.molsrInfo.timeOut,NULL);

}
/*---------------------------------------------------------------------------*/
void init_global()
{
 globalMDFP.packseqnum=0;
 globalMDFP.msgseqnum=0;

 /* Message header size */
 globalMDFP.mhSize= 3 *sizeof(ip_addr); 
 /* Packet header size */
 globalMDFP.phSize= sizeof(ip_addr);

 init_global_molsr_information();
 if(debug)
   globalVar.trace=1;
 else
   globalVar.trace=0;
 globalVar.forwardingMode=SMOLSRMODE;
}
/*---------------------------------------------------------------------------*/
FILE* openTraceFile(char* pathName)
{
 
  FILE* traceFD = NULL;
  char fileName[100];
  struct timeval traceDate;
  
  gettimeofday(&traceDate,NULL);
  sprintf(fileName,"%s.Trace.%.24s",pathName,ctime(&traceDate.tv_sec));
  traceFD = fopen(fileName, "w");

  return traceFD;
}

/*---------------------------------------------------------------------------*/
void daemonize()
{
  if(debug > 0) return;
  if (fork() != 0) exit(0);
  close(0);
  close(1);
  close(2);
  setsid();
  
}
/*---------------------------------------------------------------------------*/

int debug = 0; /* debug level */

int main(int argc, char **argv)
{
  int status;
  int on=1;

  char** current = argv;
  while( *(++current) != NULL)
    {
	if (!strcmp(*current, "-v"))
	  debug++;
      
    }
  
  init_global();


  mdfp_init_tables();
  mdfp_init_timers_var();

  globalCom.handle = ipq_create_handle(0,PF_INET);
  
  if (!globalCom.handle)
    {
      destroy_handle(globalCom.handle);
      return (-1);
    }
  
  status = ipq_set_mode(globalCom.handle, IPQ_COPY_PACKET, BUFSIZE);
  if (status < 0)
    {
      destroy_handle(globalCom.handle);
      return (-1);
    }
  
  //  daemonize();
 /* get the list of the attached interfaces */
  get_system_interfaces(&globalCom.configuredIfaces);
 
  globalCom.addressIn=get_sockaddr(PORT_MDFP,"0.0.0.0");
  
  globalCom.addressTo=get_sockaddr(PORT_MDFP,"255.255.255.255");
  

  //globalCom.sockFd=socket(PF_INET,SOCK_DGRAM,0);
  globalCom.sockFd=open_socket(globalCom.addressIn);
  if (globalCom.sockFd <0)
    perror("socket PF_INET");
  if (setsockopt(globalCom.sockFd,SOL_SOCKET, SO_BROADCAST,&on, sizeof (on))<0)
    perror("setsockopt SO_BROADCAST");
  if (setsockopt(globalCom.sockFd, SOL_IP, IP_PKTINFO, &on, sizeof (on))<0)
    perror("setsockopt SOL_IP");

  globalCom.olsrComAddress=get_sockaddr(1000+PORT_MDFP,"127.0.0.1");
  globalCom.olsrComAddressTo=get_sockaddr(1000+PORT_MDFP+1,"127.0.0.1");

  globalCom.olsrComSocket=open_socket(globalCom.olsrComAddress);
  
  if ( globalVar.trace)
    globalVar.traceFD=openTraceFile("/tmp/MDFP");
  
  init_ioscheduler(&globalVar.ioscheduler);
  
  run_main_event_loop(&globalVar.ioscheduler);

  ipq_destroy_handle(globalCom.handle);

  mdfp_release_tables();

  free_interfaces(globalCom.configuredIfaces);
  return 0;
  
  
}
