//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#define NEW_CLIENT     51
#define LEAVE_CLIENT   52

struct ClientLocal_Entry{
  ip_addr                   cliLocal_addr;
  ip_addr                   cliLocal_group;
  struct ClientLocal_Entry *next;
};	

extern struct ClientLocal_Entry *clientLocaltable;

void mdfp_process_localClient_updates();
void mdfp_release_ClientLocal_list(struct ClientLocal_Entry *clientList);

int fill_local_mdfp_header(struct mdfp *mdfpPacket,int packLen,unsigned int type);

void mdf_tell_MOLSR_localClientContent();
