//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include <asm/types.h>
#include <netinet/ether.h>
#include <netinet/in.h>
#include <net/if.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <sys/types.h>
#include <string.h>

#include "definition.h"

#define NL_BUFSIZE 8192
/*--------------------------------------------------------------------*/
ip_addr  get_iface_broadcast_by_addr(struct interfaces *Ifaces,ip_addr *ifaceAddr)
{
  /*
    Get the broadcast address of an interface with the address ifaceAddr
   */
while(Ifaces!=NULL)
  {
    if(0==memcmp(&Ifaces->int_addr,ifaceAddr,sizeof(ip_addr)))
      return (Ifaces->int_bAddr);
    Ifaces=Ifaces->next;
  }
  return 0;
}
/*--------------------------------------------------------------------*/
int get_iface_index_by_addr(struct interfaces *Ifaces,ip_addr *ifaceAddr)
{
  /*
    Get the index of an interface with the address ifaceAddr
  */
while(Ifaces!=NULL)
  {
    if(0==memcmp(&Ifaces->int_addr,ifaceAddr,sizeof(ip_addr)))
      return (Ifaces->int_index);
    Ifaces=Ifaces->next;
  }
  return 0;
}
/*--------------------------------------------------------------------*/
ip_addr get_iface_addr_by_name(struct interfaces *Ifaces,char *ifName)
{
  /*
    Get the name of an interface with the address ifaceAddr
   */
while(Ifaces!=NULL)
  {
    if(0==strcmp(Ifaces->int_name,ifName))
      return (Ifaces->int_addr);
    Ifaces=Ifaces->next;
  }
  return 0;
}
/*--------------------------------------------------------------------*/
ip_addr get_iface_addr_by_index(struct interfaces *Ifaces,int index)
{
  /*
    Get the interface address correspondign to the index index
  */
  
  while(Ifaces!=NULL)
    {
      if(Ifaces->int_index==index)
	return (Ifaces->int_addr);
      Ifaces=Ifaces->next;
    }
  return 0;
}
/*--------------------------------------------------------------------*/
void print_interfaces(struct interfaces *Ifaces)
{   
  
  /*
    Prints the information about the the configured interfaces stored in Ifaces
   */

  char tempBuf[16];
  while(Ifaces!=NULL)
    {
      printf("Interface name : %s\n",Ifaces->int_name);
      printf("Interface index : %d\n",Ifaces->int_index);
      printf("Interface address : %s\n",inet_ntop(AF_INET, &Ifaces->int_addr,tempBuf,16));
       printf("Interface broadcast address : %s\n",inet_ntop(AF_INET, &Ifaces->int_bAddr,tempBuf,16));
      Ifaces=Ifaces->next;
     
    }
}

/*--------------------------------------------------------------------*/
void free_interfaces(struct interfaces *Ifaces)
{   
  /*
    Frees the Ifaces list
  */
  struct interfaces *iface_tmp;

  while(Ifaces!=NULL)
    {
      iface_tmp=Ifaces;      
      Ifaces=Ifaces->next;
      free(iface_tmp->int_name);
      free(iface_tmp);
    }
}
/*--------------------------------------------------------------------*/
int get_system_reply(int sockFd, int seqNum,struct interfaces **listIface)
{
  /*
    Process the kernel reply for the list of interfaces request
   */

  char buf[NL_BUFSIZE];
  struct sockaddr_nl nladdr;
  struct iovec iov = { buf,NL_BUFSIZE };
  struct nlmsghdr *h;
  struct ifaddrmsg *m;
  struct rtattr *attr;
  
  struct interfaces *Ifaces=NULL;
  struct interfaces *Iface_tmp;
  int status,attrsize;
 

  while(1)
    {
      struct msghdr msg = {(void*)&nladdr, sizeof(nladdr),&iov,   1, NULL, 0, 0};	
	status = recvmsg(sockFd, &msg, 0);	
	
	h = (struct nlmsghdr*)buf;
	while ( NLMSG_OK(h, status))
	  {
	    
	    if (h->nlmsg_seq != seqNum)
	      {
		fprintf(stderr,"--Nlmsg error \n");
		free_interfaces(Ifaces);
		return -1;
	      }
	    
	    if (h->nlmsg_type == NLMSG_DONE)
	      {
		fprintf(stderr,"Netlink call done \n");
		
		print_interfaces(Ifaces);
		*listIface=Ifaces;
		return 0;
	      }
	    
	    if (h->nlmsg_type == NLMSG_ERROR)
	      {
		fprintf(stderr,"Nlmsg error \n");
		free_interfaces(Ifaces);
		return -1;
	      }	    
	    
	    Iface_tmp=(struct interfaces *)malloc(sizeof(struct interfaces));
	    Iface_tmp->next=Ifaces;
	    Ifaces=Iface_tmp;
	    
	    m=NLMSG_DATA(h);
	    Ifaces->int_index=m->ifa_index;
	    
	    attr=IFA_RTA(m);
	    attrsize=h->nlmsg_len-NLMSG_LENGTH(sizeof(*m));
	    
	    while(RTA_OK(attr,attrsize))
	      {
		
		switch(attr->rta_type) 
		  {
		  case IFA_ADDRESS:
		    memcpy(&Ifaces->int_addr,(unsigned int *)RTA_DATA(attr),sizeof(unsigned int));
		    break;
		  case IFA_LABEL:
		    Ifaces->int_name=strdup((char *)(RTA_DATA(attr)));
		    
		    break;
		  case IFA_BROADCAST:
		    memcpy(&Ifaces->int_bAddr,(unsigned int *)RTA_DATA(attr),sizeof(unsigned int));
		    break;
		  }
		attr=RTA_NEXT(attr,attrsize);		
	      }
	    
	    
	    h = NLMSG_NEXT(h, status);
	  }
    }
 
 
}
/*--------------------------------------------------------------------*/
int get_system_interfaces(struct interfaces **listIface)
{
  /*
    Send a request to the kernel to extract the list of the configured 
    interfaces
   */
  int sock;
  struct
  {
    struct nlmsghdr  nlh;
    struct ifaddrmsg ifmsg;
  }req;
    
  struct sockaddr_nl nladdr;
  static __u32 seq;
  
  if((sock = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_ROUTE)) < 0)
    {
      fprintf(stderr,"Socket Creation: ");
      return -1;
    }
  

  memset(&nladdr,0,sizeof(nladdr));
  
  nladdr.nl_family= AF_NETLINK;
  
  req.nlh.nlmsg_len = sizeof(req);
  req.nlh.nlmsg_type= RTM_GETADDR;   
  req.nlh.nlmsg_flags = NLM_F_DUMP|NLM_F_REQUEST;
  req.nlh.nlmsg_pid = 0;
  req.nlh.nlmsg_seq = ++seq;
  
  memset(&req.ifmsg,0,sizeof(struct ifaddrmsg)); 
  req.ifmsg.ifa_family=AF_INET;
  
  if(sendto(sock,&req,sizeof(req),0,(struct sockaddr*)&nladdr,sizeof(nladdr))<0)
    fprintf(stderr,"sendto request to kernel error\n");
  else
    {
      
      get_system_reply(sock,seq,listIface);
    }
  return 0;
}
