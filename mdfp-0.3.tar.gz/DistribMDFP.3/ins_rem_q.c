//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------


/*
 * This Copyright notice is in French. An English summary is given
 * but the referee text is the French one.
 *
 * Copyright (c) 2000, 2001, 2002, 2003 
 *     Adokoe.Plakoo@inria.fr, INRIA Rocquencourt,
 *     Anis.Laouiti@inria.fr, INRIA Rocquencourt.
 *     Cedric.Adjih@inria.fr, INRIA Rocquencourt.
 *
 * Ce logiciel informatique est disponible aux conditions
 * usuelles dans la recherche, c'est-�-dire qu'il peut
 * �tre utilis�, copi�, modifi�, distribu� � l'unique
 * condition que ce texte soit conserv� afin que
 * l'origine de ce logiciel soit reconnue.
 * Le nom de l'Institut National de Recherche en Informatique
 * et en Automatique (INRIA), ou d'une personne morale
 * ou physique ayant particip� � l'�laboration de ce logiciel ne peut
 * �tre utilis� sans son accord pr�alable explicite.
 * 
 * Ce logiciel est fourni tel quel sans aucune garantie,
 * support ou responsabilit� d'aucune sorte.
 * Certaines parties de ce logiciel sont d�riv�es de sources developpees par
 * University of California, Berkeley et ses contributeurs couvertes 
 * par des copyrights.
 * This software is available with usual "research" terms
 * with the aim of retain credits of the software. 
 * Permission to use, copy, modify and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and the name of INRIA, or any contributor not be used in advertising
 * or publicity pertaining to this material without the prior explicit
 * permission. The software is provided "as is" without any
 * warranties, support or liabilities of any kind.
 * This product includes software developed by the University of
 * California, Berkeley and its contributors protected by copyrights.
 */

/*
 * Routing table management daemon.
 */

char ins_que_rcsid[] =
  "$Id: ins_rem_q.c,v 1.2 2004/11/02 09:58:13 laouiti Exp $";

#include "definition.h"

/*
  mdfp_insque()  inserts  the  element pointed to by elem immedi�
  ately after the element pointed to by prev, which must NOT
  be NULL.

  mdfp_remque()  removes  the element pointed to by elem from the
  doubly-linked list.
  
*/


/*-------------------------------------------------------------*/

void
mdfp_insque(struct mdfp_qelem *elem, struct mdfp_qelem *prev)
{
  
  elem->q_back = prev;
  elem->q_forw = (struct mdfp_qelem *)prev->q_forw;
  prev->q_forw = elem; 
  ((struct mdfp_qelem *) elem->q_forw)->q_back = elem;
}

/*-------------------------------------------------------------*/

void
mdfp_remque(struct mdfp_qelem *elem)
{
  ((struct mdfp_qelem *) elem->q_back)->q_forw = 
                                (struct mdfp_qelem *)elem->q_forw;
  ((struct mdfp_qelem *) elem->q_forw)->q_back = 
                                (struct mdfp_qelem *)elem->q_back;
}

/*-------------------------------------------------------------*/

