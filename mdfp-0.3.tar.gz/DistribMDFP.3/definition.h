//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
#include <linux/netfilter.h>
#include <fcntl.h>
//#include <linux/in.h>
#include <libipq/libipq.h>
#include <linux/netfilter_ipv4.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <string.h>
#include <net/if.h>
#include <errno.h>

#include "types.h"
#include "mdfp_header.h"
#include "message.h"
#include "unix_io_scheduler.h"
#include "duplicate_table.h"
#include "localSources_table.h"
#include "igmpproc.h"
#include "localClients_table.h"
#include "checksum.h"
#include "manglepackets.h"
#include "ins_rem_q.h"
#include "interface.h"
#include "trace.h"

#define  HASHSIZE        32              /* must be a power of 2 */
#define  HASHMASK        (HASHSIZE - 1)


extern int olsr_is_sym_neighbor(ip_addr *);
extern int olsr_is_my_mprs_interface(ip_addr *);


void mdfp_hashing(ip_addr *,u_int32_t  *);

int mdfp_timed_out(struct timeval *);

void mdfp_init_timer(u_int32_t time_value, struct timeval *hold_timer);

extern int debug;
