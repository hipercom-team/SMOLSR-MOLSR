//-------------------------------------------------------------------*- c -*-
//                                SMOLSR
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "definition.h"
/*-------------------------------------------------------------------------*/
void mdfp_hashing(ip_addr *address, u_int32_t *h)
{
  /*
    Returns the hashing of and IP address
   */
  u_int32_t hash;
  u_int32_t uint_addr = *address;
  hash = ( ntohl(uint_addr) );
  hash &= 0x7fffffff; 
  *h = hash;
}


/*-------------------------------------------------------------------------*/


int mdfp_timed_out(struct timeval *timer)
{

  /*
    Returns the true if the timer has expired
   */
   return( timercmp(timer, &globalVar.now, <) || 
          timercmp(timer, &globalVar.now, ==) );
}


/*-------------------------------------------------------------------------*/
void mdfp_init_timer(u_int32_t time_value, struct timeval *hold_timer)
{ 
  /*
    Inits the timer with the given value
   */

  u_int16_t time_value_sec  = 0;
  u_int16_t time_value_msec = 0;

  time_value_sec  = time_value / 1000;
  time_value_msec = time_value - (time_value_sec * 1000);

  hold_timer->tv_sec  = time_value_sec;
  hold_timer->tv_usec = time_value_msec * 1000; 

}
/*-------------------------------------------------------------------------*/
