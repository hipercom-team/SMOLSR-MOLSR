//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _BASE_H
#define _BASE_H

//---------------------------------------------------------------------------

#ifdef SYSTEMwindows

// Remove some warnings ; the first one is really annoying, and is due
// to shortcomings of the VC++ compiler for debug symbols.

// identifier too long (for debug symbols)
#pragma warning(disable:4786)

// not enough actual parameters for macro
#pragma warning(disable:4003)

// 'this' : used in base member initializer list
#pragma warning(disable:4355)

// warning C4660: template-class specialization  is already instantiated
#pragma warning(disable:4660)

#define __func__ ""
#endif

//---------------------------------------------------------------------------

// This is to have C++ standards "for" scope rules
// i.e 
//     for(int i=0;i<15;i++) 
//       doSomething(i);
//     for(int i=0;i<15;i++) 
//       doSomeOtherThing(i);

#ifdef _MSC_VER
# if _MSC_VER < 1201
#  define for if (0); else for
# endif
#endif

// For eMVC++ 4.0, I didn't find the flag so, same thing here:
#ifdef UNDER_CE
#  define for if (0); else for
#endif

//---------------------------------------------------------------------------

// emVC++ 4.0 supports RTTI: however you might need this
// Rather: http://support.microsoft.com/default.aspx?scid=kb;en-us;830482
//#ifdef
//#include <typeinfo>
//#endif

//---------------------------------------------------------------------------

#endif //_BASE_H
