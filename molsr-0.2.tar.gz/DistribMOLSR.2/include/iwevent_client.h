//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Adokoe Plakoo, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//     $Id: iwevent_client.h,v 1.3 2004/12/28 16:05:25 plakoo Exp $
//---------------------------------------------------------------------------
// Support for Wireless Extension (WE), allow manipulation of Wireless 
// Extensions.
//---------------------------------------------------------------------------

#ifndef _WE_SUPPORT_H
#define _WE_SUPPORT_H

//---------------------------------------------------------------------------

#include "base.h"

//---------------------------------------------------------------------------

class IOScheduler;

class IIweventClient
{
public:
  virtual void open(IOScheduler* scheduler, void* data) = 0;
  virtual void handleInput() = 0;
};

//---------------------------------------------------------------------------

#endif // _WE_SUPPORT_H
