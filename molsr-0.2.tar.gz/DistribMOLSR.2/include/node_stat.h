//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Statistics about a node
//---------------------------------------------------------------------------

class NodeStat
{
public:
  
};

//---------------------------------------------------------------------------
