//---------------------------------------------------------------------------
//                             OOLSR
//               Marc Badel, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _SYSTEM_LINUX_IPV4_INTERNAL_H
#define _SYSTEM_LINUX_IPV4_INTERNAL_H

//---------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif 

//---------------------------------------------------------------------------

   /* Description d'interfaces ethernet */

typedef struct __describe_interface {
  char ifname [IFNAMSIZ];        /* Nom de l'interface */
  struct sockaddr_in ip_addr;    /* Adresse IP de l'interface */
  struct sockaddr_in broad_addr; /* Adresse broadcast liee a l'interface */
  struct sockaddr_in netmask;    /* Masque sous-reseau lie a l'interface */
  short int if_flags;            /* Bits d'etat de l'interface */
  int if_mtu;                    /* Taille maximum de transfert */
  int if_metric;                 /* Metrique associee a l'interface */
  unsigned char hwaddr[6];       /* Adresse MAC de la carte interface */
  unsigned char addr_ipv6[16];   /* Adresse IPV6 de l'interface */
  int if_mode;                   /* -1 pour non wireless, zero pour */
                                 /* mode autre qu'ad-hoc, 1 pour mode haddock */
  double frequence;              /* Frequence d'emission */

} describe_interface;

   
//---------------------------------------------------------------------------

void upd_interfaces (int skfd);

int KERN_add_route_IPV4(int skfd, 
			struct in_addr *addr_dest,
			struct in_addr *addr_gateway,
			unsigned short a_flags,unsigned int mask, short metric,
			char *int_name);

int KERN_del_route_IPV4(int skfd, 
			struct in_addr *addr_dest,
			struct in_addr *addr_gateway,
			unsigned short a_flags,unsigned int mask, short metric,
			char *int_name);

int interf_name_to_num (char *nom);

int get_MTU_interf (int numero,int code);

int get_IPV4_broadcast (int numero, int code, 
			struct in_addr *adresse);

describe_interface *get_interf_by_num (int numero,int code);
   
int get_interface_signal(int skfd, char *iface_name, struct sockaddr_in tx_ipaddr);

//---------------------------------------------------------------------------

#ifdef __cplusplus
} // closes 'extern "C"'
#endif 


//---------------------------------------------------------------------------

#endif // _SYSTEM_LINUX_IPV4_INTERNAL_H
