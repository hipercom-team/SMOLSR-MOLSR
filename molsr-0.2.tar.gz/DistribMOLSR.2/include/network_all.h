//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#error This file has been obsoleted by network_generic.h

#ifndef _NETWORK_ALL_H
#define _NETWORK_ALL_H

//---------------------------------------------------------------------------

#include "base.h"

#include <list>

#include "address.h"

//---------------------------------------------------------------------------

/// The information of one interface.
class IfaceInfo
{
public:
  char* name; /// (owned) the name of the interface
  Address address; /// address of the interface
  Address destinationAddress; /// broadcast/multicast address
  unsigned int destinationPort; /// the port to which send the data
  int mtu;
};

//---------------------------------------------------------------------------

class OLSRIface;

/// An receiver of packet. Implemented by Node.
class IPacketReceiver
{
public:
  /// (packet:owned)
  virtual void evReceivePacket(MemoryBlock* packet,
			       Address sendIfaceAddress,
			       OLSRIface* recvIface) = 0;
};

//---------------------------------------------------------------------------

/// An interface used for OLSR.
/// It performs whatever system calls are necessary to receive and send
/// packets
class ISystemIface
{
public:

  /// Open the send/receive socket(s) and register oneself in the proper
  /// IOScheduler.
  // XXX virtual void openSocket() = 0;

  /// Send a packet to an interface (packet is owned).
  virtual void sendPacket(MemoryBlock* packet) = 0;

  /// Return the maximum packet that the interface can send without IP
  /// fragmentation
  virtual int getMTU() = 0;

  virtual Address getAddress() = 0;

  void setOLSRIface(OLSRIface* aIface)
  { associatedIface = aIface; }

  OLSRIface* getOLSRIface()
  { return associatedIface; }

  IfaceConfig* getConfig() { return ifaceConfig; }

protected:
  /// The higher level interface associated to this system interface
  /// used when calling 
  OLSRIface* associatedIface;

  IfaceConfig* ifaceConfig;
};



/// Limited network configurator
class INetworkConfigurator
{
public:

  /// Add one route in the kernel
  virtual void addRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric) = 0;
  
  /// Remove one route from the kernel
  virtual void removeRoute(ISystemIface* iface, Address destIpAddress,
			   Address gatewayAddress, Address netMaskAddress, 
			   int metric) = 0;
};


//---------------------------------------------------------------------------

/// XXX: there should be some ifdef etc... to choose the proper
/// classes

#ifdef WITH_SIMULATION

#include "network_simulation.h"
typedef SimulationNetworkConfigurator NetworkConfigurator;
typedef SimulationIface SystemIface;
typedef SimulationConfig SystemConfig;

#endif

//--------------------------------------------------

//#include "network_plugin.h"
//typedef PluginNetworkConfigurator NetworkConfigurator;
//typedef PluginIface SystemIface;


// XXX: remove
class SystemConfig
{
public:
};

//--------------------------------------------------

#ifdef WITH_LINUX

#include "network_linux.h"
typedef LinuxNetworkConfigurator NetworkConfigurator;
typedef LinuxIface SystemIface;

#endif // WITH_LINUX

//---------------------------------------------------------------------------

#endif // _NETWORK_ALL_H
