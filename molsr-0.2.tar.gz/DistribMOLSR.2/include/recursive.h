//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _RECURSIVE_H
#define _RECURSIVE_H

//---------------------------------------------------------------------------

class RecursiveMessage : public IMessageContent
{
public:
  string data;
  Message* content;

  RecursiveMessage(Message* aContent)
  { content = aContent; }

  virtual IMessageContent* clone()
  {
    RecursiveMessage* result = new RecursiveMessage(content->clone());
    result->data = data;
    result->header = header->clone(false);
    result->header->content = result; // XXX: do something
    return result;
  }

  virtual void write(ostream& out) const;

  virtual ~RecursiveMessage()
  { delete content; content = NULL; }
};

//--------------------------------------------------

class Node;
class IMessageHandler;

class RecursiveMessageRewriter;

class RecursiveMessageHandler : public IMessageHandler
{
public:
  PacketManager* packetManager;
  IMessageHandler* handler;
  Node* node;
  bool shouldForward;
  RecursiveMessageRewriter* rewriter;
  
  RecursiveMessageHandler(Node* aNode,
			  IMessageHandler* aHandler,
			  bool aShouldForward,
			  RecursiveMessageRewriter* aRewriter);

  virtual void processMessage(/*borrowed*/ Message* message);

  virtual void considerForwardMessage(/*borrowed*/ Message* message,
				      string& info);

  virtual void packMessageContent(IMessageContent* message,
				  int maximumMessageSize,
				  MemoryBlock*& packedResult,
				  IMessageContent*& messageRemainingResult);

  string getAdjustedData(RecursiveMessage* m, MemoryBlock* intermediaryBlock);


  int getOverhead(string data);

  virtual void adjustMessageSize(IMessageContent* message);

  IMessageHandler* getMessageHandler(RecursiveMessage* message);
  
  IMessageContent* parseMessageContent(Message* message);
};
  
//---------------------------------------------------------------------------

void installRecursiveMessageRewriter(Node* node);

//---------------------------------------------------------------------------

#endif // _RECURSIVE_H
