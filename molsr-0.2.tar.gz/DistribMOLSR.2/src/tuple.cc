//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//         Paul Muhlethaler, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2003 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "tuple.h"
#include "protocol_tuple.h"

#include "node.h"

//---------------------------------------------------------------------------

template<typename Tuple, class Manager, typename Iterator>
void BasicTupleSet<Tuple, Manager, Iterator>::add(Tuple* tuple)
{ 
  _internalAdd(tuple);
  notifyAddition(tuple); 
}

template<class Tuple, class Manager, typename Iterator>
void BasicTupleSet<Tuple, Manager, Iterator>::remove(Tuple* tuple)
{
  notifyPreRemoval(tuple);
  _internalRemove(tuple);
  notifyRemoval(tuple);
}

template<class Tuple, class Manager, typename Iterator>
void BasicTupleSet<Tuple, Manager, Iterator>::removeAndDelete(Tuple* tuple)
{
  remove(tuple);
  delete tuple;
}


template<class Tuple, class Manager, typename Iterator>
//typename BasicTupleSet<Tuple, Manager>::TupleIterator 
Iterator BasicTupleSet<Tuple, Manager, Iterator>::getIter()
{
  Iterator result; //XXX (this, content.begin(), content.end());
  result.set = this; 
  result.q = (content.begin()) ;
  result.itEnd = (content.end()) ;
  return ( result ); 
}

// Note: this function is duplicated and modified in: 
// LinkSet, IfaceAssodicationSet
template<class Tuple, class Manager, typename Iterator>
void BasicTupleSet<Tuple, Manager, Iterator>::removeAndDeleteExpired
(Time currentTime)
{
  TupleIterator it = getIter();
  while(!it.isDone()) {
    if (it.getCurrent()->getExpireTime() <= currentTime) {
      //Tuple* current = it.getCurrent();
      it.removeAndDeleteCurrentAndDoNext();
    } else it.next();
  }
}

template<class Tuple, class Manager, typename Iterator>
Time 
BasicTupleSet<Tuple, Manager, Iterator>::getMinExpireTime(bool& hasMinTime)
{
  Time minTime = 0; // (this default value is not used)
  hasMinTime = false;
  for(Iterator it=getIter(); !it.isDone(); it.next()) {
    Time expireTime = it.getCurrent()->getExpireTime();
    if (!hasMinTime || (expireTime < minTime)) {
      minTime = expireTime;
      hasMinTime = true;
    }
  }
  return minTime;
}

//---------------------------------------------------------------------------

template<class Tuple, class Manager>
Tuple* BasicTupleSetIterator<Tuple, Manager>::getCurrent()
{ return (*q); }

template<class Tuple, class Manager>
bool BasicTupleSetIterator<Tuple, Manager>::isDone()
{
  if( q  == /*(set->content.end()*/ itEnd) return true;
  else
  return false;
}

template<class Tuple, class Manager>
void BasicTupleSetIterator<Tuple, Manager>::next()
{
  q++;
}

template<class Tuple, class Manager>
void BasicTupleSetIterator<Tuple, Manager>::removeCurrentAndDoNext()
{
  typename Manager::iterator nextIter = q;
  nextIter++;
  set->remove( *q );
  q = nextIter;
}


template<class Tuple, class Manager>
void BasicTupleSetIterator<Tuple, Manager>::removeAndDeleteCurrentAndDoNext()
{
  typename Manager::iterator nextIter = q;
  nextIter++;
  set->removeAndDelete( *q );
  q = nextIter;
}


//---------------------------------------------------------------------------
// This is for instanciating the templates with g++
// XXX: maybe there is a better way

template class BasicTupleSet<LinkTuple>;
template class BasicTupleSet<NeighborTuple>;
template class BasicTupleSet<TwoHopNeighborTuple>;
template class BasicTupleSet<MPRSelectorTuple>;
template class BasicTupleSet<TopologyTuple>;
template class BasicTupleSet<IfaceAssociationTuple>;
template class BasicTupleSet<HNATuple>;
template class BasicTupleSet<RoutingTuple>;
template class BasicTupleSet<DuplicateTuple>;
template class BasicTupleSet<HeardIfaceTuple>;


template class BasicTupleSetIterator<LinkTuple>;
template class BasicTupleSetIterator<NeighborTuple>;
template class BasicTupleSetIterator<TwoHopNeighborTuple>;
template class BasicTupleSetIterator<MPRSelectorTuple>;
template class BasicTupleSetIterator<TopologyTuple>;
template class BasicTupleSetIterator<IfaceAssociationTuple>;
template class BasicTupleSetIterator<HNATuple>;
template class BasicTupleSetIterator<RoutingTuple>;
template class BasicTupleSetIterator<DuplicateTuple>;
template class BasicTupleSetIterator<HeardIfaceTuple>;


#ifdef WITH_STAT
#include "statistic.h" 
template class BasicTupleSet<StatisticTuple>;
template class BasicTupleSetIterator<StatisticTuple>;
#endif // WITH_STAT


#if 0
void _dummy_instantiation() //XXX: remove
{
  BasicTupleSet<LinkTuple>* a;
  BasicTupleSet<NeighborTuple>* b;
  BasicTupleSet<TwoHopNeighborTuple>* c;
  BasicTupleSet<MPRSelectorTuple>* d;
  BasicTupleSet<TopologyTuple>* e;
  BasicTupleSet<IfaceAssociationTuple>* f;
  BasicTupleSet<HNATuple>* g;
  BasicTupleSet<RoutingTuple>* h;
  BasicTupleSet<DuplicateTuple>* i;
  BasicTupleSet<HeardIfaceTuple>* j;
}
#endif

//---------------------------------------------------------------------------
