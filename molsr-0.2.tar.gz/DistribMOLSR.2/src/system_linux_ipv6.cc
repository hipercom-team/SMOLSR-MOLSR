//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// System calls for Linux, IPv6
//---------------------------------------------------------------------------
// For IPv6, see for instance documentation:
//   http://www.gsp.com/cgi-bin/man.cgi?section=4&topic=ip6
//   misc. RFC, http://www.ietf.org/rfc/rfc3542.txt, ...
//---------------------------------------------------------------------------

#include <sys/types.h>
#include <netdb.h>
#include <net/if.h>

#include <ifaddrs.h>

//---------------------------------------------------------------------------

#include "system_linux.h"
#include "scheduler_simulation.h"

//---------------------------------------------------------------------------

class LinuxIPv6LowLevel : public LinuxLowLevel
{
public:
  static const int AddressSize = 128/8; // in bytes, XXX: use #include

  typedef sockaddr_in6 SystemAddress;


  static bool shouldMakeOneSocket()
  { return false; } // should make two sockets, one input, one output

  static void* systemAddressToRawAddress(SystemAddress& systemAddress)
  {
    assert( systemAddress.sin6_family == AF_INET6 );
    assert( sizeof(systemAddress.sin6_addr) == AddressSize );
    return &(systemAddress.sin6_addr);
  }

  static void rawAddressToSystemAddress(void* rawAddress, 
					SystemAddress& resultAddress)
  {
    memset(&resultAddress, 0, sizeof(resultAddress));
    resultAddress.sin6_family = AF_INET6;
    memcpy(&resultAddress.sin6_addr, rawAddress, AddressSize);
  }

  static int makeUDPSocket()
  {
    int sd = socket(PF_INET6, SOCK_DGRAM, 0);
    if(sd < 0)
      Fatal(" socket(PF_INET6, SOCK_DGRAM, 0): " << strerror(errno));
    return sd;
  }

  static void strToAddress(sockaddr_in6& sockAddress, 
			   string strGroupAddress)
			     
  {
    memset(&sockAddress, 0, sizeof(sockAddress));
    sockAddress.sin6_family = AF_INET6;

    if (strGroupAddress == "")
      sockAddress.sin6_addr = in6addr_any; 
    else inet_pton(AF_INET6, strGroupAddress.c_str(), &sockAddress.sin6_addr);
    //XXX ^^^ error management.
  }

  static void setAddressPort(SystemAddress& sockAddress, int udpPort)
  { sockAddress.sin6_port = htons(udpPort); }

  static void reprAddress(SystemAddress& address, char* result)
  { inet_ntop(AF_INET6, &address.sin6_addr, result, 4096 /*XXX!*/); }

  static void joinMulticastGroup(int sd, string ifaceName, int ifaceIndex,
				 string strGroupAddress)
  {
    struct ipv6_mreq mreq;
    memset (&mreq, 0, sizeof (mreq));
    inet_pton(AF_INET6, strGroupAddress.c_str(), &mreq.ipv6mr_multiaddr);
    mreq.ipv6mr_interface = ifaceIndex;
    
    if(setsockopt(sd, IPPROTO_IPV6, IPV6_JOIN_GROUP, 
		  (char *) &mreq, sizeof (mreq)) < 0)
      Fatal("setsockopt IPV6_JOIN_GROUP: " << strerror(errno) );
  }

  static void setSocketMulticastDefaultIface(int sd, int ifaceIndex,
					     SystemAddress& ifaceAddress)
  {
    // XXX: int ifaceIndex
    if (setsockopt(sd, IPPROTO_IPV6, IPV6_MULTICAST_IF, &ifaceIndex,
		   sizeof(ifaceIndex)) < 0)
      Fatal(" setsockopt IPV6_MULTICAST_IF: " << strerror(errno) );
  }

  static void socketBind(int sd, SystemAddress& address)
  {
    int status = bind(sd, (struct sockaddr*)&address, sizeof(address));
    if (status < 0)
      Fatal("socketBind: " << strerror(errno));
  }

  static int socketRecv(int sd, void* buffer, int bufferSize,
			SystemAddress& recvAddress)
  {
    socklen_t socketSize = sizeof(recvAddress);
    int status = recvfrom(sd, buffer, bufferSize, /*flags*/ 0,
			  (struct sockaddr*)&recvAddress, &socketSize);
    if(status <0) { // XXX: warning
      Warn("error in recvfrom: " << strerror(errno));
      return status;
    } else {
      return status;
    }
  }

  static void socketSend(int sd, void* data, int dataSize, 
			SystemAddress& sendAddress)
  {
    if(sendto(sd, data, dataSize, 0, (sockaddr*)&sendAddress,
	      sizeof(sendAddress)) <0)
      Fatal(" sendto: " << strerror(errno) );// XXX: not fatal
  }

};

//---------------------------------------------------------------------------

class LinuxIPv6NetworkConfigurator : public INetworkConfigurator
{
public:
  typedef LinuxSystemIface<LinuxIPv6LowLevel> IPv6Iface;
  bool notFatal;

  LinuxIPv6NetworkConfigurator(LinuxAddressFactory<LinuxIPv6LowLevel>* 
			       aAddressFactory, bool aNotFatal)
    : addressFactory(aAddressFactory), notFatal(notFatal) { }

  LinuxAddressFactory<LinuxIPv6LowLevel>* addressFactory;

  /// Add one route in the kernel
  virtual void addRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric)
  {
#ifndef USE_SYSTEM_IP_ROUTE
    IPv6Iface* linuxIface = dynamic_cast<IPv6Iface*>(iface);
    LinuxIPv6LowLevel::addRoute(AF_INET6, linuxIface->ifaceIndex, 
				destIpAddress, gatewayAddress, 
				netMaskAddress, metric, notFatal);
#else
    actionRoute("add", iface, destIpAddress,
		gatewayAddress, netMaskAddress, metric);
#endif
  }
  
  /// Remove one route from the kernel
  virtual void removeRoute(ISystemIface* iface, Address destIpAddress,
			   Address gatewayAddress, Address netMaskAddress, 
			   int metric)
  {
#ifndef USE_SYSTEM_IP_ROUTE
    IPv6Iface* linuxIface = dynamic_cast<IPv6Iface*>(iface);
    LinuxIPv6LowLevel::removeRoute(AF_INET6, linuxIface->ifaceIndex, 
				   destIpAddress, gatewayAddress, 
				   netMaskAddress, metric, notFatal);
#else
    actionRoute("del", iface, destIpAddress,
		gatewayAddress, netMaskAddress, metric);
#endif
  }


  void actionRoute(char* actionName,
		   ISystemIface* iface, Address destIpAddress,
		   Address gatewayAddress, Address netMaskAddress, 
		   int metric)
  {
    Warn("XXX!: this is a hack");
    char command[4096]; // XXX!: check
    IPv6Iface* systemIface = 
      dynamic_cast<IPv6Iface*>(iface);

    struct sockaddr_in6 destIPv6Address;
    struct sockaddr_in6 gatewayIPv6Address;
    addressFactory->makeSystemAddress(destIpAddress, destIPv6Address);
    addressFactory->makeSystemAddress(gatewayAddress, gatewayIPv6Address);

    // XXX: another hack:
    char destStrAddress[4096]; // XXX
    char gatewayStrAddress[4096]; //XXX
    inet_ntop(AF_INET6, &destIPv6Address.sin6_addr, destStrAddress,
	      sizeof(destStrAddress));
    inet_ntop(AF_INET6, &gatewayIPv6Address.sin6_addr, gatewayStrAddress,
	      sizeof(gatewayStrAddress));

    if (metric == 1) {
      sprintf(command, "/bin/ip route %s %s metric %d dev %s", actionName,
	      destStrAddress, metric,
	      systemIface->getName().c_str());      
    } else {
      sprintf(command, "/bin/ip route %s %s via %s metric %d dev %s", 
	      actionName, destStrAddress, gatewayStrAddress, metric,
	      systemIface->getName().c_str());
    }

    //cerr << "addRoute: " << command << endl; // XXX!!
    system(command);
  }

};

//---------------------------------------------------------------------------


class LinuxIPv6SystemFactory : public ISystemFactory
{
public:
  LinuxIPv6SystemFactory(ProtocolConfig* aProtocolConfig) 
    : protocolConfig(aProtocolConfig)
  {
    baseScheduler = new SimulationScheduler;
    scheduler = new IOScheduler(baseScheduler);
    baseScheduler->setTime(scheduler->getTime());
    networkConfigurator = new LinuxIPv6NetworkConfigurator(&addressFactory,
        protocolConfig->ignoreRouteSetupError);
  }

  virtual AddressFactory* getAddressFactory() 
  { return &addressFactory; }

  virtual ISystemIface* getIfaceByName(ProtocolConfig* protocolConfig,
				       const string name, 
				       IfaceConfig* ifaceConfig);

  virtual INetworkConfigurator* getNetworkConfigurator()
  { return networkConfigurator; }

  virtual IScheduler* getScheduler()
  { return scheduler; }
  
  virtual void visitNode(Node* node)
  { startHTTPServer(scheduler, node); }

  virtual void collectSignalEvents(Node* node)
  { 
    if (node->getProtocolConfig()->useSignalMonitoring )
      startIWEVENTClient(scheduler, node); 
  }

protected:
  LinuxAddressFactory<LinuxIPv6LowLevel> addressFactory;
  LinuxIPv6NetworkConfigurator* networkConfigurator;
  IOScheduler* scheduler;
  SimulationScheduler* baseScheduler;
  ProtocolConfig* protocolConfig;
};


//---------------------------------------------------------------------------

void parseAddressAndSuffix(string addressOrPrefix, 
			   struct in6_addr& ipv6Address, int& prefixSize)
{
  string slashSet = "/";
  string::size_type pos = addressOrPrefix.find_first_of(slashSet);
  if (pos != string::npos) {
    // There is a prefix
    string addressStr = addressOrPrefix.substr(0, pos);

    int ok = inet_pton(AF_INET6, addressStr.c_str(), &ipv6Address);
    if (!ok) 
      Fatal("cannot parse (IPv6) prefix address: " << addressStr.c_str()
	    <<", " <<strerror(errno));
    
    string prefixStr = addressOrPrefix.substr(pos+1, 
					      addressOrPrefix.size()-(pos+1));
    const char* prefixData = prefixStr.c_str();
    char* endPrefixData = NULL;
    prefixSize = strtoul(prefixData, &endPrefixData, 0);
    if (endPrefixData[0] != '\0' || ! inrange(0, prefixSize, 128 /*XXX*/) )
      Fatal("invalid prefix size " << prefixSize << " in network address: "
	    << addressOrPrefix.c_str());
  } else {
    int ok = inet_pton(AF_INET6, addressOrPrefix.c_str(), &ipv6Address);
    if (!ok) 
      Fatal("cannot parse (IPv6) address: " << addressOrPrefix.c_str()
	    <<", " <<strerror(errno));

    prefixSize = 128/8; // XXX: IPV6 address size in bytes
  }
}

//---------------------------------------------------------------------------

ISystemIface* LinuxIPv6SystemFactory::getIfaceByName
(ProtocolConfig* protocolConfig,
 const string name,
 IfaceConfig* ifaceConfig)
{
  struct ifaddrs* ifap=NULL;
  char buf[BUFSIZ];

  struct in6_addr networkAddressFilter;
  int networkPrefixFilter = -1;

  // XXX! check everywhere that length is correctly used (== strlen(...))
  if (protocolConfig->ipv6AddressFilter.length() > 0) {
    parseAddressAndSuffix(protocolConfig->ipv6AddressFilter, 
			  networkAddressFilter,
			  networkPrefixFilter);
  }


  memset(buf, 0, sizeof(buf));
  
  if (getifaddrs(&ifap) < 0) {
    return NULL;
  }

  for(struct ifaddrs* current = ifap;
      current != NULL; current = current->ifa_next) {
    if (current->ifa_addr == NULL)
      continue;
    
    if (current->ifa_addr->sa_family != AF_INET6)
      continue;
    if(strcmp(current->ifa_name, name.c_str()) != 0)
      continue;

    char strAddress[NI_MAXHOST];
  
    if(getnameinfo(current->ifa_addr, sizeof(struct sockaddr_in6), strAddress,
		   sizeof(strAddress), NULL, 0, NI_NUMERICHOST) < 0)
      continue;

    if (networkPrefixFilter >= 0) {
      
      struct in6_addr* ifaceRawAddress = 
	&(((sockaddr_in6*)current->ifa_addr)->sin6_addr);
      string ifaceStrRawAddress((char*)ifaceRawAddress, 128/8 /*XXX*/);
      string networkStrRawAddress((char*)&networkAddressFilter, 128/8 /*XXX*/);
      string networkPrefixStrRaw = 
	makeStringBitMaskNetworkOrder(128/8 /*XXX*/, networkPrefixFilter);

      if (stringBitAnd(ifaceStrRawAddress, networkPrefixStrRaw)
	  != networkStrRawAddress)
	continue;

    } else {
      // Default filter on site-local and unique-local addresses (XXX)
      if(strncmp(strAddress, "fec0:", strlen("fec0:")) != 0
	 && strncmp(strAddress, "fd", strlen("fd")) != 0) // XXX
	continue;
    }

    int resultIfaceIndex = if_nametoindex(name.c_str());
    Address ifaceAddress = addressFactory.makeAddress
      (*(sockaddr_in6*)current->ifa_addr);
    freeifaddrs(ifap);
    return new 
      LinuxSystemIface<LinuxIPv6LowLevel>
      (name, ifaceAddress,
       resultIfaceIndex,
       scheduler, &addressFactory,
       protocolConfig->ipv6MulticastAddress, ifaceConfig,
       protocolConfig->udpPort);
  }
  //current->ifa_addr;
  //current->ifa_netmask;
  //current->ifa_broadaddr;

  freeifaddrs(ifap);
  
  return NULL;
}

ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig)
{ return new LinuxIPv6SystemFactory(protocolConfig); }

#if 0
ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig)
{ return NULL; }
#endif

//---------------------------------------------------------------------------
