//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Adokoe Plakoo, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//     $Id: node_link_monitoring.cc,v 1.9 2004/12/27 16:03:20 plakoo Exp $
//---------------------------------------------------------------------------
// This file implements the link monitring to enhance the robustness
// of the link sensing mechanism
//---------------------------------------------------------------------------

#include "node.h"

bool HeardIfaceTuple::getLinkPending()
{
  bool result = true;

  if (node->getProtocolConfig()->useSignalMonitoring && 
      node->getProtocolConfig()->useHysteresisMonitoring)

    result = ( (H_signalMonitoringInfo.linkPending == false) && 
               (H_hysteresisMonitoringInfo.linkPending == false) ) ?
             false : true;

  else 
    if (!node->getProtocolConfig()->useSignalMonitoring)

      result = H_hysteresisMonitoringInfo.linkPending;

    else
      if (!node->getProtocolConfig()->useHysteresisMonitoring)

	result = H_signalMonitoringInfo.linkPending;

  return result;
}

//-----------------------------------------------------------------------------

Time HeardIfaceTuple::getLostTime()
{

  if ( getLinkPending() )
    return myMax(H_signalMonitoringInfo.lostTime,
		    H_hysteresisMonitoringInfo.lostTime);
  else 
    return myMin(H_signalMonitoringInfo.lostTime,
		    H_hysteresisMonitoringInfo.lostTime);
}

//-----------------------------------------------------------------------------

void HeardIfaceTuple::
setLinkQualityByHysteresis(int currentPacketSequenceNumber)
{
#define InstabilityRule(quality) \
 ( 1 - node->getHysteresisScaling() ) * quality

#define StabilityRule(quality) \
 ( 1 - node->getHysteresisScaling() ) * quality + node->getHysteresisScaling()

  if (H_hysteresisMonitoringInfo.linkQuality == 0) /* Initialization */
    H_hysteresisMonitoringInfo.linkQuality = node->getHysteresisScaling();

  /* Packet Sequence Number wraparound case */
  if ( currentPacketSequenceNumber < H_last_packetSequenceNumber &&
       (_ansnGreater(currentPacketSequenceNumber, H_last_packetSequenceNumber))
     )
    {
      if ( (H_last_packetSequenceNumber != MaxPacketSequenceNumber - 1) || 
	   (currentPacketSequenceNumber != 0) )
	{
	  int nb_lost = MaxPacketSequenceNumber - 1 \
	    - H_last_packetSequenceNumber + currentPacketSequenceNumber;
	  
	  while (nb_lost)
	    { 
	      H_hysteresisMonitoringInfo.linkQuality = 
		InstabilityRule(H_hysteresisMonitoringInfo.linkQuality);
	      nb_lost--;
	    }
	}

	H_hysteresisMonitoringInfo.linkQuality = 
	  StabilityRule(H_hysteresisMonitoringInfo.linkQuality);
    }
  else 
    {
      if (currentPacketSequenceNumber > H_last_packetSequenceNumber) 
	{
	  if (currentPacketSequenceNumber != H_last_packetSequenceNumber + 1)
	    {
	      int nb_lost = currentPacketSequenceNumber - \
		H_last_packetSequenceNumber - 1;
	      
	      while (nb_lost > 0)
		{ 
		  H_hysteresisMonitoringInfo.linkQuality =
		    InstabilityRule(H_hysteresisMonitoringInfo.linkQuality);
		  nb_lost--;
		}
	    }
	  
	  H_hysteresisMonitoringInfo.linkQuality = 
	    StabilityRule(H_hysteresisMonitoringInfo.linkQuality);

	}
    }
}

//-----------------------------------------------------------------------------

void HeardIfaceTuple::setLinkQualityBySignal(int signal)
{
#ifdef LINK_MONITORING

 // Update the power level field.
  if (signal == 0) // Maybe the packet came from a non-wireless interface.
                   // All packets are accepted.
    H_signalMonitoringInfo.linkQuality = node->getSignalThresholdHigh() + 10;
  else
    if (signal != -1)
      H_signalMonitoringInfo.linkQuality = signal;
    else
      H_signalMonitoringInfo.linkQuality = 0;

#endif
}

//-----------------------------------------------------------------------------

void HeardIfaceTuple::setLinkPending(MonitoringInfo& aMonitoringInfo, 
				     double highThreshold, double lowThreshold)
{
  bool saveValue = aMonitoringInfo.linkPending; 

  if ( aMonitoringInfo.linkQuality > highThreshold ) 
    {
      aMonitoringInfo.linkPending = false; 
      aMonitoringInfo.lostTime = node->getCurrentTime() - 1; 

      if (saveValue != aMonitoringInfo.linkPending)
	aMonitoringInfo.stateChanged = true;
    } 
  
  if ( aMonitoringInfo.linkQuality < lowThreshold ) 
    {
      aMonitoringInfo.linkPending = true; 
      aMonitoringInfo.lostTime = aMonitoringInfo.lostTime 
	+ node->getProtocolConfig()->NEIGHB_HOLD_TIME; 
      aMonitoringInfo.stateChanged = true;
    }  
}

//-----------------------------------------------------------------------------

void HeardIfaceTuple::setLinkQuality(int currentPacketSequenceNumber, int signal)
{

  if (currentPacketSequenceNumber > 0)
    {
      if (node->getProtocolConfig()->useHysteresisMonitoring) 
	{
	  setLinkQualityByHysteresis(currentPacketSequenceNumber);
	  setLinkPending(H_hysteresisMonitoringInfo,
			 node->getHysteresisThresholdHigh(),
			 node->getHysteresisThresholdLow());
	}
    }
  else
    if (signal > 0)
      {
	// For interfaces on which we can't collect signal infos
	// set signal field to an acceptable value.
	
	setLinkQualityBySignal(0);
	setLinkPending(H_signalMonitoringInfo,
		       node->getSignalThresholdHigh(),
		       node->getSignalThresholdLow());
      }

  if (signal < 0)
    if (node->getProtocolConfig()->useSignalMonitoring) 
      {
	setLinkQualityBySignal(signal);
	setLinkPending(H_signalMonitoringInfo,
		       node->getSignalThresholdHigh(),
		       node->getSignalThresholdLow());
      }

  if (currentPacketSequenceNumber > 0)
    if ( _ansnGreater(currentPacketSequenceNumber, H_last_packetSequenceNumber) )
      H_last_packetSequenceNumber = currentPacketSequenceNumber;

  if (H_hysteresisMonitoringInfo.stateChanged ||
      H_signalMonitoringInfo.stateChanged) 
    {
      updateAssociatedLinkTuple();
      H_hysteresisMonitoringInfo.stateChanged = false;
      H_signalMonitoringInfo.stateChanged = false;
    }
}

//-----------------------------------------------------------------------------

void HeardIfaceTuple::updateAssociatedLinkTuple()
{
  LinkTuple* linkTuple = 
    node->linkSet.findFirst_SendAndReceiveIfaceAddress(H_remonte_iface_addr,
						       H_local_iface_addr);
  
  if (linkTuple) linkTuple->updateWithLinkMonitoring(this);
}
