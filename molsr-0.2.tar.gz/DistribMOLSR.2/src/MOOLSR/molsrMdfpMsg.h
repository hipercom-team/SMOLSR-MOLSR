//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

#include "base.h"
#include "address.h"
#include "packet.h"


class MCTreeEntryMessage
{
public:
  Address ifaceAddr;            /* The address of the outgoing iface */
  Address parentAddr;
  Address sourceAddr;
  Address groupAddr;
  
  bool operator ==(MCTreeEntryMessage item)
  {
    return((item.ifaceAddr==ifaceAddr)&&
	   (item.parentAddr==parentAddr)&&
	   (item.sourceAddr==sourceAddr)&&
	   (item.groupAddr==groupAddr));
  }
};
class MCTreeMessage: public IMessageContent
{
 public:
  MCTreeMessage(){header=NULL;}
  std::list<MCTreeEntryMessage> entry_list;
  
    virtual IMessageContent* clone()
  {
    MCTreeMessage* result = new MCTreeMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    
    std::insert_iterator< std::list<MCTreeEntryMessage> > ii(result->entry_list,
							     result->entry_list.begin());
    std::copy(entry_list.begin(), entry_list.end(), ii);
    
    return result;
  }
  virtual void write(std::ostream& out) const
  {
    out << "MCTree entry Message: ";
    for(std::list<MCTreeEntryMessage>::const_iterator it = entry_list.begin();
	it != entry_list.end(); it++) {
      if (it != entry_list.begin()) out << ",";
      out << "IfaceAddress="<<(*it).ifaceAddr   << " "
	  << "ParentAddress"<<(*it).parentAddr  << " "
	  << "SourceAddress"<<(*it).sourceAddr << " "
	  << "GroupAddress" <<(*it).groupAddr;
    }
  } 
};


class MCTreeSpecification
{
public:
  typedef MCTreeMessage MessageContent;
  typedef MCTreeEntryMessage MessageItem;
  static int getContentHeaderSize(int addressSize){ return 0; }
  static int getItemSize(int addressSize) { return 4*addressSize; }
  static void process(Node* node, MessageContent* m)
  {Warn("Received MCTree packet unexpected");}
  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer) 
  { }
  
  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { 
    
    MCTreeEntryMessage entry;
    entry.ifaceAddr= buffer.popAddress();
    entry.parentAddr= buffer.popAddress();
    entry.sourceAddr= buffer.popAddress();
    entry.groupAddr= buffer.popAddress();
    result->entry_list.push_back(entry);
  }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer) { }
  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { 
    
    buffer.packAddress(item.ifaceAddr); 
    buffer.packAddress(item.parentAddr); 
    buffer.packAddress(item.sourceAddr); 
    buffer.packAddress(item.groupAddr); 
  }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->entry_list; }

};


typedef GenericMessageHandler<MCTreeSpecification>MCTreeHandler;


//---------------------------------------------------------------------------
// This class of message is used to tell MOLSR that
// a new local client has joined 
// a local client has left
// a new local source started data multicast
// a new local source has stopped data multicast since a given period

class  LeaveNewLocalSrcClientEntryMessage
{
public:
  Address srcCli;
  Address group;
};

class LeaveNewLocalSrcClientMessage: public IMessageContent
{
 public:
  std::list<LeaveNewLocalSrcClientEntryMessage> entry_list;
  
    virtual IMessageContent* clone()
  {
    LeaveNewLocalSrcClientMessage* result = new LeaveNewLocalSrcClientMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    
    std::insert_iterator< std::list<LeaveNewLocalSrcClientEntryMessage> > ii(result->entry_list,
							     result->entry_list.begin());
    std::copy(entry_list.begin(), entry_list.end(), ii);
    
    return result;
  }
  virtual void write(std::ostream& out) const
  {
    out << messageTypeToString(header->messageType) ;
       
    for(std::list<LeaveNewLocalSrcClientEntryMessage>::const_iterator it = entry_list.begin();
	it != entry_list.end(); it++) {
      if (it != entry_list.begin()) out << ",";
      out << "SrcAddress="<<(*it).srcCli << " "
	  << "MulticastGroupAddress="<< (*it).group;
    }
  } 
};
class LeaveNewLocalSrcClientSpecification
{

public:
  typedef LeaveNewLocalSrcClientMessage MessageContent;
  typedef LeaveNewLocalSrcClientEntryMessage MessageItem;
  static int getContentHeaderSize(int addressSize){ return 0; }
  static int getItemSize(int addressSize) { return 2*addressSize; }

  static void process(Node* node, MessageContent* m);

  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer) 
  { }
  
  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { 
    LeaveNewLocalSrcClientEntryMessage entry;
 
    entry.srcCli= buffer.popAddress();
    entry.group= buffer.popAddress();
  
    result->entry_list.push_back(entry);
  }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer) { }
  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { 
    
    buffer.packAddress(item.srcCli); 
    buffer.packAddress(item.group); 
  }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->entry_list; }

};
typedef GenericMessageHandler<LeaveNewLocalSrcClientSpecification>LeaveNewLocalSrcClientHandler;
//---------------------------------------------------------------------------
// Notice that we will use the MID messages to inform MDFP of the multiple  
// interfaces attached to this node

//---------------------------------------------------------------------------
