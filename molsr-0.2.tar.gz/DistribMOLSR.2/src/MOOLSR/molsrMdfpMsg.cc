//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "molsrNode.h"


//---------------------------------------------------------------------------
void LeaveNewLocalSrcClientSpecification::process(Node* node, LeaveNewLocalSrcClientMessage* m)
{
   MolsrNode *molsrNode= dynamic_cast<MolsrNode*>(node);
  molsrNode->processLeaveNewLocalSrcClientMessage(m);
}

//---------------------------------------------------------------------------
