/*---------------------------------------------------------------------------
 *                             OOLSR
 *               Marc Badel, projet Hipercom, INRIA Rocquencourt
 *  Copyright 2001-2004 Institut National de Recherche en Informatique et
 *  en Automatique.  All rights reserved.  Distributed only with permission.
 *---------------------------------------------------------------------------
 *   Marc Badel (INRIA) novembre 2001
 *
 * Lecture d'interfaces Ethernet.  
 * 
 * Necessite la bibliotheque mathematique. 
 * 
 *---------------------------------------------------------------------------*/

/* include "iwlib.h" */		/* Header */
#define _GNU_SOURCE
#include <stdio.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <math.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>		/* gethostbyname, getnetbyname */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/socket.h>	/* Pour "struct sockaddr" et autres */
/*include <net/if.h> */
#include <net/route.h>          /* Pour les changements de routes */

/*------------------------------------------------------------------

Liste des codes d'appels a IOCTL sur les sockets d'interfaces sans fil

-------------------------------------------------------------------*/

#define SIOCGIWNAME	0x8B01		/* "get name" pour protocole sans fil */
#define SIOCGIWMODE	0x8B07		/* Lire le mode d'operation had-hoc ou non */
#define SIOCGIWFREQ	0x8B05		/* Demander au systeme la frequence radio en Hz */
#define SIOCGPOWERS     0x89F7          /* Pour la puissance des emetteurs recus */
#define SIOCGMETERS     0x89F8          /* Acces aux tallies d'une interface */

/*------------------------------------------------------------------

Structures d'interfaces avec les IOCTL sur interfaces sans fil

-------------------------------------------------------------------*/

#include <linux/wireless.h>

/* Description d'interfaces ethernet */

typedef struct __describe_interface {
  char ifname [IFNAMSIZ];        /* Nom de l'interface */
  struct sockaddr_in ip_addr;    /* Adresse IP de l'interface */
  struct sockaddr_in broad_addr; /* Adresse broadcast liee a l'interface */
  struct sockaddr_in netmask;    /* Masque sous-reseau lie a l'interface */
  short int if_flags;            /* Bits d'etat de l'interface */
  int if_mtu;                    /* Taille maximum de transfert */
  int if_metric;                 /* Metrique associee a l'interface */
  unsigned char hwaddr[6];       /* Adresse MAC de la carte interface */
  unsigned char addr_ipv6[16];   /* Adresse IPV6 de l'interface */
  int if_mode;                   /* -1 pour non wireless, zero pour */
                                 /* mode autre qu'ad-hoc, 1 pour mode haddock */
  double frequence;              /* Frequence d'emission */

} describe_interface;

int nb_interf= 0;
int ipv6_available;
describe_interface *interfaces_set= 0;
static describe_interface *current_interface= 0;

/* Code de differentes requetes a transmettre au systeme */

#define FLAGS_SOCKET 0
#define MTU_SOCKET 1
#define METRIC_SOCKET 2

#define NETMASK_HOST 0xffffffff
#define NETMASK_DEFAULT 0x0

/* Declarations liees a la lecture des puissances des emetteurs */

#define MAX_EMETTEURS 200

typedef struct __puiss_emetteur {
  unsigned int ip_addr;
  unsigned char mac_addr [6];
  char signal;
  char noise;
  struct timeval date_puiss;
  unsigned char cookie1,cookie2;
} puiss_emetteur;

puiss_emetteur tab_puiss [MAX_EMETTEURS];
int nb_emetteurs;

typedef unsigned short u16; 

struct hermes_tallies_frame {
  struct timeval tallies_time;
	u16 TxUnicastFrames;
	u16 TxMulticastFrames;
	u16 TxFragments;
	u16 TxUnicastOctets;
	u16 TxMulticastOctets;
	u16 TxDeferredTransmissions;
	u16 TxSingleRetryFrames;
	u16 TxMultipleRetryFrames;
	u16 TxRetryLimitExceeded;
	u16 TxDiscards;
	u16 RxUnicastFrames;
	u16 RxMulticastFrames;
	u16 RxFragments;
	u16 RxUnicastOctets;
	u16 RxMulticastOctets;
	u16 RxFCSErrors;
	u16 RxDiscards_NoBuffer;
	u16 TxDiscardsWrongSA;
	u16 RxWEPUndecryptable;
	u16 RxMsgInMsgFragments;
	u16 RxMsgInBadMsgFragments;
	/* Those last are probably not available in very old firmwares */
	u16 RxDiscards_WEPICVError;
	u16 RxDiscards_WEPExcluded;
} __attribute__ ((packed));


/*------------------------------------------------------------------

Convertir une structure sockaddr en chaine de caracteres 
representant l'adresse IP correspondante

-------------------------------------------------------------------*/

char *sockaddr_to_string (struct sockaddr_in *so_addr)
{
  char *result,*tmp;

  tmp= (char*) inet_ntoa (so_addr->sin_addr);
  result=strdup(tmp);
  return (result);
}

/*------------------------------------------------------------------

Ouvrir un socket pour interfacer avec le systeme ou le driver. 

Depending on the protocol present, open the right socket. The socket
will allow us to talk to the driver.

-------------------------------------------------------------------*/

int sys_sockets_open(void)
{
        int ipx_sock = -1;              /* IPX socket                   */
        int ax25_sock = -1;             /* AX.25 socket                 */
        int inet_sock = -1;             /* INET socket                  */
        int ddp_sock = -1;              /* Appletalk DDP socket         */

        /*
         * Now pick any (exisiting) useful socket family for generic queries
	 * Note : don't open all the socket, only returns when one matches,
	 * all protocols might not be valid.
	 * Workaround by Jim Kaba <jkaba@sarnoff.com>
	 * Note : in 99% of the case, we will just open the inet_sock.
	 * The remaining 1% case are not fully correct...
         */
        inet_sock=socket(AF_INET, SOCK_DGRAM, 0);
        if(inet_sock!=-1)
                return inet_sock;
        ipx_sock=socket(AF_IPX, SOCK_DGRAM, 0);
        if(ipx_sock!=-1)
                return ipx_sock;
        ax25_sock=socket(AF_AX25, SOCK_DGRAM, 0);
        if(ax25_sock!=-1)
                return ax25_sock;
        ddp_sock=socket(AF_APPLETALK, SOCK_DGRAM, 0);
        /*
         * If this is -1 we have no known network layers and its time to jump.
         */
        return ddp_sock;
}

/*------------------------------------------------------------------

Fermer un socket ayant servi a interfacer avec le systeme ou le driver. 

-------------------------------------------------------------------*/

void sys_sockets_close (int numsock)

{
  close (numsock);
}

/*-------------------------------------------------------------------

 Lecture des adresses IP par demande au systeme 

-------------------------------------------------------------------*/

int get_from_sys (int sock_fd, int code, char *name, struct sockaddr **result)
{
  int errcode;
  static struct ifreq ifr;

  strncpy (ifr.ifr_name,name,(size_t) IFNAMSIZ);
  errcode= ioctl (sock_fd,code,&ifr);

  if (result) {  /* Se reserver la possibilite de ne pas recuperer de valeur */
    *result= &(ifr.ifr_addr);
  }
  return (errcode);
}

/*-------------------------------------------------------------------

 Lecture de certains parametres sur une une interface par demande au systeme 

-------------------------------------------------------------------*/

int get_param_from_sys (int sock_fd, char *name, int param, int *result)

{
  int errcode;
  struct ifreq ifr;

  strncpy (ifr.ifr_name,name,(size_t) IFNAMSIZ);

  switch (param) {

  case FLAGS_SOCKET:

    errcode= ioctl (sock_fd,SIOCGIFFLAGS,&ifr);
    *((short*) result)= ifr.ifr_flags;
    if (errcode < 0) {
      perror ("Impossible d'avoir les flags ");
    }
    break;

  case MTU_SOCKET:

    errcode= ioctl (sock_fd,SIOCGIFMTU,&ifr);
    *result= ifr.ifr_mtu;
    if (errcode < 0) {
      perror ("Impossible d'avoir le MTU ");
    }
    break;

  case METRIC_SOCKET:

    errcode= ioctl (sock_fd,SIOCGIFMETRIC,&ifr);
    *result= ifr.ifr_metric;
    if (errcode < 0) {
      perror ("Impossible d'avoir la metrique ");
    }
    break;

  default:

    errcode= -1;
    break;

  }

  return (errcode);
}

/*------------------------------------------------------------------

 Avoir le mode sans fil et la frequence sur toutes les interfaces 
 si effectivement sans fil

-------------------------------------------------------------------*/

static int wireless_get_config (int skfd, char *ifname,
				int *mode, double *frequence)
{
  struct iwreq		wrq;

  memset(&wrq, 0, sizeof(wrq));

  /* Exploiter le nom de l'interface */

  strncpy ((char*)&(wrq.ifr_name[0]),ifname,IFNAMSIZ);

  if(ioctl(skfd, SIOCGIWNAME, &wrq) < 0) {
    /* Tester la presence ou non d'extensions wireless sur l'interface */
    *mode= -1;
    return(-1);
  }

  /* Avoir le mode d'operation (Ad-Hoc ou non)*/

  if(ioctl(skfd, SIOCGIWMODE, &wrq) >= 0)
    {
      if (wrq.u.mode == 1) { /* Mode Haddock */
	*mode= 1;
      } else {
	*mode= 0;
      }
    } else {
      *mode= -1;
    }

  /* Avoir la frequence */

  if(ioctl(skfd, SIOCGIWFREQ, &wrq) >= 0)
    {
      *frequence = ((double) wrq.u.freq.m)* pow (10,(wrq.u.freq.e));
    } else {
      *frequence= -1.0l;
    }

  return(0);
}

/*------------------------------------------------------------------

 Avoir toutes les infos sur toutes les interfaces et les memoriser 

-------------------------------------------------------------------*/

void upd_interfaces (int skfd)
{
  char buff[1024];
  struct ifconf ifc;
  struct ifreq *ifr;
  int i,j,ierr;
  FILE *f_proc_ipv6;
  unsigned int conv_pour_sscanf;
  unsigned char temp_ipv6_addr [16];
  char *tmpchar;
  char temp_ifname [IFNAMSIZ]; 
  int lgline,lgname;
  char *tmp;
  char tmp_conv[10];
  char *line= &(buff[0]);
  char **bufline= &line;
  int bufsize= 100;
  describe_interface *cur_interf;
  struct sockaddr *result_from_sys;

  /* Obtenir la liste des interfaces reseau actives  */

  ifc.ifc_len = sizeof(buff);
  ifc.ifc_buf = buff;
  if(ioctl(skfd, SIOCGIFCONF, &ifc) < 0)
    {
      fprintf(stderr, "SIOCGIFCONF: %s\n", strerror(errno));
      return;
    }
  ifr = ifc.ifc_req;

/* Liberer prudemment les structures eventuelles utilisees au coup precedent */

  if (interfaces_set) free (interfaces_set);

/* Allocation de nouvelles structures pour memoriser les resultats */

  nb_interf= ifc.ifc_len / sizeof(struct ifreq);
  interfaces_set= (describe_interface*) malloc (sizeof (describe_interface) * nb_interf);

  /* Mettre les interfaces en descripteur */

  current_interface= interfaces_set;

  for(i= 1; i <= nb_interf; i++) {

    strncpy ((char*)&(current_interface->ifname[0]),
	     (char*)&(ifr->ifr_name[0]),(size_t) IFNAMSIZ); 

    ierr= get_from_sys (skfd,SIOCGIFADDR,
			(char*)&(current_interface->ifname[0]), 
			&result_from_sys);
    memcpy ((char*)&(current_interface->ip_addr),
      (char*)result_from_sys,sizeof (struct sockaddr_in));

    ierr= get_from_sys (skfd,SIOCGIFBRDADDR,
			(char*)&(current_interface->ifname[0]), 
			&result_from_sys);
    memcpy ((char*)&(current_interface->broad_addr),
      (char*)result_from_sys,sizeof (struct sockaddr_in));

    ierr= get_from_sys (skfd,SIOCGIFNETMASK,
			(char*)&(current_interface->ifname[0]), 
			&result_from_sys);
    memcpy ((char*)&(current_interface->netmask),
      (char*)result_from_sys,sizeof (struct sockaddr_in));


    ierr= get_from_sys (skfd,SIOCGIFHWADDR,
			(char*)&(current_interface->ifname[0]), 
			&result_from_sys);
    memcpy ((char*)&(current_interface->hwaddr[0]),
      (((char*)result_from_sys)+2),6);

    ierr= get_param_from_sys (skfd,(char*)&(current_interface->ifname[0]), 
			      FLAGS_SOCKET,
			      (int*)(&(current_interface->if_flags))); 

    ierr= get_param_from_sys (skfd,(char*)&(current_interface->ifname[0]), 
			      MTU_SOCKET,
			      &(current_interface->if_mtu)); 

    ierr= get_param_from_sys (skfd,(char*)&(current_interface->ifname[0]), 
			      METRIC_SOCKET,
			      &(current_interface->if_metric)); 

    ierr= wireless_get_config (skfd,(char*)&(current_interface->ifname[0]), 
			       &(current_interface->if_mode),
			       &(current_interface->frequence));

    current_interface++;
    ifr++;
  }

  /* Tenter d'obtenir les adresses IPV6 (via /proc/net/if_inet6) */

  f_proc_ipv6= fopen ("/proc/net/if_inet6","r");

  if (f_proc_ipv6) {  /* Si IPV6 est disponible sur le systeme */

    ipv6_available= 1;

    while ((lgline= getline(bufline,&bufsize,f_proc_ipv6)) >= 0) { /* Jusqu'a EOF */

      tmp= &(buff[0]);

    /* Acquisition de l'adresse IPV6 dans /proc/net/if_ipv6 */

      for (i=0; i< 16; i++) { 
	tmp_conv[0]= *tmp;
	tmp++;
	tmp_conv[1]= *tmp;
	tmp++;
	tmp_conv[2]= '\0';
	j= sscanf (&(tmp_conv[0]),"%x",&conv_pour_sscanf);
	temp_ipv6_addr [i]= (unsigned char) conv_pour_sscanf;
      }

      /* Lecture du nom de l'interface dans /proc/net/if_ipv6 */
      /* avant de recoller les morceaux */

      tmp= &(buff[lgline-2]);  /* Enlever le caractere newline */
      tmpchar= tmp;
      lgname= 0; 
      while ((*tmpchar != ' ') && (lgname < (lgline-1))) {
	tmpchar--;
	lgname++;
      }
      /* Isoler le nom de l'interface avant de la rechercher */
      memset (&(temp_ifname[0]),0,IFNAMSIZ);
      if (lgname > 0) {
	tmpchar++;
	for (i=0; i<lgname; i++) {
	  temp_ifname[i]= *tmpchar;
	  tmpchar++;
	}
      }

      /* Retrouver maintenant l'interface et recopier l'adresse IPV6 */

      current_interface= interfaces_set;
      cur_interf= NULL;
      for (i=0; i<nb_interf; i++) {
	if (strncmp (&(temp_ifname[0]),&(current_interface->ifname[0]),
		     IFNAMSIZ) == 0) {
	  cur_interf= current_interface;
	  break;
	}
	current_interface++;
      }
      if (cur_interf) { /* Recopie finale de l'adresse IPV6 */

	for (i=0; i<16; i++) { 
	  cur_interf->addr_ipv6[i]= temp_ipv6_addr[i];
	}
      }
    }
  } else {

    ipv6_available= 0;

  }

  if (ipv6_available) { /* Refermer le pseudo-fichier IPV6 s'il existe */
      fclose (f_proc_ipv6);
  }

}

/*------------------------------------------------------------------

Interrogation du systeme sur la puissance et le bruit des emetteurs 
entendus: 

Appel: 

nb_emetteurs= get_powers_and_noises (skfd, table_resultats, nbmax, 
                                     macaddr, ipaddr);

ou macaddr et ipaddr ne peuvent etre donnes tous-deux (celui qui ne 
sert pas doit etre mis a zero). 

Si "macaddr" et "ipaddr" sont tous deux a zero, les resultats sont 
donnes pour l'ensemble des emetteurs recus et la fonction retourne 
le nombre d'emetteurs. 

L'argument "table_resultats" est l'adresse d'une table de structures de 
type "puiss_emetteur" (voir la description en tete de programme). La 
dimension maximum de la structure est de "nbmax" emetteurs au maximum. 

En cas d'erreur, le resultat de la fonction est de -1. 

Cette interrogation du systeme est analogue a celle effectuee par le 
programme "lec_puiss". 

------------------------------------------------------------------ */

int get_powers_and_noises(int skfd, char *ifname, 
                          puiss_emetteur *lec_puiss, int max_nb_puiss,
			  char *macaddr, unsigned int ipaddr) 
{
  struct iwreq wrq;
  int i_macaddr;
  int nb_emetteurs;

  /* Get wireless name */
  strcpy(wrq.ifr_name, ifname);

  /* Lire les puissances d'emetteurs */
  strcpy(wrq.ifr_name, ifname);
  wrq.u.data.pointer = (caddr_t) lec_puiss;
  wrq.u.data.length = 0;
  wrq.u.data.flags = 0;

  /* Demande t-on les resultats pour UN emetteur ou tous ? */

  /* Traitement d'abord de l'adresse MAC */

  if (macaddr) {
    strncpy ((char*) lec_puiss,macaddr,6);
  } else {
    for (i_macaddr=0; i_macaddr < 6; i_macaddr++) {
      *(((unsigned char*) lec_puiss)+i_macaddr)= '\0';
    }
  }

  /* Traitement aussi de l'adresse IP */

  if (ipaddr) {
    lec_puiss->ip_addr= ipaddr;
  } else {
    lec_puiss->ip_addr= 0;
  }

  /* Appel du systeme pour l'interroger */
  /* Renoncer a tout regrouper ici */

  if(ioctl(skfd, SIOCGPOWERS, &wrq) >= 0) {
    nb_emetteurs= wrq.u.data.length;
  } else {
    nb_emetteurs= -1;
  }
  return(nb_emetteurs);
}

/*------------------------------------------------------------------

Interrogation du systeme sur la puissance et le bruit d'un emetteur
particulier identifie par son adresse IP tx_ipaddr. Renvoie:
- zero si l'intreface locale est n'est pas une interface wireless sinon
- le signal de l'emetteur s'il existe dans la table des emetteurs
  detectes sinon 
- -1.

------------------------------------------------------------------ */
describe_interface *get_interf_by_num (int numero,int code);
int interf_name_to_num (char *nom);

int get_interface_signal(int skfd, char *iface_name, struct sockaddr_in tx_ipaddr)
{
  int nb_emetteur = 0, result;
  puiss_emetteur lec_puiss;
  describe_interface *local_iface;

  local_iface = get_interf_by_num(interf_name_to_num(iface_name), 0);

  if (local_iface == NULL)
    return -1;

  if (local_iface->if_mode == -1) // Interface non wireless
    result = 0;
  else
    {
      nb_emetteur = get_powers_and_noises(skfd, local_iface->ifname, &lec_puiss, 0, NULL,
					  tx_ipaddr.sin_addr.s_addr);
      if (nb_emetteur == 1)
	result = lec_puiss.signal;
      else 
	result = -1;
    }
  
  return result;
  
}


/*------------------------------------------------------------------

Interrogation du systeme sur diverses statistiques liees a une 
interface sans fil:

Appel: 

result= get_tallies_stats (skfd, if_name, *structure_lec_tallies)

ou la strucure "structure_lec_tallies" est de type "hermes_tallies_frame" 
decrite plus haut. 

En cas d'erreur, le resultat de la fonction est de -1. Sinon, zero 
est renvoye. 

Cette interrogation du systeme est analogue a celle effectuee par le 
programme "lec_tallies". 

------------------------------------------------------------------ */

int get_tallies_stats (int skfd, char *ifname, 
		       struct hermes_tallies_frame *lec_tallies)
{
  struct iwreq		wrq;
  int result;

  /* Get wireless name */
  strcpy(wrq.ifr_name, ifname);

  /* Lire les puissances d'emetteurs */
  strcpy(wrq.ifr_name, ifname);
  wrq.u.data.pointer = (caddr_t) lec_tallies;
  wrq.u.data.length = 0;
  wrq.u.data.flags = 0;

  /* Code de l'appel systeme mis en tete du bloc de donnees utilisateur */

  *((int*) lec_tallies)= 1;

  /* Appel du systeme pour l'interroger */

  result= ioctl(skfd, SIOCGMETERS, &wrq); 
  return (result);
}

/*------------------------------------------------------------------

Lire le nombre d'interfaces utiles: 

Appel: nb_interfaces= get_nb_interf (code entier); 

ou le code a pour valeur (de meme que dans une structure 
describe_interface):

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc.

------------------------------------------------------------------ */

int get_nb_interf (int code)
{
  int result;
  int i;

  if (code < 0) { 
    return (nb_interf); /* Nombre total d'interfaces */
  }

  /* Cas ou les interfaces doivent etre selectionnees */

  result= 0;
  current_interface= interfaces_set;
  for (i=0; i<nb_interf; i++) {
    if (code > 0) {
      if (current_interface->if_mode > 0) result++;
    } else {
      if (current_interface->if_mode >= 0) result++;
    }
    current_interface++;
  }
  return (result);
}

/*------------------------------------------------------------------

Obtenir le pointeur sur une interface de la table de numero 
et de type donne. 

Appel: pointeur_descripteur= get_interf_by_num (numero,code entier); 

Le numero d'interface peut varier de 1 au nombre total. 
Seules, les interfaces selectionnees au titre du code prennent 
part a la numerotation. Par convention cependant, le numero zero 
renvoie le pointeur sur toute la table sans qu'il soit alors tenu 
compte du code. 

Le code a pour valeur (comme dans le cas precedent):

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc.

Il sert a selectionner les interfaces prises en compte dans la 
numerotation. 

Le resultat renvoye pour la fonction est le pointeur sur le 
descripteur recherche, ou le pointeur nul dans le cas d'un 
numero trop grand. 

------------------------------------------------------------------ */

describe_interface *get_interf_by_num (int numero,int code)
{
    describe_interface *cur_interf;
    int i, compteur;

    compteur= 0;

    for (i=0; i<nb_interf; i++) {

	cur_interf= interfaces_set+i;

/* Test mode ad-hoc OK ou non */

	if ((code > 0) && (cur_interf->if_mode <=0)) continue;

/* Test mode wireless simple OK ou non */

	if ((code == 0) && (cur_interf->if_mode < 0)) continue;

/* Cas ou on considere l'interface comme OK */

	compteur++;
	if (compteur == numero) { /* Cas trouve et OK */
	    return (cur_interf);
	}
    }

/* Cas rien n'a ete trouve ou numero trop grand ou incorrect */

    return (NULL);
}

/*------------------------------------------------------------------

Edition de l'etat d'une interface 

------------------------------------------------------------------ */

void list_interface_by_ptr (describe_interface *list_interf)
{
  char buffer[100];
  char *ipaddr,*broadaddr,*netmask; 
  int i;

  strncpy ((char*) &(buffer[0]),(char*)&(list_interf->ifname[0]),
	   IFNAMSIZ);
  buffer[IFNAMSIZ]= '\0';

  printf ("Interface %s \n",(char*)&(buffer[0]));

  ipaddr= sockaddr_to_string (&(list_interf->ip_addr));
  broadaddr= sockaddr_to_string (&(list_interf->broad_addr));
  netmask= sockaddr_to_string (&(list_interf->netmask));

  printf ("IPADDR %s BCAST %s MASK %s \n",ipaddr,broadaddr,netmask);

  free (ipaddr);
  free (broadaddr);
  free (netmask);

  if (ipv6_available) {
    printf("Adresse IPV6: ");
    for (i=0; i<16; i++) {
      printf ("%02x",list_interf->addr_ipv6[i]);
    }
    printf (" \n");
  } else {
    printf ("Pas d'adresse IPV6 \n");
  }

  printf ("MACADDR %02x:%02x:%02x:%02x:%02x:%02x \n", 
	  list_interf->hwaddr[0],list_interf->hwaddr[1],
	  list_interf->hwaddr[2],list_interf->hwaddr[3],
	  list_interf->hwaddr[4],list_interf->hwaddr[5]);

  printf ("MTU: %10d METRIC %10d \n",list_interf->if_mtu,
	  list_interf->if_metric);

  if (list_interf->if_mode < 0) { 

    printf ("Cette interface n'est pas wireless \n");

  } else if (list_interf->if_mode == 0) { 

    printf ("Interface wireless mais non mode ad-hoc \n");
    printf ("Frequence d'emission: %12.0f \n",list_interf->frequence);

  } else {

    printf ("Cette interface est wireless et en mode haddock \n");
    printf ("Frequence d'emission: %12.0f Hertz \n",list_interf->frequence);
  }

  printf ("Etat de l'interface: ");
  if (list_interf->if_flags & IFF_UP) {
    printf ("UP");
  } else {
    printf ("DOWN");
  }
  if (list_interf->if_flags & IFF_LOOPBACK) { 
    printf (" LOOPBACK \n");
  } else { 
    printf (" \n");
  }
}

/*------------------------------------------------------------------

Edition de l'etat d'une interface donnee par son numero.

Appel: list_interface_by_num (numero,code); ou le code sert 
encore a specifier les interfaces prises en compte dans la 
numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc.

------------------------------------------------------------------ */

void list_interface_by_num (int numero, int code)
{
    describe_interface *cur_interf;

    cur_interf= get_interf_by_num (numero, code); 
    if (cur_interf) {
	list_interface_by_ptr (cur_interf);
    }
}


/*------------------------------------------------------------------

Obtenir le nom d'une interface par son numero:

Appel: char* nom= interf_num_to_name (numero,code); 

ou le code sert encore a specifier les interfaces prises 
en compte dans la numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc. 

La chaine de caracteres resultat est allouee en memoire.

------------------------------------------------------------------ */

char *interf_num_to_name (int numero, int code)
{
    describe_interface *cur_interf;
    char *result;

    cur_interf= get_interf_by_num (numero,code);
    result= strdup ((const char*) &(cur_interf->ifname[0]));
    return (result);
}

/*------------------------------------------------------------------

Obtenir le numero d'une interface par son nom:

Appel: numero= interf_name_to_num (nom); 

Le numero est ici donne par rapport a l'ensemble de toutes les 
interfaces. 

Si aucune interface n'est trouvee avec le nom indique, le numero 
retourne est de -1. 

------------------------------------------------------------------ */

int interf_name_to_num (char *nom)
{
    int i;
    describe_interface *cur_interf;

    cur_interf= interfaces_set;

    for (i=1; i<=nb_interf; i++) {

	if (strcmp (nom,((char*) &(cur_interf->ifname[0]))) == 0) {
	    return (i);
	}
	cur_interf++;
    }
    return (-1);
}

/*------------------------------------------------------------------

Obtenir l'adresse IPV4 d'une interface:

Appel: erreur= get_IPV4_addr (numero, code, *adresse); 

ou le code sert encore a specifier les interfaces prises 
en compte dans la numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc. 

Le numero est ici donne par rapport a l'ensemble de toutes les 
interfaces. 

Si aucune interface n'est trouvee, -1 est retourne, zero sinon. 

------------------------------------------------------------------ */

int get_IPV4_addr (int numero, int code, 
		   struct in_addr *adresse)
{
    describe_interface *cur_interf;

    cur_interf= get_interf_by_num (numero, code);
    if (cur_interf) {
      memcpy (adresse,&(cur_interf->ip_addr.sin_addr),
	      sizeof (struct in_addr));
      return (0);
    } else {
	return (-1);
    }
}

/*------------------------------------------------------------------

Obtenir le masque reseau IPV4 d'une interface:

Appel: erreur= get_IPV4_mask (numero, code, *adresse); 

ou le code sert encore a specifier les interfaces prises 
en compte dans la numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc. 

Le numero est ici donne par rapport a l'ensemble de toutes les 
interfaces. 

Si aucune interface n'est trouvee, -1 est retourne, zero sinon. 

------------------------------------------------------------------ */

int get_IPV4_mask (int numero, int code, 
		   struct in_addr *adresse)
{
    describe_interface *cur_interf;

    cur_interf= get_interf_by_num (numero, code);
    if (cur_interf) {
      memcpy (adresse,&(cur_interf->netmask.sin_addr),
	      sizeof (struct in_addr));
      return (0);
    } else {
	return (-1);
    }
}

/*------------------------------------------------------------------

Obtenir l'adresse broadcast IPV4 liee a une interface:

Appel: erreur= get_IPV4_broadcast (numero, code, *adresse); 

ou le code sert encore a specifier les interfaces prises 
en compte dans la numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc. 

Le numero est ici donne par rapport a l'ensemble de toutes les 
interfaces. 

Si aucune interface n'est trouvee, -1 est retourne, zero sinon. 

------------------------------------------------------------------ */

int get_IPV4_broadcast (int numero, int code, 
			struct in_addr *adresse)
{
    describe_interface *cur_interf;

    cur_interf= get_interf_by_num (numero, code);
    if (cur_interf) {
      memcpy (adresse,&(cur_interf->broad_addr.sin_addr),
	      sizeof (struct in_addr));
      return (0);
    } else {
	return (-1);
    }
}

/*------------------------------------------------------------------

Obtenir les flags lies a une interface:

Appel: flags= get_flags_interf (numero,code); 

ou le code sert encore a specifier les interfaces prises 
en compte dans la numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc. 
Le numero est ici donne par rapport a l'ensemble de toutes les 
interfaces. 

Si aucune interface n'est trouvee, zero est retourne. 

------------------------------------------------------------------ */

short int get_flags_interf (int numero,int code)
{
    describe_interface *cur_interf;

    cur_interf= get_interf_by_num (numero, code);
    if (cur_interf) {
	return (cur_interf->if_flags);
    } else {
	return ((short int) 0);
    }
}

/*------------------------------------------------------------------

Obtenir la taille maximum de transfert (MTU) sur une interface:

Appel: MTU entier= get_MTU_interf (numero,code); 

ou le code sert encore a specifier les interfaces prises 
en compte dans la numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc. 
Le numero est ici donne par rapport a l'ensemble de toutes les 
interfaces. 

Si aucune interface n'est trouvee, zero est retourne. 

------------------------------------------------------------------ */

int get_MTU_interf (int numero,int code)
{
    describe_interface *cur_interf;

    cur_interf= get_interf_by_num (numero, code);
    if (cur_interf) {
	return (cur_interf->if_mtu);
    } else {
	return (0);
    }
}

/*------------------------------------------------------------------

Obtenir la metrique liee a une interface:

Appel: entier= get_metric_interf (numero,code); 

ou le code sert encore a specifier les interfaces prises 
en compte dans la numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc. 
Le numero est ici donne par rapport a l'ensemble de toutes les 
interfaces. 

Si aucune interface n'est trouvee, -1 est retourne. 

------------------------------------------------------------------ */

int get_metric_interf (int numero,int code)
{
    describe_interface *cur_interf;

    cur_interf= get_interf_by_num (numero, code);
    if (cur_interf) {
	return (cur_interf->if_metric);
    } else {
	return (0);
    }
}

/*------------------------------------------------------------------

Obtenir l'adresse MAC liee a une interface:

Appel: code= get_MACADDR_interf (char *macaddr, numero,code); 

ou le code sert encore a specifier les interfaces prises 
en compte dans la numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc. 
Le numero est ici donne par rapport a l'ensemble de toutes les 
interfaces. 

Si aucune interface n'est trouvee, -1 est retourne, zero sinon. 

------------------------------------------------------------------ */

int get_MACADDR_interf (char *macaddr,int numero,int code)
{
    describe_interface *cur_interf;

    cur_interf= get_interf_by_num (numero, code);
    if (cur_interf) {
	strncpy (macaddr,(char*) &(cur_interf->hwaddr[0]),6);
	return (0);
    } else {
	return (0);
    }
}

/*------------------------------------------------------------------

Obtenir l'adresse IPV6 liee a une interface:

Appel: code= get_IPV6_interf (char *IPV6addr, numero,code); 

ou le code sert encore a specifier les interfaces prises 
en compte dans la numerotation. Ses valeurs sont:

  -1 pour tout type d'interface sans aucune hypothese.

   0 pour toute interface wireless sans autre exigence.

   1 pour les interfaces wireless en mode ad-hoc. 
Le numero est ici donne par rapport a l'ensemble de toutes les 
interfaces. 

Si aucune interface n'est trouvee, ou bien que IPV6 n'est pas en 
fonction sur le systeme -1 est retourne, zero sinon. 

------------------------------------------------------------------ */

int get_IPV6_interf (char *macaddr,int numero,int code)
{
    describe_interface *cur_interf;

    cur_interf= get_interf_by_num (numero, code);
    if (cur_interf) {
	strncpy (macaddr,(char*) &(cur_interf->addr_ipv6[0]),16);
	return (0);
    } else {
	return (0);
    }
}

/*------------------------------------------------------------------

Tester si IPV6 est disponible sur le systeme:

Appel: entier= IPV6_available ();

Renvoie 1 si IPV6 disponible, zero sinon.

------------------------------------------------------------------ */

int IPV6_available ()
{
    return (ipv6_available);
}

/*------------------------------------------------------------------

Demander au noyau du systeme d'ajouter UNE route en IPV4:

Appel: entier= KERN_add_route_IPV4 (skfd,&addr_dest, &addr_gateway,
                  flags, netmask, metric, name_interf);

ou &addr_gateway peut etre passe a NULL dans le cas d'un acces direct 
possible. 

Dans le netmask, seul zero ou different de zero est pris en compte 
a l'appel. 

Le nom d'interface represente une interface a imposer si non NULL. 

Renvoie le code de bon achevement ou d'erreur retransmis par le 
syste`me. 

------------------------------------------------------------------ */

int KERN_add_route_IPV4(int skfd, 
		    struct in_addr *addr_dest, struct in_addr *addr_gateway,
		    unsigned short a_flags,unsigned int mask, short metric,
		    char *int_name)
{
  struct rtentry kernel_route;
  int result;

  memset(&kernel_route,0,sizeof(struct rtentry));

  memcpy((void*) &(((struct sockaddr_in *)&kernel_route.rt_dst)->sin_addr.s_addr),
	 (void*) addr_dest, sizeof (struct in_addr));
  ((struct sockaddr_in *)&kernel_route.rt_dst)->sin_family=AF_INET;
  
  if (addr_gateway) {
      memcpy((void*) &(((struct sockaddr_in *)&kernel_route.rt_gateway)->sin_addr.s_addr),
	     (void*) addr_gateway, sizeof (struct in_addr));
  }
  ((struct sockaddr_in *)&kernel_route.rt_gateway)->sin_family=AF_INET;
  

  kernel_route.rt_flags = a_flags;

  ((struct sockaddr_in *)&kernel_route.rt_genmask)->sin_family=AF_INET;  

  if (mask == 0) 
    ((struct sockaddr_in *)&kernel_route.rt_genmask)->sin_addr.s_addr=NETMASK_DEFAULT;
  else
    ((struct sockaddr_in *)&kernel_route.rt_genmask)->sin_addr.s_addr=NETMASK_HOST;

  
  kernel_route.rt_metric= metric+1;

  if (int_name)
    {
      kernel_route.rt_dev=(char*) malloc(strlen(int_name));
      strcpy(kernel_route.rt_dev, int_name);
    }

  result= ioctl (skfd, SIOCADDRT,&kernel_route);
  return (result);
}

/*------------------------------------------------------------------

Demander au noyau du systeme de detruire UNE route en IPV4:

Appel: entier= KERN_del_route_IPV4 (skfd, &addr_dest, netmask);

Dans le netmask, seul zero ou different de zero est pris en compte 
a l'appel. 

Renvoie le code de bon achevement ou d'erreur retransmis par le 
syste`me. 

------------------------------------------------------------------ */

int KERN_del_route_IPV4(int skfd, 
		    struct in_addr *addr_dest, struct in_addr *addr_gateway,
		    unsigned short a_flags,unsigned int mask,char *int_name)
{
  struct rtentry kernel_route;
  int result;

  memset(&kernel_route,0,sizeof(struct rtentry));

  memcpy((void*) &(((struct sockaddr_in *)&kernel_route.rt_dst)->sin_addr.s_addr),
	 (void*) addr_dest, sizeof (struct in_addr));
  ((struct sockaddr_in *)&kernel_route.rt_dst)->sin_family=AF_INET;
  
  if (addr_gateway) {
      memcpy((void*) &(((struct sockaddr_in *)&kernel_route.rt_gateway)->sin_addr.s_addr),
	     (void*) addr_gateway, sizeof (struct in_addr));
  }
  ((struct sockaddr_in *)&kernel_route.rt_gateway)->sin_family=AF_INET;
  
  kernel_route.rt_flags = a_flags;

  ((struct sockaddr_in *)&kernel_route.rt_genmask)->sin_family=AF_INET;  

  if (mask == 0) 
    ((struct sockaddr_in *)&kernel_route.rt_genmask)->sin_addr.s_addr=NETMASK_DEFAULT;
  else
    ((struct sockaddr_in *)&kernel_route.rt_genmask)->sin_addr.s_addr=NETMASK_HOST;

   result= ioctl (skfd, SIOCDELRT,&kernel_route);
   return (result);
}

/*---------------------------------------------------------------------------*/
