//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//     $Id: system_linux_ipv4.cc,v 1.8 2004/12/29 15:16:17 plakoo Exp $
//---------------------------------------------------------------------------

#include <sys/types.h>
#include <netdb.h>
#include <net/if.h>

//---------------------------------------------------------------------------

#include "system_linux.h"
#include "system_linux_ipv4.h"
#include "system_linux_ipv4_internal.h"
#include "scheduler_simulation.h"

//---------------------------------------------------------------------------

#define STR_IP_BROADCAST "255.255.255.255"



//---------------------------------------------------------------------------

typedef LinuxAddressFactory<LinuxIPv4LowLevel> LinuxIPv4AddressFactory;

class LinuxIPv4NetworkConfigurator : public INetworkConfigurator
{
public:
  int skfd; bool notFatal;

  typedef LinuxSystemIface<LinuxIPv4LowLevel> IPv4Iface;

  LinuxIPv4NetworkConfigurator(LinuxIPv4AddressFactory* aAddressFactory,
			       int aSkfd, bool aNotFatal) 
    : skfd(aSkfd), notFatal(aNotFatal), addressFactory(aAddressFactory)  { }


  /// Add one route in the kernel
  virtual void addRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric)
  {
#ifndef USE_KERN_ADD_ROUTE
    IPv4Iface* linuxIface = dynamic_cast<IPv4Iface*>(iface);
    LinuxIPv4LowLevel::addRoute(AF_INET, linuxIface->ifaceIndex,
				destIpAddress, gatewayAddress, 
				netMaskAddress, metric, notFatal);
#else
    sockaddr_in destSysAddr;
    sockaddr_in gatewaySysAddr;
    LinuxSystemIface<LinuxIPv4LowLevel>* ipv4Iface 
      = (LinuxSystemIface<LinuxIPv4LowLevel>*) iface;
    addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
    addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
    int status = KERN_add_route_IPV4(skfd, 
				     &destSysAddr.sin_addr,
				     &gatewaySysAddr.sin_addr,
				     0, 
				     0, //0xffffffffu, // XXX! real mask
				     metric, ipv4Iface->getName());
    if (status < 0)
      Fatal("KERN_add_route: " << strerror(errno) ); // XXX: not fatal
#endif
  }
  
  /// Remove one route from the kernel
  virtual void removeRoute(ISystemIface* iface, Address destIpAddress,
			   Address gatewayAddress, Address netMaskAddress, 
			   int metric)
  {
#ifndef USE_KERN_ADD_ROUTE
    IPv4Iface* linuxIface = dynamic_cast<IPv4Iface*>(iface);
    LinuxIPv4LowLevel::removeRoute(AF_INET, linuxIface->ifaceIndex,
				destIpAddress, gatewayAddress, 
				netMaskAddress, metric, notFatal);
#else
    sockaddr_in destSysAddr;
    sockaddr_in gatewaySysAddr;
    LinuxSystemIface<LinuxIPv4LowLevel>* ipv4Iface 
      = (LinuxSystemIface<LinuxIPv4LowLevel>*) iface;
    addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
    addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
    int status = KERN_del_route_IPV4(skfd, 
				     &destSysAddr.sin_addr,
				     &gatewaySysAddr.sin_addr,
				     0, 
				     0, //0xffffffffu, // XXX! real mask
				     metric, ipv4Iface->getName());
    if (status < 0)
      Fatal("KERN_del_route: "); // XXX: not fatal
#endif
  }

  LinuxIPv4AddressFactory* addressFactory;
};


class LinuxIPv4SystemFactory : public ISystemFactory
{
public:
  int skfd;

  LinuxIPv4SystemFactory(ProtocolConfig* aProtocolConfig) 
    : protocolConfig(aProtocolConfig)
  {
    skfd = LinuxIPv4LowLevel::makeUDPSocket();
    upd_interfaces(skfd);
    baseScheduler = new SimulationScheduler;
    scheduler = new IOScheduler(baseScheduler);
    baseScheduler->setTime(scheduler->getTime());
    networkConfigurator = new LinuxIPv4NetworkConfigurator
      (&addressFactory, skfd, protocolConfig->ignoreRouteSetupError);
  }

  virtual ~LinuxIPv4SystemFactory() {}

  virtual AddressFactory* getAddressFactory() 
  { return &addressFactory; }

  virtual ISystemIface* getIfaceByName(ProtocolConfig* protocolConfig,
				       const string name,
				       IfaceConfig* ifaceConfig);

  virtual INetworkConfigurator* getNetworkConfigurator()
  { return networkConfigurator; }

  virtual IScheduler* getScheduler()
  { return scheduler; }

  virtual void visitNode(Node* node)
  { startHTTPServer(scheduler, node); }
  
  virtual void collectSignalEvents(Node* node)
  { 
//    if (node->getProtocolConfig()->useSignalMonitoring )
      startIWEVENTClient(scheduler, node); 
  }
  
protected:
  LinuxIPv4AddressFactory addressFactory;
  LinuxIPv4NetworkConfigurator* networkConfigurator;
  IOScheduler* scheduler;
  SimulationScheduler* baseScheduler;
  ProtocolConfig* protocolConfig;
};

//systemFactory* getSystemFactory()
//return new LinuxSystemFactory<LinuxIPv6LowLevel>; }


ISystemIface* LinuxIPv4SystemFactory::getIfaceByName
(ProtocolConfig* protocolConfig, 
 const string name,
 IfaceConfig* ifaceConfig)
{
  if (!strncmp("pseudo:", name.c_str(), strlen("pseudo:"))) {

    string cxxname = name;
    cxxname.erase(0, strlen("pseudo:"));
    string comma = ",";
    vector<string> info = stringSplit(cxxname, comma);
    if (info.size() != 4)
      Fatal("Invalid pseudo interface name: " << name);
    //info[0];
    //int(info[1])
    string ifaceName = "pseudo:";
    ifaceName += info[0];
    ifaceName += ",";
    ifaceName += info[1];
      

    unsigned int srcPort = atoi(info[1].c_str());

    string destAddress = info[2];
    unsigned int destPort = atoi(info[3].c_str());

#ifdef WITH_IPV6
    sockaddr_in sockAddress;
    memset(&sockAddress, 0, sizeof(sockAddress));
    //sockAddress.sin6_family = AF_INET6;
    sockAddress.sin_family = AF_INET;
    inet_pton(AF_INET, info[0].c_str(), &sockAddress.sin_addr);
    Address ifaceAddress = addressFactory.makeAddress(sockAddress);

    return new
      LinuxSystemIface<LinuxIPv4LowLevel>(ifaceName, 
					  ifaceAddress,
					  -srcPort, // ifaceIndex - hack
					  scheduler, &addressFactory,
					  strdup(destAddress.c_str()),
					  ifaceConfig,
					  destPort);
#else
    UNUSED( srcPort );
    UNUSED( destPort );
    Fatal("XXX: no pseudo interfaces");
#endif
  }

  int ifaceNum = interf_name_to_num((char*)name.c_str()); //XXX: check it linux
  if (ifaceNum<0) 
    Fatal("Cannot find interface index for iface "<<name);
  describe_interface* ifaceInfo = get_interf_by_num (ifaceNum, -1);
  int ifaceIndex = if_nametoindex ((char*)name.c_str());
    
  Address ifaceAddress = addressFactory.makeAddress(ifaceInfo->ip_addr);

  // interface index
  if (ifaceIndex<0) 
    Fatal("Cannot find interface index for iface "<<name);
  
  return new 
    LinuxSystemIface<LinuxIPv4LowLevel>(name.c_str(), ifaceAddress, ifaceIndex,
					scheduler, &addressFactory,
					protocolConfig->ipv4MulticastAddress,
					ifaceConfig,
					protocolConfig->udpPort);
}

ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig)
{ return new LinuxIPv4SystemFactory(protocolConfig); }

//---------------------------------------------------------------------------
// This is for instanciating the templates with g++
// XXX: maybe there is a better way

#if 0
template class LinuxSystemIface<LinuxIPv4LowLevel>;

void _dummy_instantiation_2()
{
  //LinuxSystemIface<LinuxIPv4LowLevel>* something;
  &LinuxSystemIface<LinuxIPv4LowLevel>::openSocket;
}
#endif

//---------------------------------------------------------------------------
