//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements the Topology Discovery of Node
//---------------------------------------------------------------------------

#include "base.h"
#include "general.h"
#include "packet.h"
#include "node.h"

/// [TopologyDiscovery] This method is called when the OLSR Node is started
void Node::startTopologyDiscovery() 
{
  Time delay = _startDelay(0, protocolConfig->TC_INTERVAL);
  addGenerationEvent(delay, delay, &Node::eventTCGeneration, "tc-generation");
}

//--------------------------------------------------
/// [TopologyDiscovery] This method is called when an TCMessage is received
/// and should be processed.

void Node::processTCMessage(TCMessage* message)
{ 
  Message* header = message->header;

#ifdef WITH_STAT
    statisticSet->ensure(header->originatorAddress)->tcCount.add(1);
#endif
    
  Time currentTime = getCurrentTime();
  Time validityTime = header->getValidityTime();
  
  Address sendMainAddress = ifaceToMainAddress(header->sendIfaceAddress);
  if (!isSymmetricNeighbor(sendMainAddress)) // @@2513-2515
    return; 

  if(topologySet.findFirst_obsolete_tuple(header->originatorAddress,
					  message->ansn))
    return;
  

  TopologySet::TupleIterator it 
    = topologySet.getIter(IteratorArg(header->originatorAddress));
  while(!it.isDone())
    {
      TopologyTuple* topoTuple = it.getCurrent();
      if((topoTuple->T_last_addr==header->originatorAddress) 
	 && _ansnGreater(message->ansn,topoTuple->T_seq))
	{
	  it.removeAndDeleteCurrentAndDoNext();
	} else it.next();
    }
#if 0
  // XXX: This is funky removal, check the invariants on STL std spec anyway.
  // remove(topoTuple) results in a list_of_lastAddress[lastAddr].remove(...)
  // which is expected (by me) not to invalidate the nextIt iterator.
  // XXX: this can be factored out better with previous.
  list<TopologyTuple*>* tupleList 
    = topologySet.lastAddressToTupleList.get(header->originatorAddress);
  if (tupleList != NULL) {
    list<TopologyTuple*>::iterator it = tupleList->begin();
    while(it != tupleList->end()) {
      list<TopologyTuple*>::iterator nextIt = it; 
      nextIt++;

      TopologyTuple* topoTuple = *it;
      assert( topoTuple->T_last_addr == header->originatorAddress );
      if (_ansnGreater(message->ansn,topoTuple->T_seq))
	topologySet.remove(topoTuple);
      
      it = nextIt;
    }
  }
#endif  

  for( std::list<Address>::iterator it= message->addressList.begin();
      it!=message->addressList.end(); it++)
    {
      
      TopologyTuple* topologyTuple = topologySet.findFirst_tuple
	(header->originatorAddress,(*it));
      if (topologyTuple == NULL)
	{
	  topologyTuple= new TopologyTuple;
	  topologyTuple->T_last_addr=header->originatorAddress;
	  topologyTuple->T_dest_addr=(*it);
	  topologyTuple->T_seq=message->ansn;
	  topologyTuple->T_time=currentTime + validityTime; 
	  topologySet.add(topologyTuple);
	} else topologyTuple->T_time=currentTime + validityTime; 
      topologyTuple->update();
    }
}

//--------------------------------------------------
/// [TopologyDiscovery] This method is called when an TCMessage should
/// be generated.

void Node::eventTCGeneration() 
{
  updateCurrentTime();
  preEvent("gen-tc");
  // reschedule  XXX: refs
  double minDelay = protocolConfig->TC_INTERVAL - protocolConfig->MAXJITTER;
  if(minDelay <0) minDelay = 0;
  addGenerationEvent(getCurrentTime() + minDelay,
		     getCurrentTime() + protocolConfig->TC_INTERVAL,
		     &Node::eventTCGeneration, "tc-generation");

  TCMessage* tcMessage = new TCMessage;
  tcMessage->ansn = mprSelectorSet.ansn;
  tcMessage->reserved = 0; // XXX: draft ref

#if 0
  for(int i=0;i<10000;i++) // XXX: random data: put our main address
    tcMessage->addressList.push_back(getMainAddress());
#endif

  if (protocolConfig->tc_redundancy==TC_REDUNDANCY_FULL) {
    // put all the neighbors in the TC if TC_REDUNDANCY==2
    for(NeighborSet::TupleIterator it = neighborSet.getIter();
	!it.isDone(); it.next()) {
      NeighborTuple* neighborTuple = it.getCurrent();
      if (neighborTuple->N_status == SYM)
	tcMessage->addressList.push_back(neighborTuple->N_neighbor_main_addr);
    }
  } else {
    // XXX! bug: empty TCs should be sent only according to @@2486-2491
    
    // put all the mprSelectors in the TC if TC_REDUNDANCY==0 or 1
    for(MPRSelectorSet::TupleIterator itMprS = mprSelectorSet.getIter();
	!itMprS.isDone(); itMprS.next()) {
      MPRSelectorTuple* mprSelectorTuple = itMprS.getCurrent();
      tcMessage->addressList.push_back(mprSelectorTuple->MS_addr);
    }
    if (protocolConfig->tc_redundancy==TC_REDUNDANCY_EXTENDED)
       // add all the list of own mprs in the TC if TC_REDUNDANCY==1
      for(std::list<NeighborTuple*>::iterator itNeigh = mprList.begin(); 
	  itNeigh != mprList.end(); itNeigh++) 
	{
	  tcMessage->addressList.push_back((*itNeigh)->N_neighbor_main_addr);
	}
  }


  Message* message = new Message
    (TC_MESSAGE, // Message Type @@2402
     toMantissaExponentByte(protocolConfig->TOP_HOLD_TIME), // @@2404-2405
     getMainAddress(), // Originator @@835-836
     MaxTTL, // ttl, @@2403
     0); // hop vcount, @@868
  
  message->content = tcMessage;
  message->maxTime = getCurrentTime();
  //lastTimeTC = getCurrentTime();

  if (tcMessage->addressList.size() == 0) { 
    delete message; // XXX: empty TCs should be sent sometimes
    return;
  }


  packetManager->sendMessageToAll(message);

  postEvent("gen-tc");
}

//---------------------------------------------------------------------------

void TopologySet::notifyRemoval(TopologyTuple* tuple)
{ 
  node->shouldRecomputeRoute = true;
#if 0
 list<TopologyTuple*>* tupleList 
   = lastAddressToTupleList.get(tuple->T_last_addr);
 assert( tupleList != NULL );
 tupleList->remove(tuple);
#endif // MORE_OPT
}

void TopologySet::notifyAddition(TopologyTuple* tuple)
{ 
  node->shouldRecomputeRoute = true;
#if 0
 list<TopologyTuple*>* tupleList 
   = lastAddressToTupleList.get(tuple->T_last_addr);
 if (tupleList == NULL) {
   list<TopologyTuple*> emptyList;
   lastAddressToTupleList.add(tuple->T_last_addr, emptyList);
   tupleList = lastAddressToTupleList.get(tuple->T_last_addr);
   assert( tupleList != NULL );
 }
 tupleList->push_back(tuple);
#endif // MORE_OPT
}

//---------------------------------------------------------------------------
/// [TopologyDiscovery] Utility function which returns true if and only
/// if the ANSN is greater according to the ANSN comparison of the 
/// OLSR specification.
bool _ansnGreater(int s1, int s2)
{ 
  return( ((s1>s2)&&((s1-s2)<=MaxValue/2))||((s2>s1)&&((s2-s1)>MaxValue/2)));
}

//---------------------------------------------------------------------------
