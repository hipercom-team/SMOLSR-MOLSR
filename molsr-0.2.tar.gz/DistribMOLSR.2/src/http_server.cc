//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef UNDER_CE
#include <sys/types.h>
#include <sys/stat.h>
#endif
#ifndef SYSTEMwindows
#include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>

#ifndef UNDER_CE
#include <errno.h>
#endif

#include <scheduler_simulation.h>
#include <scheduler_unix.h>

#if defined(SYSTEMcygwin) || defined(SYSTEMlinux)
#include <sys/socket.h>
#endif

#ifndef SYSTEMwindows
#include <sys/select.h>
#include <netinet/in.h> // Linux
typedef void* SockoptPointer;
#endif


#ifdef SYSTEMwindows
#include <winsock2.h>
#ifndef SHUT_RDWR 
#define SHUT_RDWR SD_BOTH
#define SHUT_RD SD_RECEIVE
#endif // !defined(SHUT_RDWR)
typedef char* SockoptPointer;
typedef int socklen_t;
#endif // !defined(SYSTEMwindows)

#include "http_support.h"


//---------------------------------------------------------------------------
class SimpleHTTPServer;

class SimpleHTTPConnection : public IFdHandler, public IHTTPConnection
{
public:
  typedef enum {
    StateWaitingFirstChar, StateInput, StateSendingOutput,
    StateFinished
  } State;

protected:
  State state;
  IOScheduler* scheduler;
  SimpleHTTPServer* server;

  int socketFd;
  sockaddr_in sockAddr;

  string inputBuffer;
  string outputBuffer;

  string url;
  string method;
  string authentication;

public:
  SimpleHTTPConnection(SimpleHTTPServer* aServer, IOScheduler* aScheduler,
		       int aSocketFd, sockaddr_in& aSockAddr) 
    : state(StateWaitingFirstChar), scheduler(aScheduler), server(aServer),
      socketFd(aSocketFd), sockAddr(aSockAddr)
  { }

  virtual ~SimpleHTTPConnection()
  { Fatal("XXX: TODO"); }

  virtual bool waitingForInput() 
  { return (state == StateWaitingFirstChar) || (state == StateInput); }
  virtual bool waitingForOutput() 
  { return (state == StateSendingOutput); }
  virtual bool waitingForExcept() 
  { return false; /* XXX: TODO*/ }

  virtual void handleInput()
  {
    /* Set the connection file descriptor to no-delay mode. */
    //httpd_set_ndelay( connection.conn_fd );
    
    // Parse the whole message
    int MaxRequestSize = 16*1024;
    char* data = new char [MaxRequestSize];
    int status = recv(socketFd, data, MaxRequestSize, 0);
    
    if (status == 0) {
      // because connection was closed ?
      onInputError();
      return;
      // XXX: check with windows
    }

    if (status < 0) {
      onInputError(); 
      return;
      // XXX: check error, could be EAGAIN?
    }
    
    string newData(data, status);
    delete [] data;
    inputBuffer += newData;
    
    if (inputBuffer.find("\n\n") == string::npos 
	&& inputBuffer.find("\r\n\r\n") == string::npos) {
      if (inputBuffer.length() > 0)
	state = StateInput;
    } else {
      state = StateSendingOutput;
      processRequest();
    }
  }

  virtual void handleOutput() 
  {
    int count = send(socketFd, outputBuffer.data(), outputBuffer.length(), 0);
    if (count < 0) {
#ifndef UNDER_CE
      if (errno != EINTR && errno != EAGAIN) 
#endif
{
	Warn("Error in writing HTTP output: " << strerror(errno));
	endConnection();
	return;
      }
    } else if (count > 0) {
      outputBuffer.erase(0, count);
    }

    if (outputBuffer.length() == 0)
      endConnection();
  }

  virtual void handleExcept() 
  { Fatal("Impossible handleExcept"); }

  void onInputError()
  { 
    sendError(400, "Bad Request", 
	      "The request could not be understood by the server due to"
	      " malformed syntax or I/O problems.");
  }

  virtual void send404Error()
  { 
    sendError(404, "Not Found", 
	      "The server has not found anything matching the Request-URI.");
  }

  virtual void sendError(int errorCode, string title, string moreInfo,
			 string extraField = "");

  virtual void close() 
  { /* XXX: maybe do something here */ }

  virtual void serveFile()
  { send404Error(); }


  virtual void write(string data) 
  { outputBuffer += data; }

  virtual string getURL()
  { return url; }

  virtual string getAuthentication()
  { return authentication; }

  virtual void sendAuthenticate(string authenticateFieldOrRealm)
  {
    sendError(401, "Unauthorized", "The request requires user authentication.",
	      authenticateFieldOrRealm);
  }

  virtual FileDescriptor getFileDescriptor() 
  { return socketFd; }


  void endConnection()
  {
    //shutdown(socketFd, SHUT_RDWR);
#ifndef SYSTEMwindows
    ::close(socketFd);
#else // defined(SYSTEMwindows)
    closesocket(socketFd);
#endif
    scheduler->removeFdHandler(this);
    state = StateFinished;
    //XXX: delete memory
    //XXX: delete from list in server
  } 

  void vectorStringStrip(vector<string>& tokenList)
  {
    for (unsigned int i=0; i<tokenList.size(); i++) {
      string tmp = stringStrip(tokenList[i], " \t");
      tokenList[i] = tmp;
    }
  }

  void processRequest()
  {
    state = StateSendingOutput;
    inputBuffer = strReplace(inputBuffer, "\r", "");
    vector<string> lineList = stringSplit(inputBuffer, "\n");

    // Parse first line
    vector<string> requestLine = stringSplit(lineList[0], " ");
    vectorStringStrip(requestLine);
    if (requestLine[0] == "GET") {
      method = "GET";
      if (requestLine.size() > 1)
	url = requestLine[1];
    } else {
      sendError(501, "Not Implemented", 
		"The server does not support the functionality required"
		" to fulfill the request.");
      return;
    }
    
    // Parse other lines
    for (unsigned int i=1; i<lineList.size(); i++)
      if (stringStartsWith(lineList[i], "Authorization: ")) {
	authentication = strReplace(lineList[i], "Authorization: ", "");
      }

    visitorProcessRequest();
  }

  void visitorProcessRequest();
};

//---------------------------------------------------------------------------

class SimpleHTTPServer : public IHTTPServer, public IFdHandler
{
public:
  string errorTemplate;

  SimpleHTTPServer() : visitor(NULL), scheduler(NULL)  
  {
    errorTemplate = "<HTML><HEAD><TITLE>%d %s</TITLE></HEAD>\n"
      "<BODY BGCOLOR=\"#cc9999\" TEXT=\"#000000\">\n<H2>%d %s</H2>\n";    
  }

  int acceptSocket;

  virtual void open(IOScheduler* aScheduler, unsigned short port,
		    IHTTPConnectionVisitor* aVisitor)
  {
    assert( scheduler == NULL );
    scheduler = aScheduler;
    visitor = aVisitor;

    sockaddr_in ipv4Addr; //XXX: IPv6
    ipv4Addr.sin_family = AF_INET;
    ipv4Addr.sin_addr.s_addr = INADDR_ANY;
    ipv4Addr.sin_port = htons(port);
    
    acceptSocket = socket(PF_INET, SOCK_STREAM, 0);
    if (acceptSocket < 0)
      Fatal("Cannot create HTTP admin socket: " << strerror(errno));

    int on = 1;
    if (setsockopt(acceptSocket, SOL_SOCKET, SO_REUSEADDR,
		   (SockoptPointer)&on, sizeof(on)) < 0)
      Fatal("Cannot setsockopt SO_REUSEADDR on socket:" << strerror(errno));

    if (bind(acceptSocket, (sockaddr*)&ipv4Addr, sizeof(ipv4Addr)) <0)
      Fatal("Cannot bind HTTP admin socket: " << strerror(errno));

    int status = listen(acceptSocket, 10);
    if (status < 0)
      Fatal("Cannot listen on HTTP admin socket: " << strerror(errno));

    start();
  }
  
  string getErrorTemplate() { return errorTemplate; }
  
  void start()
  { scheduler->addFdHandler(this, NULL); }

  // IFdHandler methods
  virtual FileDescriptor getFileDescriptor() 
  { return acceptSocket; }

  virtual bool waitingForInput() { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; }
  virtual void handleOutput() { Fatal("Impossible handleOutput"); }
  virtual void handleExcept() { Fatal("Impossible handleExcept"); }

  virtual void handleInput()
  {
    sockaddr_in sockAddr;
    socklen_t sockAddrSize = sizeof(sockAddr);
    int status = accept(acceptSocket, (sockaddr*)&sockAddr, &sockAddrSize);
    
    if (status < 0)
      Fatal("Error in accept on HTTP admin port socket: " << strerror(errno));

    SimpleHTTPConnection* httpConnection = 
      new SimpleHTTPConnection(this, scheduler, status, sockAddr);
    scheduler->addFdHandler(httpConnection, NULL);
    connectionList.push_back(httpConnection);
  }

  virtual void setHTMLErrorTemplate(string htmlTemplate)
  { errorTemplate = htmlTemplate; }

  virtual ~SimpleHTTPServer()
  { Fatal("XXX: unimplemented"); }
  
public:
  IHTTPConnectionVisitor* visitor; // XXX: why public
protected:
  IOScheduler* scheduler;
  list<SimpleHTTPConnection*> connectionList;
};

//---------------------------------------------------------------------------

void SimpleHTTPConnection::sendError(int errorCode, string title,
				     string moreInfo, string extraFields)
{
  ostringstream errorCodeStream;
  errorCodeStream << errorCode;
  string tmp = "HTTP/1.1 @<ERROR CODE>@ @<ERROR MSG>@\r\n"
    "Content-Type: text/html\r\n" + extraFields + "\r\n";
  string tmp2 = strReplace(tmp, "@<ERROR CODE>@", errorCodeStream.str());
  string header = strReplace(tmp2, "@<ERROR MSG>@", title);
  string tmp3 = server->getErrorTemplate();
  string tmp4 = strReplace(tmp3, "%d", errorCodeStream.str());
  string body = strReplace(tmp4, "%s", title) + moreInfo;
  
  outputBuffer = header + body;
  state = StateSendingOutput;
}


void SimpleHTTPConnection::visitorProcessRequest()
{ server->visitor->visit(this); }

//---------------------------------------------------------------------------

IHTTPServer* makeHTTPServer()
{ return new SimpleHTTPServer; }

//---------------------------------------------------------------------------
