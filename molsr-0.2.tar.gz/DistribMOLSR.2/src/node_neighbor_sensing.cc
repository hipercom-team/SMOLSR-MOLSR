//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements the Neighbor Sensing of Node
//---------------------------------------------------------------------------

#include "base.h"
#include "node.h"

//---------------------------------------------------------------------------
// Link set specific version of removeExpired:
// getExpireTime() returns not the expire time of the tuple, but the
// time by which the link status may change, so instead,
// L_time must be checked, before removing links
//
// XXX: getExpireTime should be renamed "getNextEventTime()"

// XXX! re-check invariants here
void LinkSet::removeAndDeleteExpired(Time currentTime)
{
  TupleIterator it = getIter();
  while(!it.isDone()) {
    (it.getCurrent())->update();
    if (it.getCurrent()->L_time <= currentTime) {
      // Remove the corresponding HeardIfaceTuple
#ifdef LINK_MONITORING
      it.getCurrent()->removeAndDeleteAssociatedHeardIfaceTuple();
#endif
      it.removeAndDeleteCurrentAndDoNext();
    }
    else it.next();
  }
}

// XXX: move
void writeLinkTuple(ostream& out, LinkTuple* l, Time currentTime)
{
  out << l->L_neighbor_iface_addr << "@" << l->L_local_iface_addr << " ";
  out << currentTime << "/" <<l->L_time;
  out << " " << linkTypeToString(l->getStatus());
}

//---------------------------------------------------------------------------

NeighborTuple* LinkTuple::getAssociatedNeighbor() 
{
  Address mainAddress = node->ifaceToMainAddress(L_neighbor_iface_addr);
  return node->neighborSet.findFirst_MainAddr(mainAddress);
} 

NeighborTuple::AssociatedLinkIterator 
NeighborTuple::getAssociatedLinkIterator()
{ 
  return AssociatedLinkIterator
    (HasLinkNeighborAddress(node, N_neighbor_main_addr), 
     node->linkSet.getIter());
}

NeighborTuple::AssociatedTwoHopNeighborIterator 
NeighborTuple::getAssociatedTwoHopNeighborIterator()
{ 
  return AssociatedTwoHopNeighborIterator
    (HasTwoHopNeighborAddress(N_neighbor_main_addr), 
     node->twoHopNeighborSet.getIter());
}

void NeighborTuple::_updateStatus()
{
  NeighborStatus newStatus = NOT_SYM;
  bool hasLink = false;
  for(AssociatedLinkIterator it = getAssociatedLinkIterator(); 
      !it.isDone(); it.next()) {
    hasLink = true;
    LinkTuple* linkTuple = it.getCurrent();
    if (linkTuple->getStatus() == SYM_LINK)
      newStatus = SYM;
  }

  if (newStatus != N_status) {
    // this implements both @@2327-2332 and @@2334-2339
    node->notifyOneHopNeighborhoodChange();
    N_status = newStatus;

    //XXX! [PRP] document this and check the invariants
    if (hasLink // otherwise will be deleted anyway
	&& newStatus == NOT_SYM)
      removeAssociatedTupleOnDisappearance();
  }

  if (!hasLink) {
    node->neighborSet.removeAndDelete(this);
    // note: changes are handled by notifyRemoval
  }
}

void NeighborTuple::removeAssociatedTupleOnDisappearance()
{
  // Remove associated two hop neighbor tuples:
  bool removedTwoHop = false;
#ifdef WITH_DELETE_PROBLEM
  // XXX: remove, or fix. This was buggy: iterate and at the same time,
  // delete some elements.
  for(NeighborTuple::AssociatedTwoHopNeighborIterator it =
	tuple->getAssociatedTwoHopNeighborIterator(); !it.isDone();it.next()) {
    node->twoHopNeighborSet.remove(it.getCurrent()); // <- XXX: bad
    removedTwoHop = true;
  }
#else
 {
  TwoHopNeighborSet::TupleIterator it = node->twoHopNeighborSet.getIter();
  while(!it.isDone()) {
    TwoHopNeighborTuple* twoHop = it.getCurrent();
    if (twoHop->N_neighbor_main_addr == N_neighbor_main_addr) //@@2360
      it.removeAndDeleteCurrentAndDoNext();
    else it.next();
  }
 }
#endif

  if (removedTwoHop) // XXX: redundant with TwoHopNeighborSet::notifyRemoval
    node->notifyTwoHopNeighborhoodChange();

  // @@2359-2360 XXX!!! RFC says "MS_main_addr", it's "MS_addr"
  MPRSelectorSet::TupleIterator it = node->mprSelectorSet.getIter();
  while(!it.isDone()) {
    MPRSelectorTuple* mprSelectorTuple = it.getCurrent();
    if (mprSelectorTuple->MS_addr == N_neighbor_main_addr) //@@2360
      it.removeAndDeleteCurrentAndDoNext();
    else it.next();
  }

}

//---------------------------------------------------------------------------

void NeighborSet::notifyAddition(NeighborTuple* tuple)
{ 
  /* nothing to do @@2334-2339 is handled by N_status change */ 
  assert( !tuple->N_neighbor_main_addr.isNull() );
}

void NeighborSet::notifyRemoval(NeighborTuple* tuple)
{ 
  /* nothing to do for @@2327-2332  ; handled by N_status change */
  tuple->removeAssociatedTupleOnDisappearance();
}

void LinkSet::notifyAddition(LinkTuple* linkTuple)
{ 
  NeighborTuple* neighborTuple = linkTuple->getAssociatedNeighbor();

  if (linkTuple->neighborTupleEnsured) {
    assert( neighborTuple != NULL );
    neighborTuple->_updateStatus();
  } else {
    // neighborTuple->_updateStatus()is actually directly called by 
    // Node::_processsHelloNeighbor later.
  }
}

void LinkSet::notifyRemoval(LinkTuple* linkTuple)
{ 
  NeighborTuple* neighborTuple = linkTuple->getAssociatedNeighbor();
  // The following two invariants are ensured, because link tuple removal is
  // always done outside _processHelloLinkSet and _processHelloNeighborSet
  // (see implementation documentation)
  // XXX: check this is still true! with MID stuff, link may be removed
  // inside those function, on addition of new MID removing 
  assert( linkTuple->neighborTupleEnsured );
  assert( neighborTuple != NULL );

  neighborTuple->_updateStatus(); // handles indirectly @@2327-2332
}

//---------------------------------------------------------------------------

void TwoHopNeighborSet::notifyAddition(TwoHopNeighborTuple* tuple)
{ node->notifyTwoHopNeighborhoodChange(); } // [NOT IN RFC]

void TwoHopNeighborSet::notifyRemoval(TwoHopNeighborTuple* tuple)
{ node->notifyTwoHopNeighborhoodChange(); } // @@2341-2342

//---------------------------------------------------------------------------

// Update L_LOST_LINK_time and L_link_pending with link monitoring info
void LinkTuple::updateWithLinkMonitoring(HeardIfaceTuple* heardIfaceTuple)
{
#ifdef LINK_MONITORING
  //@@3202-3223
  L_LOST_LINK_time = heardIfaceTuple->getLostTime() < node->getCurrentTime() ? 
                     heardIfaceTuple->getLostTime() : 
                     std::min(L_time, heardIfaceTuple->getLostTime());
  L_link_pending = heardIfaceTuple->getLinkPending();
#endif
}

//---------------------------------------------------------------------------

void LinkTuple::removeAndDeleteAssociatedHeardIfaceTuple()
{
#ifdef LINK_MONITORING
  HeardIfaceSet::TupleIterator it = node->heardIfaceSet.getIter();
  while(!it.isDone()) {
    HeardIfaceTuple* heardIfaceTuple = it.getCurrent();
    if ( (heardIfaceTuple->H_remonte_iface_addr == L_neighbor_iface_addr) &&
	 (heardIfaceTuple->H_local_iface_addr == L_local_iface_addr) )
      it.removeAndDeleteCurrentAndDoNext();
    else it.next();
  }
#endif
}

//---------------------------------------------------------------------------

void LinkTuple::update()
{
  bool shouldUpdateNeighbor = false;
  _updateStatus(node->getCurrentTime());
  if(previousValue != NULL) {
    shouldUpdateNeighbor = (previousValue->getStatus() != getStatus());
  } else shouldUpdateNeighbor = true;

  if (shouldUpdateNeighbor) {
    node->shouldRecomputeRoute = true; 
    updateAssociatedNeighborTuple();
  }

  if (previousValue == NULL)
    previousValue = new LinkTuple(node);
  *previousValue = *this;
  previousValue->previousValue = NULL;
}

//---------------------------------------------------------------------------

void Node::startNeighborSensing()
{ 
  Time delay = _startDelay(0, protocolConfig->HELLO_INTERVAL);
  addGenerationEvent(delay, delay, &Node::eventHelloGeneration, "gen-hello");
}

void Node::eventHelloGeneration()
{
  preEvent("gen-hello");
  // reschedule XXX: refs
  double minDelay = protocolConfig->HELLO_INTERVAL - protocolConfig->MAXJITTER;
  if(minDelay <0) minDelay = 0;
  addGenerationEvent(getCurrentTime() + minDelay,
		     getCurrentTime() + protocolConfig->HELLO_INTERVAL,
		     &Node::eventHelloGeneration, "gen-hello");

  Time currentTime = getCurrentTime();

  std::list<OLSRIface*>* ifaceList = getIfaceList();
  for (std::list<OLSRIface*>::iterator ifaceIt = ifaceList->begin();
       ifaceIt != ifaceList->end(); ifaceIt++) {
    // Generate HELLO on local iface (*it):
    HelloMessage* helloMessage = new HelloMessage;
    helloMessage->reserved = 0; // @@1549-1552
    helloMessage->htime = 
      toMantissaExponentByte(protocolConfig->HELLO_INTERVAL); // @@1554-1564
    // @@1706-1709
    helloMessage->willingness = protocolConfig->willingness; // @@1580-1583
    // @@1711-1713

    AddressMap<bool> visitedNeighbor;

#if 0
    for(int i=0;i<1;i++) { // XXX: random data with our main address
      LinkEntry entry;
      entry.linkType = (LinkType)(i % 4);
      entry.neighborType = (NeighborType)((i/4) % 3);
      entry.address = getMainAddress();
      helloMessage->linkList.push_back(entry);
    }
#endif

    Address ifaceAddress = (*ifaceIt)->getAddress();

    // @@1718-1721
    if (true) /*emVC++hack*/ for(LinkSet::TupleIterator it = linkSet.getIter(); 
	!it.isDone(); it.next()) {
      LinkTuple* linkTuple = it.getCurrent();
      if (linkTuple->L_time >= currentTime // @@1719-1720
	  && linkTuple->L_local_iface_addr == ifaceAddress) { // @@1718-1719
	NeighborTuple* neighborTuple = linkTuple->getAssociatedNeighbor();
	if (neighborTuple == NULL) { // XXX!!: Kludge around bug
	  logState(cerr);
	  Warn("BUG!!: neighborTuple is null for linkTuple: ");
	  writeLinkTuple(cerr, linkTuple, currentTime);
	  cerr << endl;
	  continue;
	}
	NeighborType neighborType = 
	  _getNeighborType(neighborTuple->N_neighbor_main_addr);
	LinkType linkType = linkTuple->getStatus();
	visitedNeighbor.add(neighborTuple->N_neighbor_main_addr, true);
	
	helloMessage->addLinkEntry(linkType, neighborType, 
				   linkTuple->L_neighbor_iface_addr);
      }
    }

    // Add the neighbors that were not previously enumerated
    for(NeighborSet::TupleIterator it = neighborSet.getIter();
	!it.isDone(); it.next()) {
      Address neighborAddress = it.getCurrent()->N_neighbor_main_addr;
      if (!visitedNeighbor.get(neighborAddress, false)) { // @@1768-1771
	helloMessage->addLinkEntry(UNSPEC_LINK, // @@1770-1775
				   _getNeighborType(neighborAddress),
				   neighborAddress);
      }
    }

    Message* message = new Message
      (HELLO_MESSAGE, // Message Type @@1545-1546
       toMantissaExponentByte(protocolConfig->NEIGHB_HOLD_TIME), // @1546-1547
       getMainAddress(), // Originator @@835-836
       1, // ttl, @@1546
       0); // hop count, @@868

    message->content = helloMessage;
    message->maxTime = getCurrentTime();
  
    packetManager->sendMessage((*ifaceIt), message);
  }
  postEvent("gen-hello");
}

LinkTuple* Node::_processHelloLinkSet(HelloMessage* hello)
{
  Message* header = hello->header;
  Time currentTime = getCurrentTime();
  //XXX:remmove: Time currentExpiringTime = getExpireTime();
  Time validityTime = header->getValidityTime(); // @@1871-1872
  LinkTuple* linkTuple = 
    linkSet.findFirst_SendIfaceAddress(header->sendIfaceAddress); // @@1878

  // Ensure that the tuple is created
  bool shouldAdd = false;
  if (linkTuple == NULL) { // @@1875 - step 1
    linkTuple = new LinkTuple(this);
    linkTuple->L_neighbor_iface_addr = header->sendIfaceAddress; // @@1882
    linkTuple->L_local_iface_addr = header->recvIfaceAddress; // @@1884-1886
    linkTuple->L_SYM_time = currentTime-1; // @@1888
    linkTuple->L_time = currentTime + validityTime; // @@1890
    linkTuple->neighborTupleEnsured = false; // (not yet)
#ifdef LINK_MONITORING
    // Link monitoring updates
    if (getProtocolConfig()->useSignalMonitoring ||
	getProtocolConfig()->useHysteresisMonitoring)
      {
	HeardIfaceTuple* heardIfaceTuple = 
	  heardIfaceSet.findThisLink(header->sendIfaceAddress,
				     header->recvIfaceAddress);
	assert(heardIfaceTuple);
	linkTuple->updateWithLinkMonitoring(heardIfaceTuple); 
      }
#endif

    shouldAdd = true;
  }

  // @@1892 - step 2
  linkTuple->L_ASYM_time = currentTime + validityTime; // @@1898 - step 2.1

  LinkEntry* linkEntry = _findAddrInLinkMessage(hello, //@@1900-1902
						header->recvIfaceAddress,
						true, false);
  if (linkEntry != NULL) {   // step 2.2 - @@1900
    LinkType linkType = linkEntry->linkType;
    if (linkType == LOST_LINK) // step 2.2.1 - @@1912
      linkTuple->L_SYM_time = currentTime - 1; // @@1914
    else if (linkType == SYM_LINK  
	     ||  linkType == ASYM_LINK) { // step 2.2.2 - @@1916-1918
      linkTuple->L_SYM_time = currentTime + validityTime; // @@1920
      linkTuple->L_time = (linkTuple->L_SYM_time // @@1922
			   + protocolConfig->NEIGHB_HOLD_TIME);
    }
  }
  // @@1924 - step 2.3
  linkTuple->L_time = myMax(linkTuple->L_time, linkTuple->L_ASYM_time);
    
  if (shouldAdd) linkSet.add(linkTuple);
  linkTuple->update(); 
  //} else {
  //  if (shouldAdd) linkSet.add(linkTuple);
  //  linkTuple->update(); 
  //}
  return linkTuple;
}

LinkEntry* Node::_findAddrInLinkMessage(HelloMessage* hello, //@@1900-1902
					Address ifaceAddress,
					bool notUnspecLink,
					bool mprNeigh)
{
  for(std::list<LinkEntry>::iterator it = hello->linkList.begin();
      it != hello->linkList.end(); it++)
    if((*it).address == ifaceAddress) {
      // XXX!!! UNSPEC_LINK not in RFC
      if (notUnspecLink && ((*it).linkType == UNSPEC_LINK))
	 continue;
      if (mprNeigh && ((*it).neighborType != MPR_NEIGH))
	continue;
      return &(*it); // (note: "&*it" != "it")
    }
  return NULL;
}

// @@1749-1766
NeighborType Node::_getNeighborType(Address mainAddress)
{
  NeighborType result;
  NeighborTuple* neighborTuple = neighborSet.findFirst_MainAddr(mainAddress);
  assert( neighborTuple != NULL );
  if (isMPR(mainAddress)) // 2.1 - @@1751-1752
    result = MPR_NEIGH; // @@1754
  else if (neighborTuple != NULL) { // @@1756-1757 - should always be true
    if (neighborTuple->N_status == SYM) // @@1760
      result = SYM_NEIGH; // @@1762
    else if (neighborTuple->N_status == NOT_SYM) // @@1765
      result = NOT_NEIGH; // @@1766
    else Fatal("Impossible N_status");
  }
  return result;
}


// @@XXX
NeighborTuple* Node::_processHelloNeighborSet(HelloMessage* hello,
					      LinkTuple* linkTuple)
{
  Message* header = hello->header;
  assert( linkTuple->L_neighbor_iface_addr == header->sendIfaceAddress );
  NeighborTuple* neighborTuple = neighborSet.findFirst_MainAddr
    (ifaceToMainAddress(linkTuple->L_neighbor_iface_addr)); // @@1955-1968

  bool shouldAdd = false;
  if (neighborTuple == NULL) { // @@1982-1991
    if (linkTuple->neighborTupleEnsured) {
      logState(cerr);
      writeLinkTuple(cerr, linkTuple, currentTime);
      Warn("XXX!! BUG: linkTuple->neighborTupleEnsured");
      cerr << endl;
    }
    //assert( !linkTuple->neighborTupleEnsured ); // XXX: put back
    neighborTuple = new NeighborTuple(this);
    neighborTuple->N_neighbor_main_addr
      = ifaceToMainAddress(linkTuple->L_neighbor_iface_addr); // @@1986-1988
    // TODO: neighborTuple->event
    shouldAdd = true;
  } else { 
    // maybe there was another link to the same neighbor, in which
    // case this was not set yet, and must be done here:
    linkTuple->neighborTupleEnsured = true; 
  }

  // NOTE: the 'if' of @@2038-2040 is always true in our implementation
  neighborTuple->N_willingness = hello->willingness;

  if (shouldAdd) 
    neighborSet.add(neighborTuple);
  linkTuple->neighborTupleEnsured = true;
  neighborTuple->update(); // @@1990-1991, @@1995-1998

  assert(neighborTuple != NULL);
  return neighborTuple;
}

// @@2052-2112
void Node::_processHelloTwoHopNeighborSet(HelloMessage* hello,
					  NeighborTuple* neighborTuple)
{
  Message* header = hello->header;
  Time currentTime = getCurrentTime();
  Time validityTime = header->getValidityTime();
  
  if (!isSymmetricNeighbor(header->originatorAddress)) // @@2057-2058
    return; 
  
  for(std::list<LinkEntry>::iterator it=hello->linkList.begin();
      it != hello->linkList.end(); it++) {
    LinkEntry& linkEntry = (*it);

    Address twoHopMainAddress = ifaceToMainAddress(linkEntry.address);

    if (linkEntry.neighborType == SYM_NEIGH  // step 1 - @@2079-2081
       || linkEntry.neighborType == MPR_NEIGH) { 

      if (ifaceToMainAddress(linkEntry.address) == getMainAddress())
	continue; // @@2083-2088 - step 1.1

      // step 1.2: @@2090
      TwoHopNeighborTuple* twoHop 
	= twoHopNeighborSet.findFirst_1hopAddr_2hopAddr
	(header->originatorAddress, twoHopMainAddress); // @@2101-2102

      bool shouldAdd = false;
      if(twoHop == NULL) { // @@2090
	twoHop = new TwoHopNeighborTuple;
	twoHop->N_neighbor_main_addr = header->originatorAddress; // @@2092
	twoHop->N_2hop_addr = twoHopMainAddress; // @@2094-2095
	shouldAdd = true;
      }
      twoHop->N_time = currentTime + validityTime; // @@2097-2098
      if (shouldAdd) 
	twoHopNeighborSet.add(twoHop);
      twoHop->update();

    } else if (linkEntry.neighborType == NOT_NEIGH) { // @@2104-2105 - step 2

      TwoHopNeighborTuple* twoHop 
	= twoHopNeighborSet.findFirst_1hopAddr_2hopAddr
	(header->originatorAddress, twoHopMainAddress); // @@2105-2110
      
      if (twoHop != NULL) {
	twoHopNeighborSet.removeAndDelete(twoHop); // @@2112
	twoHop = twoHopNeighborSet.findFirst_1hopAddr_2hopAddr
	  (header->originatorAddress, twoHopMainAddress); // @@2107-2110
	assert( twoHop == NULL ); // XXX: check assumption that there can
	// be at most one two hop tuple verifiying the condition.
      }
    }      
  }
}

// @@2282-2331
void Node::_processHelloMPRSelectorSet(HelloMessage* hello,
				       NeighborTuple* neighborTuple)
{
  Message* header = hello->header;
  Time currentTime = getCurrentTime();
  Time validityTime = header->getValidityTime(); // @@2289-2290
 
  // @@2284-2287
  LinkEntry* linkEntry = NULL;
  for(std::list<Address>::iterator it = getAddressList()->begin();
      it != getAddressList()->end(); it++) {
    Address addressOfOneIface = (*it);
    linkEntry = _findAddrInLinkMessage(hello, addressOfOneIface, false, true);
    if (linkEntry != NULL) 
      break; // Found one of our address in the link list with 'MPR'
  }

  if (linkEntry != NULL) { // @@2290-2291
    MPRSelectorTuple* mprSelectorTuple = // @@2305
      mprSelectorSet.findFirst_MainAddr(header->originatorAddress);
    if(mprSelectorTuple == NULL) { // step 1 - @@2303-2307
      mprSelectorTuple = new MPRSelectorTuple;
      mprSelectorTuple->MS_addr = header->originatorAddress; // @@2309
      mprSelectorSet.add(mprSelectorTuple);
    }
    // step 2 - @@2311-2317
    mprSelectorTuple->MS_time = currentTime + validityTime; // @@2317
    mprSelectorTuple->update();
  }
}

const double Epsilon = 1.0e-6;

void Node::processHelloMessage(HelloMessage* hello )
{ 
  Message* header = hello->header;
  Time validityTime = header->getValidityTime(); // @@2289-2290

#ifdef WITH_STAT
    statisticSet->ensure(header->originatorAddress)->helloCount.add(1);
#endif

  bool notFromMainAddress = !(header->originatorAddress 
			      == header->sendIfaceAddress);
  if(notFromMainAddress) { //XXX: should be configurable
    // The time for which there will be a link tuple valid:
    Time useTime = validityTime + protocolConfig->NEIGHB_HOLD_TIME+Epsilon;
    setTemporaryIfaceAssociation(header->originatorAddress, 
				 header->sendIfaceAddress,
				 useTime);
  }

  // [Implementation issue] Chicken and egg problem:
  // _processHelloLinkSet may create a linkTuple
  // _processHelloNeighborSet may create a neighborTuple
  // -> the first one to be called doesn't have the second object.
  // Here we choose linkTuple to potentially not have a associated
  // neighborTuple, this is handled by having a state 'neighborTupleEnsured'
  // in linkTuple.

  LinkTuple* linkTuple = _processHelloLinkSet(hello); // @@1867
  NeighborTuple* neighborTuple = _processHelloNeighborSet(hello, linkTuple);  
  assert( linkTuple->neighborTupleEnsured ); // now it must be ensured
  _processHelloTwoHopNeighborSet(hello, neighborTuple);
  _processHelloMPRSelectorSet(hello, neighborTuple);

  if(notFromMainAddress) 
    forgetTemporaryIfaceAssociation();
}

//XXX: check that every call uses a main address
bool Node::isSymmetricNeighbor(const Address& mainAddress)
{ //@@XXX
  NeighborTuple* neighborTuple = neighborSet.findFirst_MainAddr(mainAddress); 
  return (neighborTuple != NULL && neighborTuple->N_status == SYM);
}

bool Node::isMPRSelector(Address ifaceAddress)
{ 
  Address mainAddress = ifaceToMainAddress(ifaceAddress);
  MPRSelectorTuple* mprsTuple = mprSelectorSet.findFirst_MainAddr(mainAddress);
  return mprsTuple != NULL;
}

//---------------------------------------------------------------------------

#if 0
ostream& operator << (ostream& out, NeighborSet& neighborSet)
{
  out << "[NeighborSet: ";
  for(NeighborSet::TupleIterator it = neighborSet.getIter();
      !it.isDone(); it.next()) {
    NeighborTuple* t = it.getCurrent();
     out << t->N_neighbor_main_addr  << " " << t->N_status <<  " " 
	<< t->N_willingness << " ";
  }
  out << "]";
}
#endif

//---------------------------------------------------------------------------

//XXX: move some of this code elsewhere
void writeExpireTime(ostream& out, Time currentTime, Time expireTime)
{ 
  if(expireTime < currentTime) out << "-";
  else if (expireTime > currentTime) out << "+";
  else out << "=";
  out << "/" << expireTime;
}

void NeighborSet::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();

  bool isFirst = true;
  for(NeighborSet::TupleIterator it = getIter();
      !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    NeighborTuple* t = it.getCurrent();
    out << t->N_neighbor_main_addr << " " 
	<< neighborStatusToString(t->N_status) << "[";

    bool isFirstLink = true;
    for(NeighborTuple::AssociatedLinkIterator lit = 
	  t->getAssociatedLinkIterator(); !lit.isDone(); lit.next()) {
      if(!isFirstLink) out << ",";
      else isFirstLink = false;

      LinkTuple* l = lit.getCurrent();
      out << l->L_neighbor_iface_addr << "@" << l->L_local_iface_addr << " ";
      writeExpireTime(out, currentTime, l->L_time);
      out << " " << linkTypeToString(l->getStatus());
    }
    out << "]";
  }
}

void LinkSet::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();

  bool isFirst = true;
  for(LinkSet::TupleIterator it = getIter(); !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;


    LinkTuple* l = it.getCurrent();
    out << l->L_neighbor_iface_addr << "@" << l->L_local_iface_addr << " ";
    writeExpireTime(out, currentTime, l->L_time);
    out << " " << linkTypeToString(l->getStatus());
  }
}

void TwoHopNeighborSet::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();

  bool isFirst = true;
  for(TwoHopNeighborSet::TupleIterator it = getIter();
      !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    TwoHopNeighborTuple* t = it.getCurrent();
    out << t->N_neighbor_main_addr << "->" << t->N_2hop_addr << " ";
    writeExpireTime(out, currentTime, t->N_time);
  }
}

void MPRSelectorSet::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();

  bool isFirst = true;
  for(MPRSelectorSet::TupleIterator it = getIter();
      !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    MPRSelectorTuple* t = it.getCurrent();
    out << t->MS_addr<<" ";
    writeExpireTime(out, currentTime, t->MS_time);
  }
}

void TopologySet::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();

  bool isFirst = true;
  for(TopologySet::TupleIterator it = getIter();
      !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    TopologyTuple* t = it.getCurrent();
    out << t->T_last_addr << "->" << t->T_dest_addr<<" ";
    writeExpireTime(out, currentTime, t->T_time);
  }
}

void IfaceAssociationSet::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();

  bool isFirst = true;
  for(IfaceAssociationSet::TupleIterator it = getIter();
      !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    IfaceAssociationTuple* t = it.getCurrent();
    out << t->I_main_addr << "@" << t->I_iface_addr<<" ";
    writeExpireTime(out, currentTime, t->I_time);
  }
}

void HNASet::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();

  bool isFirst = true;
  for(HNASet::TupleIterator it = getIter();
      !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    HNATuple* t = it.getCurrent();
    out << t->A_network_addr << "/" << t->A_netmask
	<< "@" << t->A_gateway_addr <<" ";
    writeExpireTime(out, currentTime, t->A_time);
  }
}


void DuplicateSet::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();

  bool isFirst = true;
  for(DuplicateSet::TupleIterator it = getIter();
      !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    DuplicateTuple* t = it.getCurrent();
    out << t->D_addr << "/" << t->D_seq_num
        << "(";
    bool isFirstIface = true;
    for(std::list<Address>::iterator it = t->D_iface_list.begin();
	it != t->D_iface_list.end(); it++) {
      if (!isFirstIface) out << ";";
      else isFirstIface = false;
      out << (*it);
    }
    out << "):" << t->D_retransmitted << " ";
    writeExpireTime(out, currentTime, t->D_time);
  }
}

//---------------------------------------------------------------------------
