//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _NODE_INHERITANCE_H
#define _NODE_INHERITANCE_H

//---------------------------------------------------------------------------

// Compile-time inheritance graph without templates.

class Node;
class MeshAPNode;
class SecurityNode;
class QosNode;
class MOOLSRNode;
class MostNode;
class NodeWithConversion;

typedef Node NodeLevel0;

// Level 1: WITH_EXTENSION
typedef NodeLevel0 ParentNodeWithConversion;
#ifdef WITH_EXTENSION
typedef NodeWithConversion NodeLevel1;
#else
typedef NodeLevel0 NodeLevel1;
#endif // WITH_EXTENSION

// Level 2: ASSOCIATION_DB
typedef NodeLevel1 ParentMeshAPNode;
#ifdef ASSOCIATION_DB
typedef MeshAPNode NodeLevel2;
#else
typedef NodeLevel1 NodeLevel2;
#endif // ASSOCIATION_DB

// Level 3: WITH_SECURITY
typedef NodeLevel2 ParentSecurityNode;
#ifdef WITH_SECURITY
typedef SecurityNode NodeLevel3;
#else
typedef NodeLevel2 NodeLevel3;
#endif // WITH_SECURITY

// Level 4: WITH_QOS
typedef NodeLevel3 ParentQosNode;
#ifdef WITH_QOS
typedef QosNode NodeLevel4;
#else
typedef NodeLevel3 NodeLevel4;
#endif // WITH_QOS

// Level 5: MOOLSR
typedef NodeLevel4 ParentMOOLSRNode;
#ifdef MOOLSR
typedef MOOLSRNode NodeLevel5;
#else
typedef NodeLevel4 NodeLevel5;
#endif // MOOLSR

//Level 6: MOST
typedef NodeLevel5 ParentMostNode;
#ifdef MOST
typedef MostNode NodeLevel6;
#else
typedef NodeLevel5 NodeLevel6;
#endif // MOST

#if 0 // XXX: remove
// Level 6: Node with conversion
typedef NodeLevel5 ParentNodeWithConversion;
#ifdef WITH_EXTENSION
typedef NodeWithConversion NodeLevel6;
#else
typedef NodeLevel5 NodeLevel6;
#endif // Node with conversion
#endif

// The class to use externally
typedef NodeLevel6 ClassNode;

//---------------------------------------------------------------------------

#include "node.h"

//#ifdef WITH_EXTENSION
#include "message_conversion.h"
//#endif // WITH_EXTENSION

#ifdef ASSOCIATION_DB
#include "node_ap.h"
#endif // ASSOCIATION_DB

#ifdef WITH_SECURITY
#include "security.h"
#endif // WITH_SECURITY

#ifdef WITH_QOS
#include "qos.h"
#include "qos_flow.h"
#endif // WITH_QOS

#ifdef MOST
#include "mostNode.h"
#endif //MOST

//---------------------------------------------------------------------------

#endif //_NODE_INHERITANCE_H
