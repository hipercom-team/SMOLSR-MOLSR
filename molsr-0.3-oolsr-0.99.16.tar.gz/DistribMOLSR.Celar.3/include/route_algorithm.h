//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements route calculation algorithms
//---------------------------------------------------------------------------

#ifndef ROUTE_ALGORITHM_H
#define ROUTE_ALGORITHM_H

#include <assert.h>
#include "mystream.h"
#include <algorithm>	
 

#include <list>
#include <vector>
#include "general.h"
#include "address.h"
using std::list;
using std::pair;
using std::vector;

//---------------------------------------------------------------------------

#if 0

template <typename Key, typename Value, typename HashType, class HashFunction>
class HashTable
{
public:
  typedef pair<Key, Value> Cell;
  typedef list<Cell> CellList;

  int nbBucket;

  HashTable(int aNbBucket) : nbBucket(aNbBucket)
  { 
    bucketArray.reserve(nbBucket);
  }

  CellList& getBucket(Key& key)
  {
    HashFunction hashFunction;
    HashType hashValue = hashFunction(key);
    return bucketArray[hashValue % nbBucket];
  }

  bool findCell(Key& key, typename CellList::iterator& resultIt)
  {
    CellList& cellList = getBucket(key);
    typename CellList::iterator it = cellList.begin();
    while (it != cellList.end()) {
      if (*it.first == key) {
	resultIt = it;
	return true;
      }
      it++;
    }
    return false;
  }

  Cell* findCell(Key& key)
  {
    typename CellList::iterator it;
    if (findCell(key, it))
      return &(*it);
    else return NULL;
  }

  Value* find(Key& key)
  {
    Cell* cell = findCell(key);
    if (cell == NULL) return NULL;
    else return &(cell->value);
  }

  void remove(Key& key)
  {
    typename CellList::iterator it;
    bool found = findCell(key, it);
    assert( found );
    it.remove();
  }

  void insert(Key& key, Value& value)
  {
    Cell* cell = findCell(key);
    if (cell == NULL) {
      CellList& cellList = getBucket(key);
      Cell newCell(key, value);
      cellList.push_back(newCell);
    } else {
      cell->value = value;
    }
  }

protected:
  vector<CellList> bucketArray;
};

//---------------------------------------------------------------------------


template <typename Value>
struct Identity {
  Value& operator() (Value& value) { return value; }
};

template <typename Value>
class IntHashTable 
  : public HashTable<int, Value, unsigned int, Identity<unsigned int> >
{};

#endif

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

const int MaxDistance = (1<<30);
//const int GrayDistance = MaxDistance - 1;

class GraphNode
{
public:
  //GraphNode() : neighb {}

  int distance;
  int nextHop[2];
  list<int> neighborList;
  void* data;
 void printNeighborList(){
	 std::list<int>::iterator iter = neighborList.begin();
	cout << "(" ;
	for(;iter!=neighborList.end();iter++)
	cout << *iter << ","; 
	cout << ")";
}
};

//---------------------------------------------------------------------------

class RouteAlgorithm
{
public:
  RouteAlgorithm() : nbNode(0) { }

  int addNode(void* data)
  {
	for(int i=0; i<nbNode;i++) {
		if (nodeInfoArray[i].data == data)
			return i;  		
	}  
	   
    int result = nbNode; 
    nbNode++; 
    
    //nodeInfoArray.resize(nbNode); 
    //nodeInfoArray[result].neighborList.clear();
    //GraphNode newGraphNode;
    //GraphNode* graphNode = new GraphNode;
    GraphNode graphNode;
    graphNode.data = data;
    nodeInfoArray.push_back(graphNode);
    //nodeInfoArray[result]->neighborList = new list<int>; // XXX: leak
    assert( (int)nodeInfoArray.size() == result+1 );
    return result;
  }

  void addLink(int nodeIdx, int anotherNodeIdx, bool bothWays = false)
  { 
    assert( inrange(0, nodeIdx, nbNode) );
    assert( inrange(0, anotherNodeIdx, nbNode) );
    GraphNode* nodeInfo = &nodeInfoArray[nodeIdx];
    
    
	std::list<int>::iterator iter;
    iter = std::find (nodeInfo->neighborList.begin(), nodeInfo->neighborList.end(), anotherNodeIdx);
  	if (iter == nodeInfo->neighborList.end()){
	  	 nodeInfo->neighborList.push_back(anotherNodeIdx);	  	 
  	} else cout << " link exist " << endl;    
    
    if (bothWays)
      addLink(anotherNodeIdx, nodeIdx, false);
  }

  void clearStartingNodes()
  {
	  startingNodeList.clear();
	}
	
  void addStartingNode(int nodeIdx)
  { 
    //GraphNode& nodeInfo = nodeInfoArray[nodeIdx];
    //nodeInfo.distance = 0;
    assert( inrange(0, nodeIdx, nbNode) );
    startingNodeList.push_back(nodeIdx);
  }
  
  //void removeNode(string Address);
  //void removeLink(string Address);

  //void computeRouteTable();
  void breadthFirst();

  list<int> startingNodeList;
  
  //vector<  > neighborListArray;
  vector< GraphNode > nodeInfoArray;

  bool isReached(int nodeIdx) { 
    assert( inrange(0, nodeIdx, nbNode) );
    return nodeInfoArray[nodeIdx].distance != MaxDistance;
  }
  
 int getDistance(Address address ) {
	int nodeIdx = addNode(&address);
   assert( inrange(0, nodeIdx, nbNode) );
    return nodeInfoArray[nodeIdx].distance;
 }

 void printGraph() {
	cout << "SYCHO3 : node Info" ;
	for(int n = nbNode;n>0;n--){
		assert(nodeInfoArray[n].data != NULL);
		cout <<toText(*((Address*)nodeInfoArray[n].data));
		nodeInfoArray[n].printNeighborList();
	}
	
}

	void calculateRoutes(Address source) { 
		clearStartingNodes();
		addStartingNode(addNode(&source));
		breadthFirst();
	}
	
  ~RouteAlgorithm()
  { 
    assert( (int)nodeInfoArray.size() == nbNode );
#if 0
    for (int i=0;i<nbNode;i++) {
      if (nodeInfoArray[i] != NULL)
	delete nodeInfoArray[i];
      nodeInfoArray[i] = NULL;
    }
#endif
  }
    
  int nbNode;
};

#endif
