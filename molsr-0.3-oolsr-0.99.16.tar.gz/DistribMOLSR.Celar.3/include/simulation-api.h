//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file can be used in C and C++ programs
//---------------------------------------------------------------------------

#ifndef _SIMULATION_API_H
#define _SIMULATION_API_H

//---------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#define PLUGEE_OPAQUE_EXTENSION_VERSION_MAJOR 1
#define PLUGEE_OPAQUE_EXTENSION_VERSION_MINOR 0

//--------------------------------------------------

typedef void(*GetLinkFunction)(void* data,
			       int srcNodeIdx, int srcIfaceIdx,
			       int* resultCount,
				int** nodeIdxList, 
			       int** ifaceIdxList);

typedef void(*MulticastRecvPacketFunction)(int originNodeIndex,
					   int originIfaceIndex,
					   int rcvNodeIndex,
					   int rcvIfaceIndex,
					   int dstGroupIndex,
					   /* borrowed: */
					   void* packetData, int packetSize);

int doesRequirePlugin();
void initSimulation(char* pluginFileName, int aMaxNodeIndex);
void multicastJoinGroup(int nodeIndex, int groupIndex);
void multicastLeaveGroup(int nodeIndex, int groupIndex);
void multicastSenderJoin(int nodeIndex, int groupIndex);
void multicastSenderLeave(int nodeIndex, int groupIndex);
void addNode(int nodeIndex, int nbIface, int mtu, 
	     void* configData, int configSize);
void addNodeLink(int srcNodeIdx, int srcIfaceIdx, 
		 int dstNodeIdx, int dstIfaceIdx);
void removeNodeLink(int srcNodeIdx, int srcIfaceIdx, 
		    int dstNodeIdx, int dstIfaceIdx);
void addDynamicLink(int srcNodeIdx, int srcIfaceIdx, 
		    GetLinkFunction getLinkFunction, void* data);
void removeDynamicLink(int srcNodeIdx, int srcIfaceIdx);
double getSimulationTime();
void runUntil(double maxTime);
void writeState(char* fileName, char* info);
void scheduleFunctionAt(double relativeTime, //XXX: useless cruft
			void(*f)(void*, void*, void*), void* data);

void sendMulticastPacket(int senderNodeIndex, int senderIfaceIndex,
			 int dstGroupIndex, 
			 /* borrowed: */ void* packetData, int packetSize);
void setRecvMulticastPacketFunction(MulticastRecvPacketFunction func);

//--------------------------------------------------

typedef struct s_WorldNodeInfo {
  double pos[2];
  double speed[2];
  double lastClock;
  double receiveRange;

  double minPos[2], maxPos[2]; // XXX: useful? (should use world stuff)
} WorldNodeInfo;

void initWorld(int nbNode, int nbIface, double areaWidth, double areaHeight,
	       double minRange, double maxRange, double maxSpeed, 
	       int rangeModel);
void worldCreateRadioLink();

//--------------------------------------------------

// Returns a pointer to an internal datastructure representing
// the OLSR protocol (normally: Node*)
void* getInternalNode(int nodeIndex);

// Returns a pointer to an internal datastructure representig
// the node position (normally: WorldNode*)
void* getInternalWorldNode(int nodeIndex);

WorldNodeInfo* getWorldNodeInfo(int nodeIndex);
   
//--------------------------------------------------

void getSimulationStat(char** resultData, int* resultSize);

//--------------------------------------------------

void* doPluginOpaqueFunctionCall
(char* cFunctionName,
 int argCount, void** argData, int* argSize,
 int* resultCount, void*** resultData, int** resultSize);

void* doSimulatorOpaqueFunctionCall
(char* cFunctionName,
 int argCount, void** argData, int* argSize,
 int* resultCount, void*** resultData, int** resultSize);

//--------------------------------------------------

#ifdef __cplusplus
} // end of extern "C"
#endif // __cplusplus

//---------------------------------------------------------------------------

#endif // _SIMULATION_API_H
