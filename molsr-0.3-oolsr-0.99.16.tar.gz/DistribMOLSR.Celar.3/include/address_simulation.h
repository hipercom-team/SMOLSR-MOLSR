//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// XXX: is this still used?
//---------------------------------------------------------------------------

class SimulationAddressFactory;

/// Simulation (which is the base type for Address)
/// This class should be passed by value
class SimulationAddress 
{
public:
  SimulationAddress(int nodeIdx, int ifaceIdx);
  SimulationAddress();

  /// Returns the size of the address when in networking format
  int getNetSize();

  /// Write the address in networking order and format, in the first
  /// bytes of data. The number of bytes which are written is
  /// given by the method getNetSize()
  void toNet(void* data);

  /// Return the maximum size of the address when written in human-readable
  /// form (including room for the final (char)0)
  int getMaxTextSize();

  /// Write the address in human-readable format, in the first
  /// bytes of data, and add a trailer (char)0. 
  /// The number of bytes which are written is less or equal to the number
  /// given by the method getMaxTextSize()
  void toText(char* data);

  /// Return true if and only if the other address is the same as this
  /// address.
  bool isSame(SimulationAddress other);

protected:
  SimulationAddressFactory* factory;
  int addressIndex;

  friend class SimulationAddressFactory;
};

/// This class is in charge of 
class SimulationAddressFactory
{
public:
  /// Return the size of the address when in networking format.
  /// It will be the same as IPv4Address::getNetSize()
  int getAddressSize();

  /// Takes the first bytes (the exact number is given by method
  /// getAddressSize()) as an address in networking order and return
  /// it as an IPv4Address
  SimulationAddress peekAddress(void* data);

  /// Takes a null terminated string and return the address
  SimulationAddress parseAddress(char* textString);
};

//---------------------------------------------------------------------------
