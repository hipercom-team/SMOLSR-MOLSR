//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _SERIALIZATION_H
#define _SERIALIZATION_H

#error not used nor implemented yet

//---------------------------------------------------------------------------

class ISerializer;

class ISerializable
{
public:
  virtual void serialize(ISerializer* serializer) = 0;
};

class ISerializer
{
public:
  void serialize();

  template<typename Value>
  void serialize(Value& value)
  { serialize((void*)&value, sizeof(Value)); }

  template<typename Value>
  void unserialize(Value& value)
  { serialize((void*)&value, sizeof(Value)); }
};

//---------------------------------------------------------------------------

#endif _SERIALIZATION_H
