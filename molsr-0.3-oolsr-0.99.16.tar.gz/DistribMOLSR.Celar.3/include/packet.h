//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _PACKET_H
#define _PACKET_H

//---------------------------------------------------------------------------

#include "base.h"

#include <list>

#include "tuple.h"
#include "address.h"
#include "network_generic.h"
#include "protocol_config.h"
#include "packet_buffer.h"

//---------------------------------------------------------------------------

const int PacketHeaderSize = 4; // @@743

const int MessageHeaderWithoutAddressSize = 8; // @@743-749

const int MessageTypeLimit = 256; // XXX@@
const int LinkCodeLimit = 16; // @@1613

//---------------------------------------------------------------------------

typedef enum {
  HELLO_MESSAGE = 1, // @@3611
  TC_MESSAGE = 2,    // @@3613
  MID_MESSAGE = 3,   // @@3615
  HNA_MESSAGE = 4,    // @@3617

  HELLOv2_MESSAGE = 5,
  TCv2_MESSAGE = 6,

  // GMA_MESSAGE = 5,
  //XXX MOOLSR
  SC_MESSAGE=11,
  CP_MESSAGE=12,
  LEAVE_MESSAGE=13, 

  MCTREE=31,
  SMOLSRMSG=32,
  NEWLOCALCLIENT=51,
  NEWLOCALSOURCE=61,     
  LEAVELOCALCLIENT=52,      
  LEAVELOCALSOURCE=62,

  //XXX MOOLSR
  GMA_MESSAGE =0x80,
  MI_MESSAGE = 0x81,

#ifdef MOST
  MOST_JOIN_MESSAGE=70,
  MOST_LEAVE_MESSAGE=71,
  MOST_LOGICAL_NEIGHBOR=72,
#endif //MOST

#ifdef NU_AUTOCONF
  // Niigata University autoconfiguration
  HELLO_MESSAGE_WITH_STATE = 0x82,
  TC_MESSAGE_WITH_STATE = 0x83,
#endif // NU_AUTOCONF

#ifdef ASSOCIATION_DB
  LABA_MESSAGE  = 172,
  LABCA_MESSAGE = 173,
  ABBR_MESSAGE  = 174,
#endif

#ifdef WITH_QOS
  QOS_HELLO_MESSAGE = 175,
  QOS_TC_MESSAGE = 176,
#endif // WITH_QOS

#ifdef WITH_SECURITY
  PACKET_INFO_MESSAGE = 177,
#endif

  NO_MESSAGE=0x100
 } MessageType;

static inline const string messageTypeToString(MessageType type)
{ 
  static char resultCache[128]; //XXX: dangerous -- No longer, with 'string'
  switch(type) {
  case HELLO_MESSAGE: return "hello";
  case TC_MESSAGE: return "tc";
  case MID_MESSAGE: return "mid";
  case HNA_MESSAGE: return "hna";
    //XXXX MOOLSR
  case SC_MESSAGE: return "SourceClaim";
  case CP_MESSAGE: return "ConfParent";
  case LEAVE_MESSAGE: return "LeaveMsg";
  case NEWLOCALCLIENT: return "NEWLOCALCLIENT";
  case NEWLOCALSOURCE: return"NEWLOCALSOURCE";      
  case LEAVELOCALCLIENT: return " LEAVELOCALCLIENT";
  case LEAVELOCALSOURCE:return "LEAVELOCALSOURCE";
  case MCTREE: return"MCTREE";
  case SMOLSRMSG: return"SMOLSRMSG";
    //XXXX MOOLSR
#ifdef MOST
  case MOST_JOIN_MESSAGE: return "mostJoin";
  case MOST_LEAVE_MESSAGE: return "mostLeave";
  case MOST_LOGICAL_NEIGHBOR: return "mostLogicalNeighbor";
#endif //MOST
#ifdef NU_AUTOCONF
  case HELLO_MESSAGE_WITH_STATE: return "hello-with-state";
  case TC_MESSAGE_WITH_STATE: return "tc-with-state";
#endif // NU_AUTOCONF
  default: sprintf(resultCache, "0x%02x", type); return resultCache;
  }
}

//---------------------------------------------------------------------------

const int MaxTTL = 255; // @@2403,

const int MaxPacketSequenceNumber = (1<<16); // 16 bits - @@XXX

const int MaxValue  = (1<<16); // 16 bits - @@XXX

static inline int seqNumGreater(int s1, int s2) // XXX: check names
{ return( ((s1>s2)&&((s1-s2)<=MaxValue/2))||((s2>s1)&&((s2-s1)>MaxValue/2))); }


//---------------------------------------------------------------------------

class PackingInfo
{
public:
  OLSRIface* iface; // NULL if broadcast on all iface, otherwise, the one iface
};

//---------------------------------------------------------------------------

class Message;

class IMessageRewriter
{
public:
  virtual Message* rewrite(Message*) = 0;
  virtual ~IMessageRewriter() {}
};

//---------------------------------------------------------------------------

class IMessageContent
{
public:
  Message* header;

public:
  
  IMessageContent():header(NULL){}
  /// (internal) Makes a copy of the message.
  virtual IMessageContent* clone() = 0; 

  /// Get the base message
  virtual Message* getMessage() { return header; }

  /// Write the message content
  virtual void write(ostream& out) const = 0;

  virtual void destroy(bool deleteHeader);

  virtual ~IMessageContent() { destroy(true); }
};

typedef enum {
  ReceivedMessage,
  GeneratedMessage,
  NoOrigin
} MessageOrigin;

const int NoMessageSequenceNumber = -1;


#ifdef WITH_EXTENSION
class MessageTLVSet;
#endif

typedef enum { 
  MessageUnchecked, MessageCheckedOk, MessageCheckedBad 
} MessageState;

/// An OLSR message.
/// XXX: this documentation was not reviewed/updated
/// Normally one and only one of the fields packedContent and content
/// will be not NULL and the other will be NULL. This corresponds 
/// to two different cases: when packedContent is not NULL, the packet
/// was usually received, and was not parsed yet ; this is used for
/// forwarding. The other case is a locally generated message, not yet
/// converted to network format (sequence of bytes). Usually, when
/// in the code, a message is expected to have a content != NULL,
/// a reference to a IMessageContent is used (and the message header
/// itself can be retrieved from getMessage()).
class Message
{
public:
  /// The fields of the OLSR message
  MessageType messageType;
  int vtime;
  int messageSize; // (filled by MessageHandler)
  Address originatorAddress;
  int timeToLive;
  int hopCount;
  int messageSequenceNumber;

  int minMessageSize; // (filled by MessageHandler)

  /// Additional field used when receiving: sender interface address
  Address sendIfaceAddress;
  ///  Additional field used when receiving: receiving interface address
  Address recvIfaceAddress;

  /// The message content in network form
  MemoryBlock* packedContent;
  /// The header content in network form (only for received message)
  MemoryBlock* packedHeader;

  /// The message content in high level form (HelloMessage, etc...)
  IMessageContent* content;

  /// Additional field (used for unicast messages, for host attachment)
  Address destinationAddress;

public:
  /// Constructors
  Message() : messageType(NO_MESSAGE),
	      messageSize(-1), minMessageSize(-1), packedContent(NULL),
	      content(NULL), maxTime(0)
#ifdef WITH_EXTENSION
	      , messageTLVSet(NULL)
#endif // WITH_EXTENSION
{}

  Message(MessageType aMessageType, int aVTime, 
	  Address aOriginatorAddress, 
	  int aTimeToLive, int aHopCount) //, int aMessageSequenceNumber)
    : messageType(aMessageType),
      vtime(aVTime),
      messageSize(-1),
      originatorAddress(aOriginatorAddress),
      timeToLive(aTimeToLive),
      hopCount(aHopCount), 
      messageSequenceNumber(NoMessageSequenceNumber),
      minMessageSize(-1), 
      packedContent(NULL),  content(NULL), 
      origin(NoOrigin),
      maxTime(0)
#ifdef WITH_SECURITY
      , checkStatus(MessageUnchecked)
#endif // WITH_SECURITY
#ifdef WITH_EXTENSION
    , messageTLVSet(NULL)
#endif
  { packedHeader = NULL; }

  /// Destructor
  ~Message();

  /// Makes a copy of the message
  Message* clone(bool withPackedContent = true);

  /// Return the validity time, decoded from the 'vtime' attribute
  Time getValidityTime()
  { return fromMantissaExponentByte(vtime); }

  int getMessageSize();

  //--------------------------------------------------

  void setContent(IMessageContent* newContent);

  //--------------------------------------------------

  MessageOrigin origin;

  /// The maximum acceptable time, before the message gets emitted
  Time maxTime;

#ifdef WITH_SECURITY
  MessageState checkStatus;
#endif // WITH_SECURITY

#ifdef WITH_EXTENSION
  MessageTLVSet* messageTLVSet;
#endif // WITH_EXTENSION
};

inline ostream& operator << (ostream& out, const IMessageContent& m)
{ m.write(out); return out; }

void writeMessage(ostream& out, const Message& m, bool withContent = true);

inline ostream& operator << (ostream& out, const Message& m)
{ 
  writeMessage(out, m);
  return out;
}

//---------------------------------------------------------------------------

class PacketManager;
class PacketBuffer;

/// A IMessageHandler as the responsibility of doing message-type specific
/// steps in message processing/handling. PacketManager is doing the 
/// message-independant processing.
/// In perticular, the PacketManager knows how to pack/parse the Message header
/// but not the content of the message (HELLO link lists, etc...)
class IMessageHandler
{
public:
  /// Process the message (the content). Normally will call the proper
  /// message handling method of Node. (message is borrowed)
  virtual void processMessage(/*borrowed*/ Message* message) = 0;

  // Send a message to each of the ifaceList
  //virtual void sendMessage(std::list<OLSRIface*>* ifaceList,
  // Message* message) = 0;

  /// Possibly forward the message. Some message (such as HELLO) are not
  /// forwarded, in which case nothing is done, otherwise, using
  /// PacketManager helper function, the message can be forwarded
  /// (message is borrowed)
  /// Will return true iff the message is forwarded
  virtual void considerForwardMessage(/*borrowed*/ Message* message,
				      string& info) = 0;

  /// Parse the message in a message specific-way ; i.e. parse the content
  /// in 'message.packedContent' into a proper value in 'message.content'
  /// and return this last value. 
  //  Update: now should return a messageContent
  //          with messageContent->header != message
  virtual IMessageContent* parseMessageContent(/*borrowed*/
					       Message* message) = 0;

  /// XXX: possibly obsolete doc warning!
  /// Perform the opposite of parseMessageContent: given a message,
  /// with a proper message.content field, the message.content is transformed
  /// into network format (a sequence of bytes), into 'message.packedContent'.
  /// The operation is here complicated by the maximum message size:
  /// - the result is stored in messageResult, which should be a newly 
  /// created instance of Message (with messageResult.content == NULL)
  /// - if there wasn't enough space to fully fill the message,
  /// the remaining information should be in a newly created instance
  /// of IMessageHandler, holding the remaining information. In this case
  /// a new messageSequenceNumber must be allocated. If there was enough
  /// space *messageRemainingResult must be set to NULL.
  /// - if the packing fails, *messageResult and *messageRemainingResult
  /// must be set to NULL, and the message will be discarded.
  virtual void packMessageContent(/*borrowed*/ IMessageContent* message,
				  int maximumMessageSize,
				  MemoryBlock*& packedResult,
				  IMessageContent*& messageRemainingResult,
				  // new parameter (28 sept 2005), [add it
				  // and ignore it (used by security.cc)]:
				  PackingInfo& packingInfo)=0;

  virtual void adjustMessageSize(IMessageContent* message) = 0;

  virtual bool shouldPureFlood() { return false; }

  //virtual bool hasTLV() { return false; }

  virtual ~IMessageHandler() {}
};

//---------------------------------------------------------------------------

template <class MessageSpecification>
class GenericMessageHandler : public IMessageHandler
{
public:
  typedef typename MessageSpecification::MessageContent MessageContent;
  typedef typename MessageSpecification::MessageItem MessageItem;
  typedef typename std::list<typename MessageSpecification::MessageItem> 
  MessageItemList;

  GenericMessageHandler(Node* aNode) : node(aNode) {}

  virtual void processMessage(Message* message);

  virtual void considerForwardMessage(Message* message, string& info);

  virtual IMessageContent* parseMessageContent(Message* message);

  virtual void packMessageContent(IMessageContent* message, 
				  int maximumMessageSize,
				  MemoryBlock*& blockResult,
				  IMessageContent*& messageRemainingResult,
				  PackingInfo& packingInfo);

  virtual void adjustMessageSize(IMessageContent* message);

protected:
  Node* node;
};

//---------------------------------------------------------------------------

class MessageQueue
{
public:
  /// messages waiting to be delivered
  std::list<Message*> queue;
};

/// An OLSR Interface (as opposed to a system interface)
class OLSRIface
{
public:  
  OLSRIface(Node* aNode, ISystemIface* aSystemIface) 
    : node(aNode), iface(aSystemIface), buffer(NULL), nextSequenceNumber(0) 
  { iface->setOLSRIface(this); }

  ISystemIface* getSystemIface()
  { return iface; }

  IfaceConfig* getConfig()
  { return iface->getConfig(); }

  /// allocate a new packet sequence number (by incrementation)
  int allocateSequenceNumber()
  { 
    int result = nextSequenceNumber;  // @@XXX wrap around
    nextSequenceNumber = (nextSequenceNumber + 1) % MaxPacketSequenceNumber;
    return result;
  }

  Address getAddress();

  string getName();

  int getIndex();

  /// MTU of the OLSRIface - this is MTU of a packet being sent.
  /// Ensures: this doesn't change.
  int getMTU();

  /// actually send a packet. 
  void sendPacket(Address destinationAddress, MemoryBlock* packet);

#ifdef LINK_IWEVENT_MONITORING
  int getSignalFileDescriptor();
#endif

#ifdef LINK_SIGNAL_MONITORING
  int getSignalLevel(Address txAddress)
  {
    return iface->getSignalLevel(txAddress);
  }
#endif
  /// Send a message on the local message queue
  //void sendMessageOnLocalQueue(Message* message)
  //{ localMessageQueue->queue.push_back(message); }


  int getFreeSpace()
  {
    if (buffer == NULL)
      prepareBuffer();
    return getMTU() - buffer->offset();
  }

  void ensureSameDestinationAddress(Address destinationAddress) 
  {
    if (!destinationAddress.isSame(lastDestinationAddress)) {
      flushPacket();
      lastDestinationAddress = destinationAddress;
    }
  }


  void appendBlock(Address destinationAddress, MemoryBlock* block) // borrowed
  {
    ensureSameDestinationAddress(destinationAddress);
    if (getFreeSpace() < block->size)
      flushPacket();
    if (buffer == NULL)
      prepareBuffer();
    buffer->packBlock(block);
  }

  void flushPacket();

  ~OLSRIface()
  {
    if(buffer != NULL) {
      delete buffer;
      buffer = NULL;
    }
  }
	
protected:
  Node* node;

  /// The actual interface
  ISystemIface* iface;

  Address lastDestinationAddress;
  PacketBuffer* buffer;

  void prepareBuffer()
  { 
    assert(buffer==NULL);
    buffer = new PacketBuffer; 
    buffer->pushUInt16(0); // @@XXX
    buffer->pushUInt16(0); // size: to be completed
    assert( buffer->offset() == PacketHeaderSize );
  }

  int nextSequenceNumber;
};

//---------------------------------------------------------------------------

class Node;

class MessageAndIface
{
public:
  Message* message;
  OLSRIface* iface; // NULL means all ifaces.
};

class PacketManager
{
#if defined MOOLSR || defined MOST
  friend class MDFPCom;
#endif
public:
  PacketManager(Node* aNode);

  /// Returns the global message queue of the OLSR interfaces
  /// (this can be also obtained from one OLSR interface).
  /// The local message queue of one OLSR interface is obtained via
  /// the associated OLSRIface.
  std::list<MessageAndIface>* queue;
  
  /// Allocate a new message sequence number (by incrementing the counter)
  /// Returns a value which fits in 16 bits, as demanded in OLSR specification
  int allocateMessageSequenceNumber();

  /// Send a message to all the OLSR interface (it will end up in the 
  /// global queue). (update: don't use directly, use Node::sendMessageToAll)
  void sendOneMessageToAll(Message* message)
  { sendOneMessage(NULL, message); }

  /// Send a message to one the OLSR interface. It will end up in the local
  /// queue, so it should be either:
  /// - not splittable
  /// - sent only on one interface
  /// - such that you really really know what you what you are doing.
  /// (if iface == NULL, the above doesn't apply, see sendMessageToAll instead)
  // Update: don't use directly, use Node::sendMessage
  virtual void sendOneMessage(OLSRIface* iface, Message* message);

  void notifyMessageQueuing();

  /// Send a message which is already in serialized form (message.packedContent
  /// is different of NULL) to all OLSR interfaces.
  void sendPackedMessageToAll(/*owned*/ Message* message) 
  { 
    MessageAndIface messageAndIface;
    messageAndIface.message = message;
    messageAndIface.iface = NULL;
    queue->push_back(messageAndIface);
    notifyMessageQueuing();
  }

  /// Send a message which is already in serialized form (message.packedContent
  /// is different of NULL) to one OLSR interface.
  void sendPackedMessage(OLSRIface* iface, /*owned*/ Message* message)
  { 
    MessageAndIface messageAndIface;
    messageAndIface.message = message;
    messageAndIface.iface = iface;
    queue->push_back(messageAndIface);
    notifyMessageQueuing();
  }

  /// This is the entry point where the processing of packet begans
  /// (rawPacket is owned)
  void processPacket(Address sendIfaceAddress, Address recvIfaceAddress,
                     MemoryBlock* rawPacket);

  /// An utility function for IMessageHandler (especially 
  /// IMessageHandler::considerForwardMessage) ; this implement the default
  /// forwarding of the OLSR specification.
  /// (message is borrowed)
  void defaultForwardingMessage(Message* message, string& info);

  // Force a retransmission of the message if it has not yet been retransmitted
  // useful for MPR flooding.
  void ensureRetransmitMessage(Message* m, string& info);

  /// Pack messages awaiting in the global message queue into one packet
  /// on each interface. 
  /// - If there is not enough room (MTU), and if possible, the last
  ///   global message will be split
  /// - If there is enough room (MTU), then for each interface, the
  ///   messages of the local queue are appended, and if necessary
  ///   split.
  void packMessageQueue();

  // A utility function
  //XXX parsePacket(Address sendIfaceAddress, Address recvIfaceAddress,
  // MemoryBlock* rawPacket);

  // A utility function
  // IMessageContent* parseMessage(Message* message);

  typedef struct {
    int sizeFieldPosition;
    int messageStartPosition;
  } PositionInfo;

  PositionInfo packMessageHeader(PacketBuffer& buffer, Message* m);

  void adjustPackedMessageSize(PacketBuffer& buffer, PositionInfo info);


  void sendUpToTime(Time limitTime);
 
  void addMessageHandler(unsigned int messageType, IMessageHandler* handler);

  void write(ostream& out);
  
  //Used for MDFP
  IMessageHandler* getMessageHandler(unsigned int messageType)
  { return(messageHandler[messageType]);}
  
  Message* friendPopMessage(PacketBuffer& packet,
			    Address sendIfaceAddress,
			    Address recvIfaceAddress)
  { return (popMessage(packet, sendIfaceAddress, recvIfaceAddress)); }
  //end Used for MDFP

  IMessageRewriter* messageRewriter;

protected:

  void appendPackedMessage(OLSRIface* iface,
			   /*owned*/ Message* newMessage);

  void packMessage(Message* message, int maximumMessageSize,
		   MemoryBlock*& newBlock, Message*& newMessage,
		   PackingInfo& packingInfo);

  void genericAppendMessage(OLSRIface* iface, Message* message, int minMTU);

  void appendBlockOnAllIface(MemoryBlock* block);
  int getIfaceMinFreeSpace();
  int getIfaceMinMTU();

  int getMessageHeaderSize();

  void parsePacket(PacketBuffer& packet,
		   std::list<Message*>& resultMessageList,
		   int& resultPacketSequenceNumber,
		   Address sendIfaceAddress,
		   Address recvIfaceAddress);

  //Security extension:
  bool hasNetTime;
  Time lastNetTime;
public:
  void setNetTime(Time netTime)
  { lastNetTime = netTime; hasNetTime = true; }

public: // XXXX:
  Message* popMessage(PacketBuffer& packet,
		      Address sendIfaceAddress,
		      Address recvIfaceAddress);
protected:

  /// Monitor all links on which packets are receiving and 
  /// calculate their quality. This information is used
  /// in link sensing mechanism.
  void processLinkMonitoring(Address sendIfaceAddress, 
			     Address recvIfaceAddress, 
			     int packetSequenceNumber);


  Node* node;

  int nextMessageSequenceNumber; /// The next allocated sequence number

  IMessageHandler* messageHandler[MessageTypeLimit];

};

//---------------------------------------------------------------------------

// Macro to keep detailed informations about the packet/MPR flooding process:
// result in the following possible information (not all at the same time)
// not-sym,sym,already-retransmitted,in-iface-list,from-mpr,retransmit,
// from-other-iface
//
// With multicast extension:
// emmCheckForward, no-duplicate|with-duplicate, 
// no-retransmitted|already-retransmitted,should-forward|should-not-forward
#define PktD(l, collect, m, output) \
    BeginMacro \
      if ( ( (l).lPacketProcessing || \
             ((l).lMulticast && \
              m->messageType == node->getProtocolConfig()->multicastType) ) \
          && (l).out != NULL) { \
        ostringstream out; out << output; \
        collect += out.str(); \
      } \
    EndMacro

#define PktDEnd(l, collect, m, output) \
    BeginMacro \
      if ( ( (l).lPacketProcessing || \
             ((l).lMulticast && \
              m->messageType == node->getProtocolConfig()->multicastType) ) \
          && (l).out != NULL) { \
         (*(l).out) << collect.c_str() << output; \
      } \
    EndMacro

//---------------------------------------------------------------------------

static inline ostream& operator << (ostream& out, PacketManager& packetManager)
{ packetManager.write(out); return out; }

//---------------------------------------------------------------------------

#endif // _PACKET_H
