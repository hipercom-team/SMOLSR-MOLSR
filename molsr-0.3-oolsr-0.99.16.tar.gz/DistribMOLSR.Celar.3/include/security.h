//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _SECURITY_H
#define _SECURITY_H

//---------------------------------------------------------------------------

#include "node_inheritance.h"

//---------------------------------------------------------------------------

class RecursiveMessage : public IMessageContent
{
public:
  Message* content;
  MessageType messageType;
  string authInfo;
  bool   withAddress;
  bool   withTimestamp;
  bool   authOk;

  RecursiveMessage(Message* aContent)
  { content = aContent; }

  virtual IMessageContent* clone()
  {
    RecursiveMessage* result = new RecursiveMessage(content->clone());
    result->authInfo = authInfo;
    result->withAddress = withAddress;
    result->withTimestamp = withTimestamp;
    result->authOk = authOk;
    result->messageType = messageType;
    result->header = header->clone(false);
    result->header->content = result; // XXX: do something
    return result;
  }

  virtual void write(ostream& out) const;

  virtual ~RecursiveMessage()
  { delete content; content = NULL; }
};

//--------------------------------------------------

class Node;
class IMessageHandler;

class RecursiveMessageRewriter;

class IAuthenticationManager;

class RecursiveMessageHandler : public IMessageHandler
{
public:
  PacketManager* packetManager;
  IMessageHandler* handler;
  Node* node;
  bool shouldForward;
  bool shouldHaveTimestamp;
  bool shouldHaveAddress;
  RecursiveMessageRewriter* rewriter;
  
  MessageType baseMessageType;
  MessageType recursiveMessageType;

  RecursiveMessageHandler(Node* aNode,
			  IMessageHandler* aHandler,
			  bool aShouldForward,
			  bool aShouldHaveTimestamp,
			  bool aShouldHaveAddress,
			  MessageType aBaseMessageType,
			  MessageType aRecursiveMessageType,
			  RecursiveMessageRewriter* aRewriter);

  virtual void processMessage(/*borrowed*/ Message* message);

  virtual void considerForwardMessage(/*borrowed*/ Message* message,
				      string& info);

  virtual void packMessageContent(IMessageContent* message,
				  int maximumMessageSize,
				  MemoryBlock*& packedResult,
				  IMessageContent*& messageRemainingResult,
				  PackingInfo& packingInfo);

  string getAuthInfoContent(
			    IAuthenticationManager* authenticationManager,
			    RecursiveMessage* m,
			    string& rawHeader,
			    /*borrowed*/ MemoryBlock* intermediaryBlock,
			    PackingInfo& packingInfo);

  int getAuthInfoSize();

  int getOverhead(string data);

  //  virtual Time getTimeOffset(Address originatorAddress);
#if 0
  virtual bool checkTimeOffset(Time currentTime, Address originatorAddress, 
			       Time otherTime, Time tolerance);
#endif

  virtual void adjustMessageSize(IMessageContent* message);

  IMessageHandler* getMessageHandler(RecursiveMessage* message);
  
  IMessageContent* parseMessageContent(Message* message);

  virtual bool shouldPureFlood();
    //{ return rewriter->stdHandlerTable[baseMessageType]->shouldPureFlood(); }
      //packetManager->getMessageHandler(baseMessageType)->shouldPureFlood(); }
  //{ return handler->shouldPureFlood(); }

  virtual ~RecursiveMessageHandler() { }
};
  
//---------------------------------------------------------------------------

void installRecursiveMessageRewriter(Node* node);

//---------------------------------------------------------------------------

#ifndef WITH_PYTHON_TIME_PROTOCOL
class TimeOffsetExchangeProtocol;
#endif

class TimeExchangeMessageHandler;

//#include "node_ap.h"
class SecurityNode : public ParentSecurityNode
{
public:
  SecurityNode() 
    : ParentSecurityNode()
#ifndef WITH_PYTHON_TIME_PROTOCOL
      , timeProtocol(NULL)
#else
      , timeExchangeHandler(NULL), timeOffsetTable(1.0)
#endif // WITH_PYTHON_TIME_PROTOCOL
  { }

  virtual void start()
  {
    ParentSecurityNode::start(); // start parent
    startSecurity();
  }

  virtual void startSecurity();

#ifndef WITH_PYTHON_TIME_PROTOCOL
  bool checkTimeOffsetWithOther(Time currentTime, string& rawAddress,
				Time otherTime, Time toleratedMargin);
#else

#error this must be rewritten
  Time getTimeOffsetWithOther(string& rawAddress)
  {
    timeOffsetTable.expire(getCurrentTime());
    Time* timeOffset = timeOffsetTable.get(rawAddress);
    if (timeOffset == NULL) 
      return 0.0;
    else return *timeOffset;
  }
#endif

  void processExternalInfo(/*owned*/ MemoryBlock* block);

  virtual void logState(ostream& out, bool noEnd = false);

  virtual void eventTimeProtocolGeneration();

  MemoryBlock* updatePacketBeforeSend(/*owned*/ MemoryBlock* packet);

  //virtual void sendMessage(OLSRIface* iface, Message* message);

  virtual void getLevelList(vector<int>& result);

  virtual vector<string>* getTableNameList();
  virtual vector<vector<string>*>* getTableContent(string name);

protected:
  RecursiveMessageRewriter* rewriter;

#ifndef WITH_PYTHON_TIME_PROTOCOL
  TimeOffsetExchangeProtocol* timeProtocol;
#else
  TimeExchangeMessageHandler* timeExchangeHandler;
  ExpiringMap<string, Time> timeOffsetTable; // indexed by address
#endif
};

//---------------------------------------------------------------------------

const int SecureSubHeaderSize = 4;
const int SecureHeaderTypeMessage = 0x1;
const int SecureHeaderTypeAuthInfo = 0x2;

const int SecureFlagWithAddress = (1<<4);
const int SecureFlagWithTimestamp = (1<<5);
const int SecureMethodMask = ((1<<4)-1);

//---------------------------------------------------------------------------

#endif // _SECURITY_H
