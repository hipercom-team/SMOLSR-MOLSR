//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// The tuples and the sets used by the OLSR prptocol
//---------------------------------------------------------------------------

#ifndef _PROTOCOL_TUPLE_H
#define _PROTOCOL_TUPLE_H

//---------------------------------------------------------------------------

#include "base.h"

#include <list>
using std::list;

#include "general.h"
#include "tuple.h"
//#include "serialization.h"
#include "node_link_monitoring.h"
#ifdef MOOLSR
#include "molsrTuple.h"
#endif
class Node;

//---------------------------------------------------------------------------
// Various base values
//---------------------------------------------------------------------------

typedef enum {
  UNSPEC_LINK = 0, // @@3621
  ASYM_LINK = 1,   // @@3623
  SYM_LINK = 2,    // @@3625
  LOST_LINK = 3    // @@3627

#ifdef LINK_MONITORING
  ,PENDING_LINK = 10203
#endif
} LinkType;

static inline bool validLinkType(LinkType linkType)
{ 
  int linkTypeInt = (int)linkType;
  return inrange(0, linkTypeInt, 4);
} // @@3621-3627

static inline string linkTypeToString(LinkType linkType)
{ 
  switch(linkType) {
  case UNSPEC_LINK: return "unspec";
  case ASYM_LINK: return "asym";
  case SYM_LINK: return "sym";
  case LOST_LINK: return "lost";
#ifdef LINK_MONITORING
  case PENDING_LINK: return "pending";
#endif
  default:  return "???"; //XXX: Fatal("Impossible link type: " << (int)linkType);
  }
}


typedef enum {
  NOT_NEIGH = 0, // @@3631
  SYM_NEIGH = 1, // @@3633
  MPR_NEIGH = 2  // @@3635
} NeighborType;

static inline bool validNeighborType(NeighborType neighborType)
{
  int neighborTypeInt = (int)neighborType;
  return inrange(0, neighborTypeInt, 4); // @@3631-3635
}

static inline const string neighborTypeToString(NeighborType type)
{ 
  switch(type) {
  case NOT_NEIGH: return "not-neigh";
  case SYM_NEIGH: return "sym-neigh";
  case MPR_NEIGH: return "mpr-neigh";
  default: return "???";
  }
}

const int MaxANSN = (1<<16); // 16 bits - @@XXX
extern bool _ansnGreater(int s1, int s2);

//---------------------------------------------------------------------------
// [NeighborSensing] Link, Neighbor, Two-Hop Neighbor Tuple and Set
//---------------------------------------------------------------------------

typedef enum {
  SYM, NOT_SYM
} NeighborStatus;

static inline char* neighborStatusToString(NeighborStatus status)
{
  switch(status) {
  case SYM: return "sym";
  case NOT_SYM: return "not-sym";
  default: 
	Fatal("Impossible neighbor status: " << (int)status);
	return "impossible";
  }
}

class LinkTuple;
class LinkSet;
class TwoHopNeighborTuple;
class TwoHopNeighborSet;

struct HasLinkNeighborAddress;
struct HasTwoHopNeighborAddress;
struct HasTwoHopNodeAddress;
struct HasTwoHopLinkNeighborAddress;
struct IsLocalIfaceNeighbor;
struct IsLocalIfaceTwoHopNeighbor;

//--------------------------------------------------

class NeighborTuple : public ITuple
{
public:
  Address        N_neighbor_main_addr;
  NeighborStatus N_status;
  int            N_willingness;
#ifdef NU_AUTOCONF
  Time           N_MPR_memory_time;
  Time           N_MPR_forced_time;
#endif /* NU_AUTOCONF */

#ifdef WITH_QOS
  bool   hasQosInfo;
  double qosLoad;
  double beLoad;
  double qosLab;
  double beLab;
#endif // WITH_QOS

  NeighborTuple(Node* aNode) : N_status(NOT_SYM), node(aNode),
			       previousValue(NULL)
  {
#ifdef WITH_QOS
    hasQosInfo = false;
#endif
  }

  virtual ~NeighborTuple() {}

  typedef Filter<LinkTuple,BasicTupleSetIterator<LinkTuple>, 
		 HasLinkNeighborAddress> AssociatedLinkIterator;

  AssociatedLinkIterator getAssociatedLinkIterator();

  typedef Filter<TwoHopNeighborTuple,
		 BasicTupleSetIterator<TwoHopNeighborTuple>, 
		 HasTwoHopNeighborAddress> AssociatedTwoHopNeighborIterator;

  AssociatedTwoHopNeighborIterator 
  getAssociatedTwoHopNeighborIterator();

  // Note: update() automatically removes tuple from TupleSet 
  //if the neighbor tuple has no associated link tuple
  virtual void update() { _updateStatus(); }

  /// NeighborTuple never expire: they are removed when the last link tuple
  /// expires @@XXX
  Time getExpireTime(Time currentTime) { return TimeNever; }

  int getWillingness() { return N_willingness; }

  /// Remove Two-Hop Neighbor tuples and MPR selector tuples
  /// which concern this neighbor
  void removeAssociatedTupleOnDisappearance();

  friend class LinkTuple;
  friend class LinkSet;

  //virtual void serialize(ISerializer* serializer) {
  //Fatal("XXX: not implemented yet");
  //}

protected:
  Node* node;
  NeighborTuple* previousValue;
  void _updateStatus();

};

class NeighborSet : public BasicTupleSet<NeighborTuple>
{
public:
  NeighborSet(Node* aNode) : node(aNode) { }

  NeighborTuple* findFirst_MainAddr(Address mainAddress)
  { Search(NeighborTuple, current->N_neighbor_main_addr == mainAddress); }

  typedef Filter<NeighborTuple,BasicTupleSetIterator<NeighborTuple>, 
		 IsLocalIfaceNeighbor> LocalIfaceNeighborIterator;
  LocalIfaceNeighborIterator
  getLocalIfaceNeighborIterator(Address localIfaceAddress);

  virtual void write(ostream& out);

protected:
  Node* node;
  virtual void notifyRemoval(NeighborTuple* tuple);
  virtual void notifyAddition(NeighborTuple* tuple);
};

//--------------------------------------------------
class HeardIfaceTuple;

class LinkTuple : public ITuple
{
public:
  Address L_local_iface_addr;
  Address L_neighbor_iface_addr;
  Time L_SYM_time;
  Time L_ASYM_time;
  Time L_time;

  LinkTuple(Node* aNode) : 
    node(aNode), 
    neighborTupleEnsured(false),
    previousValue(NULL),
    L_LOST_LINK_time(TimePastNever),
    L_link_pending(false)
  {}
  
  /// Return the link type (as advertised in HELLO message), corresponding
  /// to the state obtained by the timers.
  LinkType getStatus() { return _status; }

  /// Example of "utility" function, on added on a Tuple
  NeighborTuple* getAssociatedNeighbor();

  virtual Time getExpireTime(Time currentTime) 
  { Time result = myMin(L_time, getUpdateTime(currentTime)); return result; }

  virtual void update();

  // For a LinkTuple, getUpdateTime returns the next time any timer has expired
  // for the tuple.
  Time getUpdateTime(Time currentTime)
  { 
#ifdef LINK_MONITORING
    // XXX: check the logic of this code...
    if (_status == LOST_LINK 
	&& (L_LOST_LINK_time >= currentTime)) // XXX: dangerous float comp.
      return L_LOST_LINK_time;
#endif
    if (_status == SYM_LINK)
      return L_SYM_time;
    else if (_status == ASYM_LINK)
      return L_ASYM_time;
    else return TimeFutureNever; // XXX: maybe:L_time (not important)
  }

  void updateAssociatedNeighborTuple()
  {
    NeighborTuple* neighborTuple = getAssociatedNeighbor();
    // [PRP] if !neighborTupleEnsured, we are in _processHelloLinkSet with 
    // a new linktuple and the neighborTuple->_updateStatus() will be
    // called later by _processHelloNeighborSet
    if (neighborTupleEnsured)
      neighborTuple->_updateStatus();
  }

  // Update L_LOST_LINK_time and L_link_pending with link monitoring info
  void updateWithLinkMonitoring(HeardIfaceTuple* heardIfaceTuple);

  void removeAndDeleteAssociatedHeardIfaceTuple();

  virtual ~LinkTuple()
  { if (previousValue != NULL) delete previousValue; previousValue = NULL; }

  Node* node;
  bool neighborTupleEnsured;

  virtual void write(ostream& out);

#if 0 
  // XXX: not used
  bool isSymmetrical()
  { return _status == SYM_LINK && !L_link_pending; }
#endif  

protected:
  LinkTuple* previousValue;
  LinkType _status;

  // These attributs are updated by the class HeardIfaceTuple which monitors 
  // all links we are hearing. The link quality is calculated in the class 
  // HeardIfaceTuple. 
  // These attributs initialization can be done with the method
  // updateWithLinkMonitoring() defined in this class. This method is also
  // call by HeardIfaceTuple when the pending state of the link changes.

  Time L_LOST_LINK_time; // Link Layer notification @@3127-3128
  bool L_link_pending;   // Link Hysteresis, @@3122-3125

  friend class LinkTupleSubject;

  void _updateStatus(Time currentTime)
  {
    // NOTE: changed '>=' of the draft to '>', etc... 
    // important only for simulations where a scheduled event
    // at time <clock>, will be called back with *exactly* a
    // current time == <clock>
    // Not considering '>=' as '>' will result into a scheduling
    // event for link status expiration, and when, called back
    // failing to change the status (and then scheduling the same
    // event for the exact same time: infinite loop) - exactly
    // as for removal.
#ifdef LINK_MONITORING
    if (L_LOST_LINK_time > currentTime)
      _status = LOST_LINK;
    else if (L_link_pending) // @@XXX
      _status = PENDING_LINK;
    else
#endif
    if (L_SYM_time > currentTime) // @@1725
      _status = SYM_LINK; // @@1727
    else if (L_ASYM_time > currentTime // @@1729-1732
	     && L_SYM_time <= currentTime)
      _status = ASYM_LINK; // @@1734
    else if (L_ASYM_time <= currentTime 
	     && L_SYM_time <= currentTime) // @@1743-1745
      _status = LOST_LINK; // @@1747
    else Fatal("impossible case");
  }
};

class LinkSet : public BasicTupleSet<LinkTuple>
{
public:
  LinkSet(Node* aNode) : node(aNode) { }

  LinkTuple* findFirst_SendIfaceAddress(Address address) 
  { Search(LinkTuple, current->L_neighbor_iface_addr == address); }
  
  LinkTuple* findFirst_SendAndReceiveIfaceAddress(Address txAddress, 
						  Address rxAddress) 
  { Search(LinkTuple, ( current->L_neighbor_iface_addr == txAddress &&
			current->L_local_iface_addr == rxAddress ) ); }
  
  virtual void removeAndDeleteExpired(Time currentTime);

protected:
  Node* node;
  virtual void notifyRemoval(LinkTuple* tuple);
  virtual void notifyAddition(LinkTuple* tuple);
  virtual void write(ostream& out);
};

//--------------------------------------------------

class TwoHopNeighborTuple : public ITuple
{
public:
  Address N_neighbor_main_addr;
  Address N_2hop_addr;
  Time    N_time;

#ifdef WITH_QOS
  bool   hasQosInfo;
  double qosLoad;
  double beLoad;
  double qosLab;
  double beLab;
#endif

  TwoHopNeighborTuple() 
  {
#ifdef WITH_QOS
    hasQosInfo = false;
#endif
  }

  virtual Time getExpireTime(Time currentTime) { return N_time; }
  virtual void update() { /* nothing to do */ }
  virtual ~TwoHopNeighborTuple() {}
};

class TwoHopNeighborSet : public BasicTupleSet<TwoHopNeighborTuple>
{
public:
  TwoHopNeighborSet(Node* aNode) : node(aNode) { }

  TwoHopNeighborTuple* findFirst_1hopAddr_2hopAddr
  (Address oneHop, Address twoHop)
  {
    Search(TwoHopNeighborTuple,
	   current->N_neighbor_main_addr == oneHop
	   && current->N_2hop_addr == twoHop);
  }
  
  //------------------------------

  typedef Filter<TwoHopNeighborTuple,
		 BasicTupleSetIterator<TwoHopNeighborTuple>, 
		 IsLocalIfaceTwoHopNeighbor> LocalIfaceTwoHopNeighborIterator;
  LocalIfaceTwoHopNeighborIterator
  getLocalIfaceTwoHopNeighborIterator(Node* aNode, Address localIfaceAddress);

  //------------------------------

  virtual void notifyAddition(TwoHopNeighborTuple* tuple);

  virtual void notifyRemoval(TwoHopNeighborTuple* tuple);

  virtual void write(ostream& out);

protected:
  Node* node;
};

//---------------------------------------------------------------------------
// [MPRSelection] MPR Selector Tuple and Set
//---------------------------------------------------------------------------

class MPRSelectorTuple : public ITuple
{
public:
  Address MS_addr;
  Time    MS_time;

  virtual Time getExpireTime(Time currentTime) { return MS_time; }
  virtual void update() { /* nothing to do */ }
  virtual ~MPRSelectorTuple() {}
};


class MPRSelectorSet : public BasicTupleSet<MPRSelectorTuple>
{
public:
  MPRSelectorSet(Node* aNode) : ansn(0), node(aNode) { }
  
  MPRSelectorTuple* findFirst_MainAddr(Address mainAddress)
  {  Search(MPRSelectorTuple, current->MS_addr == mainAddress); }

  virtual void notifyAddition(MPRSelectorTuple* tuple)
  { _incrementAnsn(); /* @@XXX*/ }

  virtual void notifyRemoval(MPRSelectorTuple* tuple)
  { _incrementAnsn(); /* @@XXX */ }

  void _incrementAnsn();

  virtual void write(ostream& out);
  
  unsigned int ansn;
  Node* node;
};

//---------------------------------------------------------------------------
// [TopologyDiscovery] Topology Tuple and Set
//----------------------------------------------------------------------------


class TopologyTuple : public ITuple
{
public:
  Address      T_dest_addr;
  Address      T_last_addr;
  unsigned int T_seq;
  Time         T_time;

  //#ifdef WITH_QOS
  //bool   hasQosInfo;
  //double availableBw;
  //#endif // WITH_QOS

  TopologyTuple() //: hasQosInfo(false), availableBw(0.0) 
  { }

  virtual Time getExpireTime(Time currentTime) { return T_time; }
  virtual void update() { /* nothing to do - XXX:check */ }
  virtual ~TopologyTuple() {}
};

class TopologySet : public OptimizedBasicTupleSet<TopologyTuple>
{
public:
  TopologySet(Node* aNode) : node(aNode) {}

  virtual Address getAddressKey(TopologyTuple* tuple)
  { return tuple->T_last_addr; }

  TopologyTuple* findFirst_obsolete_tuple(Address lastAddr,unsigned int seqNu)
  { 
    OptimizedSearch
      (TopologyTuple, 
       ((current->T_last_addr == lastAddr) 
	&& _ansnGreater(current->T_seq, seqNu)),
       lastAddr); 
  }

  TopologyTuple* findFirst_tuple(Address lastAddr,Address destAddr)
  { 
    OptimizedSearch
      (TopologyTuple, (current->T_last_addr == lastAddr)
       &&(current->T_dest_addr == destAddr),
       lastAddr); 
  }

#if 0
  // XXX: remove, this has been factored out
  AddressMap<list<TopologyTuple*> > lastAddressToTupleList;

  TopologyTuple* findFirst_obsolete_tuple(Address lastAddr,unsigned int seqNu)
  { 
    list<TopologyTuple*>* tupleList = lastAddressToTupleList.get(lastAddr);
    if (tupleList == NULL)
      return NULL;
    for(list<TopologyTuple*>::iterator it = tupleList->begin();
	it != tupleList->end(); it++) {
      TopologyTuple* current = *it;
      if ((current->T_last_addr == lastAddr) 
	  && _ansnGreater(current->T_seq, seqNu))
	return current;
    }
    return NULL;
  }

  TopologyTuple* findFirst_tuple(Address lastAddr, Address destAddr)
  { 
    list<TopologyTuple*>* tupleList = lastAddressToTupleList.get(lastAddr);
    if (tupleList == NULL)
      return NULL;
    for(list<TopologyTuple*>::iterator it = tupleList->begin();
	it != tupleList->end(); it++) {
      TopologyTuple* current = *it;
      if (current->T_dest_addr == destAddr) 
	return current;
    }
    return NULL;
  }
#endif //0

  virtual void notifyRemoval(TopologyTuple* tuple);

  virtual void notifyAddition(TopologyTuple* tuple);

  virtual void write(ostream& out);

public:
  Node* node;
};

//---------------------------------------------------------------------------
// Interface Association Base, Tuple and Set
//---------------------------------------------------------------------------

class IfaceAssociationTuple : public ITuple
{
public:
  Address I_iface_addr; /// interface address of a node @@1192-1193
  Address I_main_addr;  /// main address of this node @@1193-1194
  Time    I_time;       /// time at which this tuple expires @@1194-1195

  virtual Time getExpireTime(Time currentTime) { return I_time; }
  virtual void update() { /* Nothing to do (XXX: check this) */ }
  virtual ~IfaceAssociationTuple() {}
};

class IfaceAssociationSet : public BasicTupleSet<IfaceAssociationTuple>
{
public:
  IfaceAssociationSet(Node* aNode) : node(aNode) { }

  IfaceAssociationTuple* 
  findFirst_IfaceAssociation(Address originator,Address iface)
  {
    Search(IfaceAssociationTuple,
	   ((current->I_main_addr==originator)
	    &&(current->I_iface_addr==iface)));
  }

  IfaceAssociationTuple* findFirst_IfaceAssociation(Address iface)
  { Search(IfaceAssociationTuple,(current->I_iface_addr==iface)); }

  virtual void write(ostream& out);

  virtual void notifyRemoval(IfaceAssociationTuple* tuple);
  virtual void notifyPreRemoval(IfaceAssociationTuple* tuple);
  virtual void notifyAddition(IfaceAssociationTuple* tuple);

protected:
  Node* node;
};

//---------------------------------------------------------------------------
// [HNABase] Host and Network Association Base, Tuple and Set
//---------------------------------------------------------------------------

class HNATuple : public ITuple
{
public:
  Address A_gateway_addr; /// address of an OLSR interface of the gtway @@2900
  Address A_network_addr; /// network address, @@2901-2902
  Address A_netmask; ///  netmask of a network, reachable through this gateway
  Time A_time; /// time at which this tuple expires @@2902-2903

  virtual Time getExpireTime(Time currentTime) { return A_time; }
  virtual void update() { /* nothing to do (XXX: check this) */ }
  virtual ~HNATuple() {}
};

class HNASet : public BasicTupleSet<HNATuple>
{
public:
  HNASet(Node* aNode) : node(aNode) { }

  HNATuple* 
  findFirst_HNA(Address origAddr,Address netAddr,Address netmask)
  { Search(HNATuple,((current->A_gateway_addr==origAddr)
				&&(current->A_network_addr==netAddr)
				&&(current->A_netmask==netmask))) }

  virtual void write(ostream& out);

protected:
  virtual void notifyRemoval(HNATuple* tuple);
  virtual void notifyAddition(HNATuple* tuple);
  Node* node;
};

//---------------------------------------------------------------------------
// Routing Tuple and Table
//---------------------------------------------------------------------------

class RoutingTuple : public ITuple
{
public:
  Address R_dest_addr;
  Address R_dest_mask_addr;
  Address R_next_addr;
  Address R_last_addr; // (informational only)
  int     R_dist;
  Address R_iface_addr;


  bool isSame(RoutingTuple& other)
  { return R_dest_addr == other.R_dest_addr
      && R_dest_mask_addr == other.R_dest_mask_addr
      && R_next_addr == other.R_next_addr
      && R_dist == other.R_dist
      && R_iface_addr == other.R_iface_addr; }
      

  virtual Time getExpireTime(Time currentTime) { return TimeNever; }
  virtual void update() { /* nothing to do */ }
  virtual ~RoutingTuple() {}
};

class RoutingTable : public OptimizedBasicTupleSet<RoutingTuple>
{
public:
  RoutingTable(Node* aNode) : node(aNode) { }

  virtual Address getAddressKey(RoutingTuple* tuple)
  { return tuple->R_dest_addr; }

  void addRoutingEntry(Address dest, Address next, Address last, int dist,
		       Address ifaceAddress);

  void addRoutingNetEntry(Address dest, Address destMask,
			  Address next, Address last,
			  int dist, Address ifaceAddress);

  RoutingTuple* findFirst_Destination(Address destinationAddress)
  { OptimizedSearch(RoutingTuple, 
		    current->R_dest_addr == destinationAddress,
		    destinationAddress); }

  RoutingTuple* findFirst_Destination_Mask(Address destinationAddress,
					   Address destinationMask)
  { OptimizedSearch (RoutingTuple, 
		     current->R_dest_addr == destinationAddress
		     && current->R_dest_mask_addr== destinationMask,
		     destinationAddress); }

  RoutingTuple* findFirst_Same(RoutingTuple* routingTuple)
  { OptimizedSearch(RoutingTuple, 
		    current->isSame(*routingTuple),
		    routingTuple->R_dest_addr); }

#if 0

  AddressMap< std::list<RoutingTuple*> > addressToRoutingTupleList;

  RoutingTuple* findFirst_Destination(Address destinationAddress);
  RoutingTuple* findFirst_Same(RoutingTuple* routingTuple);

#endif // ROUTE_OPT

  virtual void notifyRemoval(RoutingTuple* tuple)
  { /* nothing to do */ }

  virtual void notifyAddition(RoutingTuple* tuple)
  { /* nothing to do */ }

  virtual void write(ostream& out);

  virtual ~RoutingTable();

protected:
  Node* node;
  AddressMap<RoutingTuple*> routeTo;
};

//---------------------------------------------------------------------------
// [PacketProcessing] Duplicate, Tuple and Set
//---------------------------------------------------------------------------

class DuplicateTuple : public ITuple
{
public:
  Address            D_addr;
  int                D_seq_num;
  bool               D_retransmitted;
  std::list<Address> D_iface_list;
  Time               D_time;

#ifdef NU_AUTOCONF
  string             D_hash;
#endif

#ifdef WITH_SECURITY
  Time netTime;
  bool hasNetTime;
#endif

  /// Utility function, returns true if and only if the address is in
  /// the D_iface_list
  bool isInIfaceList(Address ifaceAddress);

  virtual Time getExpireTime(Time currentTime) { return D_time; }
  virtual void update() { /* nothing to do */ }

  virtual ~DuplicateTuple() { /* nothing to do */ }
};


class DuplicateSet : public OptimizedBasicTupleSet<DuplicateTuple>
{
public:
  DuplicateSet(Node* aNode) : node(aNode) { }

  virtual Address getAddressKey(DuplicateTuple* tuple)
  { return tuple->D_addr; }

  DuplicateTuple* findFirst_Address_MessageSequenceNumber
  (Address originatorAddress, int messageSequenceNumber)
  { 
    OptimizedSearch(DuplicateTuple,
	   (current->D_addr == originatorAddress)
		    && (current->D_seq_num ==messageSequenceNumber),
		    originatorAddress);
  }

protected:
  Node* node;

  virtual void write(ostream& out);
  
  virtual void notifyRemoval(DuplicateTuple* tuple)
  { /* nothing to do */ }

  virtual void notifyAddition(DuplicateTuple* tuple)
  { /* nothing to do */ }
};

//---------------------------------------------------------------------------

class HNATuple_ : public ITuple
{
public:
  Address A_gateway_addr; /// address of an OLSR interface of the gtway @@2900
  Address A_network_addr; /// network address, @@2901-2902
  Address A_netmask; ///  netmask of a network, reachable through this gateway
  Time A_time; /// time at which this tuple expires @@2902-2903

  virtual Time getExpireTime(Time currentTime) { return A_time; }
  virtual void update() { /* nothing to do (XXX: check this) */ }
  virtual ~HNATuple_() {}
};

class HNASet_ : public BasicTupleSet<HNATuple>
{
public:
  HNASet_(Node* aNode) : node(aNode) { }

  HNATuple* 
  findFirst_HNA(Address origAddr,Address netAddr,Address netmask)
  { Search(HNATuple,((current->A_gateway_addr==origAddr)
				&&(current->A_network_addr==netAddr)
				&&(current->A_netmask==netmask))) }

  virtual void write(ostream& out){}

protected:
  virtual void notifyRemoval(HNATuple* tuple){}
  virtual void notifyAddition(HNATuple* tuple){}
  Node* node;
};

//---------------------------------------------------------------------------

#endif // _PROTOCOL_TUPLE_H
