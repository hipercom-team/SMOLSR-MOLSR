//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//               Adokoe Plakoo, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//     $Id: node_mpr_selection.h,v 1.7 2005/05/17 17:30:56 adjih Exp $
//---------------------------------------------------------------------------
// The classes and structures used in MPR computation
//---------------------------------------------------------------------------

#ifndef _NODE_MPR_SELECTION_H
#define _NODE_MPR_SELECTION_H

//---------------------------------------------------------------------------

#include "base.h"

//---------------------------------------------------------------------------

class LocalIfaceMPRComputation;
/**
 * \class OneHopNodeTuple
 * \brief OneHopNodeTuple corresponds to NeighborTuple 
    with special methods used in MPR computation.
 * \author Adokoe
 *
 * In the following comments the two definitions bellow are used:
 * - N is the subset of neighbors of this node 
 *   (the node performing the computation), which are
 *   neighbor of the interface I (one of this node interface).
 * - N2 is the set of 2-hop neighbors reachable from the interface I, 
 *   excluding:
 *   (i)   the nodes only reachable by members of N with
 *          willingness WILL_NEVER
 *   (ii)  the node performing the computation
 *   (iii) all the symmetric neighbors: the nodes for which
 *         there exists a symmetric link to this node on some interface.
 */

class OneHopNodeTuple
{
public:
  NeighborTuple* neighborTuple;
  bool isMPR;

  OneHopNodeTuple(NeighborTuple* aNeighborTuple, 
		  LocalIfaceMPRComputation* aMPRComputation, Node* aNode,
		  Address ifaceAddress) :
    neighborTuple(aNeighborTuple),
    node(aNode),
    mprComputation(aMPRComputation), local_iface_addr(ifaceAddress) {};
  void setMPR(bool mpr) { isMPR = mpr; };
  bool isSelectedAsMPR() { return isMPR; };
  /**
   *  The degree of a 1-hop neighbor node y (where y is a
   *  member of N), is defined as the number of symmetric
   *  neighbors of node y, EXCLUDING all the members of N and
   *  EXCLUDING the node performing the computation.
   */
  int getDegree();
  /**
   * The reachability of a node in N is the
   * number of nodes in N2 which are not yet covered by at
   * least MPR_COVERAGE node in the MPR set, and which are reachable
   * through this 1-hop neighbor
   */
  int getReachability();

protected:
  Node* node;
  LocalIfaceMPRComputation* mprComputation;
  /**
   * The address of the interface I which the MPR set
   * is generated for.
   */
  Address local_iface_addr;  
};

//---------------------------------------------------------------------------

/**
 * \class TwoHopNodeTuple
 * \brief A TwoHopNodeTuple is the second endpoint of a two hops link.
 * \author Adokoe
 *
 * In the following comments the two definitions bellow are used:
 * - N is the subset of neighbors of this node
 *   (the node performing the computation) , which are
 *   neighbor of the interface I (one of this node interface).
 * - N2 is the set of 2-hop neighbors reachable from the interface I, 
 *   excluding:
 *   (i)   the nodes only reachable by members of N with
 *          willingness WILL_NEVER
 *   (ii)  the node performing the computation
 *   (iii) all the symmetric neighbors: the nodes for which
 *         there exists a symmetric link to this node on some interface.
 *
 * N.B: A TwoHopNeighborTuple corresponds to a two hops link i.e. 
 * a link between a neighbor node and a two hops neighbor node  
 * while a TwoHopNodeTuple corresponds to a two hops neighbor node only.
 * N2 will be built with TwoHopNodeTuple instances.
 */
class TwoHopNodeTuple
{
public:
  Address Main_addr;

  TwoHopNodeTuple(LocalIfaceMPRComputation* aMPRComputation, Node* aNode,
		  Address main_address, Address ifaceAddress) : 
    Main_addr(main_address),  node(aNode),
    mprComputation(aMPRComputation), L_local_iface_addr(ifaceAddress)
    //#ifdef MPR_OPT
    // XXX! remove: this doesn't optimize
    //,oneHopListCache(NULL)
    //#endif
 {}

  /**
   * Return true if this node is only reachable 
   * by members of N with willingness WILL_NEVER.
   */
  bool isOnlyReachableByWillNever();
  /**
   * Return true if there exists a symmetric link
   * to this node on some interface.
   */
  bool isAlsoNeighbor(); 
  /**
   * A poorly covered node is a node in N2 which is covered
   * by less than MPR_COVERAGE nodes in N.
   */
  bool isPoorlyCovered();
  bool isLinkedTo(OneHopNodeTuple& oneHopNode);
  bool isFoundInStrictTwoHopList();
  /**
   * How many MPR nodes are covering this node at the moment.
   */
  int getCurrentMprCoverage();

  typedef Filter<TwoHopNeighborTuple,
                 BasicTupleSetIterator<TwoHopNeighborTuple>,
                 HasTwoHopNodeAddress> AssociatedTwoHopLinkIterator;

  AssociatedTwoHopLinkIterator  getAssociatedTwoHopLinkIterator();

#ifdef MPR_OPT
  typedef IteratorAdapter<NeighborTuple*, std::list<NeighborTuple*>::iterator> 
  AssociatedNeighborIterator;
#else
  typedef Filter<NeighborTuple,
                 BasicTupleSetIterator<NeighborTuple>,
                 HasTwoHopLinkNeighborAddress> AssociatedNeighborIterator;
#endif

  AssociatedNeighborIterator  getAssociatedNeighborIterator();

protected:
  Node* node;
  LocalIfaceMPRComputation* mprComputation;
  /**
   * The address of the interface I which the MPR set
   * is generated for.
   */
  Address L_local_iface_addr;

  //#ifdef MPR_OPT
  //list<NeighborTuple*>* oneHopListCache;
  //#endif
};

//-----------------------------------------------------------------------------

/**
 * \class LocalIfaceMPRComputation
 * \brief This class computes the MPR list of a given local interface.
 * \author Adokoe
 * 
 * In the following comments the two definitions bellow are used:
 * - N is the subset of neighbors of this node
 *   (the node performing the computation), which are
 *   neighbor of the interface I (one of this node interface).
 * - N2 is the set of 2-hop neighbors reachable from the interface I, 
 *   excluding:
 *   (i)   the nodes only reachable by members of N with
 *          willingness WILL_NEVER
 *   (ii)  the node performing the computation
 *   (iii) all the symmetric neighbors: the nodes for which
 *         there exists a symmetric link to this node on some interface.
 *
 */

class LocalIfaceMPRComputation
{
public:
  /**
  * oneHopNodeList corresponds to N in the above definition
  */
  list<OneHopNodeTuple*> oneHopNodeList; 
  /**
  * strictTwoHopNodeList corresponds to N2 in the above definition
  */
  list<TwoHopNodeTuple*> strictTwoHopNodeList;

  AddressMap<OneHopNodeTuple*> oneHopNodeTable;
  
  LocalIfaceMPRComputation(Node* aNode, Address ifaceAddress) :
    node(aNode), local_iface_addr(ifaceAddress) {};

  ~LocalIfaceMPRComputation()
  {
    deleteOneHopNodeList();
    deleteStrictTwoHopNodeList();
  };

  void setOneHopNodeList();
  void setStrictTwoHopNodeList();
  void deleteOneHopNodeList();
  void deleteStrictTwoHopNodeList();
  bool isSelectedAsLocalIfaceMpr(Address main_address);
  bool isStrictTwoHopNodeListEmpty() 
  {
    return strictTwoHopNodeList.begin() == strictTwoHopNodeList.end();
  };
  OneHopNodeTuple* getOneHopNode(Address main_address);

  OneHopNodeTuple* getOneHopNode(NeighborTuple* neighborTuple);
  bool isNewMprNodeNeeded();

  /**
   * Select as MPR all members of N with willingness equal to WILL_ALWAYS.
   */
  void selectWillAlwaysAsMpr();
  /**
   * Select as MPRs those nodes in N which cover the poorly
   * covered nodes in N2.
   */
  void selectPoorlyCoveredNeighborAsMpr();
  /**
   * Select as a MPR the node with highest willingness among
   * the nodes in N with non-zero reachability.  In case of
   * multiple choice select the node which provides
   * reachability to the maximum number of nodes in N2.  In
   * case of multiple nodes providing the same amount of
   * reachability, select the node as MPR whose degree is greater.
   */
  void selectOtherMpr();
  /**
   * Remove the nodes from N2 which are now covered
   * by MPR_COVERAGE nodes in the MPR set.
   */
  void removeMprCoveredNodes();
  /**
   * Compute the MPR selection algorithm one interface I.
   */
  void computeMpr();
  /**
   * Add the MPR set generated for the interface I
   * to the node's MPR set. Duplicate element is avoided 
   * in the node MPR list.
   */
  void addMprToNodeList();


#ifdef MPR_OPT
  void initOptimization();

  // neighbor main addr -> boolean
  AddressMap<bool> neighborHasLinkOnThis; 

  // neighbor main addr -> neighborTuple iff it is on this iface
  AddressMap<NeighborTuple*> localNeighborTuple; 

  // two hop main addr -> list of neighborTuple/s
  AddressMap< list<NeighborTuple*> > twoHopToOneHopList;

  // the list of the two hop neighbor tuple on this interface
  std::list<TwoHopNeighborTuple*> twoHopNeighborSetOnIface;
#endif

protected:

  Node* node;
  /**
   * The address of the interface I which the MPR set
   * is generated for.
   */
  Address local_iface_addr; 
};

//---------------------------------------------------------------------------

// Return true iff:
// - neighborTuple has a link on the interface with address L_local_iface_addr
//
// Iterator:
// - gives neighborTuple which have a link on a given iface
// - iteration time: O( NxL )
// - used: 2 times

struct IsLocalIfaceNeighbor
{
  IsLocalIfaceNeighbor(Address aLocalIfaceAddress) :
    localIfaceAddress(aLocalIfaceAddress) { }

  bool operator () (NeighborTuple& neighborTuple)
  {
    if (neighborTuple.N_status != SYM)
      return false;

    for(NeighborTuple::AssociatedLinkIterator it = 
	  neighborTuple.getAssociatedLinkIterator(); !it.isDone(); it.next())

	if (it.getCurrent()->L_local_iface_addr == localIfaceAddress)	
	  return true;
    
    return false;
  }

  Address localIfaceAddress;
};

//-----------------------------------------------------------------------------

// Return true iff:
// - twoHopTuple has one-hop on the interface with address L_local_iface_addr
//
// Iterator:
// - gives twoHopTuple which can be reached by one iface
// - iteration time: O( TxNxL )
// - used: 2 times

struct IsLocalIfaceTwoHopNeighbor
{
  IsLocalIfaceTwoHopNeighbor(Node* aNode, Address aLocalIfaceAddress)
   : node(aNode), localIfaceAddress(aLocalIfaceAddress) {}

  bool operator () (TwoHopNeighborTuple& twoHopTuple)
  {
    for(NeighborSet::LocalIfaceNeighborIterator it = 
	  node->neighborSet.getLocalIfaceNeighborIterator(localIfaceAddress);
	!it.isDone(); it.next())

      if (it.getCurrent()->N_status == SYM)
	if (it.getCurrent()->N_neighbor_main_addr == 
	    twoHopTuple.N_neighbor_main_addr) return true;

    return false;
  }

  Node* node;
  Address localIfaceAddress;
};

//---------------------------------------------------------------------------

#endif // _NODE_MPR_SELECTION_H
