//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//---------------------------------------------------------------------------
// <GENERATED>
// Template: <TEMPLATE>
// Date: <DATE>
// User: <USER>
// Command: <COMMAND>
//---------------------------------------------------------------------------
// <NOMOD>
//---------------------------------------------------------------------------

#ifndef _GEN_PROTOCOL_CONFIG_H
#define _GEN_PROTOCOL_CONFIG_H

//---------------------------------------------------------------------------

using std::string;

#include <map>
#include <string>
#include <vector>
#include "mystream.h"
#include <list>

//#include "address.h"
#include "general.h"

//---------------------------------------------------------------------------

class ExternalChannelConfig
{
public:
  string name;
  //int    messageType;
  int    channelIn;
  int    channelOut;
  //FloodingMode floodingMode;
};

//---------------------------------------------------------------------------

#ifdef WITH_SECURITY
class AuthenticationMethod
{
public:
  string name;
  string parameter;
  int authInfo;
};
#endif

//---------------------------------------------------------------------------

class ParseError
{
public: 
  ParseError(string aError) : error(aError) {}
  string error;
};

#define ThrowParseError(x) \
    BeginMacro \
      ostringstream message; \
      message << x; \
      throw (ParseError(message.str())); \
    EndMacro

static inline bool parseBool(string data)
{ return atoi(data.c_str())>0; }

static inline string parseString(string data)
{ return data; }

static inline int parseInt(string data)
{ 
  char* info=NULL;
  int result = strtol(data.c_str(), &info, 0);
  if (*info != '\0')
    ThrowParseError("Cannot parse integer: " << data);
  else return result;
}
//{ return atoi(data.c_str()); }

static inline double parseFloat(string data)
{ return atof(data.c_str()); /* XXX: error handling */ }

extern std::vector<string> stringSplit(string aLine, string charSet);

static inline std::list< std::pair<string,string> > parseHNAList(string data)
{ 
  std::list< std::pair<string,string> > result;
  string dashSeparator = "/";
  string semiColonSeparator = ",";

  std::vector<string> hnaStrList = stringSplit(data, semiColonSeparator);
  for (std::vector<string>::iterator it = hnaStrList.begin();
       it != hnaStrList.end();it++) {
    std::vector<string> oneHNA = stringSplit((*it), dashSeparator);
    assert (oneHNA.size() == 2);
    result.push_back( std::pair<string,string> (oneHNA[0], oneHNA[1]) );
  }
  return result;
}

static inline ostream& operator << 
  (ostream& out, std::list< std::pair< string, string> > data)
{
  bool isFirst = true;
  out << "(";
  for (std::list< std::pair< string, string> >::iterator it = data.begin();
       it != data.end(); it++) {
    if (!isFirst) 
      out << ", ";
    else isFirst = false;
    out << (*it).first << "/" << (*it).second ;
  }
  out << ")";
  return out;
}
					 

//--------------------------------------------------

class GeneratedLog
{
public:
<GEN_LOG_FIELD>

  GeneratedLog() { setDefaultValue(); }

  void setDefaultValue() {
<GEN_LOG_DEFAULT>
  }

  void setAllDefaultValue(bool value) {
<GEN_LOG_ALL_DEFAULT>
  }

  void write(ostream& out) const
  {
    out <GEN_LOG_OUTPUT>;
  }
};

//--------------------------------------------------

class GeneratedIfaceConfig
{
public:
  GeneratedIfaceConfig() { setDefaultValue(); }

<GEN_IFACE_CONF_FIELD>

  void setDefaultValue() {
<GEN_IFACE_DEFAULT>
  }

  string parseData(std::vector<string>& data) {
    if (data.size() < 2) return "not enough arguments";
    <GEN_IFACE_CONF_PARSE_CODE> else {
      return "Cannot parse XXX";
    }
    return "";
  }

  void write(ostream& out) const
  {
    out <GEN_IFACE_OUTPUT>;
  }
};

#define REPR_PARAM(result, name) \
  BeginMacro \
    vector<string>* info = new vector<string>; \
    ostringstream tmp; tmp << name; \
    info->push_back(""#name); \
    info->push_back(tmp.str()); \
    result->push_back(info); \
  EndMacro

class GeneratedProtocolConfig
{
public:
  GeneratedProtocolConfig() { setDefaultValue(); }

<GEN_CONF_FIELD>

  void setDefaultValue() {
<GEN_CONF_DEFAULT>
  }

  string parseData(GeneratedLog& log, std::vector<string>& data) {
    if (data.size() < 2) return "not enough arguments";
    <GEN_CONF_PARSE_CODE> else {
      return "Cannot parse XXX";
    }
    return "";
  }

  void write(ostream& out) const
  {
    out <GEN_CONF_OUTPUT>;
  }

  vector<vector<string>*>* getTable() const
  {
    vector<vector<string>*>* result = new vector<vector<string>*>;
    vector<string>* header = new vector<string>;
    header->push_back("Param Name");
    header->push_back("Value");
    result->push_back(header);
    
    <GEN_REPR_OUTPUT>;
    
    return result;
  }

  ExternalChannelConfig* getChannelByName(string name)
  {
    for (ITER(std::list<ExternalChannelConfig>, it, externalChannelList)) {
      if ((*it).name == name)
	return &(*it);
    }
    return NULL;
  }

  std::map<string,GeneratedIfaceConfig*> ifaceConfig;
  std::list<ExternalChannelConfig> externalChannelList;
#ifdef WITH_SECURITY
  std::list<AuthenticationMethod> authMethodList;
#endif
};

//---------------------------------------------------------------------------

#endif /*_GEN_PROTOCOL_CONFIG_H*/
