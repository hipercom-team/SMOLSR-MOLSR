/*---------------------------------------------------------------------------
 *                             hostap_capture
 *               Cedric Adjih, projet Hipercom, INRIA Rocquencourt
 *  Copyright 2004 Institut National de Recherche en Informatique et
 *  en Automatique.  All rights reserved.  Distributed only with permission.
 *---------------------------------------------------------------------------
 * under GPL when distributed for hostap
 *---------------------------------------------------------------------------*/

#include <linux/if_ether.h>

#define HOSTAP_CAPTURE_TARGET_NONE  0x0
#define HOSTAP_CAPTURE_TARGET_OLSR  0x1
#define HOSTAP_CAPTURE_TARGET_ALL   0x2
#define HOSTAP_CAPTURE_TARGET_MASK  0x3

#define HOSTAP_CAPTURE_ASCII       0x4

#define HOSTAP_CAPTURE_TYPE_OFFSET '0'

#define HOSTAP_CAPTURE_MAX (IW_CUSTOM_MAX - 2)

typedef struct {
  unsigned char  capture_type;
  signed char    signal;
  signed char    noise;
  unsigned short rate;
  unsigned int   mac_time;
  unsigned int   sequence;
} hostap_capture_header_t;

#define IPv6_ALEN 16

typedef struct {
  hostap_capture_header_t header;

  unsigned char  isIPv6;

  unsigned char eth_src[ETH_ALEN];
  unsigned char eth_dst[ETH_ALEN];

  union {
    struct in_addr ipv4;
    struct in6_addr ipv6;
  } src;

  union {
    struct in_addr ipv4;
    struct in6_addr ipv6;
  } dst;

} hostap_capture_olsr_t;

#define HOSTAP_CAPTURE_PACKET_MAX (HOSTAP_CAPTURE_MAX \
				   - sizeof(hostap_capture_header_t) \
				   -sizeof(unsigned int))

typedef struct {
  hostap_capture_header_t header;
  unsigned int captured_size;
  unsigned char packet[HOSTAP_CAPTURE_PACKET_MAX];
		       /* XXX: what about alignement padding ... */
} hostap_capture_packet_t; /* XXX: attribute(packed) */

/*---------------------------------------------------------------------------*/
