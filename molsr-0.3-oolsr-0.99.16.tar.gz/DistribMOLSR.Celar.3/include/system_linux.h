//-----------------------------------------------------------------*- c++ -*-
//                             OOLSR
//               Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _SYSTEM_LINUX_H
#define _SYSTEM_LINUX_H

//---------------------------------------------------------------------------

#include "general.h"
#include "address.h"
#include "network_generic.h"
#include "scheduler_unix.h"

//---------------------------------------------------------------------------

#include <net/if.h>
#include <linux/pkt_sched.h>
//#include "http_support.cc"

class LinuxLowLevel
{
public:
  static void socketBindToDevice(int sd, string deviceName);

  static void setSocketReuseAddr(int sd);

  static void setSocketBroadcast(int sd);

  static void setSocketPriority(int sd);

  static void addRoute(int family, int ifaceIndex, Address destIpAddress,
		       Address gatewayAddress, Address netMaskAddress, 
		       int metric, bool notFatal);

  static void removeRoute(int family, int ifaceIndex, Address destIpAddress,
			  Address gatewayAddress, Address netMaskAddress, 
			  int metric, bool notFatal);

protected:

  static int modifyRoute( int action, int flags, int family, int ifaceIndex,
			  Address destIpAddress,
			  Address gatewayAddress, Address netMaskAddress, 
			  int metric, bool notFatal);
  static int prefix_length(int family, void *anetmask);
  static int get_system_reply(int sockFd, int seqNum, bool notFatal);
  static int addattr(struct nlmsghdr* header, int type, void* data, int alen);
};

//---------------------------------------------------------------------------

#ifdef WITH_QOS
class LinuxPacketCounter : public IPacketCounter
{
public:
  LinuxPacketCounter(string aIfaceName, string aTCLocation,
		     string aSyntaxTcCmd1, string aSyntaxTcCmd2,
		     string aSyntaxTcCmd3,
		     int aQosQosTcHandle, int aQosOlsrTcHandle,
		     int aQosBeTcHandle)
    : ifaceName(aIfaceName), tcLocation(aTCLocation),
      syntaxTcCmd1(aSyntaxTcCmd1), syntaxTcCmd2(aSyntaxTcCmd2),
      syntaxTcCmd3(aSyntaxTcCmd3),
      qosQosTcHandle(aQosQosTcHandle), qosOlsrTcHandle(aQosOlsrTcHandle),
      qosBeTcHandle(aQosBeTcHandle)
  {
    olsr.tx_bytes   = 0;
    olsr.tx_packets = 0;
    qos.tx_bytes    = 0;
    qos.tx_packets  = 0;
    be.tx_bytes     = 0;
    be.tx_packets   = 0;
    oldBeRate       = 0;
    ifIndex         = if_nametoindex(aIfaceName.c_str());
  }

  virtual unsigned long setTcInfo(int beRate, int tcHysteresis) {
    std::ostringstream sBeRate;
    string tcCmd;

    // smoothly sliding average
    if (beRate > oldBeRate)
      beRate = (beRate + oldBeRate)/2;

    int deltaBeRate = oldBeRate - beRate;
    if (deltaBeRate < 0)
      deltaBeRate = -deltaBeRate;

    if (deltaBeRate < tcHysteresis)
      return 1; // beRate has not changed enough

    sBeRate << beRate;
    tcCmd = tcLocation + syntaxTcCmd1 + ifaceName + syntaxTcCmd2
      + sBeRate.str() + syntaxTcCmd3;

    system (tcCmd.c_str());

    oldBeRate = beRate;
    return 0;
  }

  virtual unsigned long getQdiscInfo() {

    struct nlmsghdr *nlh;
    struct tcmsg *tcmsg;
    struct rtattr *rta;

    struct tc_stats stats;

    char msgbuf[8192];
    int sock, rtlen, handle;
    unsigned int res, msgseq=0;

    if((sock = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_ROUTE)) < 0){
      fprintf(stderr, "socket rtnetlink tc qdisc\n");
      return 1;
    }

    memset(msgbuf, 0, 8192);

    nlh = (struct nlmsghdr*) msgbuf;
    tcmsg = (struct tcmsg*) NLMSG_DATA(nlh);

    nlh->nlmsg_len   = NLMSG_LENGTH(sizeof(struct rtmsg));
    nlh->nlmsg_type  = RTM_GETQDISC;
    nlh->nlmsg_flags = NLM_F_ROOT | NLM_F_MATCH | NLM_F_REQUEST;
    nlh->nlmsg_pid   = getpid();
    nlh->nlmsg_seq   = msgseq++;

    if(send(sock, nlh, nlh->nlmsg_len, 0) < 0) {
      fprintf(stderr, "send rtnetlink tc qdisc failed\n");
      return 1;
    }

    res = read_sock(sock, msgbuf, msgseq, getpid());
    close(sock);

    for( ; NLMSG_OK(nlh,res); nlh = NLMSG_NEXT(nlh, res)){
      tcmsg = (struct tcmsg *)NLMSG_DATA(nlh);

      if (tcmsg->tcm_ifindex != ifIndex)
	continue;

      handle = tcmsg->tcm_handle >> 16;
      if ((handle != qosQosTcHandle) &&
	  (handle != qosOlsrTcHandle) &&
	  (handle != qosBeTcHandle))
	continue;

      rta = (struct rtattr *)TCA_RTA(tcmsg);
      rtlen = RTM_PAYLOAD(nlh);
      for( ; RTA_OK(rta, rtlen); rta = RTA_NEXT(rta, rtlen)) {
	if (rta->rta_type == TCA_STATS) {
	  memset(&stats, 0, sizeof(struct tc_stats));
	  memcpy(&stats, RTA_DATA(rta), sizeof(struct tc_stats));
	  if (handle == qosQosTcHandle) { // qosQosTcHandle
	    qos.tx_bytes = stats.bytes;
	    qos.tx_packets = stats.packets;
	  }
	  else if (handle == qosOlsrTcHandle) { // qosOlsrTcHandle
	    olsr.tx_bytes = stats.bytes;
	    olsr.tx_packets = stats.packets;
	  }
	  else { // qosBeTcHandle
	    be.tx_bytes = stats.bytes;
	    be.tx_packets = stats.packets;
	  }
	}
      } // end for

    } // end for

    return 0;
  }

  virtual unsigned long getOlsrByteCount() {
    return olsr.tx_bytes;
  }

  virtual unsigned long getQosByteCount() {
    return qos.tx_bytes;
  }

  virtual unsigned long getBeByteCount() {
    return be.tx_bytes;
  }

  virtual unsigned long getOlsrPacketCount() {
    return olsr.tx_packets;
  }

  virtual unsigned long getQosPacketCount() {
    return qos.tx_packets;
  }

  virtual unsigned long getBePacketCount() {
    return be.tx_packets;
  }

  virtual unsigned long getByteCount()
  { 
    string data = getEthernetInfo();
    vector<string> infoSeq = stringSplit(data, " ");
    if (infoSeq.size() < 1)
      return 0;
    else return (unsigned long)atoll(infoSeq[0].c_str()); // XXX: gnu extension
  }

  virtual unsigned long getPacketCount()
  { 
    string data = getEthernetInfo();
    vector<string> infoSeq = stringSplit(data, " ");
    if (infoSeq.size() < 2) return 0;
    else return (unsigned long)atoll(infoSeq[1].c_str()); // XXX: gnu extension
  }

  // XXX: this information could be put in a cache
  string getEthernetInfo()
  {
    FILE* f = fopen("/proc/net/dev", "r");
    if (f == NULL) {
      Warn("Cannot open '/proc/net/dev'" << strerror(errno));
      return "";
    }
    while (!feof(f) && !ferror(f)) {
#if 0
      char* line = NULL;
      size_t lineSize;
      if (getline(&line, &lineSize, f) >=0 ) { // GNU extension
      } ///
#endif
      size_t lineSize = 2048;
      char line[lineSize];
      if (fgets(line, lineSize, f) != NULL) {
	string result = line;
	//free(line);
	if (result.find(ifaceName) != string::npos ) {
	  string::size_type pos = result.find(":");
	  if (pos != string::npos) {
	    fclose(f);
	    return result.substr(pos+1, string::npos);
	  }
	}
      }
    }
    fclose(f);
    return "";
  }

  virtual ~LinuxPacketCounter() {}
protected:

  int read_sock(int sockfd, char * buf, unsigned int seqnum, int pid) {

    unsigned int readlen, msglen;
    struct nlmsghdr * nlh;

    readlen = 0;
    msglen = 0;
    do{
      if((readlen = recv(sockfd, buf, 8192 - msglen, 0)) < 0) {
	fprintf(stderr, "error reading rtnetlink socket\n");
	return -1;
      }
      nlh = (struct nlmsghdr*) buf;
      if((NLMSG_OK(nlh, readlen) == 0) || (nlh->nlmsg_type == NLMSG_ERROR)){
	fprintf(stderr, "error receiving rtnetlink socket\n");
	return -1;
      }
      if(nlh->nlmsg_type == NLMSG_DONE)
	break;
      else{
	buf    += readlen;
	msglen += readlen;
      }
    } while((nlh->nlmsg_seq != seqnum) || ((int)(nlh->nlmsg_pid) != pid));

    return msglen;
  }

  string ifaceName, tcLocation, syntaxTcCmd1, syntaxTcCmd2, syntaxTcCmd3;
  int qosQosTcHandle, qosOlsrTcHandle, qosBeTcHandle, oldBeRate;
  int ifIndex;

  struct _qdiscstat_t {
    int tx_bytes, tx_packets; // the only information that interest us
  };
  typedef struct _qdiscstat_t qdiscstat_t, *qdiscstat_pt;
  qdiscstat_t qos, olsr, be;
};
#endif //WITH_QOS

//---------------------------------------------------------------------------

template <class LowLevel>
class LinuxAddressFactory : public AddressFactory
{
public:

  typedef typename LowLevel::SystemAddress SystemAddress;

  LinuxAddressFactory() : AddressFactory(LowLevel::AddressSize)
  {}

  Address makeAddress(SystemAddress& systemAddress) 
  { return Address(this, LowLevel::systemAddressToRawAddress(systemAddress)); }

  void makeSystemAddress(Address address, SystemAddress& result)
  { LowLevel::rawAddressToSystemAddress(address.getRawAddress(), result); }

  virtual Address parseAddress(string textString) {
    SystemAddress systemAddress;
    LowLevel::strToAddress(systemAddress, textString);
    return makeAddress(systemAddress);
  }

  virtual void write(ostream& out, const Address& address)
  {
    typename LowLevel::SystemAddress systemAddress;
    LowLevel::rawAddressToSystemAddress(address.getRawAddress(),
					systemAddress);
    char strAddress[4096]; // XXX
    LowLevel::reprAddress(systemAddress, strAddress);
    out << strAddress;
  }
};

//---------------------------------------------------------------------------

template<class LowLevel>
class LinuxSystemIface : public ISystemIface, public IFdHandler
{
public:
  IOScheduler* scheduler;
  LinuxAddressFactory<LowLevel>* addressFactory;
  IPacketReceiver* packetReceiver;
  Address address;
  string strOutputAddress;
  unsigned int port;
  unsigned int recvPort;

  virtual ~LinuxSystemIface() { }

  LinuxSystemIface(string aIfaceName, Address aAddress, int aIfaceIndex,
		   IOScheduler* aScheduler,
		   LinuxAddressFactory<LowLevel>* aFactory,
		   string aStrOutputAddress, 
		   IfaceConfig* aIfaceConfig, 
		   unsigned int aPort);

#ifdef LINK_SIGNAL_MONITORING
  int getSignalLevel(Address txAddress);
#endif

#ifdef LINK_IWEVENT_MONITORING
  virtual int getSignalFileDescriptor() { return signalSocket; }
#endif

  virtual void openSocket(IPacketReceiver* aPacketReceiver);
  
  virtual void sendPacket(Address destinationAddress, MemoryBlock* packet);

  virtual int getMTU()
  { return ifaceConfig->mtu; }

  virtual Address getAddress()
  { return address; }

  virtual int getIndex()
  { return ifaceIndex; }

  virtual string getIfaceName() { return getName(); }

  // IFdHandler
  virtual FileDescriptor getFileDescriptor() { return inputSocket; }
  virtual bool waitingForInput() { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; } // XXX:  check
  virtual void handleInput();
  virtual void handleOutput() { Fatal("Impossible call to handleOutput"); }
  virtual void handleExcept() { Fatal("Impossible call to handleExcept"); }

  // borrowed
  string getName() { return name; }

public:
  int ifaceIndex;

protected:
  typename LowLevel::SystemAddress sendSystemAddress;
  int inputSocket;
  int outputSocket;
#ifdef LINK_MONITORING
  int signalSocket;
#endif
  string name; // system name of the interface
};

//---------------------------------------------------------------------------

extern ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig);
extern ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig);
extern void startHTTPServer(IOScheduler* scheduler, Node* node);

//---------------------------------------------------------------------------

#endif // _SYSTEM_LINUX_H
