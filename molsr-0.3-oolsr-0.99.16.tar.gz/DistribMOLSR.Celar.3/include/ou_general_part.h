//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file contains extracts of the file ou_general.h from libolsrutil
// and from the file ou_packet.h file:
/*---------------------------------------------------------------------------*
 *                             libolsrutil
 *               Cedric Adjih, projet Hipercom, INRIA Rocquencourt
 *  Copyright 2005 Institut National de Recherche en Informatique et
 *  en Automatique.  All rights reserved.  Distributed only with permission.
 *---------------------------------------------------------------------------*/

#ifndef _OU_GENERAL_PART_H
#define _OU_GENERAL_PART_H

/*---------------------------------------------------------------------------
 * Putting/getting data in network order
 *---------------------------------------------------------------------------*/

typedef unsigned char  ou_u8;
typedef unsigned short ou_u16;
typedef unsigned int   ou_u32;

#define GET_U8_AT(pointer, offset) \
    (((ou_u8*)(pointer))[offset])

#define GET_U16_AT(pointer, offset) \
    (ou_u32)( (GET_U8_AT(pointer,offset)<<8) \
               + GET_U8_AT(pointer,offset+1))

#define GET_U32_AT(pointer, offset) \
    (ou_u32)( (GET_U8_AT(pointer,offset)<<(3*8)) \
               + (GET_U8_AT(pointer,offset+1)<<(2*8)) \
               + (GET_U8_AT(pointer,offset+2)<<8) \
               + GET_U8_AT(pointer,offset+3))

#define GET_U8(pointer) (*(ou_u8*)(pointer))
#define GET_U16(pointer) GET_U16_AT(pointer,0)
#define GET_U32(pointer) GET_U32_AT(pointer,0)

#define SIZE_U8   1
#define SIZE_U16  2
#define SIZE_U32  4

  /*--------------------------------------------------*/

#define PUT_U8_AT(pointer, offset, value) \
     BeginMacro (((ou_u8*)(pointer))[offset]) = (value); EndMacro

#define PUT_U16_AT(pointer, offset, value) \
     BeginMacro \
         PUT_U8_AT(pointer, offset, ((value)>>8)&0xff); \
         PUT_U8_AT(pointer, offset+1, (value)&0xff); \
     EndMacro

#define PUT_U32_AT(pointer, offset, value) \
     BeginMacro \
         PUT_U8_AT(pointer, offset, ((value)>>(3*8))&0xff); \
         PUT_U8_AT(pointer, offset+1, ((value)>>(2*8))&0xff); \
         PUT_U8_AT(pointer, offset+2, ((value)>>8)&0xff); \
         PUT_U8_AT(pointer, offset+3, (value)&0xff); \
     EndMacro

//---------------------------------------------------------------------------
// Parts from "ou_packet.h"
//---------------------------------------------------------------------------

/*---------- Packet ----------*/

#define OLSR_PACKET_HEADER_SIZE 4
#define OLSR_OFFSET_PACKET_LENGTH 0
#define OLSR_OFFSET_PACKET_SEQUENCE_NUMBER 2

typedef struct {
  MemoryBlock  packet;
  MemoryBlock* message;
  int    nbMessage;
} PacketStructure;

/*
 * Return value:
 *   if there is no error:
 *     return the number of messages in the packet (>=0)
 *   if there is an error:
 *    -1 if packet too short
 *    -2 if packet length field value is greater than packet size
 *    -3 if message header of last message can't fit in packet
 *    -4 if last message (content) can't fit in packet
 *    -5 if extension block size can't fit message
 *    <other values> depending on parsing extension block
 */
int countMessageInPacket(int addressSize, MemoryBlock& packet);

/* Return value: same as countMessageInPacket */
int parsePacketStructure(int addressSize, MemoryBlock& content,
                         /*created*/ PacketStructure** result);

#define freePacketStructure(pointer) free(pointer)

/*--------------------------------------------------*/

#define OLSR_MESSAGE_HEADER_SIZE(addressSize) (8+(addressSize))
#define OLSR_OFFSET_MESSAGE_TYPE(addressSize) (0)
#define OLSR_OFFSET_VTIME(addressSize) (1)
#define OLSR_OFFSET_MESSAGE_SIZE(addressSize) (2)
#define OLSR_OFFSET_ORIGINATOR_ADDRESS(addressSize) (4)
#define OLSR_OFFSET_TIME_TO_LIVE(addressSize) (4+(addressSize))
#define OLSR_OFFSET_HOP_COUNT(addressSize) (5+(addressSize))
#define OLSR_OFFSET_MESSAGE_SEQUENCE_NUMBER(addressSize) (6+(addressSize))

/*--------------------------------------------------*/

//---------------------------------------------------------------------------

#endif /*_OU_GENERAL_PART_H*/
