//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Code developped for Mesh Point simulations for 802.11s
//---------------------------------------------------------------------------

#ifndef _NODE_AP_H
#define _NODE_AP_H

#include "node_inheritance.h"
#include "node.h"
#include "packet.h"

//---------------------------------------------------------------------------

#include <map>
#include <bitset>
using std::bitset;
using std::map;


//---------------------------------------------------------------------------

typedef unsigned short StationSeqNum;


const int MaxStationSeqNum = 1 << 16;

static inline bool isStationSeqNumGreater(StationSeqNum s1, StationSeqNum s2)
{ 
  return( ((s1>s2)&&((s1-s2)<=MaxStationSeqNum/2))
	  || ((s2>s1)&&((s2-s1)>MaxStationSeqNum/2)));
}

static inline 
bool isStationSeqNumGreaterOrEqual(StationSeqNum s1, StationSeqNum s2)
{ return s1==s2 || isStationSeqNumGreater(s1, s2); }

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

typedef unsigned short BlockChecksum;

//---------------------------------------------------------------------------

class LocalAssociationTuple;
class LocalAssociationBaseBlock;

class LocalAssociationTuple
{
public:
  LocalAssociationTuple(Address aAddress) 
    : LA_station_address(aAddress), LA_station_sequence_number(0), block(NULL) 
  {}

  Address       LA_station_address;
  StationSeqNum LA_station_sequence_number;

  LocalAssociationBaseBlock* block;

  virtual void write(ostream& out);
};

#define MAX_NB_BLOCK 16
#define MUTABLE_SET_MAX_SIZE 16
//#define 

//--------------------------------------------------

class AssociationBaseChecksum
{
public:
  typedef unsigned short ChecksumKey;

  ChecksumKey key;
  unsigned short nbBlock;
  BlockChecksum blockChecksum[MAX_NB_BLOCK];

  unsigned int getNetSize();

  void popFromBuffer(PacketBuffer& buffer);
  
  void packToBuffer(PacketBuffer& buffer);

  void write(ostream& out);
};

//--------------------------------------------------

class AssociationBase;
class AssociationBaseMessageHandler;
class LocalAssociationBase;
class MeshAPNode;

class LocalAssociationBaseBlock
{
public:
  //LocalAssociationBaseBlock(Node* aNode) : node(aNode) {}

  BlockChecksum getChecksum(AddressFactory* addressFactory, unsigned int key);

  void clear(AssociationBase* stationSet);

  void forget(LocalAssociationTuple* stationTuple)
  {
    unsigned int previousSize = associationList.size();
    associationList.remove(stationTuple);
    assert( previousSize == associationList.size()+1 ); // should be one&unique
  }

  void add(LocalAssociationTuple* stationTuple)
  { 
    associationList.push_back(stationTuple); 
    stationTuple->block = this;
  }

  int getIndex() { return LA_block_index; }
 
  list<LocalAssociationTuple*>& getStationList()
  { return associationList; }

  virtual void write(ostream& out);

  virtual ~LocalAssociationBaseBlock() { /* nothing to do */ }

  friend class AssociationBase;
  friend class LocalAssociationBase;
  friend class LocalAssociationTuple;
  friend class AssociationBaseMessageHandler;
  friend class MeshAPNode;

protected:
  list<LocalAssociationTuple*> associationList;
  int LA_block_index;
};


//--------------------------------------------------

class LocalAssociationBase;
class MeshAPNode;

// XXX: GlobalAssociationBase and LocalAssociationBase used to be derived
// from this one, but no longer, so it could be merged with 
// LocalAssociationBase

class AssociationBase
{
public:
  AssociationBase(Node* aNode) : node(aNode)
  {
    for(int i=0; i<MAX_NB_BLOCK; i++) {
      block[i].LA_block_index = i;
    }
  }

  AssociationBaseChecksum* getChecksum(unsigned short key);

  LocalAssociationTuple* findStationByAddress(Address address);

  virtual void write(ostream& out);

  LocalAssociationBaseBlock* getBlock(int blockIndex);

  void add(LocalAssociationTuple* stationTuple, int blockIndex);

  void disassociate(LocalAssociationTuple* stationTuple);

  void removeAndDelete(LocalAssociationTuple* stationTuple);

  int getMaxBlockIndex();

  virtual ~AssociationBase()
  { }
  
  friend class LocalAssociationBase;
  friend class MeshAPNode;

protected:
  int getNbBlock();

  Node* node;
  LocalAssociationBaseBlock block[MAX_NB_BLOCK];
  list<LocalAssociationTuple*> associationList;
};

//--------------------------------------------------

class MeshAPNode;

typedef pair<int, Time> BlockIndexAndTime;
typedef LocalAssociationTuple LocalAssociationTuple;

class LocalAssociationBase : public AssociationBase
{
public:
  LocalAssociationBase(Node* aNode)
    : AssociationBase(aNode),
      recordedRequest(MAX_NB_BLOCK, false)
  {}

  void performAssociateStation(Address stationAddress, 
			       StationSeqNum stationSeqNum);
  
  void performDisassociateStation(Address stationAddress);

  void recordRequest(int blockIndex);

  virtual void write(ostream& out);
    
  friend class MeshAPNode;

protected:
  //AddressMap<BlockIndexAndTime> recordedBlockIndexTable;
  vector<bool> recordedRequest;

  int _findBlockIndex();
};

//---------------------------------------------------------------------------

class GlobalAssociationTuple : public ITuple
{
public:
  GlobalAssociationTuple(Node* aNode) : GA_block_index(-1), node(aNode) {}

  int           GA_block_index;
  Address       GA_AP_address;
  Address       GA_station_address;
  StationSeqNum GA_station_sequence_number;
  Time          GA_expiration_time;

  virtual void update() 
  { /* nothing to do */ }

  virtual void write(ostream& out);

  virtual Time getExpireTime(Time currentTime) 
  { return GA_expiration_time; }

protected:
  Node* node;
};

class GlobalAssociationBase : public BasicTupleSet<GlobalAssociationTuple>
{
public:

  GlobalAssociationBase(Node* aNode) : node(aNode)
  {}

  GlobalAssociationTuple* getBestGlobalAssociation(Address stationAddress);

  GlobalAssociationTuple* findFirst_APAndStation(Address meshAPAddress,
						 Address stationAddress)
  { Search(GlobalAssociationTuple, 
	   current->GA_AP_address == meshAPAddress
	   && current->GA_station_address == stationAddress); }

  // BlockIndex == -1 means all the blocks
  void getByAPAddressBlockIndex(Address meshAPAddress, int blockIndex, 
				list<GlobalAssociationTuple*>& result)
  {
    BeginOptimizedSearch(GlobalAssociationTuple,) {
      if (current->GA_AP_address == meshAPAddress
	  && (blockIndex < 0 
	      || (current->GA_block_index == blockIndex)))
	result.push_back(current);
    } EndSearch();
  }

  virtual void write(ostream& out);

  virtual void notifyRemoval(GlobalAssociationTuple* tuple)
  { /* do nothing */ }

  virtual void notifyAddition(GlobalAssociationTuple* tuple)
  { /* do nothing */ }

protected:
  Node* node;
};

//---------------------------------------------------------------------------

typedef pair<int,StationSeqNum> BlockIndexAndSeqNum;

//---------------------------------------------------------------------------

class StationInfo
{
public:
  Address address;
  StationSeqNum stationSeqNum;

  void write(ostream& out);
};

class BlockInfo
{
public:
  int blockIndex;
  list<StationInfo> stationInfoList;
};

class LABAMessage : public IMessageContent
{
public:
  LABAMessage(AddressFactory* aAddressFactory)
    : addressFactory(aAddressFactory) {}
  
  virtual IMessageContent* clone();
  virtual void write(ostream& out) const;

  unsigned short  nbBlock;
  list<BlockInfo> blockInfoList;
protected:
  AddressFactory* addressFactory;
};

class LABAMessageHandler : public IMessageHandler
{
public:
  LABAMessageHandler(MeshAPNode* aNode) : node(aNode) {}
  virtual void processMessage(/*borrowed*/ Message* message);
  virtual void considerForwardMessage(/*borrowed*/ Message* message,
                                      string& info);
  virtual IMessageContent* parseMessageContent(Message* message);
  virtual void packMessageContent(IMessageContent* message,
                                  int maximumMessageSize,
                                  MemoryBlock*& packedResult,
                                  IMessageContent*& messageRemainingResult,
				  PackingInfo& packingInfo);
  virtual void adjustMessageSize(IMessageContent* message);

protected:
  MeshAPNode* node;
};

//---------------------------------------------------------------------------


class LABCAMessage : public IMessageContent
{
public:
  LABCAMessage(AddressFactory* aAddressFactory)
    : addressFactory(aAddressFactory) {}

  virtual IMessageContent* clone();
  virtual void write(ostream& out) const;

  vector<BlockChecksum> blockChecksumList;

protected:
  AddressFactory* addressFactory;
};

class LABCAMessageHandler : public IMessageHandler
{
public:
  LABCAMessageHandler(MeshAPNode* aNode) : node(aNode) {}
  virtual void processMessage(/*borrowed*/ Message* message);
  virtual void considerForwardMessage(/*borrowed*/ Message* message,
                                      string& info);
  virtual IMessageContent* parseMessageContent(Message* message);
  virtual void packMessageContent(IMessageContent* message,
                                  int maximumMessageSize,
                                  MemoryBlock*& packedResult,
                                  IMessageContent*& messageRemainingResult,
				  PackingInfo& packingInfo);
  virtual void adjustMessageSize(IMessageContent* message);

protected:
  MeshAPNode* node;
};

//---------------------------------------------------------------------------

class ABBRMessage : public IMessageContent
{
public:
  ABBRMessage(AddressFactory* aAddressFactory)
    : addressFactory(aAddressFactory) {}

  virtual IMessageContent* clone();
  virtual void write(ostream& out) const;

  Address   destinationAPAddress;
  Address   nextHopAddress; // (if broadcast, it is sender main address)
  list<int> blockIndexList;

protected:
  AddressFactory* addressFactory;
};

class ABBRMessageHandler : public IMessageHandler
{
public:
  ABBRMessageHandler(MeshAPNode* aNode) : node(aNode) {}
  virtual void processMessage(/*borrowed*/ Message* message);
  virtual void considerForwardMessage(/*borrowed*/ Message* message,
                                      string& info);
  virtual IMessageContent* parseMessageContent(Message* message);
  virtual void packMessageContent(IMessageContent* message,
                                  int maximumMessageSize,
                                  MemoryBlock*& packedResult,
                                  IMessageContent*& messageRemainingResult,
				  PackingInfo& packingInfo);
  virtual void adjustMessageSize(IMessageContent* message);

protected:
  MeshAPNode* node;
};

//---------------------------------------------------------------------------

class MeshAPNode : public ParentMeshAPNode
{
public:
  MeshAPNode();

  virtual void start(); // overrides Node::start

  void processLABAMessage(LABAMessage* labaMessage);
  void processLABCAMessage(LABCAMessage* labcaMessage);
  void processABBRMessage(ABBRMessage* labcaMessage);

  void performAssociateStation(Address stationAddress, 
			       StationSeqNum stationSeqNum);
  void performDisassociateStation(Address stationAddress);

  bool getAssociation(Address stationAddress,
		      Address& resultMeshAP,
		      StationSeqNum& resultStationSeqNum);
  
  virtual void logState(ostream& out, bool noEnd=false);

  void logAssociationTable(ostream& out);

  LocalAssociationBase* getLocalAssociationBase()
  { return &localAssociationBase; }

  virtual void getNextExpireTime(Time& nextExpireTime, bool& hasExpireTime);

protected:

#if 0
  void _reallyProcessAssociationBaseMessage(AssociationBaseMessage* message);

  void processAssociationBaseAdvertisementMessage(AssociationBaseMessage* message);
  void processAssociationBaseRequestMessage(AssociationBaseMessage* message);

  void recordRequest(Address originatorAddress, int blockIndex,
		     AssociationBaseSeqNum seqNum);



  void requestMissingBlock(Address meshAPAddress,
			    AssociationBaseChecksum* currentChecksum,
			    std::list<int>& blockIndexList,
			    bool hadAssociationBase);

  void sendAssociationBaseMessage(MessageType messageType,
			     Address originatorAddress,
			     Address destinationAddress,
			     AssociationBaseMessage* stationSetMessage,
			     int ttl, int hopCount);
#endif

  void sendLABCAMessage(int nbBlock);
  void sendLABAMessage(list<BlockInfo>& blockInfoList, int nbBlock);
  void sendABBRMessage(Address meshAPAddress, list<int>& blockIndexList);

  void notifyEndProcessABBRMessage(Address originatorAddress);

  void startLocalAssociationBaseAdvertisement();

  void notifyBlockChange(int blockIndex, bool isAssociation);

  virtual void eventLABGeneration();

  void updateAssociationTable(); 

  virtual void performTupleExpiration();

public: // public = XXX!! hack, remove
  GlobalAssociationBase globalAssociationBase;
  LocalAssociationBase localAssociationBase;
  //int noLABGenerationCount;

protected:
  map<int, bool> isBlockChanged;
  list<int> blockChangeCountList;
  list<int> blockRequestCountList;
  int blockChangeCount;
  int blockRequestCount;
  bool fullMode;
};

//---------------------------------------------------------------------------

static inline ostream& operator << (ostream& out, AssociationBase& o)
{ o.write(out); return out; }

static inline ostream& operator << (ostream& out, LocalAssociationBase& o)
{ o.write(out); return out; }

static inline ostream& operator << (ostream& out, LocalAssociationTuple& o)
{ o.write(out); return out; }

static inline ostream& operator << (ostream& out, LABAMessage& o)
{ o.write(out); return out; }

static inline ostream& operator << (ostream& out, AssociationBaseChecksum& o)
{ o.write(out); return out; }

static inline ostream& operator << (ostream& out, LocalAssociationBaseBlock& o)
{ o.write(out); return out; }

//---------------------------------------------------------------------------

string getAssociationStat();

//---------------------------------------------------------------------------

#endif //_NODE_AP_H
