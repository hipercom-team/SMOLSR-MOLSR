//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004-2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _STATISTIC_H
#define _STATISTIC_H

//---------------------------------------------------------------------------

#include "tuple.h"

//---------------------------------------------------------------------------

class SimpleStat
{
public:
  SimpleStat() : total(0.0), count(0) {}
  void add(double value, double aCount = 1.0)
  { total += value; count += aCount; }
  
  double total;
  double count;
};

//---------------------------------------------------------------------------

class TimeAverageStat
{
public:
  TimeAverageStat() :  total(0.0), totalTime(0.0), hasLastValue(false) { }

  void addStat(double currentTime, double value) {
    if (!hasLastValue)
      firstTime = currentTime;
    _update(currentTime);

    if (!hasValue) {
      minValue = value;
      maxValue = value;
    }
    minValue = myMin(value, minValue);
    maxValue = myMax(value, maxValue);
    hasValue = true;

    lastValue = value;
    hasLastValue = true;
  }


  void switchOff(double currentTime)
  {
    _update(currentTime);
    hasLastValue = false;
  }

  void _update(double currentTime) {
    if (hasLastValue) {
      total += (currentTime - lastTime) * lastValue;
      totalTime += (currentTime - lastTime);
    }
    lastTime = currentTime;
  }

  double getMean(double currentTime)
  { 
    _update(currentTime);
    if (totalTime > 0.0) {
      return total / totalTime;
    } else return 0.0;
  }
  
  double total;
  double totalTime;
  double lastValue;
  double lastTime;
  double firstTime;
  bool hasLastValue;
  bool hasValue;
  double minValue;
  double maxValue;
};

//---------------------------------------------------------------------------

class StatisticTuple : public ITuple
{
public:
  Address      S_main_addr;
  Time         S_time;

  SimpleStat   tcCount;
  SimpleStat   helloCount;
  SimpleStat   packetCount;
  TimeAverageStat routeAvailability;
  TimeAverageStat routeLength;

  StatisticTuple(Node* aNode) : node(aNode) {}

  virtual Time getExpireTime(Time currentTime) { return TimeNever; }
  virtual void update() { /* nothing to do */ }
protected:
  Node* node;
};

class StatisticSet : public BasicTupleSet<StatisticTuple>
{
public:
  StatisticSet(Node* aNode);

  StatisticTuple* findFirst_MainAddr(Address mainAddress)
  { Search(StatisticTuple, current->S_main_addr == mainAddress); }

  virtual void write(ostream& out)
  { out << "<StatisticSet>"; }

  StatisticTuple* ensure(Address address);

protected:
  Time creationTime;
  Node* node;
  virtual void notifyRemoval(StatisticTuple* tuple);
  virtual void notifyAddition(StatisticTuple* tuple);
};


//---------------------------------------------------------------------------

#endif // _STATISTIC_H
