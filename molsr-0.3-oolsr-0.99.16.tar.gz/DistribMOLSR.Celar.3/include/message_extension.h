//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//            Geraud Allard, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _MESSAGE_EXTENSION_H
#define _MESSAGE_EXTENSION_H

//---------------------------------------------------------------------------

#include "ou_general_part.h"

//---------------------------------------------------------------------------

typedef MemoryBlock Block;

inline Block* clone(Block* data)
{ return new Block(data->data, data->size, true); }

//---------------------------------------------------------------------------
// Note:
//  Was:  an attempt to use more C++ data structures: Block could replace
// MemoryBlock in most of OOLSR in the future
// NOTE: because this Block::data() return a const, it is not stl-ly correct
// to use it as a MemoryBlock where the content is changed :-(
//
//typedef basic_string<Octet> Block;
//
//inline Block* clone(Block* data)
//{ return new Block(data->data(), data->size()); }
//
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

class ITLV;

// PacketManager (or Node) will probably implement this:
class ITLVManager
{
public:
  // unpack a TLV: if the TLV cannot be unpacked, return a clone,
  // otherwise return the unpacked TLV
  virtual ITLV* unpackTLV(/*borrowed*/ ITLV& aTLV);
};

//---------------------------------------------------------------------------

typedef unsigned int TLVType;

class ITLV
{
public:
  virtual TLVType getType() = 0;
  virtual int getLength() = 0; // length of the content
  virtual Block* getPackedValue() = 0; // as a string of bytes
  virtual ITLV* clone() = 0;
  virtual ~ITLV() {}
  virtual bool isPackedTLV() { return false; } // template method
};

// A basic TLV - a block of bytes
class IRawTLV : public ITLV
{
public:
  IRawTLV(TLVType aType, /*owned*/ Block* aBlock) 
    : type(aType), data(aBlock) { }
  virtual TLVType getType() { return type; }
  virtual int getLength() { return data->size; }
  virtual Block* getPackedValue() { return ::clone(data); }
  virtual IRawTLV* clone()
  { return new IRawTLV(type, ::clone(data)); }
  virtual ~IRawTLV() { delete data; }

protected:
  TLVType type;
  Block* data;
};

// A semi-basic TLV:
class IPackedTLV : public IRawTLV
{
public:
  IPackedTLV(TLVType aType, /*owned*/ Block* aBlock) : IRawTLV(aType, aBlock) 
  { }

  virtual ~IPackedTLV()
  { }

  virtual bool isPacketTLV()
  { return true; }
};

#if 0
// XXX: remove, now using   tlv->isPackedTLV()

inline bool isPackedTLV(ITLV* tlv)
{ 
  IPackedTLV* packedTLV = dynamic_cast<IPackedTLV*>(tlv);
  return packedTLV != NULL;
}
#endif

//--------------------------------------------------

// A TLV with as any fixed-size structure, with packing/unpacking 
// functions defined as:
//   TLVHelper::getLength();
//   TLVHelper::pack(Value& value, void* result);
//   TLVHelper::unpack(void* data, Value& result);
template<class BasicTLVHelper>
class IBasicTLV : public ITLV
{
public:
  typedef typename BasicTLVHelper::Value Value;

  IBasicTLV(TLVType aType, Value aValue) 
    : type(aType), value(aValue) { }

  virtual TLVType getType() { return type; }
  virtual int getLength() { return BasicTLVHelper::getLength(); }
  virtual Block* getPackedValue()
  {
    MemoryBlock* result = new Block(getLength());
    BasicTLVHelper::pack(value, result->data);
    return result;
  }
  virtual IBasicTLV* clone()
  { return new IBasicTLV(type, value); }

  virtual ~IBasicTLV() { }
protected:
  TLVType type;
  Value value;
};

//--------------------

class UInt32TLVHelper
{
public:
  typedef unsigned int Value;
  static int getLength() { return SIZE_U32; }
  static void pack(Value& value, void* result) { PUT_U32_AT(result, 0, value);}
  static void unpack(Value& value, void* result) { value = GET_U32(result); }
};

typedef IBasicTLV<UInt32TLVHelper> U32TLV;

//--------------------

class UInt16TLVHelper
{
public:
  typedef unsigned short int Value;
  static int getLength() { return SIZE_U16; }
  static void pack(Value value, void* result) { PUT_U16_AT(result, 0, value); }
  static void unpack(Value& value, void* result) { value = GET_U16(result); }
};

typedef IBasicTLV<UInt16TLVHelper> U16TLV;

//--------------------

class UInt8TLVHelper
{
public:
  typedef unsigned char Value;
  static int getLength() { return SIZE_U8; }
  static void pack(Value value, void* result) { PUT_U8_AT(result, 0, value); }
  static void unpack(Value& value, void* result) { value = GET_U8(result); }
};

typedef IBasicTLV<UInt8TLVHelper> U8TLV;

//---------------------------------------------------------------------------
// The set of TLV of a message
//---------------------------------------------------------------------------

//#define MAX_TLV_TYPE (0x100)

class MessageTLVSet
{
public:
  void addTLV(ITLV* tlv) 
  { tlvList.push_back(tlv); }

  MessageTLVSet* clone()
  { Fatal("XXX: not implemented yet"); return NULL; }

  virtual ~MessageTLVSet()
  { Fatal("unimplemented, should delete tlvList"); }

protected:
  list<ITLV*> tlvList;
};


//---------------------------------------------------------------------------
// 
//---------------------------------------------------------------------------

class AddressAndTLV
{
public:
  AddressAndTLV() : tlv(NULL) {}
  AddressAndTLV(Address anAddress, /*owned*/ITLV* aTLV) : tlv(aTLV) 
  { address = anAddress; }
  ~AddressAndTLV()
  { delete tlv; }

  Address address;
  ITLV* tlv;
};

class MessageWithTLV : public IMessageContent
{
public:
  
  // For Message TLVs
  void addTLV(Address anAddress, ITLV* aTLV);

  virtual IMessageContent *clone()
  { Fatal("XXX: unimplemented"); }

  virtual void write(std::ostream&) const
  { Fatal("XXX: unimplemented"); }

  // 
  void merge(MessageWithTLV* otherMessage); // XXX: should be done by handler

protected:
  list< AddressAndTLV > tlvList;
};

//---------------------------------------------------------------------------

class MessageWithTLVHandler : public IMessageHandler
{
public:
  //PacketManager* packetManager;
  //IMessageHandler* handler;
  Node* node;
  
  MessageWithTLVHandler(Node* aNode);

  //--------------------------------------------------
  // IMessageHandler methods
  //--------------------------------------------------

  // this method should process a message iff all fragments have been obtained
  //   it will call reallyProcessMessage(...) after packing TLV
  virtual void processMessage(/*borrowed*/ Message* message)
  { Fatal("XXX: unimplemented"); }

  virtual void considerForwardMessage(/*borrowed*/ Message* message,
				      string& info)
  { Fatal("XXX: unimplemented"); }

  virtual void packMessageContent(IMessageContent* message,
				  int maximumMessageSize,
				  MemoryBlock*& packedResult,
				  IMessageContent*& messageRemainingResult)
  { Fatal("XXX: unimplemented"); }

  virtual void adjustMessageSize(IMessageContent* message)
  { Fatal("XXX: unimplemented"); }

  // XXX: should this be private?
  virtual IMessageContent* parseMessageContent(Message* message)
  { Fatal("XXX: unimplemented"); }
  
  //--------------------------------------------------
  // Proper method: this template method call the node processing
  //--------------------------------------------------

  virtual void reallyProcessMessage(Message& message) = 0;

  //virtual bool hasTLV() { return true; } // XXX: remove, looks strange

protected:
};

//---------------------------------------------------------------------------

#endif // _MESSAGE_EXTENSION_H
