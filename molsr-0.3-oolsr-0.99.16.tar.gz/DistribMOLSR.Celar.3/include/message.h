//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _MESSAGE_H
#define _MESSAGE_H

//---------------------------------------------------------------------------

#include "protocol_tuple.h"

//---------------------------------------------------------------------------

static inline NeighborType linkCodeToNeighborType(int linkCode)
{ 
  assert( inrange(0, linkCode, LinkCodeLimit) ); 
  return (NeighborType)(linkCode >> 2); 
} // @@1620

static inline LinkType linkCodeToLinkType(int linkCode)
{ 
  assert( inrange(0, linkCode, LinkCodeLimit) ); 
  return (LinkType)(linkCode & 3); 
} // @@1620

static inline int linkAndNeighborToCode(LinkType linkType,
					NeighborType neighborType)
{ 
  assert( validLinkType(linkType) );
  assert( validNeighborType(neighborType) );
  return ((int)linkType) | (((int)neighborType) << 2); 
}

typedef enum {
  WILL_NEVER = 0,   // @@3657
  WILL_LOW = 1,     // @@3659
  WILL_DEFAULT = 3, // @@3661
  WILL_HIGH = 6,    // @@3663
  WILL_ALWAYS = 7   // @@3665
} Willingness;


typedef enum {
  TC_REDUNDANCY_BASIC = 0,   // @@3317 
  TC_REDUNDANCY_EXTENDED = 1,// @@3321
  TC_REDUNDANCY_FULL = 2     // @@3325
} TC_redundancy;

const double HYST_THRESHOLD_HIGH = 0.8;
const double HYST_THRESHOLD_LOW  = 0.3;
const double HYST_SCALING = 0.5;

//---------------------------------------------------------------------------

const double DefaultFreeSpaceSplittingProportionLimit = 0.3; // 30%

const double DefaultLocalSplittingProportionLimit = 0.1;     // 10%
  
const double DefaultGlobalSplittingProportionLimit = 0.5;    // 50%

//---------------------------------------------------------------------------

class LinkEntry
{
public:
  LinkType     linkType;
  NeighborType neighborType;
  Address      address;
};

const int HelloHeaderSize = 4; // @@1523
const int HelloLinkMessageHeaderSize = 4; // @@1525

class HelloMessage : public IMessageContent
{
public:
  int reserved;
  int htime;
  int willingness;
  std::list<LinkEntry> linkList; /// (owned) the list of link entries

  /// Makes a copy of the message.
  virtual IMessageContent* clone()
  { 
    HelloMessage* result = new HelloMessage;
    result->reserved = reserved;
    result->htime = htime;
    result->willingness = willingness;
    result->header = header->clone(false); 
    result->header->content = result;
    std::insert_iterator< std::list<LinkEntry> > ii(result->linkList,
						    result->linkList.begin());
    std::copy(linkList.begin(), linkList.end(), ii);
    return result;
  }

  /// Write the message content
  virtual void write(ostream& out) const
  {
    out << "hello reserved=" << reserved << " htime="
	<< fromMantissaExponentByte(htime) << "(" << htime << ")"
	<< " willing=" << willingness << " link=";
    for(std::list<LinkEntry>::const_iterator it = linkList.begin();
	it != linkList.end(); it++) {
      if (it != linkList.begin()) out << ",";
      out << neighborTypeToString((*it).neighborType) << "+" 
          << linkTypeToString((*it).linkType)
	  << ":" << (*it).address;
    }
  }

  void addLinkEntry(LinkType linkType, NeighborType neighborType,
		    Address address)
  {
    LinkEntry linkEntry;
    linkEntry.linkType = linkType;
    linkEntry.neighborType = neighborType;
    linkEntry.address = address;
    linkList.push_back(linkEntry);
  }
};

class Node;

class HelloMessageHandler : public IMessageHandler
{
public:
  HelloMessageHandler(Node* aNode) : node(aNode) {}

  virtual void processMessage(Message* message);

  virtual void considerForwardMessage(Message* message, string& info)
  { /* no forwarding - @@1803-1807 */ } 

  virtual IMessageContent* parseMessageContent(Message* message);

  int internalGetMessageSize(HelloMessage* m, 
			     std::list<Address>* resultList=NULL);

  virtual void packMessageContent(IMessageContent* message, 
				  int maximumMessageSize,
				  MemoryBlock*& messageResult,
				  IMessageContent*& messageRemainingResult,
				  PackingInfo& packingInfo);

  virtual void adjustMessageSize(IMessageContent* message);

  virtual ~HelloMessageHandler() { }

protected:
  Node* node;
};

//---------------------------------------------------------------------------

class MIDMessage : public IMessageContent
{
public:
  std::list<Address> addressList; /// (owned) a list of addresses

  virtual IMessageContent* clone()
  {
    MIDMessage* result = new MIDMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    std::insert_iterator< std::list<Address> > ii(result->addressList,
						  result->addressList.begin());
    std::copy(addressList.begin(), addressList.end(), ii);
    return result;
  }

  /// Write the message content
  virtual void write(ostream& out) const
  {
    out << "mid "
	<< " address=";
    for(std::list<Address>::const_iterator it = addressList.begin();
	it != addressList.end(); it++) {
      if (it != addressList.begin()) out << ",";
      out << (*it);
    }
  }
};

//---------------------------------------------------------------------------

const int TCHeaderSize = 4; // @@XXX

class TCMessage : public IMessageContent
{
public:
  unsigned int ansn;
  unsigned int reserved;
  std::list<Address> addressList; /// (owned) a list of addresses

  void clearList() { addressList.clear(); }

  virtual IMessageContent* clone()
  {
    TCMessage* result = new TCMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    result->ansn = ansn;
    result->reserved = reserved;
    std::insert_iterator< std::list<Address> > ii(result->addressList,
						  result->addressList.begin());
    std::copy(addressList.begin(), addressList.end(), ii);
    return result;
  }

  /// Write the message content
  virtual void write(ostream& out) const
  {
    out << "tc ansn=" << ansn << " reserved=" << reserved
	<< " address=";
    for(std::list<Address>::const_iterator it = addressList.begin();
	it != addressList.end(); it++) {
      if (it != addressList.begin()) out << ",";
      out << (*it);
    }
  }
};

class TCSpecification
{
public:
  typedef TCMessage MessageContent;
  typedef Address MessageItem;
  static int getContentHeaderSize(int addressSize) { return TCHeaderSize; }
  static int getItemSize(int addressSize) { return addressSize; }
  static void process(Node* node, MessageContent* m);
  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer)
  {
    result->ansn = buffer.popUInt16();
    result->reserved = buffer.popUInt16();
  }
  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { result->addressList.push_back( buffer.popAddress() ); }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer)
  {
    buffer.pushUInt16(m->ansn); // @@XXX
    buffer.pushUInt16(m->reserved); // @@XXX
  }
  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { buffer.packAddress(item); }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->addressList; }
};

typedef GenericMessageHandler<TCSpecification> TCMessageHandler;

//---------------------------------------------------------------------------
// MID Messages
//---------------------------------------------------------------------------

class MIDSpecification
{
public:
  typedef MIDMessage MessageContent;
  typedef Address MessageItem;
  static int getContentHeaderSize(int addressSize) { return 0; }
  static int getItemSize(int addressSize) { return addressSize; }
  static void process(Node* node, MessageContent* m);
  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer) { }
  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { result->addressList.push_back( buffer.popAddress() ); }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer) { }
  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { buffer.packAddress(item); }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->addressList; }
};

typedef GenericMessageHandler<MIDSpecification> MIDMessageHandler;

//---------------------------------------------------------------------------
// HNA Messages
//---------------------------------------------------------------------------

class HNAEntry
{
public:
  Address address;
  Address addressMask;
};

class HNAMessage : public IMessageContent
{
public:
  std::list<HNAEntry> hnaEntryList; /// (owned) a list of addresses


  virtual IMessageContent* clone()
  {
    HNAMessage* result = new HNAMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    std::insert_iterator< std::list<HNAEntry> > 
      it(result->hnaEntryList, result->hnaEntryList.begin());
    std::copy(hnaEntryList.begin(), hnaEntryList.end(), it);
    return result;
  }

  /// Write the message content
  virtual void write(ostream& out) const
  {
    out << "hna address=";
    for(std::list<HNAEntry>::const_iterator it = hnaEntryList.begin();
	it != hnaEntryList.end(); it++) {
      if (it != hnaEntryList.begin()) out << ",";
      out << (*it).address << "/" << (*it).addressMask;
    }
  }
};

class HNASpecification
{
public:
  typedef HNAMessage MessageContent;
  typedef HNAEntry MessageItem;
  static int getContentHeaderSize(int addressSize) { return 0; }
  static int getItemSize(int addressSize) { return 2*addressSize; }
  static void process(Node* node, MessageContent* m);
  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer) { }

  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { 
    HNAEntry entry;
    entry.address = buffer.popAddress();
    entry.addressMask = buffer.popAddress();
    result->hnaEntryList.push_back( entry ); 
  }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer) { }
  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { 
    buffer.packAddress(item.address); 
    buffer.packAddress(item.addressMask); 
  }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->hnaEntryList; }
};

typedef GenericMessageHandler<HNASpecification> HNAMessageHandler;

//---------------------------------------------------------------------------

#endif // _MESSAGE_H
