//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _GENERAL_H
#define _GENERAL_H

//---------------------------------------------------------------------------

#include "base.h"

#include <assert.h>
#include <stdio.h>

#include <cstdlib>
#include <string>
#include "mystream.h"
#include <vector>
#include <list>
#include <map>

using std::string;
using std::vector;
using std::list;

//---------------------------------------------------------------------------
//
/// General: 
/// - owning one reference, indicated by /* owned */,
///    means that the reference belongs to the caller
/// - borrowing one reference, indicated by /* borrowed */,
///    means that the reference belongs to the callee, and
///    hence must be freed
/// - Some interfaces, like ISystemFactory, are (more or less) pure
/// abstract interface: their name is prefixed by "I".
//---------------------------------------------------------------------------

// because VC++6 doesn't have std::min
template <class T>
T myMin(T x, T y)
{ if (x<y) return x; else return y; }

template <class T>
T myMax(T x, T y)
{ if (x>y) return x; else return y; }

//---------------------------------------------------------------------------

#define ITER(type,it,data) \
  type::iterator it = (data).begin() ; it != (data).end(); it++


//---------------------------------------------------------------------------

extern string strReplace(string data, string before, string after);
extern string format3UInt(void* data);

//---------------------------------------------------------------------------

/// The type used to represent time in the system.
typedef double Time;

// The constant used to represent a time which will never happen.

const double TimeNever = 1e100;
const double TimeFutureNever = TimeNever;
const double TimePastNever = - TimeFutureNever;

typedef unsigned char octet;

/// A block of memory
class MemoryBlock
{
public:
  octet* data;
  int size;

  MemoryBlock(octet* initialData, int initialSize, bool shouldCopy)
  { 
    size = initialSize; 
    if (shouldCopy) {
      data = new octet[size];
      memcpy(data, initialData, size);
    } else data = initialData;
  }

  MemoryBlock(int initialSize);
  MemoryBlock* clone();
  ~MemoryBlock();
};

ostream& operator << (ostream& out, MemoryBlock& block);

/// Converts a Time into a byte holding mantissa/exponent, as
/// used in Vtime
int toMantissaExponentByte(Time value);

/// Converts a byte holding mantissa/exponent, as used in Vtime, into
/// a Time.
Time fromMantissaExponentByte(int valueAsByte);

//---------------------------------------------------------------------------

template <typename T>
static inline bool inrange(const T& minInclVal, T& val, const T& maxExclVal)
{ return (minInclVal <= val) && (val < maxExclVal); }


//---------------------------------------------------------------------------

#define BeginMacro do {
#define EndMacro } while(0)

#define UNUSED(x) BeginMacro (x)=(x); EndMacro

//---------------------------------------------------------------------------

extern ostream* createLogFile(string fileTemplate, string infix);

//---------------------------------------------------------------------------

extern bool stringStartsWith(string a, string b);
extern bool stringEndsWith(string a, string b);
extern string strReplace(string data, string before, string after);
//extern string stringReplace(const string& aLine, const string& before, 
//			    const string& after);
extern vector<string> stringSplit(string aLine, string charSet);

extern string stringBitAnd(string a, string b);
extern string stringBitNot(string a);
extern string makeStringBitMaskNetworkOrder(int size, int prefix);
extern string stringStrip(string a, string charSet);
extern string stringLower(string a);

//---------------------------------------------------------------------------

//extern double drawRandomDouble();

extern double drawDouble(double maxValue);

extern double getTimeOfDay();

//---------------------------------------------------------------------------
// defined in md5sum.cc, not general.cc:

extern string getMD5(string data);
extern string getHexMD5(string data);
extern string asHex(string data);

//---------------------------------------------------------------------------

#ifdef UNDER_CE
#define errno  (WSAGetLastError())
extern char* strerror(int errorCode);
#endif

//---------------------------------------------------------------------------

extern void* opaqueMakeResult
(list<string>& resultList,
 int* resultCount, void*** resultData, int** resultSize);

extern void* errorBadNbArg(char* prefix, int expected, int actual);

//---------------------------------------------------------------------------

void writeExpireTime(ostream& out, Time currentTime, Time expireTime);
void writeRelativeExpireTime(ostream& out, Time currentTime, Time expireTime);

//---------------------------------------------------------------------------

extern string getBufferAndDelete(ostringstream* out);

#define Repr(args) \
  (getBufferAndDelete(dynamic_cast<ostringstream*> \
		     (&  ((*(new ostringstream)) << args))  ))

//---------------------------------------------------------------------------
// Those are defined in mt19937ar.cc

#ifdef NEWRAND
extern void init_genrand(unsigned long s);

/* initialize by an array with array-length */
/* init_key is the array for initializing keys */
/* key_length is its length */
extern void init_by_array(unsigned long init_key[], int key_length);

/* generates a random number on [0,0x7fffffff]-interval */
extern unsigned long genrand_int32(void);

/* generates a random number on [0,1]-real-interval */
extern double genrand_real1(void);

/* generates a random number on [0,1)-real-interval */
extern double genrand_real2(void);
#endif

//---------------------------------------------------------------------------

#define StrFloatPrecision (10)

//---------------------------------------------------------------------------

extern bool strToInt(string value, int& result);
extern void setBit(void* data, int bitIndex, int value);
extern int getBit(void* data, int bitIndex);
extern void setSuffixBitToRandom(void* data, int size, int prefixSize);
extern void setSuffixBitTo(void* data, int size, int prefixSize, int value);

//---------------------------------------------------------------------------

extern bool writeFile(string fileName, string data, string& strError);
extern bool readFile(string fileName, string& resultData, string& strError);

//---------------------------------------------------------------------------

//XXX: check the semantics of "static inline"
static inline list<string>& operator << (list<string>& stringList,
					 const string& additionalString)
{
  stringList.push_back(additionalString);
  return stringList;
}

static inline list<string>& operator << (list<string>& stringList,
					 const char* additionalString)
{
  string tmp = additionalString;
  stringList.push_back(tmp);
  return stringList;
}

string reprStr(string data, int blockSize=1);

//---------------------------------------------------------------------------

template <class Key, class Value>
class ExpiringMap
{
public:

  class TimeAndValue {
  public:
    double expireTime;
    Value value;
  };

  class ExpireKeyValue {
  public:
    double expireTime;
    Key key;
    Value value;
  };

  ExpiringMap(double aCheckInterval)
    : checkInterval(aCheckInterval), lastTimeCheck(-1)
  { }


  virtual ~ExpiringMap() { }

  void refresh(double expireTime, const Key& key)
  { content[key].expireTime = expireTime; }

  bool hasKey(const Key key)
  { return content.find(key) != content.end(); }

  void set(double expireTime, Key& key, Value& value)
  {
    TimeAndValue current;
    current.expireTime = expireTime;
    current.value = value;
    content[key] = current;
  }

  Value* get(Key& key)
  { 
    typename std::map<Key, TimeAndValue>::iterator it = content.find(key);
    if (it != content.end())
      return &((*it).second.value); // XXX: check this is not ref to a tempor.
    else return NULL;
  }

  void expire(double currentTime)
  {
    //XXX:remove: typedef std::map<Key, TimeAndValue> Map;
    //typename Map::iterator it;
    if (lastTimeCheck == -1 || currentTime > lastTimeCheck + checkInterval) {
      lastTimeCheck = currentTime;
      std::list<Key> oldKeyList;

      for (typename std::map<Key, TimeAndValue>::iterator it = content.begin();
	   it != content.end(); it++) {
	if ((*it).second.expireTime < currentTime)
	  oldKeyList.push_back((*it).first);
      }
      for (typename std::list<Key>::iterator it = oldKeyList.begin();
	   it != oldKeyList.end(); it++) {
	notifyDelete(*it);
	content.erase(*it);
      }
    }
  }

  // Template method
  virtual void notifyDelete(Key& key)
  { /* do nothing */ }

  //std::map<Key, TimeAndValue>& getContent() { return content; }

  void getContent(std::list< std::pair<Key, Time> >& resultList)
  {
    for (typename std::map<Key, TimeAndValue>::iterator it = content.begin();
	 it != content.end(); it++) {
      std::pair<Key, Time> info( (*it).first, (*it).second.expireTime);
      resultList.push_back(info);
    }
  }

  void getContent(std::list< ExpireKeyValue >& resultList)
  {
    for (typename std::map<Key, TimeAndValue>::iterator it = content.begin();
	 it != content.end(); it++) {
      ExpireKeyValue info;
      info.expireTime = (*it).second.expireTime;
      info.key = (*it).first;
      info.value = (*it).second.value;
      resultList.push_back(info);
    }
  }


protected:
  std::map<Key, TimeAndValue> content;
  double checkInterval;
  double lastTimeCheck;
};

//---------------------------------------------------------------------------

extern string readFile(string fileName);

//---------------------------------------------------------------------------

#ifdef SYSTEMlinux
#include <unistd.h>
#include <signal.h> // XXX!!
#endif

#ifdef SYSTEMlinux
static inline void breakpoint()
{ kill(getpid(), SIGSTOP); }

#else

static inline void breakpoint()
{ Warn("breakpoint not implemented"); }

#endif

//---------------------------------------------------------------------------

#endif // _GENERAL_H
