//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _OLSR_CONFIG_H
#define _OLSR_CONFIG_H

//---------------------------------------------------------------------------

#include "base.h"
#include "general.h"
#include "gen_protocol_config.h"

//---------------------------------------------------------------------------

/// The configuration of the protocol itself (independently of system)
class ProtocolConfig : public GeneratedProtocolConfig
{
public:
  // (nearly everything is in GeneratedProtocolConfig)

  ProtocolConfig() //: mainIface("") 
  {}

  //string mainIface;
};

//--------------------------------------------------

typedef GeneratedIfaceConfig IfaceConfig;

static inline ostream& 
operator << (ostream& out, const GeneratedProtocolConfig& config)
{ config.write(out); return out; }

static inline ostream& 
operator << (ostream& out, const GeneratedIfaceConfig& config)
{ config.write(out); return out; }

//--------------------------------------------------

class Log;

class ConfigParser
{
public:  
  void parseArgList(GeneratedProtocolConfig& baseConfig, Log& log,
		    char** argv, int argc); // (prog name should be removed)
  void parse(GeneratedProtocolConfig& baseConfig, Log& log, string& data);
  void parseLine(GeneratedProtocolConfig& baseConfig, Log& log, string& line);
  void parseFile(GeneratedProtocolConfig& baseConfig, 
		 Log& log, string fileName);

  string currentFileName;
  int currentLineNumber;
};

//---------------------------------------------------------------------------

#endif // _OLSR_CONFIG_H
