//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _QOS_FLOW_H
#define _QOS_FLOW_H

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
// Documentation: format of the packed qosFlowTable
// see written documentation.
//---------------------------------------------------------------------------

#endif // _QOS_FLOW_H
