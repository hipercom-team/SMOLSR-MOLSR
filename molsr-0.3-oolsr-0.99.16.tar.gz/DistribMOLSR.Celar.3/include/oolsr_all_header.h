//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//---------------------------------------------------------------------------
// This file includes all the headers of the OOLSR source files
//---------------------------------------------------------------------------

#ifndef _OOLSR_ALL_HEADER_H
#define _OOLSR_ALL_HEADER_H

//---------------------------------------------------------------------------

#ifndef SYSTEMlinux
#define SYSTEMopnet // XXX this should be defined in including files.
#endif

//--------------------------------------------------
// Configuration of OOLSR (defined in Makefile.private.template)

#ifndef MPR_OPT // XXX this should be defined in config file
#define MPR_OPT
#define MORE_OPT
#define WITH_MULTICAST_ENCAPSULATION
#define REPR_ROUTE_LAST_HOP
#define ASSOCIATION_DB
#endif

//---------------------------------------------------------------------------
// Include files
//---------------------------------------------------------------------------

#include "base.h"
#include "general.h"
#include "mystream.h"

#ifdef SYSTEMwindows
#error should not define SYSTEMwindows
#endif

#include "address.h"
#include "tuple.h"
#include "protocol_tuple.h"

#include "gen_protocol_config.h"
#include "protocol_config.h"
#include "log.h"

#include "packet.h"
//#include "security.h"

#include "protocol_observer.h"
#include "node_link_monitoring.h"
#include "node.h"
#include "node_mpr_selection.h"

//#ifdef WITH_EXTENSION
//#include "message_conversion.h"
//#endif
//#ifdef ASSOCIATION_DB
//#include "node_ap.h"
//#endif

#include "node_inheritance.h"

//---------------------------------------------------------------------------

#endif // _OOLSR_ALL_HEADER_H
