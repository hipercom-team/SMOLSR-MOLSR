//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _MESSAGE_CONVERSION_H
#define _MESSAGE_CONVERSION_H

//---------------------------------------------------------------------------

#include "packet.h"

//---------------------------------------------------------------------------
// XXX: this should be in another file

const int MessageTLVTypeWillingness = 2;
//const int 
class MessageWithTLV;

//---------------------------------------------------------------------------

class NodeWithConversion : public ParentNodeWithConversion
{
public:
  virtual void start();

  virtual void sendMessage(OLSRIface* iface, /*owned*/Message* message);

  virtual void sendMessageToAll(Message* message)
  { packetManager->sendOneMessageToAll(message); }

  virtual MessageWithTLV* convertHELLOToV2(Message* message);

  virtual HelloMessage* convertHELLOToV1(Message* message);

protected:
};

//---------------------------------------------------------------------------

#endif // _MESSAGE_CONVERSION_H
