//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _EXTERNAL_COM_SOCKET_H
#define _EXTERNAL_COM_SOCKET_H

//---------------------------------------------------------------------------

class Node;
class IOScheduler;

#include "external_message.h"

//---------------------------------------------------------------------------

class SocketExternalComManager : public IExternalCommunicationManager
{
public:
  SocketExternalComManager(IOScheduler* aIOScheduler)
    : scheduler(aIOScheduler)
  { }

  void setNode(Node* aNode) { node = aNode; }

  virtual IExternalMessageReceiver* open(int channelIn, int channelOut,
					 IExternalMessageReceiver* receiver);

protected:
  Node* node;
  IOScheduler* scheduler;
};

//---------------------------------------------------------------------------

#endif // _EXTERNAL_COM_SOCKET_H
