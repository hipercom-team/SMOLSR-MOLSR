//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _PACKET_BUFFER_H
#define _PACKET_BUFFER_H

//---------------------------------------------------------------------------

#include <math.h>

//---------------------------------------------------------------------------
/// The exception thrown when the packet is not correct.
class PacketFormatError
{ 
};

//---------------------------------------------------------------------------
/// Utility class to format packets: pack/unpack data.

// Internally, 
//  | data already written/read | to be (re-)read | ............... |
//  ^ 0                         ^ first           ^ first+count     ^ capacity
// When writing:
//  . `first' points to the first byte to be written to
//  . `capacity' is the amount of free space in the current write buffer
//     (0 initially, automatically grown)
//  . `count' is normally set to 0 (when appending data), but after 
//     ::rewind or ::setPosition, `count' is maintained so that the 
//     last byte already written is always: `first + count'
// When reading:
//  . `first' points to the the first byte to be read
//  . `count' is the number of byte which have still not been consumed
//  . `capacity' is not changed

class PacketBuffer
{
public:
  PacketBuffer() : data(NULL), first(0), count(0), capacity(0),
		   addressFactory(NULL) {}

  PacketBuffer(AddressFactory* aAddressFactory)
    : data(NULL), first(0), count(0), capacity(0), 
      addressFactory(aAddressFactory) { }

  PacketBuffer(MemoryBlock& memoryBlock,
	       AddressFactory* aAddressFactory=NULL) 
    : data(NULL), first(0), count(0), capacity(0),
      addressFactory(aAddressFactory)
  {
    _realloc(memoryBlock.size);
    count = memoryBlock.size;
    memcpy(data, memoryBlock.data, count);
  }

  void rewind()
  { count += first; first = 0; }

  int size() { return count; }

  static int sizeUInt8() { return 1; }
  static int sizeUInt16() { return 2; }
  static int sizeUInt32() { return 4; }

  int popUInt16()
  { 
    int result=(int)data[first+1]+(((int)data[first])<<8); 
    consume(2); 
    return result;
  }

  void pushUInt16(int value)  
  { 
    assert( 0<=value && value<(1<<16) );
    _ensure(2);
    data[first] = value>>8;
    data[first+1] = value&0xff;     
    first += 2;
    if(count>0) 
      count -= myMin(count, 2);
  }

  unsigned int popUInt32()
  { 
    unsigned int result = (popUInt16()<<16) | popUInt16();
    return result;
  }

  void pushUInt32(unsigned int value)
  { 
    //assert( 0<=value && value<(1<<16) );
    _ensure(4);
    pushUInt16( (value>>16) & 0xffff );
    pushUInt16( (value) & 0xffff );
  }


  int popUInt8()
  {
    int result=(int)data[first];
    consume(1);
    return result;
  }

  void pushUInt8(int value)
  {
    assert( 0<=value && value<(1<<8) );
    _ensure(1);
    data[first] = value;
    first++;
    if(count>0) 
      count--;
  }

  void packDoubleAsFixed(double value) // XXX: remove, bool setLower = false)
  {
    int valueHigh = (int)floor(value);
    assert( valueHigh <= value );
    unsigned int valueLow = (unsigned int)((value-valueHigh)*((1<<31)-1));
    //XXX:remove: if (setLower) valueLow |= 1;
    pushUInt32( (unsigned int)valueHigh );
    pushUInt32(valueLow);
  }

  void packOptDoubleAsFixed(double value, bool isPresent)
  {
    int valueHigh = (int)floor(value);
    assert( valueHigh <= value );
    unsigned int valueLow = (unsigned int)((value-valueHigh)*((1<<31)-1));
    if (isPresent) valueLow |= 1;
    pushUInt32( (unsigned int)valueHigh );
    pushUInt32(valueLow);
  }

  double popOptDoubleAsFixed(bool& isResultPresent)
  {
    int valueHigh = (signed int)popUInt32();
    unsigned int valueLow = popUInt32();
    isResultPresent = (valueLow&1) == 1;
    valueLow &= ~1u;
    return valueHigh + (valueLow)/(double)((1<<31)-1);
  }

  double popDoubleAsFixed()
  {
    int valueHigh = (signed int)popUInt32();
    unsigned int valueLow = popUInt32();
    return valueHigh + (valueLow)/(double)((1<<31)-1);
  }

  void popSubBuffer(int amount, PacketBuffer& result)
  {
    if (amount<0)
      throw PacketFormatError();
    result._free();
    result._realloc(amount);
    result.first = 0;
    result.count = amount;
    result.addressFactory = addressFactory;
    memcpy(result.data, data+first, amount);
    consume(amount);
  }

  MemoryBlock* popBlock(int amount)
  {
    if (amount<0)
      throw PacketFormatError();
    MemoryBlock* result = new MemoryBlock(data+first, amount, true);
    consume(amount);
    return result;
  }

  MemoryBlock* peekBlock(int amount)
  {
    if (amount<0)
      throw PacketFormatError();
    verifyAvailable(amount);
    MemoryBlock* result = new MemoryBlock(data+first, amount, true);
    return result;
  }

  string popString(int amount)
  {
    if (amount<0)
      throw PacketFormatError();
    string result((char*)(data+first), amount);
    consume(amount);
    return result;
  }

  string popAllString()
  {
    string result((char*)(data+first), size());
    consume(size());
    return result;
  }

  string peekAllString()
  {
    string result((char*)(data+first), size());
    return result;
  }

  Address popAddress()
  { 
    Address result = addressFactory->peekAddress(data+first);
    consume(addressFactory->getAddressSize());
    return result;
  }

  void packAddress(Address address)
  {
    int addressSize = address.getNetSize();
    _ensure(addressSize);
    address.toNet(data+first);
    first += addressSize;
  }

  void consume(int byteCount)
  { 
    first += byteCount; 
    count -= byteCount;
    if (count<0)
      throw PacketFormatError();
  }

  void verifyAvailable(int byteCount)
  {
    if (count - byteCount<0)
      throw PacketFormatError();
  }

  void raiseWarning(char* message) { Warn("Warning:" << message); }
  void raiseError(char* message) { Warn("Error: " << message); }

  void crop(int newCount)
  {
    assert(newCount <= count);
    count = newCount;
  }

  int offset() { return first; }

  void packBlock(MemoryBlock* borrowedBlock)
  { packData(borrowedBlock->data, borrowedBlock->size); }

  void packData(void* moreData, int dataSize)
  {
    if (dataSize<0)
      throw PacketFormatError();
    _ensure(dataSize);
    memcpy(data+first, moreData, dataSize);
    first += dataSize;
    if(count>0) 
      count -= myMin(count, dataSize);
  }

  int getPosition()
  { assert(count == 0); return first; }
  
  int getSizeFrom(int initialPosition)
  { assert(count == 0); return first - initialPosition; }

  void setPosition(int position)
  { count += (first - position); first = position; }

  MemoryBlock* getContent()
  { return new MemoryBlock(data+first, count, true); }

  ~PacketBuffer()
  { _free(); }

protected:
  
  PacketBuffer(const PacketBuffer& other)
  { Fatal("impossible"); }

  void _realloc(int newSize=-1)
  {
    if (newSize == -1) newSize=capacity*2+16;
    octet* newData = new octet [newSize];
    memcpy(newData, data, first+count);
    if (data!=NULL) delete [] data;
    data = newData;
    capacity = newSize;
  }
  
  void _free()
  {
    if(data!=NULL)
      delete [] data;
    data = NULL; 
    capacity=0;
  }

  void _ensure(int freeSpace)
  {
    while(first+freeSpace>capacity)
      _realloc();
  }
  
  octet* data;
  int first;
  int count;
  int capacity;  

  AddressFactory* addressFactory;
};

//---------------------------------------------------------------------------

#endif // _PACKET_BUFFER_H
