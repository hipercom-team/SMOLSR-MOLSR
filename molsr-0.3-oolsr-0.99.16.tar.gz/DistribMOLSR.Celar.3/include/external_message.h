//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _EXTERNAL_MESSAGE_H
#define _EXTERNAL_MESSAGE_H

//---------------------------------------------------------------------------

#include "mystream.h"

#include "protocol-plugin-api.h"

#include "address.h"
#include "packet.h"
//#include "node.h"

//---------------------------------------------------------------------------

class Node;

class IExternalMessageReceiver
{
public:
  virtual void handleMessage(/*owned*/ MemoryBlock* message) = 0;
  virtual ~IExternalMessageReceiver() {}
};

class IExternalCommunicationManager
{
public:
  virtual IExternalMessageReceiver* open(int channelIn, int channelOut,
					 IExternalMessageReceiver* receiver) 
    = 0;
  virtual ~IExternalCommunicationManager() {}
};

//---------------------------------------------------------------------------
// External Message/Handler: derived from general_encapsulation.h
//---------------------------------------------------------------------------

class ByteMessage : public IMessageContent
{
public:
  MemoryBlock* data;
   
  virtual IMessageContent* clone();

  virtual void write(ostream& out) const;

  virtual ~ByteMessage() { delete data; data = NULL; }
}; 

//--------------------------------------------------

class ByteMessageHandler : public IMessageHandler
{
public:
  ByteMessageHandler(Node* aNode, int aMessageType)
    : node(aNode)
  { messageType = aMessageType; }

  //--------------------------------------------------
  // IMessageHandler interface
  //--------------------------------------------------

  virtual void processMessage(Message* message);

  virtual void considerForwardMessage(Message* m, string& info);

  virtual IMessageContent* parseMessageContent(Message* message);

  virtual void packMessageContent(IMessageContent* message, 
				  int maximumMessageSize,
				  MemoryBlock*& blockResult,
				  IMessageContent*& messageRemainingResult,
				  PackingInfo& packingInfo);

  virtual void adjustMessageSize(IMessageContent* message);

  //--------------------------------------------------
  // Simple sending of a message
  //--------------------------------------------------

  virtual void sendMessage(/*owned*/ MemoryBlock* data /*, ... vtime*/);

  //--------------------------------------------------
  // Simple receival of a message
  //--------------------------------------------------

  virtual void actuallyProcessMessage(/*borrowed*/ Message* message,
				      /*borrowed*/ MemoryBlock* packedHeader,
				      /*borrowed*/ MemoryBlock* block)
  { /* template method: derive and do something here */ }

  //--------------------------------------------------
  // Simple display of a message
  //--------------------------------------------------


protected:
  Node* node;
  int messageType;
};

//---------------------------------------------------------------------------

class ExternalMessageHandler : public ByteMessageHandler,
			       public IExternalMessageReceiver
{
public:
  ExternalMessageHandler(Node* aNode, int aMessageType, bool aWithHeader) 
    : ByteMessageHandler(aNode, aMessageType), withHeader(aWithHeader)
  { extChannelOut = NULL; messageType = aMessageType; }

  //--------------------------------------------------
  // IExternalMessageReceiver interface:
  //--------------------------------------------------

  virtual void handleMessage(MemoryBlock* message);

  //--------------------------------------------------
  // Specific methods
  //--------------------------------------------------

  void setExternalMessageReceiver(IExternalMessageReceiver* aExtChannelOut)
  { extChannelOut = aExtChannelOut; }

  virtual void actuallyProcessMessage(/*borrowed*/ Message* message,
				      /*borrowed*/ MemoryBlock* packedHeader,
				      /*borrowed*/ MemoryBlock* block)
  { 
    if (extChannelOut == NULL) {
      Warn("No extChannelOut available in handleMessage - message dropped.");
    } else if (withHeader) {
      MemoryBlock* wholeMessage = new MemoryBlock(packedHeader->size+
						  block->size);
      memcpy(wholeMessage->data, packedHeader->data, packedHeader->size);
      memcpy(wholeMessage->data + packedHeader->size,
	     block->data, block->size);
      extChannelOut->handleMessage(wholeMessage);
    } else extChannelOut->handleMessage(block->clone()); 
  }

  // Template method: do nothing here (children class can implement it)
  // (process messages coming from the external message handler)
  virtual void processExternalInfo(/*owned*/ MemoryBlock* packet)
  { delete packet; }

protected:
  IExternalMessageReceiver* extChannelOut;

  bool mprFlooding;
  bool withHeader;
};

//---------------------------------------------------------------------------

#endif // _EXTERNAL_MESSAGE_H
