//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _SCHEDULER_SIMULATION_H
#define _SCHEDULER_SIMULATION_H

//---------------------------------------------------------------------------

#include "base.h"
#include "scheduler_generic.h"

//---------------------------------------------------------------------------

/// SimulationScheduler: simply an implementation of the AbstractScheduler
/// interface. It doesn't schedule in real time, instead, it schedules
/// sequentially each time the event with the lowest time.

const int MaxSchedulerEvent = 40960;

class SimulationScheduler : public IScheduler
{
public:
  SimulationScheduler();

  // -- implementations of IScheduler
  virtual EventIdentifier addEvent(Time relativeTime, 
				   IEvent* event, void* data);
  virtual EventIdentifier addEventAt(Time absoluteTime, IEvent* event,
				     void* data);
  virtual void removeEvent(EventIdentifier eventIdentifier);
  virtual void runUntil(Time absoluteTime);
  virtual void runUntilNoEvent();
  virtual Time getTime();
  //protected:
  virtual Time getFirstEventTime();
  virtual bool hasEvent() { return getMinTimeIndex() >= 0; /* XXX */ }
  virtual void write(ostream& out);

  // -- end of IScheduler

  void setTime(Time newClock)
  { clock = newClock; }
  
protected:
  // Returns the index of the first event to be scheduled
  int getMinTimeIndex();

  typedef struct {
    double clock;
    IEvent* callback;
    void* data;
  } SchedulerEvent;
  
  SchedulerEvent eventList[MaxSchedulerEvent];
  Time clock;
  int lastEvent;
};

//---------------------------------------------------------------------------

class DriftScheduler : public IScheduler
{
public:
  DriftScheduler(IScheduler* aScheduler) 
    : scheduler(aScheduler), driftCoef(1.0), driftOffset(0.0) { }

  void setDrift(double aDriftCoef, double aDriftOffset)
  { driftCoef = aDriftCoef; driftOffset = aDriftOffset; }

  void changeDriftCoef(double aDriftCoef)
  {
    Time realTime = scheduler->getTime();
    // before: a * t + b, after: a' t + b' ---> b' = b + (a-a') t
    driftOffset += (driftCoef - aDriftCoef) * realTime;
    driftCoef = aDriftCoef;
  }

  virtual Time applyDrift(Time realTime) 
  { return driftCoef*realTime + driftOffset; }

  virtual Time unapplyDrift(Time driftedTime)
  { return (driftedTime - driftOffset) / driftCoef; }

  // -- implementations of IScheduler
  virtual EventIdentifier addEvent(Time relativeTime, 
				   IEvent* event, void* data)
  { return addEventAt(getTime() + relativeTime, event, data); }

  virtual EventIdentifier addEventAt(Time absoluteTime, IEvent* event,
				     void* data)
  { return scheduler->addEventAt(unapplyDrift(absoluteTime), event, data); }

  virtual void removeEvent(EventIdentifier eventIdentifier)
  { scheduler->removeEvent(eventIdentifier); }

  virtual void runUntil(Time absoluteTime)
  { scheduler->runUntil(unapplyDrift(absoluteTime)); }

  virtual void runUntilNoEvent()
  { scheduler->runUntilNoEvent(); }

  virtual Time getTime()
  { return applyDrift(scheduler->getTime()); }

  //protected:
  virtual Time getFirstEventTime()
  { return applyDrift(scheduler->getTime()); }

  virtual bool hasEvent() { return scheduler->hasEvent(); }

  virtual void write(ostream& out)
  { scheduler->write(out); }

  // -- end of IScheduler

  double getDriftCoef() { return driftCoef; }
  double getDriftOffset() { return driftOffset; }
  
protected:
  IScheduler* scheduler;
  double driftCoef;
  double driftOffset;
};

//---------------------------------------------------------------------------

#endif // _SCHEDULER_SIMULATION
