//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004-2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// A world: nodes with a position, a speed, a receive range.
//---------------------------------------------------------------------------

#ifndef _SIMUL_WORLD_H
#define _SIMUL_WORLD_H

//---------------------------------------------------------------------------

#include "general.h"
#include <math.h>
#include <vector>
#include <list>

//---------------------------------------------------------------------------

#ifndef _SIMULATION_API_H
typedef struct s_WorldNodeInfo {
  double pos[2];
  double speed[2];
  double lastClock;
  double receiveRange;

  double minPos[2], maxPos[2]; // XXX: useful? (should use world stuff)
} WorldNodeInfo;
#endif

class WorldNode : public WorldNodeInfo
{
public:

  void getPos(double clock, double xy[2]) {
    assert( clock >= lastClock);
    for(int i=0;i<2;i++) {
      pos[i] += speed[i] * (clock-lastClock);
      for(;;) {
	if(pos[i] < minPos[i]) {
	  pos[i] = 2*minPos[i] - pos[i];
	  speed[i] = -speed[i];
	} else if (pos[i] > maxPos[i]) {
	  pos[i] = 2*maxPos[i] - pos[i];
	  speed[i] = -speed[i];
	} else break;
      }
      xy[i] = pos[i];
    }
    lastClock=clock;
  }

};

//---------------------------------------------------------------------------

class AllPairRoute
{
public:
  AllPairRoute(int aNbNode) : nbNode(aNbNode) 
  { 
    distance = allocMatrix();
    pred = allocMatrix();
  }
  
  //FloydWarshall
  void compute()
  {
    for (int i=0; i<nbNode; i++)
      for (int j=0; j<nbNode; j++)
	if (distance[i][j] > 0)
	  pred[i][j] = i;
	else pred[i][j] = -1;
    for (int k=0; k<nbNode; k++)
      for (int i=0; i<nbNode; i++)
	for (int j=0; j<nbNode; j++)
	  if (distance[i][j] > distance[i][k] + distance[k][j]) {
	    distance[i][j] = distance[i][k] + distance[k][j];
	    pred[i][j] = pred[k][j];
	  }
  }

  bool getRoute(int srcIdx, int dstIdx, std::list<int>& result)
  {
    if (distance[srcIdx][dstIdx] <= 0)
      return false;
    result.clear();
    int current = dstIdx;
    while (current != srcIdx) {
      assert( distance[srcIdx][current] > 0 );
      result.push_front(current);
      current = pred[srcIdx][current];
      assert( 0<= current && current < nbNode );
    }
    result.push_front(srcIdx);
    return true;
  }

  int** allocMatrix()
  {
    int** result = new int* [nbNode];
    for (int i=0; i< nbNode;i++) {
      result[i] = new int [nbNode];
      memset(result[i], 0, sizeof(int)*nbNode);
    }
    return result;
  }

  void deleteMatrix(int** array)
  {
    for (int i=0; i<nbNode; i++)
      delete [] array[i];
    delete [] array;
  }

  ~AllPairRoute()
  {
    deleteMatrix(distance);
    deleteMatrix(pred);
  }

  //protected:
  int nbNode;
  int** distance;
  int** pred;
};

//--------------------------------------------------

typedef enum {
  LimitRange = 0,
  LinearRange = 1,
  ExponentialRange = 2
} RangeModel;

class World
{
public:
  World(int aMaxNode, double aWidth, double aHeight, 
	double aMinRange, double aMaxRange, double aMaxSpeed) 
    : nbNode(aMaxNode), width(aWidth), height(aHeight),
    minRange(aMinRange), maxRange(aMaxRange), maxSpeed(aMaxSpeed),
    rangeModel(LimitRange)
  { 
    for(int i=0;i<nbNode;i++)
      nodeArray.push_back(NULL);
  }
  
  int getNbNode() { return nbNode; }


  AllPairRoute* getAllRoute(double clock)
  {
    AllPairRoute* result = new AllPairRoute(nbNode);
    for (int i=0; i<nbNode; i++)
      for (int j=0; j<nbNode; j++)
	if (i == j) { result->distance[i][j] = 0; result->pred[i][j] = i; }
	else {
	  if (inRange(clock, i, j)) {
	    result->distance[i][j] = 1;
	  } else {
	    result->distance[i][j] = 1000000;
	  }
	}
    result->compute();
    return result;
  }

  void checkAllRoute(double clock, AllPairRoute* allPair, int maxDistance,
		     int& nbRouteOk, int& nbRouteNotFound, 
		     int& nbRouteBad, int& nbRouteBrokenOnce)
  {
    nbRouteOk = 0;
    nbRouteNotFound = 0;
    nbRouteBad = 0;
    nbRouteBrokenOnce = 0;
    assert( allPair->nbNode == nbNode );
    for (int i=0; i<nbNode; i++) 
      for (int j=0; j<nbNode; j++) {
	if (allPair->distance[i][j]>0 && allPair->distance[i][j]<maxDistance) {
	  std::list<int> route;
	  bool ok = allPair->getRoute(i, j, route);
	  if (!ok) {
	    nbRouteNotFound++;
	  } else {
	    assert( route.front() == i && route.back() == j );
	    int broken = 0;
	    int current = route.front();
	    route.pop_front();
	    for (ITER(std::list<int>, it, route)) {
	      if (!inRange(clock, current, *it))
		broken++;
	      current = *it;
	    }
	    if (broken == 0) 
	      nbRouteOk++;
	    else {
	      nbRouteBad++;
	      if (broken == 1)
		nbRouteBrokenOnce ++;
	    }
	  }
	}
      }
  }

  void setRangeModel(RangeModel newRangeModel)
  { rangeModel = newRangeModel; }

  static double randomDouble(double minValue = 0.0, double maxValue = 1.0)
  { return minValue + (maxValue - minValue) * drawDouble(1.0); }

  void create(int nodeIdx)
  {
    assert(inrange(0, nodeIdx, nbNode));
    assert(nodeArray[nodeIdx] == NULL);
    
    WorldNode* node = new WorldNode;
    node->pos[0] = randomDouble(0, width);
    node->minPos[0] = 0.0;
    node->maxPos[0] = width;
    node->pos[1] = randomDouble(0, height);
    node->minPos[1] = 0.0;
    node->maxPos[1] = height;
    node->lastClock = 0.0;
    node->receiveRange = randomDouble(minRange, maxRange);
    node->speed[0] = randomDouble(0, maxSpeed);
    node->speed[1] = randomDouble(0, maxSpeed);

    nodeArray[nodeIdx] = node;
  }

  void setLinearRange(double deltaRange)
  { 
    assert ( rangeModel == LimitRange );
    assert ( deltaRange > 0 );
    maxRange = minRange + deltaRange;
    rangeModel = LinearRange;
  }

  void getReceiverList(int nodeIdx, double clock, std::list<int>& resultList) 
  {
    double xy[2];
    nodeArray[nodeIdx]->getPos(clock, xy);
    for(int i=0;i<nbNode;i++) {
      if(nodeArray[i] != NULL) {
	double otherXY[2];
	nodeArray[i]->getPos(clock, otherXY);
	double dx = xy[0] - otherXY[0];
	double dy = xy[1] - otherXY[1];
	double dist = sqrt(dx*dx+dy*dy);
	bool canReceive = false;

	if (rangeModel == LimitRange) {
	  double d = nodeArray[i]->receiveRange;
	  canReceive = (dist <= d);
	} else if (rangeModel == LinearRange) {
	  if (dist <= minRange)
	    canReceive = true;
	  else if (dist <= maxRange) {
	    double p = drawDouble(1.0);
	    canReceive = (p * (maxRange-minRange) <= (maxRange - dist));
	  }
	} else if (rangeModel == ExponentialRange) {
	  if (dist <= minRange)
	    canReceive = true;
	  else {
	    double p = drawDouble(1.0);
	    double pSuccess = exp( log(2) * (dist - minRange) 
				   / (maxRange - minRange) );
	    canReceive = (p <= pSuccess);
	  }
	}
	if (canReceive) 
	  resultList.push_back(i);
      }
    }
  }

  bool inRange(double clock, int srcIdx, int dstIdx)
  {
    double xy[2];
    nodeArray[srcIdx]->getPos(clock, xy);
    double otherXY[2];
    nodeArray[dstIdx]->getPos(clock, otherXY);
    double dx = xy[0] - otherXY[0];
    double dy = xy[1] - otherXY[1];
    double dist = sqrt(dx*dx+dy*dy);
    if (rangeModel == LinearRange) {
      // Not really a boolean!
      static bool warnInRange = false;
      if (!warnInRange) {
	warnInRange = true;
	cerr << "WARNING: world::inRange() method called, but it has"
	  " no meaning for probabilistic receiving" << endl;
      }
      return dist <= maxRange;
    } else {
      assert( rangeModel == LimitRange ); // otherwise it is not boolean
    }
    //std::cout << "dist=" << dist << " " << nodeArray[dstIdx]->receiveRange << endl;
    return dist <= nodeArray[dstIdx]->receiveRange;
  }

   WorldNode* getNode(int nodeIdx)
   {
     assert( inrange(0, nodeIdx, nbNode) );
     return nodeArray[nodeIdx];
   }

  World* clone()
  {
    World* result = new World(nbNode, width, height, minRange, 
			      maxRange, maxSpeed);
    for (int i=0; i<nbNode; i++) {
      result->nodeArray[i] = new WorldNode;
      result->nodeArray[i] = nodeArray[i];
    }
    return result;
  }
   
  ~World()
  {
    for (int i=0; i<nbNode; i++)
      if (nodeArray[i] != NULL)
	delete nodeArray[i];
  }

protected:
  int nbNode;
  std::vector<WorldNode*> nodeArray;

  double width, height, minRange, maxRange, maxSpeed;
  RangeModel rangeModel;
};

//---------------------------------------------------------------------------

#endif // _SIMUL_WORLD_H
