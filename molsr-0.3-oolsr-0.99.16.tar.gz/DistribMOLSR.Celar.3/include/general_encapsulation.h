//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Management of Multicast Encapsulated packets
//---------------------------------------------------------------------------

#ifndef _GENERAL_ENCAPSULATION_H
#define _GENERAL_ENCAPSULATION_H

//---------------------------------------------------------------------------

#include "mystream.h"

#include "protocol-plugin-api.h"

#include "address.h"
#include "packet.h"
#include "node.h"

//---------------------------------------------------------------------------

extern PPA_PlugeeApi* simulatorApi; // XXX: should be defined elsewhere

//---------------------------------------------------------------------------

class EMMessage : public IMessageContent
{
public:
  MemoryBlock* packet;
  Address destinationAddress;


  virtual Address getDestinationAddress()
  { return destinationAddress; }
   
  virtual IMessageContent* clone()
  {
    EMMessage* result = new EMMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    result->packet = packet->clone();
    result->destinationAddress = destinationAddress;
    return result;
  }

  /// Write the message content
  virtual void write(ostream& out) const
  {
    out << "encapsulated multicast dest= " << destinationAddress
	<< "size=" << packet->size << " content=";
    for(int i=0;i<packet->size;i++) {
      if(i%4 == 0 && i!=0) 
	out << "_";
      char info[10];
      sprintf(info,"%02x", ((unsigned char*)packet->data)[i]);
      out << info;
    }
  }

  virtual ~EMMessage() { delete packet; packet = NULL; }
}; 

//--------------------------------------------------

class EMMessageHandler : public IMessageHandler
{
public:
  EMMessageHandler(Node* aNode, PPA_PlugeeNode aPlugeeNode) 
    : node(aNode), plugeeNode(aPlugeeNode) {}

  virtual void processMessage(Message* message)
  {
    IMessageContent* messageContent = parseMessageContent(message);
    EMMessage* emMessage = dynamic_cast<EMMessage*>(messageContent);

    PPA_Packet ppaPacket;
    ppaPacket.size = emMessage->packet->size;
    ppaPacket.data = malloc(ppaPacket.size); // (allocated by malloc, not new)
    memcpy(ppaPacket.data, emMessage->packet->data, ppaPacket.size);

#ifdef MULTICAST_RESEARCH
    D(*node->log, lMulticast,
      node->getRealTime() << " [process-message] " 
      << node->getMainAddress() << " " << message->originatorAddress
      << ":" << message->messageSequenceNumber << " content=" 
      << format3UInt(ppaPacket.data) << " "  
      << node->isMember(emMessage->destinationAddress) << endl);
#endif

    simulatorApi->sendDecapsulatedMulticastPacketFunction
      (plugeeNode, 
       message->originatorAddress.getRawAddress(),
       emMessage->getDestinationAddress().getRawAddress(),
       message->recvIfaceAddress.getRawAddress(),
       ppaPacket);
    delete emMessage;
  }

  virtual void considerForwardMessage(Message* m, string& info)
  {
#if defined (MULTICAST_RESEARCH)  || defined (MOOLSR)   
    IMessageContent* messageContent = parseMessageContent(m);
    EMMessage* emMessage = dynamic_cast<EMMessage*>(messageContent);

    PktD(*node->log, info, m, "emmCheckForward,");

    DuplicateTuple* duplicateTuple = 
      node->duplicateSet.findFirst_Address_MessageSequenceNumber
      (m->originatorAddress, m->messageSequenceNumber); // @@999-1001


    // The message has been processed: put it in the duplicate table in
    // any case.
    if (duplicateTuple == NULL) {
      duplicateTuple = new DuplicateTuple;
      duplicateTuple->D_addr = m->originatorAddress; // @@1045
      duplicateTuple->D_seq_num = m->messageSequenceNumber; // @@1047
      duplicateTuple->D_time = node->getCurrentTime()
	+ node->getProtocolConfig()->DUP_HOLD_TIME; // @@1049
      //duplicateTuple->D_iface_list.push_back(m->recvIfaceAddress);
      duplicateTuple->D_retransmitted = false; // @@1053-1054
      node->duplicateSet.add(duplicateTuple);

      PktD(*node->log, info, m, "no-duplicate,");
    } else {
      PktD(*node->log, info, m, "with-duplicate,");
    }

    // Forward it if it has not been retransmitted and function says
    // it should be.
    if (!duplicateTuple->D_retransmitted) { 
      PktD(*node->log, info, m, "no-retransmitted,");
      if (node->shouldForwardEMMessage(emMessage)) {
	PktD(*node->log, info, m, "should-forward");
	Message* newMessage = m->clone();
	newMessage->timeToLive --; // @@1059
	newMessage->hopCount ++; // @@1061
	node->getPacketManager()->sendPackedMessageToAll(newMessage); // @@1071-1073
	duplicateTuple->D_retransmitted = true;
      } else { PktD(*node->log, info, m, "should-not-forward"); }
    } else {
      PktD(*node->log, info, m, "already-retransmitted,");
    }

#elif defined MOST 
    IMessageContent* messageContent = parseMessageContent(m);
    EMMessage* emMessage = dynamic_cast<EMMessage*>(messageContent);

    DuplicateTuple* duplicateTuple =
      node->duplicateSet.findFirst_Address_MessageSequenceNumber
      (m->originatorAddress, m->messageSequenceNumber);
    // Never consider a duplicate for forwarding
    if (duplicateTuple == NULL) {
      duplicateTuple = new DuplicateTuple;
      duplicateTuple->D_addr = m->originatorAddress;
      duplicateTuple->D_seq_num = m->messageSequenceNumber;
      duplicateTuple->D_time = node->getCurrentTime()
        + node->getProtocolConfig()->DUP_HOLD_TIME;
      node->duplicateSet.add(duplicateTuple);
      duplicateTuple->D_retransmitted = false;  //not used
      MostNode* mostnode = dynamic_cast<MostNode*>(node);
      mostnode->mostForward(m,emMessage->destinationAddress);
      PktD(*node->log, info, m, mostnode->logForwardInfo(emMessage));
    }
#else
    PktD(*node->log, info, m, "using-mpr-flooding,");
    node->getPacketManager()->defaultForwardingMessage(m, info);
#endif // MULTICAST_RESEARCH || MOOLSR
  }

  virtual IMessageContent* parseMessageContent(Message* message)
  {
    EMMessage* result = new EMMessage;
    PacketBuffer buffer(*message->packedContent, node->getAddressFactory());
    result->destinationAddress = buffer.popAddress();
    result->packet = buffer.popBlock(buffer.size()); // (owned)
    result->header = message->clone(false);
    return result;
  }

  virtual void packMessageContent(IMessageContent* message, 
				  int maximumMessageSize,
				  MemoryBlock*& blockResult,
				  IMessageContent*& messageRemainingResult,
				  PackingInfo& packingInfo)
  {
    EMMessage* m = dynamic_cast<EMMessage*>(message);

    if (maximumMessageSize < m->header->messageSize) {
      // Impossible to split:
      blockResult = NULL;
      messageRemainingResult = NULL;
      // XXX: warning.
      return;
    }

#ifdef MOST
    // cpp-2.95.4 doesn't like #ifdef inside macros, so the whole D(...)
    // is put twice
    D(*node->log, lMulticast,
      node->getRealTime() << " [pack-message] " 
      << node->getMainAddress() << " " << m->header->originatorAddress
      << ":" << m->header->messageSequenceNumber << " content="
      << format3UInt(m->packet->data)
      << " multicastAddress=" << m->destinationAddress
      << " destinationAddress=" << m->header->destinationAddress
      << endl);

#else

    D(*node->log, lMulticast,
      node->getRealTime() << " [pack-message] " 
      << node->getMainAddress() << " " << m->header->originatorAddress
      << ":" << m->header->messageSequenceNumber << " content="
      << format3UInt(m->packet->data) << endl);

#endif






    PacketBuffer buffer;

    //XXX:remove: int initialPosition = buffer.getPosition();
    PacketManager::PositionInfo info 
      = node->getPacketManager()->packMessageHeader(buffer, message->header);
    buffer.packAddress(m->destinationAddress);
    buffer.packBlock(m->packet);
    node->getPacketManager()->adjustPackedMessageSize(buffer, info);

    buffer.rewind();
    blockResult = buffer.getContent();
  }

  virtual void adjustMessageSize(IMessageContent* message)
  {
    int addressSize = node->getAddressFactory()->getAddressSize();
    EMMessage* m = dynamic_cast<EMMessage*>(message);
    m->header->messageSize =
      MessageHeaderWithoutAddressSize + addressSize // message header
      + addressSize // destination address
      + m->packet->size; // content
    m->header->minMessageSize = m->header->messageSize;
  }

protected:
  Node* node;
  PPA_PlugeeNode plugeeNode;
};

//---------------------------------------------------------------------------

#endif /*_GENERAL_ENCAPSULATION_H*/
