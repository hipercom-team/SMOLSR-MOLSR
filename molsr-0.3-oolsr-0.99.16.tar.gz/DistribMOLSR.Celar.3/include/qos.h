//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _QOS_H
#define _QOS_H

//---------------------------------------------------------------------------

#include "node_inheritance.h"
#include "packet.h"

#include "qos_flow.h"

//---------------------------------------------------------------------------

class IPacketCounter
{
public:
  virtual unsigned long setTcInfo(int beRate, int tcHysteresis) = 0;
  virtual unsigned long getQdiscInfo() = 0;
  virtual unsigned long getOlsrByteCount() = 0;
  virtual unsigned long getQosByteCount() = 0;
  virtual unsigned long getBeByteCount() = 0;
  virtual unsigned long getOlsrPacketCount() = 0;
  virtual unsigned long getQosPacketCount() = 0;
  virtual unsigned long getBePacketCount() = 0;

  virtual unsigned long getByteCount() = 0;
  virtual unsigned long getPacketCount() = 0;
};

//---------------------------------------------------------------------------

class QosFlowDef
{
public:
  Address sourceAddress;
  int sourcePort; //
  Address destinationAddress;
  int destinationPort;

  void write(ostream& out);
};

class QosFlow : public QosFlowDef
{
public:
  double  bandwidth;

  list<Address> currentRoute;
  Time expireTime;
  int routeQuality;

  bool hasRoute() { return !currentRoute.empty(); }

  void write(ostream& out);
};

inline ostream& operator << (ostream& out, QosFlow& flow)
{ flow.write(out); return out; }

inline ostream& operator << (ostream& out, QosFlowDef& flow)
{ flow.write(out); return out; }

//---------------------------------------------------------------------------

struct QosFlowLess
{
  bool operator() (QosFlow* const& flow1, QosFlow* const& flow2) const;
};

typedef std::set<QosFlow*, QosFlowLess> QosFlowSet;


class QosFlowTable
{
public:
  QosFlow* findFlow(QosFlowDef& qosFlowDef);
  
  QosFlow* addFlow(QosFlowDef& qosFlowDef, 
		   double bandwidth, Time expirationTime);
   
  void deleteFlow(QosFlow* flow);

  void write(ostream& out);

  void expireAllFlow(Time currentTime);

  QosFlowSet qosFlowTable;

  /// Return the whole table in a network format
  string pack(); 

  /// Handle a request
  bool unpackFlowList(AddressFactory* addressFactory,
		      string& data, std::list<QosFlow>& resultFlowList);
};

//---------------------------------------------------------------------------

#define QSR_MESSAGE_VERSION_MAJOR 0
#define QSR_MESSAGE_VERSION_MINOR 0

#define QSR_ACTION_REQUEST 0
#define QSR_ACTION_REPLY 1

//---------------------------------------------------------------------------

#define QSR_MESSAGE_VERSION (((QSR_MESSAGE_VERSION_MAJOR)<<4)\
                              |QSR_MESSAGE_VERSION_MINOR )

static inline int majorVersionOf(int fullVersion)
{ return fullVersion >> 4; }

static inline int minorVersionOf(int fullVersion)
{ return fullVersion & 0xf; }

//---------------------------------------------------------------------------

class QosInfo
{
public:
  double qosLoad;        // 0 to 1, Qos + OLSR
  double qosLab;         // 0 to 1, QoS + OLSR
  double beLoad;         // 0 to 1, only BE
  double beLab;          // 0 to 1, only BE

  void write(ostream& out) const;
};

class AddressAndQosInfo
{
public:
  Address address;
  QosInfo qos;
};

//---------------------------------------------------------------------------

class QosTuple : public ITuple
{
public:
  Address mainAddress;
  QosInfo qos; 
  Time    expireTime;
  unsigned int qosANSN; // for Qos-TC

  list<AddressAndQosInfo> neighborQosList;

  QosTuple(Node* aNode) : node(aNode) { qosANSN = 0; }

  virtual Time getExpireTime(Time currentTime) { return expireTime; }
  virtual void update() { /* nothing to do */ }
  virtual ~QosTuple() 
  { /* nothing to do */ }
  
  void write(ostream& out, bool isNeighborQosSet);

  Node* node;
};

//--------------------------------------------------

class QosSet : public BasicTupleSet<QosTuple>
{
public:
  QosSet(Node* aNode) : node(aNode) { }

  /*
  QosTuple* findFirst_obsolete_tuple(Address lastAddr,unsigned int seqNu)
  { 
    OptimizedSearch
      (QosTuple, 
       ((current->mainAddress == lastAddr) 
	&& _ansnGreater(current->qosANSN, seqNu)),
       lastAddr); 
  }
  */

  QosTuple* findFirst(Address oneHop)
  { Search(QosTuple, current->mainAddress == oneHop); }

  //------------------------------

  void write(ostream& out, bool isHelloQosSet);

  virtual void notifyAddition(QosTuple* tuple)
  { /* nothing to do */ }

  virtual void notifyRemoval(QosTuple* tuple)
  { /* nothing to do */ }

  virtual void write(ostream& out)
  { Fatal("Use ::write(out, true|false) instead of ::write(out)"); }

  virtual ~QosSet() {}

protected:
  Node* node;
};

//---------------------------------------------------------------------------

class QosMessage;
class QosSet;

class QosNode : public ParentQosNode
{
public:
  QosNode();

  virtual void start(); // overrides Node::start

  void setPacketCounter(IPacketCounter* aPacketCounter)
  { 
    if (packetCounter != NULL)
      delete packetCounter;
    packetCounter = aPacketCounter;
  }

  void processContentiousQosHelloMessage(QosMessage& qosHelloMessage);
  void processQosHelloMessage(QosMessage& qosHelloMessage);
  void processQosTCMessage(QosMessage& qosTCMessage);
  
  virtual void logState(ostream& out, bool noEnd=false);

  virtual void logQosTable(ostream& out);


  virtual void getNextExpireTime(Time& nextExpireTime, bool& hasExpireTime);

  void generateQosHello();
  
  void generateQosTC();

  virtual void notifyHelloGeneration()
  { if (protocolConfig->useQos) generateQosHello(); }

  virtual void notifyTCGeneration()
  { if (protocolConfig->useQos) generateQosTC(); }

  void handleRequest(QosFlow& flowRequest);

  void deleteFlow(QosFlow* flow)
  { flowTable.deleteFlow(flow); }

  string packFlowTable() 
  { return flowTable.pack(); }

  virtual void notifyRouteCalculation()
  {
    //if (protocolConfig->useQos) computeAllQosRoute();
  }

  void computeAllQosRoute();

  void handleQSRMessage(/*owned*/ MemoryBlock* message);

  bool computeFlowRoute(QosFlow& flow);

  bool _computeBestEffortFlowRoute(QosFlow& flow);

  bool _computeQosFlowRoute(QosFlow& flow);

  void sendFlowTable();

  double tmpCurrentQosLoad; // XXX! to change
  double tmpCurrentBeLoad; // XXX! to change

  void computeCurrentLoad()
  { 
    if (packetCounter == NULL) {
      currentQosLoad = 0;
      currentBeLoad  = 0;
      return;
    }
     
    Time clock = getCurrentTime();
    if (hasLastCounterTime && (clock < (lastCounterTime 
	+ protocolConfig->qosMinPacketCounterDelay)))
      return; // Too early to measure again

    // get Qdisc Statistics Info
    packetCounter->getQdiscInfo();
    unsigned long currentOlsrPacketCount = packetCounter->getOlsrPacketCount();
    unsigned long currentOlsrByteCount   = packetCounter->getOlsrByteCount();
    unsigned long currentQosPacketCount  = packetCounter->getQosPacketCount();
    unsigned long currentQosByteCount    = packetCounter->getQosByteCount();
    unsigned long currentBePacketCount   = packetCounter->getBePacketCount();
    unsigned long currentBeByteCount     = packetCounter->getBeByteCount();

    if (!hasLastCounterTime) {
      currentQosLoad = 0;
      currentBeLoad  = 0;
    } else {
      const int BitsPerByte = 8;
      double transmitQosLoad = (currentQosByteCount - lastQosByteCount)
	* BitsPerByte / protocolConfig->qosUnicastRate
	/ (clock - lastCounterTime);
      double transmitBeLoad = (currentBeByteCount - lastBeByteCount)
	* BitsPerByte / protocolConfig->qosUnicastRate
	/ (clock - lastCounterTime);
      double transmitOlsrLoad = (currentOlsrByteCount - lastOlsrByteCount)
	* BitsPerByte / protocolConfig->qosBroadcastRate
	/ (clock - lastCounterTime);
      double macDelayQosLoad = (currentQosPacketCount - lastQosPacketCount)
	* protocolConfig->qosUnicastMacDelay
	/ (clock - lastCounterTime);
      double macDelayBeLoad = (currentBePacketCount - lastBePacketCount)
	* protocolConfig->qosUnicastMacDelay
	/ (clock - lastCounterTime);
      double macDelayOlsrLoad = (currentOlsrPacketCount - lastOlsrPacketCount)
	* protocolConfig->qosBroadcastMacDelay
	/ (clock - lastCounterTime);

      currentQosLoad = transmitQosLoad + macDelayQosLoad
	+ transmitOlsrLoad + macDelayOlsrLoad;
      currentBeLoad  = transmitBeLoad + macDelayBeLoad;

      if (currentQosLoad > 1.0)
	currentQosLoad = 1.0;
      else if (currentQosLoad < 0)
	currentQosLoad = 0.0;
      assert( currentQosLoad >= 0 );
      if (currentBeLoad > 1.0)
	currentBeLoad = 1.0;
      else if (currentBeLoad < 0)
	currentBeLoad = 0.0;
      assert( currentBeLoad >= 0 );
      DD(lQos, "[qos-load]", "qos_xmit=" << transmitQosLoad
	 << " qos_delay=" << macDelayQosLoad
	 << " olsr_xmit=" << transmitOlsrLoad
	 << " olsr_delay=" << macDelayOlsrLoad
	 << " be_xmit=" << transmitBeLoad
	 << " be_delay=" << macDelayBeLoad
	 << " qos_load=" << currentQosLoad 
	 << " be_load=" << currentBeLoad 
	 << " qos_pkt=" << currentQosPacketCount 
	 << " qos_byte=" << currentQosByteCount 
	 << " be_pkt=" << currentBePacketCount 
	 << " be_byte=" << currentBeByteCount 
	 << " olsr_pkt=" << currentOlsrPacketCount 
	 << " olsr_byte=" << currentOlsrByteCount << endl);
    } 
    hasLastCounterTime = true;
    lastCounterTime = clock;
    lastOlsrPacketCount = currentOlsrPacketCount;
    lastOlsrByteCount   = currentOlsrByteCount;
    lastQosPacketCount  = currentQosPacketCount;
    lastQosByteCount    = currentQosByteCount;
    lastBePacketCount   = currentBePacketCount;
    lastBeByteCount     = currentBeByteCount;
  }

  /*
    -- comment out by DANG

  void computeCurrentLoad()
  { 
    if (packetCounter == NULL) {
      currentLoad = 0;
      return;
    }
     
    Time clock = getCurrentTime();
    unsigned long currentPacketCount = packetCounter->getPacketCount();
    unsigned long currentByteCount = packetCounter->getByteCount();
    if (hasLastCounterTime && clock < lastCounterTime 
	+ protocolConfig->qosMinPacketCounterDelay)
      return; // Too early to measure again

    if (!hasLastCounterTime) {
      currentLoad = 0;
    } else {
      const int BitsPerByte = 8;
      double transmitLoad = (currentByteCount - lastByteCount) * BitsPerByte
	/ protocolConfig->qosMediumBandwidth / (clock - lastCounterTime);
      double macDelayLoad = (currentPacketCount - lastPacketCount)
	* protocolConfig->qosMediumMacDelay / (clock - lastCounterTime);
      currentLoad = transmitLoad + macDelayLoad;
      if (currentLoad > 1.0)
	currentLoad = 1.0;
      else if (currentLoad < 0)
	currentLoad = 0;
      assert( currentLoad >= 0 );
      DD(lQos, "[qos-load]", "xmit=" << transmitLoad << " delay=" 
	 << macDelayLoad << " load=" << currentLoad 
	 << " pkt=" << currentPacketCount 
	 << " byte=" << currentByteCount << endl);
    } 
    hasLastCounterTime = true;
    lastCounterTime = clock;
    lastPacketCount = currentPacketCount;
    lastByteCount = currentByteCount;
  }
  */

  void computeLAB();

  void setTcParameters();

  // Add some additional infos.
  virtual vector<string>* getTableNameList(); /* result is owned */
  virtual vector<vector<string>*>* getTableContent(string name);

  virtual ~QosNode()
  { if (packetCounter != NULL) delete packetCounter; packetCounter = NULL; }

protected:

  QosSet contentiousQosSet;

  QosSet topologyQosSet;

  QosFlowTable flowTable;

  virtual void performTupleExpiration();

  IPacketCounter* packetCounter;
  bool hasLastCounterTime;
  Time lastCounterTime;
  //  unsigned long lastPacketCount;
  //  unsigned long lastByteCount;

  struct _listSortedPlus_t {
    double value;
    struct _listSortedPlus_t *pNext;
  };
  typedef struct _listSortedPlus_t listSortedPlus_t, *listSortedPlus_pt;

  listSortedPlus_pt insertLspValue(double aValue, listSortedPlus_pt aLSP) {
    listSortedPlus_pt i, j, newElement;
    i = j = aLSP;
    while ((i != NULL) && (aValue > i->value)) {
      j = i;
      i = i->pNext;
    }
    newElement = (listSortedPlus_pt)malloc(sizeof(listSortedPlus_t));
    newElement->value = aValue;
    newElement->pNext = i;
    if (j == aLSP)
      return newElement;
    else {
      j->pNext = newElement;
      return aLSP;
    }
  }

  void freeLsp(listSortedPlus_pt aLSP) {
    listSortedPlus_pt i, j;
    i = aLSP;
    while (i != NULL) {
      j = i;
      i = i->pNext;
      free(j);
    }
  }

  unsigned long lastQosByteCount;
  unsigned long lastQosPacketCount;
  unsigned long lastOlsrByteCount;
  unsigned long lastOlsrPacketCount;
  unsigned long lastBeByteCount;
  unsigned long lastBePacketCount;

  double currentQosLoad;  // QoS + OLSR
  double currentBeLoad;   // only BE
  double currentQosLab;   // QoS + OLSR
  double currentBeLab;    // only BE
  double currentMinQosLab; // QoS + OLSR
  double currentMinBeLab;  // only BE
  unsigned short currentQosANSN;

  IExternalMessageReceiver* channelToQsr;
};

//---------------------------------------------------------------------------

class QosMessage : public IMessageContent
{
public:
  QosMessage(AddressFactory* aAddressFactory) 
    : addressFactory(aAddressFactory) {}
  
  virtual IMessageContent* clone();
  virtual void write(ostream& out) const;

  bool isHello();

  QosInfo qosInfo; // for a QoS Hello, it is the load of the node
               // for a QoS TC, it is the minimum of the LAB at two hops
  unsigned int qosANSN; // for a QoS TC only

  std::list<AddressAndQosInfo> neighborQosList;

protected: 
  AddressFactory* addressFactory;
};

class QosMessageHandler : public IMessageHandler
{
public:
  QosMessageHandler(QosNode* aNode /*, MessageType messageType*/)
    : node(aNode) {}
  virtual void processMessage(/*borrowed*/ Message* message);
  virtual void considerForwardMessage(/*borrowed*/ Message* message,
                                      string& info);
  virtual IMessageContent* parseMessageContent(Message* message);
  virtual void packMessageContent(IMessageContent* message,
                                  int maximumMessageSize,
                                  MemoryBlock*& packedResult,
                                  IMessageContent*& messageRemainingResult,
				  PackingInfo& packingInfo);
  virtual void adjustMessageSize(IMessageContent* message);

protected:
  QosNode* node;
};

//---------------------------------------------------------------------------

class QSRExternalMessageReceiver : public IExternalMessageReceiver
{
public:
  QSRExternalMessageReceiver(QosNode* aQosNode) : qosNode(aQosNode) 
  { }

  virtual void handleMessage(/*owned*/ MemoryBlock* message)
  { qosNode->handleQSRMessage(message); }

  virtual ~QSRExternalMessageReceiver() {}
protected:
  QosNode* qosNode;
};

//---------------------------------------------------------------------------

#endif // _QOS_H
