
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h> // XXX: for windows
#include <iptypes.h>
#include <iphlpapi.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <sys/socket.h>
#include <sys/types.h>

#include "general.h"

//---------------------------------------------------------------------------

void startWinSock2()
{
  int err;
  WORD wVersionRequested;
  WSADATA wsaData;
  
  // open winsock //
  wVersionRequested = MAKEWORD( 2, 2 );
  err = WSAStartup( wVersionRequested, &wsaData );
  if ( err != 0 ) {
    printf("Error: WSAStartup failed with error %d\n", WSAGetLastError());
    exit(1);
  }
  if ( LOBYTE( wsaData.wVersion ) != 2 ||
       HIBYTE( wsaData.wVersion ) != 2 ) 
    {
      WSACleanup( );
      if (err == SOCKET_ERROR) {
	printf("WSACleanup failed with error %d\n", WSAGetLastError());
      }
      exit(1);
    }
  // winsock ok //
}

//---------------------------------------------------------------------------

int main(int argc, char** argv)
{
  startWinSock2();

  int ifaceSocket = socket(AF_INET, SOCK_DGRAM, 0);
  if(ifaceSocket < 0)
    Fatal(" socket(PF_INET6, SOCK_DGRAM, 0): " << strerror(errno));

  int ifaceIndex = atoi(argv[1]);
  char* ifaceStrAddress = argv[2];
  struct in_addr ifaceAddress;
  ifaceAddress.s_addr = inet_addr(argv[2]);

  sockaddr_in bindAddress;
  bindAddress.sin_family = AF_INET;
  bindAddress.sin_addr.s_addr = INADDR_ANY; //ifaceAddress.s_addr;
  bindAddress.sin_port = htons(15698);
  int status = bind(ifaceSocket, (struct sockaddr*)&bindAddress,
		    sizeof(bindAddress));
  if (status < 0)
    Fatal("socketBind: " << strerror(errno) << " " << WSAGetLastError());
  
  //LowLevel::setSocketReuseAddr(ifaceSocket);
  if (setsockopt(ifaceSocket, IPPROTO_IP, IP_MULTICAST_IF, 
		 (char*)&ifaceAddress,
		 sizeof(ifaceAddress)) != 0)
    Fatal(" setsockopt IP_MULTICAST_IF: " << strerror(errno) );
  
  struct ip_mreq mreq; // not mreqn
  memset (&mreq, 0, sizeof (mreq));
  mreq.imr_multiaddr.s_addr = inet_addr("224.0.0.1");
  mreq.imr_interface = ifaceAddress;
  if (setsockopt(ifaceSocket, IPPROTO_IP, IP_ADD_MEMBERSHIP,
		 (char *) &mreq, sizeof (mreq)) != 0)
    Fatal(" setsockopt IP_ADD_MEMBERSHIP: " << strerror(errno) );


    for(;;) {
      sockaddr_in recvAddress;
      char buffer[4096];
      int bufferSize = sizeof(buffer);
      socklen_t socketSize = sizeof(recvAddress);
      int status = recvfrom(ifaceSocket, (char*)buffer, bufferSize, /*flags*/0,
			    (struct sockaddr*)&recvAddress, &socketSize);
      cout << "Received packet with " << status <<" bytes." << endl;
    }
}


//---------------------------------------------------------------------------
