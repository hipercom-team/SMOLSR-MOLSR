//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This test only checks that the include files are ok.
//---------------------------------------------------------------------------

#include "address.h"
#include "protocol_config.h"
#include "olsr_daemon.h"
#include "system_network.h"
#include "general.h"
#include "tuple.h"
#include "scheduler.h"
#include "packet.h"
#include "node.h"

int main(int argc, char** argv)
{ return 0; }

//---------------------------------------------------------------------------
