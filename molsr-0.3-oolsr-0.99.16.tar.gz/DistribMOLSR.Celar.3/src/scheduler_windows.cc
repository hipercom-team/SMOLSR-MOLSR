//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// copied from scheduler_unix.cc
// (which in turns had parts from olsrdv5/main/unix_io_scheduler.c)
// now added parts from olsrdv5/main/main.c
//---------------------------------------------------------------------------

#include <winsock2.h>
#include <windows.h>

#include "general.h"
#include "log.h"
#include "scheduler_generic.h"
#include "scheduler_unix.h"

//---------------------------------------------------------------------------

typedef std::pair<IFdHandler*,void*> HandlerInfo;
typedef std::list<HandlerInfo> HandlerList;

#include <map>

Time WindowsIOScheduler::getTime() 
{ return getTimeOfDay(); } // From: general_windows.cc

void WindowsIOScheduler::addFdHandler(IFdHandler* fdHandler, void* data)
{ handlerList.push_back( HandlerInfo(fdHandler, data) ); }

void WindowsIOScheduler::write(ostream& out)
{ scheduler->write(out); }

//---------------------------------------------------------------------------

#define WM_MY_SOCKET WM_USER+1
HWND MakeWorkerWindow(void);
static HWND gWorkerWindow = NULL; // Window to post socket,timer events to

//---------------------------------------------------------------------------

static HWND getWorkerWindow()
{
  if (gWorkerWindow == NULL)
    gWorkerWindow = MakeWorkerWindow();
  return gWorkerWindow;
}

//---------------------------------------------------------------------------

// XXX: INLIB

v_time=SetTimer(gWorkerWindow, 0,TIMER_RATE*1000,NULL);

if (v_time<0) 
  printf("SetTimer failed with error %d\n");

v_socket = WSAAsyncSelect(s,gWorkerWindow,WM_SOCKET,FD_READ|FD_WRITE);
    if (v_socket == SOCKET_ERROR)
    {
      printf("WSAAsyncSelect failed: %d\n", WSAGetLastError());
        return -1;
    }
	
    while (GetMessage (&message, NULL, 0, 0))
    {
         TranslateMessage (&message) ;
         DispatchMessage (&message) ;
    }
    
	// close winsock //
	err = WSACleanup();
	if (err == SOCKET_ERROR) {
		printf("WSACleanup failed with error %d\n", WSAGetLastError());
	}
	// socket ok just quit
	olsr_delete_all_kernel_routes(0);
	return 0;
#endif

  exit(1);
} /* main */


// XXX: INLIB
#if defined(OLSRWINDOWS)

void process(int fd)
{
	struct sockaddr_in from,localIF;
    size_t fromlen;
	int cc,bytes,error,rpt=0;
	union {
		char	buf[MAXPACKETSIZE+1];
		struct	olsr olsr;
	}inbuf;
	PacketInfo pktinfo;
	olsr_u32_t address;

	for (;;) {
		fromlen = sizeof (from);
 		cc = recvfrom(fd, &inbuf, sizeof (inbuf),0,&from,&fromlen);
		if (cc <= 0) {
			break;
		}
		
		if (fromlen != sizeof (struct sockaddr_in))
			break;


	    get_main_address(&address);		
		error = WSAIoctl(fd,SIO_ROUTING_INTERFACE_QUERY,(&from),sizeof(from),
					 &localIF,sizeof(localIF),&bytes,NULL,NULL);

		if(error!=0) {
			error=WSAGetLastError();
			if(error == WSAEHOSTUNREACH) 
				localIF.sin_addr.s_addr=address;
            else{
				printf("SIO_ROUTING_INTERFACE_QUERY failed with: %d\n",error);
				break;
			}
		}
		
		
		pktinfo.src_address=from.sin_addr.s_addr;
//		pktinfo.dst_address=address;           /*recheck this statement*/
		pktinfo.dst_address=localIF.sin_addr.s_addr;
		pktinfo.iface_address=localIF.sin_addr.s_addr;  
		pktinfo.port=from.sin_port;
		
		olsr_input(&pktinfo, &inbuf.olsr, cc);		
	}
}

// XXX: INLIB
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
  switch (uMsg)
  {
	case WM_TIMER :   // Timer message comming !
		timer(1);
		break;
	case WM_SOCKET :  // Socket message comming !
		switch(WSAGETSELECTEVENT(lParam))
		{
		  case FD_READ : 
			process(wParam); 
			break;
		  case FD_WRITE :
			break;
		}
		break;
  }
}

//---------------------------------------------------------------------------

// XXX: INLIB
//
// Function: MakeWorkerWindow
//
// Description:
//    Create a hidden window to receive our socket messages.
//
HWND MakeWorkerWindow(void)
{
  WNDCLASS wndclass;
  CHAR *ProviderClass = "AsyncSelect";
  HWND Window;
  
  wndclass.style = CS_HREDRAW | CS_VREDRAW ;
  wndclass.lpfnWndProc = (WNDPROC)WindowProc;
  wndclass.cbClsExtra = 0;
  wndclass.cbWndExtra = 0;
  wndclass.hInstance = NULL;
  wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
  wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
  wndclass.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
  wndclass.lpszMenuName = NULL;
  wndclass.lpszClassName = ProviderClass;

  if (RegisterClass(&wndclass) == 0)
    Fatal("RegisterClass() failed with error #" << GetLastError());

  // Create a window.

  if ((Window = CreateWindow(
			     ProviderClass,
			     "",
			     WS_OVERLAPPEDWINDOW,
			     CW_USEDEFAULT,
			     CW_USEDEFAULT,
			     CW_USEDEFAULT,
			     CW_USEDEFAULT,
			     NULL,
			     NULL,
			     NULL,
			     NULL)) == NULL)
    Fatal("CreateWindow() failed with error #" <<GetLastError());
  return Window;
}

//---------------------------------------------------------------------------


void WindowsIOScheduler::waitForIO(Time maxTime)
{
#if 0
  int i,j;
  fd_set fdSet[3]; // (note: in cygwin/winsock2, this is not a bitmap)
  int maxFD = -1;
  int status;
  sigset_t sigset;
  //struct { IFdHandler* handler; } handlerTable [FD_SETSIZE][3];
  std::map<FileDescriptor, IFdHandler*> handlerTable[3];

  const int Input = 0, Output = 1, Except = 2;
  // update the "lastFD"
#define ADD_HANDLER(x,h) do { \
       FileDescriptor fd = h->getFileDescriptor(); \
       if(fd>maxFD) maxFD = fd; \
       FD_SET(fd, &(fdSet[x])); \
   handlerTable[x].insert(std::pair<FileDescriptor, IFdHandler*>(fd, h)); \
    } while(0)

  // set fd_set/s 
  maxFD = 0;
  for(j=0;j<3;j++) {
    FD_ZERO(&(fdSet[j]));
    for(HandlerList::iterator it = handlerList.begin();
	it!= handlerList.end(); it++) 
      {
	IFdHandler* handler = (*it).first;
	if (j == Input) {
	  if (handler->waitingForInput())
	    ADD_HANDLER(Input, handler);
	} else if (j == Output) {
	  if (handler->waitingForOutput()) 
	    ADD_HANDLER(Output, handler);
	} else if (j == Except) {
	  if (handler->waitingForExcept())
	    ADD_HANDLER(Except, handler);
	} else Fatal("Impossible select set index");
      }
  }

  /* select */
  struct timeval tv;
  tv.tv_sec = (unsigned int)maxTime;
  tv.tv_usec = (unsigned int) ((maxTime - tv.tv_sec)*(1e6 - 1));
  assert( tv.tv_usec < 1000000 );
  status = select(maxFD+1, fdSet+0, fdSet+1, fdSet+2, &tv);

  if (status < 0) {
    if (errno != EINTR) // XXX: check for cygwin/Windows
      Warn("select:" << strerror(errno));
  } else if (status > 0) {
    for(j=0;j<3;j++) {
      for(std::map<FileDescriptor, IFdHandler*>::iterator it 
	    = handlerTable[j].begin(); it != handlerTable[j].end(); it++) {
	//for(i=0;i<FD_SETSIZE;i++) { // XXX: not optimized
	if(FD_ISSET((*it).first, &(fdSet[j]))) {
	  IFdHandler* handler = (*it).second;
          assert( handler != NULL );
	  if(j == Input) handler->handleInput();
	  else if (j == Output) handler->handleOutput();
	  else if (j == Except) handler->handleExcept();
	  else Fatal("Impossible select set index");
          FD_CLR((*it).first, &(fdSet[j]));
        }
      }
    }
  }
#endif
  //return status != 0; /* time out */

  Fatal("Not implemented yet!");
}

//---------------------------------------------------------------------------




//---------------------------------------------------------------------------
