//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "qos.h"

//---------------------------------------------------------------------------
// QoS Message
//---------------------------------------------------------------------------

// Result between 0 and 0xffff (inclusive)
static inline int qosLoadToInt(double load)
{ return (unsigned int)(load * ((1<<16)-1)); }

// Result between 0.0 and 1.0 (inclusive)
static inline double intToQosLoad(int loadAsInt)
{ return ((double)loadAsInt) / ((1<<16)-1); }

// Result between 0 and 0xff (inclusive)
static inline int qosLoadToChar(double load) {
  return (unsigned int)(load * ((1<<8) - 1));
}

// Result between 0.0 and 1.0 (inclusive)
static inline double charToQosLoad(int loadAsChar) {
  return ((double)loadAsChar) / ((1<<8)-1);
}

bool QosMessage::isHello()
{
  assert( header->messageType == QOS_HELLO_MESSAGE
	  || header->messageType == QOS_TC_MESSAGE );
  return header->messageType == QOS_HELLO_MESSAGE;
}

IMessageContent* QosMessage::clone()
{
  QosMessage* result = new QosMessage(addressFactory);
  result->qosInfo = qosInfo;
  result->qosANSN = qosANSN;
  result->neighborQosList = neighborQosList;
  result->header = header->clone(false);
  result->header->content = result;
  return result;
}

void QosInfo::write(ostream& out) const
{ out << "qos:" << qosLoad << "/" << qosLab
      << ",be:" << beLoad << "/" << beLab; }

static inline ostream& operator << (ostream& out, QosInfo& qosInfo)
{ out << "qos:" << qosInfo.qosLoad << "/" << qosInfo.qosLab
      << ",be:" << qosInfo.beLoad << "/" << qosInfo.beLab; return out; }

void QosMessage::write(ostream& out) const
{
  out << "QoS "; qosInfo.write(out); out << " ";
  bool isFirst = true;
  for (ITER(std::list<AddressAndQosInfo>, it, 
	    const_cast< list<AddressAndQosInfo>& >(neighborQosList))) {
    if (!isFirst) out << ";";
    else isFirst = false;
    out << (*it).address << "="; 
    (*it).qos.write(out);
  }
  out << "";
}

//--------------------------------------------------

void QosMessageHandler::processMessage(/*borrowed*/ Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  QosMessage* qosMessage = dynamic_cast<QosMessage*>(messageContent);
  if (qosMessage->isHello()) {
    node->processContentiousQosHelloMessage(*qosMessage);
    node->processQosHelloMessage(*qosMessage);
  }
  else node->processQosTCMessage(*qosMessage);
}

void QosMessageHandler::considerForwardMessage
(/*borrowed*/ Message* message, string& info)
{ 
  if (message->messageType == QOS_TC_MESSAGE)
    node->getPacketManager()->defaultForwardingMessage(message, info);
}

void popQosInfo(PacketBuffer& packetBuffer, QosInfo& result)
{
  unsigned int qosLoad = packetBuffer.popUInt8();
  unsigned int beLoad  = packetBuffer.popUInt8();
  unsigned int qosLab  = packetBuffer.popUInt8();
  unsigned int beLab   = packetBuffer.popUInt8();

  result.qosLoad = charToQosLoad(qosLoad);
  result.beLoad  = charToQosLoad(beLoad);
  result.qosLab  = charToQosLoad(qosLab);
  result.beLab   = charToQosLoad(beLab);
}

IMessageContent* 
QosMessageHandler::parseMessageContent(Message* message)
{
  QosMessage* result = new QosMessage(node->getAddressFactory());
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());  

  if (message->messageType == QOS_HELLO_MESSAGE) {
    result->qosANSN = 0; // not defined for Hello
    popQosInfo(buffer, result->qosInfo);
  } else { // QOS_TC_MESSAGE
    result->qosANSN = buffer.popUInt16();
    result->qosInfo.qosLoad = 0.0;
    result->qosInfo.beLoad  = 0.0;
    result->qosInfo.qosLab  = charToQosLoad( buffer.popUInt8() );
    result->qosInfo.beLab   = charToQosLoad( buffer.popUInt8() );
  }

  while (buffer.size()>0) {
    AddressAndQosInfo currentInfo;
    currentInfo.address = buffer.popAddress();
    popQosInfo(buffer, currentInfo.qos);
    result->neighborQosList.push_back(currentInfo);
  }
  delete message->packedContent; // XXX: this can be factored
  message->packedContent = NULL;
  message->content = result;
  result->header = message;
  return result;
}

static const int QosInfoSize = 
        2   // [load]
      + 2;  // [lab]

static int getQosMessageSize(int addressSize, int nbAddress)
{ return QosInfoSize + (nbAddress * (addressSize + QosInfoSize)); }


void packQosInfo(QosInfo& info, PacketBuffer& packetBuffer)
{
  packetBuffer.pushUInt8( qosLoadToChar(info.qosLoad) );
  packetBuffer.pushUInt8( qosLoadToChar(info.beLoad) );
  packetBuffer.pushUInt8( qosLoadToChar(info.qosLab) );
  packetBuffer.pushUInt8( qosLoadToChar(info.beLab) );
}

void QosMessageHandler::packMessageContent
(IMessageContent* message, int maximumMessageSize,
 MemoryBlock*& packedResult, IMessageContent*& messageRemainingResult,
 PackingInfo& packingInfo)
{
  QosMessage* m = dynamic_cast<QosMessage*>(message);
  //int addressSize = node->getAddressFactory()->getAddressSize();

  PacketBuffer buffer;
  //int initialPos = buffer.getPosition();
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message->header);

  if (m->header->messageType == QOS_HELLO_MESSAGE) {
    packQosInfo(m->qosInfo, buffer);
  } else {
    buffer.pushUInt16(m->qosANSN); // @@XXX
    buffer.pushUInt8(qosLoadToChar(m->qosInfo.qosLab)); // @@XXX
    buffer.pushUInt8(qosLoadToChar(m->qosInfo.beLab)); // @@XXX
  }

  //XXX splitting is not supported
  for (ITER(std::list<AddressAndQosInfo>, it, m->neighborQosList)) {
    buffer.packAddress((*it).address);
    packQosInfo((*it).qos, buffer);
  }
  messageRemainingResult = NULL;
 
  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  packedResult = buffer.getContent();
}

void QosMessageHandler::adjustMessageSize(IMessageContent* message)
{
  QosMessage* m = dynamic_cast<QosMessage*>(message);
  int addressSize = node->getAddressFactory()->getAddressSize();

  m->header->messageSize = 
    MessageHeaderWithoutAddressSize + addressSize // message header
    + getQosMessageSize(addressSize, m->neighborQosList.size());
  m->header->minMessageSize =  m->header->messageSize;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

QosNode::QosNode() : ParentQosNode(), 
		     contentiousQosSet(this), 
		     topologyQosSet(this)
{
  packetCounter       = NULL;
  hasLastCounterTime  = false;
  lastQosPacketCount  = 0;
  lastQosByteCount    = 0;
  lastOlsrPacketCount = 0;
  lastOlsrByteCount   = 0;
  lastBePacketCount   = 0;
  lastBeByteCount     = 0;
  lastCounterTime     = -1;

  currentQosLab    = 0.0; // will be recomputed first anyway
  currentBeLab     = 0.0; // will be recomputed first anyway
  currentMinQosLab = 0.0; // will be recomputed first anyway
  currentMinBeLab  = 0.0; // will be recomputed first anyway
  currentQosANSN   = 0;

  currentQosLoad   = 0.0;
  currentBeLoad    = 0.0;
  //currentQos.load = drawDouble(0.5);
  //currentQos.availableBw = drawDouble(0.5);
}

//---------------------------------------------------------------------------

void QosNode::start()
{
  if (protocolConfig->useQos) {
    QosMessageHandler* qosHelloMessageHandler = new QosMessageHandler(this);
    QosMessageHandler* qosTCMessageHandler = new QosMessageHandler(this);
    packetManager->addMessageHandler(QOS_HELLO_MESSAGE,
				     qosHelloMessageHandler);
    packetManager->addMessageHandler(QOS_TC_MESSAGE, qosTCMessageHandler);

    ExternalChannelConfig* channel 
      = protocolConfig->getChannelByName("qsr-exchange");
    if (channel == NULL) {
      Fatal("No qsr-exchange channel found in configuration. With QoS enabled "
	    "the configuration file must include one line like:\n"
	    "  external-channel qsr-exchange <port-in> <port-out>\n");
    }
    
    if (externalCommunication == NULL) {
      Fatal("No external communication manager, internal problem, "
	    " communication channel to QSR cannot be open.\n");
    }
    
    channelToQsr = externalCommunication->open
      (channel->channelIn, channel->channelOut,
       new QSRExternalMessageReceiver(this));
  }
  ParentQosNode::start();
}

void QosNode::handleQSRMessage(/*owned*/ MemoryBlock* message)
{
  string messageContent((char*)message->data, message->size);
  std::list<QosFlow> qosFlowList;
  bool ok = flowTable.unpackFlowList(addressFactory, messageContent,
				     qosFlowList);
  if (ok) {
    for (ITER(std::list<QosFlow>, it, qosFlowList)) {
      handleRequest(*it);
    }
  }
}

void QosNode::sendFlowTable()
{
  string packedTable = flowTable.pack();

#if 0  
  MemoryBlock* message = new MemoryBlock(packedTable.size() + 4 /*header*/);
  message->data[0] = (char)QSR_MESSAGE_VERSION;
  message->data[1] = (char)QSR_ACTION_REPLY;
  message->data[2] = 0; // reserved
  message->data[3] = 0; // reserved
  memcpy(message->data + 4, packedTable.data(), packedTable.size());
#endif

  MemoryBlock* message = new MemoryBlock((octet*)packedTable.data(),
					 packedTable.size(), true);

  // DANG -- action must be set to 1
  message->data[0] = (char)QSR_MESSAGE_VERSION;
  message->data[1] = (char)QSR_ACTION_REPLY;
  message->data[2] = 0; // reserved;
  message->data[3] = 0; // reserved;

  assert( channelToQsr != NULL );
  channelToQsr->handleMessage(message);
  delete message;
}

//---------------------------------------------------------------------------

void QosNode::handleRequest(QosFlow& flowRequest)
{
  Time expireTime = currentTime + protocolConfig->qosHoldTime;
  //#warning remove logQosTable
  //  logQosTable(*log->out); // XXX
  DD(lQos, "[qos]", "request " << flowRequest);
  flowTable.expireAllFlow(getCurrentTime());
  QosFlow* existingFlow = flowTable.findFlow(flowRequest);
  if (existingFlow == NULL) {
    D(*log, lQos, " new-flow ");

    QosFlow* newFlow = flowTable.addFlow
      (*(QosFlowDef*)&flowRequest, flowRequest.bandwidth, expireTime);
    //*newFlow = flowRequest; // XXX: reinterpret_cast
    if (!computeFlowRoute(*newFlow)) {
      D(*log, lQos, " rejected" << endl);
      newFlow->bandwidth = 0;
      newFlow->currentRoute.clear();
    } else {
      D(*log, lQos, " accepted" << endl);
    }
    //    Warn("should to gratuitous send");
    sendFlowTable();
  } else {
    existingFlow->expireTime = expireTime;
    // and FlowTable will be send after the next Hello processing event
    //Warn("XXX: not implemented yet - what if different bandwidth");
  }
}

//---------------------------------------------------------------------------

void QosNode::processQosTCMessage(QosMessage& message)
{
  Message& header = *message.header;
  Address sendMainAddress = ifaceToMainAddress(header.sendIfaceAddress);

  // XXX: DANG's HACKING
  //  D(*log, lQos, getRealTime() << " [process-qos-tc-message] "
  //    << getMainAddress() << " " << sendMainAddress << " " << header.originatorAddress << " " << message.qosANSN << " pre-processing " << endl);

  if (!isSymmetricNeighbor(sendMainAddress)) {
    // XXX: DANG's HACKING
    D(*log, lQos, getRealTime() << " [process-qos-tc-message] "
      << getMainAddress() << " " << sendMainAddress << " tc rejected :: from asymmetric neighbor " << endl);
    return; // we will get the message from a symmetric neighbor...
            // ... so avoid processing it several times
  }

  Time currentTime = getCurrentTime();
  Time validityTime = header.getValidityTime();
  
  /*
  if(topologySet.findFirst_obsolete_tuple(header.originatorAddress,
					  message.qosANSN)) {
    // XXX: DANG's HACKING
    D(*log, lQos, getRealTime() << " [process-qos-tc-message] "
      << getMainAddress() << " " << sendMainAddress << " tc rejected :: obsolete " << endl);
    return;
  }
  */

  QosSet::TupleIterator it_fo
    = topologyQosSet.getIter(); // find First obsolete tuple
  bool notFoundObsolete = true;
  while (!(it_fo.isDone()) && notFoundObsolete) {
    QosTuple* topoTuple_fo = it_fo.getCurrent();
    if ((topoTuple_fo->mainAddress == header.originatorAddress)
	&& _ansnGreater(topoTuple_fo->qosANSN, message.qosANSN))
      notFoundObsolete = false;
    else it_fo.next();
  }

  if (!notFoundObsolete) {
    // XXX: DANG's HACKING
    D(*log, lQos, getRealTime() << " [process-qos-tc-message] "
      << getMainAddress() << " " << sendMainAddress << " tc rejected :: obsolete " << endl);
    return;
  }

  /*
    XXX: no need
  QosSet::TupleIterator it
    = topologyQosSet.getIter(); //IteratorArg(header->originatorAddress));
  while(!it.isDone()) {
    QosTuple* topoTuple = it.getCurrent();
    if (topoTuple->mainAddress == header.originatorAddress) 
      //       && _ansnGreater(topoTuple->qosANSN, message.qosANSN))
      // XXX: otherwise, should be _ansnGreater(message.qosANSN, topoTuple->qosANSN))
      it.removeAndDeleteCurrentAndDoNext();
    else it.next();
  }
  */

  QosTuple* qosTuple = topologyQosSet.findFirst(header.originatorAddress);

  if (qosTuple == NULL) {
    qosTuple = new QosTuple(this);
    qosTuple->mainAddress = header.originatorAddress;
    //qosTuple-> = header->;
    topologyQosSet.add(qosTuple);
  }
  qosTuple->qos.qosLoad = message.qosInfo.qosLoad;  // normally must be ZERO
  qosTuple->qos.beLoad  = message.qosInfo.beLoad;   // normally must be ZERO
  qosTuple->qos.qosLab  = message.qosInfo.qosLab;
  qosTuple->qos.beLab   = message.qosInfo.beLab;
  qosTuple->qosANSN = message.qosANSN;
  qosTuple->expireTime = currentTime + validityTime;
  qosTuple->neighborQosList.clear();

  for(ITER(std::list<AddressAndQosInfo>, it, message.neighborQosList)) {
    qosTuple->neighborQosList.push_back(*it);
  }

  D(*log, lQos, getRealTime() << " [process-qos-tc-message] "
    << getMainAddress() << " " << message.qosANSN << " " << message << endl);
}

void QosNode::processContentiousQosHelloMessage(QosMessage& message) {
  Message& header = *message.header;
  Address sendMainAddress = ifaceToMainAddress(header.sendIfaceAddress);

  Time currentTime = getCurrentTime();
  Time validityTime = header.getValidityTime();

  QosTuple* qosTuple = contentiousQosSet.findFirst(header.originatorAddress);

  if (qosTuple == NULL) {
    qosTuple = new QosTuple(this);
    qosTuple->mainAddress = header.originatorAddress;
    contentiousQosSet.add(qosTuple);
  }

  qosTuple->qos.qosLoad = message.qosInfo.qosLoad;
  qosTuple->qos.beLoad  = message.qosInfo.beLoad;
  qosTuple->qos.qosLab  = message.qosInfo.qosLab;
  qosTuple->qos.beLab   = message.qosInfo.beLab;
  qosTuple->expireTime = currentTime + validityTime;

  for(ITER(std::list<AddressAndQosInfo>, it, message.neighborQosList)) {
    if (isOneOfOurIfaceAddress((*it).address))
      continue;

    qosTuple = contentiousQosSet.findFirst((*it).address);
    if (qosTuple == NULL) {
      qosTuple = new QosTuple(this);
      qosTuple->mainAddress = (*it).address;
      contentiousQosSet.add(qosTuple);
    }
    qosTuple->qos.qosLoad = (*it).qos.qosLoad;
    qosTuple->qos.beLoad  = (*it).qos.beLoad;
    qosTuple->qos.qosLab  = (*it).qos.qosLab;
    qosTuple->qos.beLab   = (*it).qos.beLab;
    qosTuple->expireTime  = currentTime + validityTime;
  }
}

void QosNode::processQosHelloMessage(QosMessage& message)
{
  Message& header = *message.header;

  D(*log, lQos, getRealTime() << " [process-qos-hello-message] "
    << getMainAddress() << " " << header.originatorAddress << " ");

  int neighborNotFound = 0;

  NeighborTuple* neighTuple = neighborSet.findFirst_MainAddr
    (header.originatorAddress);
  if (neighTuple == NULL) {
    D(*log, lQos, "not-known" << endl);
    return;
  }

  neighTuple->hasQosInfo = true;
  neighTuple->qosLoad = message.qosInfo.qosLoad;
  neighTuple->beLoad  = message.qosInfo.beLoad;
  neighTuple->qosLab  = message.qosInfo.qosLab;
  neighTuple->beLab   = message.qosInfo.beLab;

  D(*log, lQos, "(qos:" << neighTuple->qosLoad << "/" << neighTuple->qosLab << ",be:" << neighTuple->beLoad << "/" << neighTuple->beLab << ") ");
  
  bool isFirst = true;
  for (ITER(std::list<AddressAndQosInfo>, it, message.neighborQosList)) {
    AddressAndQosInfo info = (*it);
    if (isOneOfOurIfaceAddress((*it).address))
      continue;
    TwoHopNeighborTuple* twoHop 
      = twoHopNeighborSet.findFirst_1hopAddr_2hopAddr
      (header.originatorAddress, ifaceToMainAddress(info.address));
    if (!isFirst) { D(*log, lQos, ","); }
    else isFirst = false;

    if (twoHop != NULL) {
      D(*log, lQos, twoHop->N_2hop_addr);
      twoHop->hasQosInfo = true;
      twoHop->qosLoad = (*it).qos.qosLoad;
      twoHop->beLoad  = (*it).qos.beLoad;
      twoHop->qosLab  = (*it).qos.qosLab;
      twoHop->beLab   = (*it).qos.beLab;
      D(*log, lQos, "(qos:" << twoHop->qosLoad << "/" << twoHop->qosLab << ",be:" << twoHop->beLoad << "/" << twoHop->beLab << ") ");
    } else {
      D(*log, lQos, "!" << info.address);
    }
  }
  D(*log, lQos, endl);
}

//---------------------------------------------------------------------------

void QosNode::computeLAB()
{
  computeCurrentLoad();
  double localQosLoad = currentQosLoad;
  double localBeLoad  = currentBeLoad;
  double olsrOverheadThreshold = 20.0/protocolConfig->qosMediumCapacity;
  currentQosLab = 0.9; // Use 90 percent of maximum channel capacity
  currentBeLab  = 0.9; // Use 90 percent of maximum channel capacity
  currentMinQosLab = 0.9;  // Use 90 percent of maximum channel capacity
  currentMinBeLab  = 0.9;  // Use 90 percent of maximum channel capacity

  int nbBeNodes = 1;
  listSortedPlus_pt lSP = insertLspValue(localBeLoad, NULL);

  for(QosSet::TupleIterator it = contentiousQosSet.getIter();
      !it.isDone(); it.next()) {
    QosTuple* current = it.getCurrent();
    currentQosLab -= current->qos.qosLoad;
    lSP = insertLspValue(current->qos.beLoad, lSP);
    nbBeNodes++;
    if (current->qos.qosLoad > olsrOverheadThreshold) {
      currentMinQosLab = std::min(currentMinQosLab, current->qos.qosLab);
      currentMinBeLab  = std::min(currentMinBeLab, current->qos.beLab);
    }
  }

  /*
  AddressMap<bool> visitedTable;
  for (NeighborSet::TupleIterator it = neighborSet.getIter(); 
       !it.isDone(); it.next()) {
    NeighborTuple* current = (*it);
    if (current->hasQosInfo 
	&& visitedTable.get(current->N_neighbor_main_addr) == NULL) {
      visitedTable.add(current->N_neighbor_main_addr, true);
      currentQosLab -= current->qosLoad;
      lSP = insertLspValue(current->beLoad, lSP);
      nbBeNodes++;
      if (current->qosLoad > olsrOverheadThreshold) {
	currentMinQosLab = std::min(currentMinQosLab, current->qosLab);
	currentMinBeLab  = std::min(currentMinBeLab, current->beLab);
      }
    }
  }

  for (TwoHopNeighborSet::TupleIterator it = twoHopNeighborSet.begin(); 
       it != twoHopNeighborSet.end(); it.next()) {
    TwoHopNeighborTuple* current = (*it);
    if (current->hasQosInfo 
	&& visitedTable.get(current->N_2hop_addr) == NULL) {
      visitedTable.add(current->N_2hop_addr, true);
      currentQosLab -= current->qosLoad;
      lSP = insertLspValue(current->beLoad, lSP);
      nbBeNodes++;
      if (current->qosLoad > olsrOverheadThreshold) {
	currentMinQosLab = std::min(currentMinQosLab, current->qosLab);
	currentMinBeLab  = std::min(currentMinBeLab, current->beLab);
      }
    }
  }
  */

  currentQosLab -= localQosLoad;
  if (currentQosLab < 0.0)
    currentQosLab = 0.0;
  currentMinQosLab = std::min(currentMinQosLab, currentQosLab);

  currentBeLab = currentMinQosLab;
  listSortedPlus_pt lIt = lSP;
  while ((lIt != NULL) && (currentBeLab > (double)(lIt->value * nbBeNodes))) {
    currentBeLab -= lIt->value;
    nbBeNodes--;
    lIt = lIt->pNext;
  }
  if (nbBeNodes == 0)
    currentBeLab = currentMinQosLab - (currentBeLab * 0.3);
  else
    currentBeLab = currentBeLab/nbBeNodes * 0.7;

  currentMinBeLab = std::min(currentMinBeLab, currentBeLab);

  freeLsp(lSP);

  setTcParameters();
}

void QosNode::setTcParameters() {
  double min2HopLab = currentMinBeLab * exp(currentMinBeLab - 0.9);
  //  double beRate = min2HopLab / 3.0 * exp(currentMinLAB - 1.0) / alpha;
  double beRate = min2HopLab * protocolConfig->qosMediumCapacity / protocolConfig->qosFamousAlpha;
  if (beRate < 1.0)
    beRate = 1.0;
  packetCounter->setTcInfo((int)beRate, protocolConfig->qosTcHyst);

  DD(lQos, "[set-tc-parameters]", "beRate=" << beRate << endl);
}

void QosNode::generateQosHello()
{
  updateCurrentTime();
  preEvent("gen-qos-hello-generation");

  // Create QoS Hello message
  QosMessage* m = new QosMessage(addressFactory);

  computeLAB();
  m->qosANSN = 0; // not defined for QoS Hello messages
  m->qosInfo.qosLoad = currentQosLoad;
  m->qosInfo.beLoad  = currentBeLoad;
  m->qosInfo.qosLab  = currentQosLab;
  m->qosInfo.beLab   = currentBeLab;
  assert( inrange(0.0-Epsilon, currentQosLoad, 1.0+Epsilon) );
  assert( inrange(0.0-Epsilon, currentBeLoad, 1.0+Epsilon) );
  assert( inrange(0.0-Epsilon, currentQosLab, 1.0+Epsilon) );
  assert( inrange(0.0-Epsilon, currentBeLab, 1.0+Epsilon) );

  //--

  for (NeighborSet::TupleIterator it = neighborSet.getIter();
       !it.isDone();it.next()) {
    NeighborTuple* neighTuple = (*it);
    AddressAndQosInfo info;
    info.address = neighTuple->N_neighbor_main_addr;
    if (neighTuple->hasQosInfo) {
      info.qos.qosLoad = neighTuple->qosLoad;
      info.qos.beLoad  = neighTuple->beLoad;
      info.qos.qosLab  = neighTuple->qosLab;
      info.qos.beLab   = neighTuple->beLab;
      m->neighborQosList.push_back(info);
    }
  }

  // Put the header and send it
  Time expirationTime = protocolConfig->NEIGHB_HOLD_TIME;
  Message* message = new Message
    (QOS_HELLO_MESSAGE,
     toMantissaExponentByte(expirationTime), // vtime
     getMainAddress(), // originator address
     1, // ttl
     0); // hop count

  m->header = message;
  message->content = m;
  message->maxTime = getCurrentTime();

  D(*log, lQos, getRealTime() << " [generate-qos-hello-message] "
    << getMainAddress() << " " << (*message) << endl);
  packetManager->sendOneMessage(NULL, message);

  computeAllQosRoute(); 

  postEvent("gen-qos-hello-generation");
}

void QosNode::generateQosTC()
{
  updateCurrentTime();
  preEvent("gen-qos-tc-generation");

  // Create QoS TC message
  QosMessage* m = new QosMessage(addressFactory);

  // The ANSN and M2LAB (current load is not used, actually)
  m->qosANSN = currentQosANSN;
  currentQosANSN = (currentQosANSN + 1) % MaxANSN;
  m->qosInfo.qosLoad = currentQosLoad; // not used actually
  m->qosInfo.beLoad  = currentBeLoad;  // not used actually
  m->qosInfo.qosLab  = currentMinQosLab;
  m->qosInfo.beLab   = currentMinBeLab;

  // Put the LAB from the MPRS (for now: all the neighbors)
  for (NeighborSet::TupleIterator it = neighborSet.getIter();
       !it.isDone();it.next()) {
    NeighborTuple* t = it.getCurrent();
    if (t->hasQosInfo && (t->N_status == SYM)) {
      AddressAndQosInfo neighInfo;
      neighInfo.address = t->N_neighbor_main_addr;
      neighInfo.qos.qosLoad = t->qosLoad;
      neighInfo.qos.beLoad  = t->beLoad;
      neighInfo.qos.qosLab  = t->qosLab;
      neighInfo.qos.beLab   = t->beLab;
      m->neighborQosList.push_back(neighInfo);
    }
  }

  // Put the header and send it
  Time expirationTime = protocolConfig->TOP_HOLD_TIME;
  Message* message = new Message
    (QOS_TC_MESSAGE,
     toMantissaExponentByte(expirationTime), // vtime
     getMainAddress(), // originator address
     MaxTTL, // ttl
     0); // hop count

  m->header = message;
  message->content = m;
  message->maxTime = getCurrentTime();

  D(*log, lQos, getRealTime() << " [generate-qos-tc-message] "
    << getMainAddress() << " " << (*message) << endl);
  packetManager->sendOneMessage(NULL, message);

  postEvent("gen-qos-tc-generation");
}

//---------------------------------------------------------------------------

void QosNode::performTupleExpiration()
{
  contentiousQosSet.removeAndDeleteExpired( getCurrentTime() );
  topologyQosSet.removeAndDeleteExpired( getCurrentTime() );
  ParentQosNode::performTupleExpiration();
}

void QosNode::getNextExpireTime(Time& nextExpireTime, bool& hasExpireTime)
{
  ParentQosNode::getNextExpireTime(nextExpireTime, hasExpireTime);
  //updateMinExpireTime(getCurrentTime(), nextExpireTime, hasExpireTime, 
  //neighborQosSet);
  updateMinExpireTime(getCurrentTime(), nextExpireTime, hasExpireTime, 
		      topologyQosSet);
}

//---------------------------------------------------------------------------

void QosNode::logQosTable(ostream& out)
{
  out << getRealTime() << " [qos-info] " << getMainAddress() 
      << " qos_load=" << currentQosLoad
      << " be_load=" << currentBeLoad
      << " qos_lab=" << currentQosLab 
      << " be_lab=" << currentBeLab
      << " m2_qoslab=" << currentMinQosLab
      << " m2_belab=" << currentMinBeLab
      << endl;


  //out << getRealTime() << " [neighbor-qos-table] " << getMainAddress()<<" "; 
  //neighborQosSet.write(out, true);
  //out << endl;
  
  out << getRealTime() << " [topology-qos-table] " << getMainAddress() << " ";
  topologyQosSet.write(out, false);
  out << endl;

  out << getRealTime() << " [qos-flow-table] " << getMainAddress() << " ";
  flowTable.write(out);
  out << endl;
}

void QosNode::logState(ostream& out, bool noEnd)
{
  ParentQosNode::logState(out, true);
  logQosTable(out);
  if (!noEnd) {
    out << getRealTime() << " [state-end] " << getMainAddress() << endl;
  }
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void QosTuple::write(ostream& out, bool isNeighborQosSet)
{
  Time currentTime = node->getCurrentTime();
  out << mainAddress << "=" << qos << ".[";
  bool isFirst = true;
  for(ITER(std::list<AddressAndQosInfo>, it, neighborQosList)) {
    if (!isFirst) out << ",";
    else isFirst = false;
    out << (*it).address << "=" << (*it).qos;
  }
  out << "]";
  writeExpireTime(out, currentTime, expireTime);
}

void QosSet::write(ostream& out, bool isNeighborQosSet)
{
  bool isFirst = true;
  for(QosSet::TupleIterator it = getIter(); !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    QosTuple* t = it.getCurrent();
    t->write(out,isNeighborQosSet);
  }
}

//---------------------------------------------------------------------------

template class BasicTupleSet<QosTuple>;
template class BasicTupleSetIterator<QosTuple>;

// XXX: remove
//static QosNode qosNode;
//static QosSet qosSet(&qosNode);

#if 0
// XXX: remove
double QosNode::getCurrentLoad()
{
 
}
#endif

//---------------------------------------------------------------------------

void QosNode::computeAllQosRoute()
{
  flowTable.expireAllFlow(getCurrentTime());

  // XXX: clear used bandwidth?

  std::list<QosFlow*> blockedFlowList;
  for (ITER(QosFlowSet, it, flowTable.qosFlowTable)) {
    if (!computeFlowRoute(*(*it))) {
      //blockedFlowList.push_back(*it);
      //      (*it)->bandwidth = 0;

      // Qos flow route hysteresis
      (*it)->routeQuality--;
      if ((*it)->routeQuality <= 0) {
	(*it)->bandwidth = 0;
	(*it)->currentRoute.clear();
      }
    }
    else {
      (*it)->routeQuality = 6;
    }
  }

  // Note: not used, see above.
  for (ITER(std::list<QosFlow*>, it, blockedFlowList))
    flowTable.deleteFlow(*it);

  sendFlowTable();
}

//---------------------------------------------------------------------------

bool QosNode::_computeQosFlowRoute(QosFlow& flow)
{
  // *never* compute routes for another flow, or a flow on another interface
  if (!(flow.sourceAddress == getMainAddress())) {
    D(*log, lQos, getRealTime() << " [compute-qos-flow-route] "
      << getMainAddress() << " " << flow.sourceAddress << " " << flow.destinationAddress << " result=FALSE :: source!=MainAddress " << endl);
    return false;
  }

  if (flow.sourceAddress == flow.destinationAddress) {
    D(*log, lQos, getRealTime() << " [compute-qos-flow-route] "
      << getMainAddress() << " " << flow.sourceAddress << " " << flow.destinationAddress << " result=FALSE :: source==destination " << endl);
    return false;
  }

  // check if the route exists, even in Best Effort mode
  RoutingTuple* routingTuple 
    = ParentQosNode::getRoute(flow.destinationAddress);
  if (routingTuple == NULL) {
    D(*log, lQos, getRealTime() << " [compute-qos-flow-route] "
      << getMainAddress() << " " << flow.sourceAddress << " " << flow.destinationAddress << " result=FALSE :: route not exist even in Best Effort " << endl);
    return false;
  }

  // check if the current route is valid
  bool routeStillValid = true;
  if (flow.currentRoute.empty() ||  // if no route then must create new route
      (flow.currentRoute.size() < 2))  // route must have at least src and dest
    routeStillValid = false;

  // check if each single link of the route is still valid
  if (routeStillValid) {
    bool firstRound = true;
    Address lastHop;
    for (std::list<Address>::iterator it = flow.currentRoute.begin();
	 (it != flow.currentRoute.end()) && routeStillValid; it++) {
      if (!firstRound) {
	if (lastHop == flow.sourceAddress) {
	  // check if ``(*it)'' is still in my neighborhood
	  NeighborTuple* neighTuple = neighborSet.findFirst_MainAddr(*it);
	  if (neighTuple == NULL)
	    routeStillValid = false;
	}
	else {
	  // check if the link ``(lastHop, (*it))'' is still in topologyQosSet
	  // XXX: careful with the 2nd hop, as it is not always in the topologyQosSet
	  // XXX: need to be changed when MPRs do not advertise all neighbors as MPR Selectors
	  QosTuple* qosTuple = topologyQosSet.findFirst(lastHop);
	  if (qosTuple == NULL)
	    routeStillValid = false;
	  else {
	    bool foundNextHop = false;
	    for (std::list<AddressAndQosInfo>::iterator mprsit = qosTuple->neighborQosList.begin(); (mprsit != qosTuple->neighborQosList.end()) && !foundNextHop; mprsit++) {
	      if (mprsit->address == (*it))
		foundNextHop = true;
	    }  // end for each MPR Selectors in qosTuple
	    routeStillValid = foundNextHop;
	  }
	}  // end if lastHop == flow.sourceAddress
      }  // end if !firstRound
      lastHop = (*it);
      firstRound = false;
    }  // end for each link in flow.currentRoute
  }  // end if routeStillValid


  //------ begin computing qos routing table with requestedBw constraint ------
#ifndef REPR_ROUTE_LAST_HOP
#error you need to compile with  REPR_ROUTE_LAST_HOP defined.
#endif

  // compute the new amount of bandwidth that this flow would consume
  double requestedBw = flow.bandwidth * (double)(std::min(routingTuple->R_dist, 5)) * protocolConfig->qosFamousAlpha;

  if (requestedBw > 1.0)
    requestedBw = 1.0;

  // compute a Qos routing table with the ``requestedBw'' as constraint
#ifdef ROUTE_OPT
  // Build a table of symetric neighbors
  AddressMap<bool> isSymmetricNeighborTable;
  for(NeighborSet::TupleIterator it = neighborSet.getIter(); 
      !it.isDone(); it.next())
    {
      NeighborTuple* neighborTuple = it.getCurrent();
      if (neighborTuple->N_status == SYM)
	isSymmetricNeighborTable.add(neighborTuple->N_neighbor_main_addr,
				     true);
    }
#endif
  
  // Step 1 - @@2648
  RoutingTable* qosRoutingTable = new RoutingTable(this);

  // Step 2
  for(NeighborSet::TupleIterator it = neighborSet.getIter(); !it.isDone(); 
      it.next()) { 
    NeighborTuple* neighborTuple = it.getCurrent();
    // XXX: HACK BW
    if ((neighborTuple->N_status == SYM) &&
    	(neighborTuple->qosLab >= requestedBw)) { // XXX: DANG! normally must be min2hopQosLab >= requestedBw
      qosRoutingTable->addRoutingEntry
	( neighborTuple->N_neighbor_main_addr,  // destination address (!)
	  neighborTuple->N_neighbor_main_addr,  // next hop (!)
	  getMainAddress(),                     // last hop (!)
	  1,                                    // route length (!)
	  getMainAddress());                    // local interface
    }
  }

  // Step 3
  
  AddressMap<TwoHopNeighborTuple*> reachableTwoHopTable;

  // Select the candidate two hop neighbors
  for(TwoHopNeighborSet::TupleIterator // @@2695
	it = twoHopNeighborSet.getIter(); !it.isDone(); it.next()) {
    TwoHopNeighborTuple* twoHop = it.getCurrent();
    Address address = twoHop->N_2hop_addr;
#ifdef ROUTE_OPT
    if (isSymmetricNeighborTable.get(address, false) 
	|| address == getMainAddress()) 
      continue; // @@2695-2696
#else
    if (isSymmetricNeighbor(address) || address == getMainAddress()) 
      continue; // @@2695-2696
#endif
    // XXX: HACK BW
    if (twoHop->qosLab < requestedBw)
      continue;
    NeighborTuple* neighborTuple = 
      neighborSet.findFirst_MainAddr(twoHop->N_neighbor_main_addr);
    assert( neighborTuple != NULL ); // XXX: proove
    if (neighborTuple->N_willingness == WILL_NEVER) // @@2696-2698 
      continue;
    // XXX: HACK BW
    if (neighborTuple->qosLab < requestedBw)
      continue;
    // XXX: this will choose the first possible two hop neighbor
    if (reachableTwoHopTable.get(address) == NULL) {
      reachableTwoHopTable.add(address, twoHop);
    }
  }
    
  // Actually set up the routes to two hop neighbors
  for(AddressMap<TwoHopNeighborTuple*>::Iterator it =
	reachableTwoHopTable.getIter(); !it.isDone(); it.next()) {
    TwoHopNeighborTuple* twoHop = it.getCurrent().second;
    RoutingTuple* routingTuple // @@2707-2708, @@2715-2716
      = qosRoutingTable->findFirst_Destination(twoHop->N_neighbor_main_addr);
    assert( routingTuple != NULL ); // XXX: prove it
    qosRoutingTable->addRoutingEntry
      ( twoHop->N_2hop_addr, // @@2702
	routingTuple->R_next_addr, // @@2704-2708
	routingTuple->R_next_addr,
	2, // @@2710
	routingTuple->R_iface_addr); // @@2712-2716
  }

  // Step 3bis (RFC has two steps 3)
  bool tableChanged = true;
  int h = 2; // @@2721
  while(tableChanged) {
    tableChanged = false;
    
    // Step 3.1
    for(QosSet::TupleIterator it = topologyQosSet.getIter(); // @@2725
	!it.isDone(); it.next()) {
      QosTuple* topologyTuple = it.getCurrent();

      // XXX: HACK BW
      if (topologyTuple->qos.qosLab < requestedBw)
      	continue;

      RoutingTuple* routingTuple
	= qosRoutingTable->findFirst_Destination(topologyTuple->mainAddress);
      if (routingTuple == NULL) 
	continue; // no route to this MPR
      if (routingTuple->R_dist != h) // XXX: prove that there is only with h
	continue; // @@2728-2729

      for (std::list<AddressAndQosInfo>::iterator mprsit = 
	     topologyTuple->neighborQosList.begin(); 
	   mprsit != topologyTuple->neighborQosList.end(); mprsit++) {
	if (mprsit->address == getMainAddress())
	  continue;
	// XXX: HACK BW
	if (mprsit->qos.qosLab < requestedBw)
	  continue;

	RoutingTuple* tempRoutingTuple
	  = qosRoutingTable->findFirst_Destination(mprsit->address);
	if (tempRoutingTuple != NULL) {
	  // XXX: to be changed, retain the largest path among multiple paths
	  continue;
	}
	else {
	  // route does not exist, create new one
	  tableChanged = true; // @@2722-2723
	  qosRoutingTable->addRoutingEntry
	    ( mprsit->address,
	      routingTuple->R_next_addr,
	      topologyTuple->mainAddress,
	      h+1,
	      routingTuple->R_iface_addr);
	}  // end if route exists
      } // end for each MPR Selector of this MPR in the topologyQosSet
    } // end for each entry in the topologyQosSet

    h++; // go to the next level
  } // end while tableChanged
  //------ end computing qos routing table with requestedBw constraint ------

  routingTuple
    = qosRoutingTable->findFirst_Destination(flow.destinationAddress);
  if (!routeStillValid ||
      ((routingTuple != NULL) &&
       (flow.currentRoute.size() > (unsigned int)(routingTuple->R_dist + 1)))) {
    if (routingTuple == NULL) {
      // old route no longer valid, and no new route found
      D(*log, lQos, getRealTime() << " [compute-qos-flow-route] "
	<< getMainAddress() << " " << flow.sourceAddress << " " << flow.destinationAddress << " result=FALSE :: new route not exist " << endl);
      return false;
    }
    else {
      // old route no longer valid, but new route found
      flow.currentRoute.clear();
      flow.currentRoute.push_front(flow.destinationAddress);
      Address currentAddress = routingTuple->R_last_addr;
      while (!(currentAddress == flow.sourceAddress)) {
	flow.currentRoute.push_front( currentAddress );

	routingTuple
	  = qosRoutingTable->findFirst_Destination(currentAddress);
	assert( routingTuple != NULL );
	currentAddress = routingTuple->R_last_addr;
      }
      assert( !flow.currentRoute.empty() );
      // flow.currentRoute.pop_back(); // (don't) remove destination
      flow.currentRoute.push_front(getMainAddress()); // add source (this node)
    } // end if routingTuple == NULL
  }  // end if !routeStillValid ...

  D(*log, lQos, getRealTime() << " [compute-qos-flow-route] "
    << getMainAddress() << " " << flow.sourceAddress << " " << flow.destinationAddress << " result=TRUE :: ok " << endl);
  return true;
}

//---------------------------------------------------------------------------

bool QosNode::_computeBestEffortFlowRoute(QosFlow& flow)
{
  flow.currentRoute.clear();
  
  if (flow.sourceAddress == flow.destinationAddress)
    return false;

#ifndef REPR_ROUTE_LAST_HOP
#error you need to compile with  REPR_ROUTE_LAST_HOP defined.
#endif


  // Just use the best effort flow
  RoutingTuple* routingTuple 
    = ParentQosNode::getRoute(flow.destinationAddress);
  if (routingTuple == NULL)
    return false;
  
  Address currentAddress = flow.destinationAddress;
  while (!(currentAddress == flow.sourceAddress)) {
    flow.currentRoute.push_front( currentAddress );

    routingTuple = getRoute(currentAddress);
    assert( routingTuple != NULL );
    currentAddress = routingTuple->R_last_addr;
  }
  assert( !flow.currentRoute.empty() );
  // flow.currentRoute.pop_back(); // (don't) remove destination
  flow.currentRoute.push_front(getMainAddress()); // add source (this node)

  return true;
}

//---------------------------------------------------------------------------

static struct AddressLess doAddressLess;

bool QosFlowLess::operator() (QosFlow* const& flowPtr1,
			      QosFlow* const& flowPtr2) const
{
  const QosFlow& flow1 = *flowPtr1;
  const QosFlow& flow2 = *flowPtr2;
  if (!(flow1.sourceAddress == flow2.sourceAddress))
    return doAddressLess(flow1.sourceAddress, flow2.sourceAddress);
  else if (flow1.sourcePort != flow2.sourcePort)
    return flow1.sourcePort < flow2.sourcePort;
  else if (!(flow1.destinationAddress == flow2.destinationAddress))
    return doAddressLess(flow1.destinationAddress, flow2.destinationAddress);
  else if (flow1.destinationPort != flow2.destinationPort)
    return flow1.destinationPort < flow2.destinationPort;
  else return false;
}

//---------------------------------------------------------------------------

void QosFlowDef::write(ostream& out)
{
  out << sourceAddress << ":" << sourcePort << "->" 
      << destinationAddress << ":" << destinationPort;
}

void QosFlow::write(ostream& out)
{
  out << (*(QosFlowDef*)this) << "/" << bandwidth << " ";
  if (!hasRoute()) {
    out << "(no-route) ";
  } else {
    bool isFirst = true;
    out << "(";
    for (ITER(std::list<Address>, it, currentRoute)) {
      if (isFirst) isFirst = false;
      else out << ",";
      out << (*it);
    }
    out << ")";
  }
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// QosFlowTable
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void QosFlowTable::write(ostream& out)
{
  bool isFirst = true;
  for (ITER(QosFlowSet, it, qosFlowTable)) {
    if (isFirst) isFirst = false;
    else out << "; ";
    (*it)->write(out);
    out << (*it)->expireTime;
  }
}

//---------------------------------------------------------------------------

QosFlow* QosFlowTable::findFlow(QosFlowDef& qosFlowDef)
{
  QosFlow flowHeader;
  *(QosFlowDef*)&flowHeader = qosFlowDef;
  QosFlowSet::iterator it = qosFlowTable.find(&flowHeader);
  if (it == qosFlowTable.end())
    return NULL;
  else return (*it);
}

//---------------------------------------------------------------------------

QosFlow* QosFlowTable::addFlow(QosFlowDef& qosFlowDef,
			       double bandwidth,
			       Time expirationTime)
{
  assert( findFlow(qosFlowDef) == NULL );
  QosFlow* flow = new QosFlow;
  *(QosFlowDef*)flow = qosFlowDef;
  flow->bandwidth = bandwidth;
  flow->expireTime = expirationTime;
  qosFlowTable.insert(flow);
  return flow;
}

void QosFlowTable::deleteFlow(QosFlow* flow)
{
  std::set<QosFlow*, QosFlowLess>::iterator it = qosFlowTable.find(flow);
  assert (it != qosFlowTable.end());
  qosFlowTable.erase(flow);
  delete flow;
}

//---------------------------------------------------------------------------

string QosFlowTable::pack()
{  
  std::vector<string> addressDataList;
  std::vector<string> flowDataList;

  for (ITER(QosFlowSet, it, qosFlowTable)) {
    QosFlow* flow = (*it);

    unsigned short flowInfo[10];

    string rawSrcAddr = flow->sourceAddress.getRawStr();
    string rawDstAddr = flow->destinationAddress.getRawStr();

    flowInfo[0] = addressDataList.size();
    addressDataList.push_back(rawSrcAddr);
    flowInfo[2] = addressDataList.size();
    addressDataList.push_back(rawDstAddr);
    flowInfo[4] = addressDataList.size();
    flowInfo[5] = flow->currentRoute.size();
    for (ITER(std::list<Address>, it, flow->currentRoute)) {
      addressDataList.push_back((*it).getRawStr());
    }
    
    flowInfo[1] = flow->sourcePort;
    flowInfo[3] = flow->destinationPort;
    flowInfo[6] = qosLoadToInt(flow->bandwidth);
    flowInfo[7] = 0;
    *(unsigned int *)&(flowInfo[8]) = (unsigned int)flow->expireTime;
    flowDataList.push_back(string((char*)&flowInfo, sizeof(flowInfo)));
  }

  octet header[8];
  header[0] = QSR_MESSAGE_VERSION;
  header[1] = QSR_ACTION_REPLY;
  header[2] = 0; // reserved
  header[3] = 0; // reserved
  *(unsigned short*)(&(header[4])) = addressDataList.size();
  *(unsigned short*)(&(header[6])) = flowDataList.size();
  
  string result((char*)header, 8);
  
  for (unsigned int i=0; i<addressDataList.size(); i++)
    result += addressDataList[i];

  for (unsigned int i=0; i<flowDataList.size(); i++)
    result += flowDataList[i];

  return result;
}

//---------------------------------------------------------------------------

void QosFlowTable::expireAllFlow(Time currentTime)
{
  std::list<QosFlow*> expiredFlowList;
  for (ITER(QosFlowSet, it, qosFlowTable)) {
    if ((*it)->expireTime <= currentTime)
      expiredFlowList.push_back(*it);
  }
  for (ITER(std::list<QosFlow*>, it, expiredFlowList))
    deleteFlow(*it);
}

//---------------------------------------------------------------------------

const int QSRMsgHeaderSize = 2*4;
const int QSRMsgFlowSize = 5*4;

bool QosFlowTable::unpackFlowList
(AddressFactory* addressFactory, 
 string& dataStr, std::list<QosFlow>& resultFlowList)
{
  int addressSize = addressFactory->getAddressSize();
  octet* data = (octet*) dataStr.data();
  int version = data[0];
  if (majorVersionOf(version) != QSR_MESSAGE_VERSION_MAJOR) {
    Warn("Bad major version in received QSR message, message ignored ("
	 "was: " << majorVersionOf(version) << ", supported: "
	 << QSR_MESSAGE_VERSION_MAJOR << ")");
    return false;
  }
    
  if (data[1] != QSR_ACTION_REQUEST) {
    Warn("Unsupported action in received QSR message, message ignored ("
	 "was: " << data[1]);
    return false;
  }

  int nbAddress = *(unsigned short*)(data+QSRMsgHeaderSize-4);
  int nbFlow = *(unsigned short*)(data+QSRMsgHeaderSize-4 + 2);

  int sizeCheck = QSRMsgHeaderSize 
    + addressSize * nbAddress + nbFlow * QSRMsgFlowSize;
  
  if (sizeCheck != (int)dataStr.size()) {
    Warn("Bad message size in received QSR message, nbAddress=" 
	 << nbAddress << ", nbFlow=" << nbFlow << " expectedSize="
	 << sizeCheck << ", actualSize=" << dataStr.size());
    return false;
  }

  std::vector<Address> addressTable;
  for (int i=0;i<nbAddress;i++) {
    octet* current = data + QSRMsgHeaderSize + addressSize * i;
    addressTable.push_back(addressFactory->peekAddress(current));
  }
  assert( (int)addressTable.size() == nbAddress );

  for (int i=0; i<nbFlow; i++) {
    octet* current = data + QSRMsgHeaderSize + addressSize * nbAddress;
    unsigned short* info = (unsigned short*)current;
    QosFlow flow;

    int srcFlow = info[0];
    flow.sourcePort = info[1];
    int dstFlow = info[2];
    flow.destinationPort = info[3];
    int firstAddressIndex = info[4];
    int nbRouteAddress = info[5];
    
    if (srcFlow > nbAddress || dstFlow > nbAddress 
	|| firstAddressIndex+nbRouteAddress > nbAddress
	|| nbRouteAddress > 0) {
      Warn("Bad addresses indices in QSR message, src="
	   << srcFlow <<", dst=" << dstFlow << ", lastRouteAddress=" 
	   << (firstAddressIndex+nbRouteAddress) << ", nbRouteAddress=" 
	   << nbRouteAddress << endl);
      return false;
    }
    
    flow.sourceAddress = addressTable[srcFlow];
    flow.destinationAddress = addressTable[dstFlow];

    // -> info[6], info[7] <-
    flow.bandwidth = intToQosLoad(info[6]);
    unsigned int expireTime = (unsigned int)&(info[8]);
    flow.expireTime = expireTime;
    resultFlowList.push_back(flow);
  }
  return true;
}

//---------------------------------------------------------------------------

vector<vector<string>*>* QosNode::getTableContent(string name)
{
  if (name == "QosContentious")
    return ::getTableContentDerived<QosNode, QosSet, QosContentiousTupleSubject>
      (this, contentiousQosSet);

  else if (name == "QosTopology")
    return ::getTableContentDerived<QosNode, QosSet, QosTopologyTupleSubject>
      (this, topologyQosSet);

  else if (name == "QosFlowTable") {
    vector<vector<string>*>* result = new vector<vector<string>*>;

    // build header
    vector< string >* headerContent = new vector< string >;
    headerContent->push_back("flowID");
    headerContent->push_back("sourceAddress");
    headerContent->push_back("sourcePort");
    headerContent->push_back("destinationAddress");
    headerContent->push_back("destinationPort");
    headerContent->push_back("bandwidth");
    headerContent->push_back("currentRoute");
    headerContent->push_back("expireTime");

    result->push_back(headerContent);

    // insert each flow
    int flowId = 1;
    for (ITER(QosFlowSet, it, flowTable.qosFlowTable)) {
      vector< string >* flowContent = new vector< string >;

      ostringstream flowIdStr;
      ostringstream srcAddrStr;
      ostringstream srcPortStr;
      ostringstream dstAddrStr;
      ostringstream dstPortStr;
      ostringstream bandwidthStr;
      ostringstream currentRouteStr;
      ostringstream expireTimeStr;

      flowIdStr << flowId;
      srcAddrStr << (*it)->sourceAddress;
      srcPortStr << (*it)->sourcePort;
      dstAddrStr << (*it)->destinationAddress;
      dstPortStr << (*it)->destinationPort;
      bandwidthStr << (*it)->bandwidth;
      expireTimeStr << ((*it)->expireTime - getCurrentTime());

      flowContent->push_back(flowIdStr.str());
      flowContent->push_back(srcAddrStr.str());
      flowContent->push_back(srcPortStr.str());
      flowContent->push_back(dstAddrStr.str());
      flowContent->push_back(dstPortStr.str());
      flowContent->push_back(bandwidthStr.str());

      bool firstAddress = true;
      for (std::list<Address>::iterator routeIT = (*it)->currentRoute.begin();
	   routeIT != (*it)->currentRoute.end(); routeIT++) {
	if (!firstAddress)
	  currentRouteStr << ",";
	firstAddress = false;
	currentRouteStr << (*routeIT);
      }

      flowContent->push_back(currentRouteStr.str());
      flowContent->push_back(expireTimeStr.str());

      result->push_back(flowContent);
    }

    return result;
  }

  else return ParentQosNode::getTableContent(name);
}

vector<string>* QosNode::getTableNameList()
{
  char* tableName[] = { 
    "QosContentious", "QosTopology", "QosFlowTable", NULL };

  vector<string>* result = ParentQosNode::getTableNameList();

  for (char** it = tableName; *it != NULL; it++)
    result->push_back(*it);

  return result;
}

//---------------------------------------------------------------------------
