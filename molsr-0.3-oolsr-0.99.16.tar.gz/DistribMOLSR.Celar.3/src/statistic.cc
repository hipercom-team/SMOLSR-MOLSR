//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
// Cedric Adjih, Information Network Research Group,
// Department of Information Engineering, Niigata University.
// Copyright 2004 - Niigata University
// All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "statistic.h"

StatisticSet::StatisticSet(Node* aNode) : node(aNode)
{ creationTime = node->getCurrentTime(); }


StatisticTuple* StatisticSet::ensure(Address address) 
{
  StatisticTuple* result = findFirst_MainAddr(address);
  Time currentTime = node->getCurrentTime();
  if (result == NULL) {
    result = new StatisticTuple(node);
    result->S_main_addr = address;
    result->S_time = currentTime;
    add(result);
  }
  return result;
}

void StatisticSet::notifyRemoval(StatisticTuple* tuple)
{ /* nothing to do */ }

void StatisticSet::notifyAddition(StatisticTuple* tuple)
{ /* nothing to do */ }

//---------------------------------------------------------------------------
