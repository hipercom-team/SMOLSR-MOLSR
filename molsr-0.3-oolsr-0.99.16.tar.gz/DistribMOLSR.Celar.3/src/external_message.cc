//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "external_message.h"

//---------------------------------------------------------------------------

IMessageContent* ByteMessage::clone()
{
  ByteMessage* result = new ByteMessage;
  result->header = header->clone(false); 
  result->header->content = result;
  result->data = data->clone();
  return result;
}

void ByteMessage::write(ostream& out) const
{
  out << "external size=" << data->size << " content=";
  for(int i=0;i<data->size;i++) {
    if(i%4 == 0 && i!=0) 
      out << "_";
    char info[10];
    sprintf(info,"%02x", ((unsigned char*)data->data)[i]);
    out << info;
  }
}

//---------------------------------------------------------------------------

void ByteMessageHandler::processMessage(/*borrowed*/ Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  ByteMessage* extMessage 
    = dynamic_cast<ByteMessage*>(messageContent);
    
  D(*node->log, lExternal,
    node->getRealTime() << " [process-message] " 
    << node->getMainAddress() << " external-message " 
    << message->originatorAddress 
    << ":" << message->messageSequenceNumber << endl);
  
  MemoryBlock originatorAddressBlock
    ((octet*)message->originatorAddress.getRawAddress(),
     node->getAddressFactory()->getAddressSize(), true);
  //actuallyProcessMessage(message->packedHeader, extMessage->packet);
  actuallyProcessMessage(message,
			 &originatorAddressBlock, extMessage->data);
  delete extMessage;
}

//---------------------------------------------------------------------------

// This is called only when 
void ByteMessageHandler::considerForwardMessage(Message* m, string& info)
{
  PktD(*node->log, info, m, "using-mpr-flooding,");
  node->getPacketManager()->defaultForwardingMessage(m, info);
}

//---------------------------------------------------------------------------

IMessageContent* ByteMessageHandler::parseMessageContent(Message* message)
{
  ByteMessage* result = new ByteMessage;
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());
  result->data = buffer.popBlock(buffer.size()); // (owned)
  result->header = message->clone(false);
  result->header->content = result;
  return result;
}

//---------------------------------------------------------------------------

void ByteMessageHandler::packMessageContent
(IMessageContent* message, 
 int maximumMessageSize,
 MemoryBlock*& blockResult,
 IMessageContent*& messageRemainingResult,
 PackingInfo& packingInfo)
{
  ByteMessage* m = dynamic_cast<ByteMessage*>(message);
  
  if (maximumMessageSize < m->header->messageSize) {
    // Impossible to split:
    blockResult = NULL;
    messageRemainingResult = NULL;
    Warn("External message to big, not splitted: maxSize=" 
	 << maximumMessageSize << " messageSize=" << m->header->messageSize);
    return;
  }
  
  D(*node->log, lExternal, node->getRealTime() << " [pack-message] " 
    << node->getMainAddress() << " external-message " 
    << m->header->originatorAddress << ":" 
    << m->header->messageSequenceNumber << endl);
  
  PacketBuffer buffer;
  
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message->header);
  buffer.packBlock(m->data);
  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  
  messageRemainingResult = NULL;

  buffer.rewind();
  blockResult = buffer.getContent();
}

//---------------------------------------------------------------------------

void ByteMessageHandler::adjustMessageSize(IMessageContent* message)
{
  int addressSize = node->getAddressFactory()->getAddressSize();
  ByteMessage* m = dynamic_cast<ByteMessage*>(message);
  m->header->messageSize =
    MessageHeaderWithoutAddressSize + addressSize // message header
    + m->data->size; // content
  m->header->minMessageSize = m->header->messageSize;
}

//---------------------------------------------------------------------------

void ByteMessageHandler::sendMessage(MemoryBlock* data)
{
  Message* message = new Message
    ((MessageType)messageType, // Message Type 
     0, // not used
     node->getMainAddress(), // Originator @@835-836
     MaxTTL, // ttl,
     0); // hop count, @@868
  
  ByteMessage* extMessage = new ByteMessage;
  extMessage->data = data;
  message->content = extMessage;
  message->maxTime = node->getCurrentTime();
  node->sendMessage(NULL, message);
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

#define EXT_MSG_PROTOCOL_VER_MAJOR 1
#define EXT_MSG_PROTOCOL_VER_MINOR 0

#define EXT_MSG_PROTOCOL_VER(major,minor) (((major)<<4) | (minor))
#define EXT_MSG_PROTOCOL_MAJOR(version) ((version)>>4)
#define EXT_MSG_PROTOCOL_MINOR(version) ((version)& 0xf)

// Protocol: [version][code][data...]
// code = 1: send packet
// code = 2: message to ExternalMessageHandler::processExternalInfo

// handle a message coming from an "External Message Handler"
void ExternalMessageHandler::handleMessage(MemoryBlock* block)
{
  if (block->size < 2) {
    Warn("Message from channel is too small, dropping it");    
    delete block;
    return;
  }

  int version = block->data[0];
  if (EXT_MSG_PROTOCOL_MAJOR(version) != EXT_MSG_PROTOCOL_VER_MAJOR) {
    Warn("Message from channel with unsupported major version="
	 << EXT_MSG_PROTOCOL_MAJOR(version) << "."
	 << EXT_MSG_PROTOCOL_MINOR(version) 
	 << " (supported:" << EXT_MSG_PROTOCOL_VER_MAJOR << "."
	 << EXT_MSG_PROTOCOL_VER_MINOR);
    delete block;
    return;
  }

  int code = block->data[1];
  MemoryBlock* packet = new MemoryBlock(block->data+2, block->size-2, true);
  delete block; block = NULL;

  if (code == 1) {
    sendMessage(packet);
  } else if (code == 2) {
    processExternalInfo(packet);
  } else {
    Warn("Message from channel with unsupported action code=" << code);
    delete packet;
  }
}

//---------------------------------------------------------------------------
