//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//---------------------------------------------------------------------------
// This file includes all the code of the OOLSR source files
//---------------------------------------------------------------------------

#include <oolsr_all_header.h>

//---------------------------------------------------------------------------
// C++ source files
//---------------------------------------------------------------------------

#include "address.cc"
#include "tuple.cc"
#include "general.cc"
//#include "general_opnet.cc"
#ifndef SYSTEMlinux
#include "general_windows.cc"
#else
#include "general_linux.cc"
#endif
#include "protocol_config.cc"
#include "security.cc"
#include "node_general.cc"
#include "node_neighbor_sensing.cc"
#include "node_topology_discovery.cc"
#include "node_mpr_selection.cc"
#include "node_iface_association_base.cc"
#include "node_hna.cc"
#include "node_route_calculation.cc"
#include "node_observer_subject.cc"
#include "packet.cc"
#include "message.cc"
#include "md5util.cc"
#ifdef ASSOCIATION_DB
#include "node_ap.cc"
#endif
#ifdef WITH_QOS
#include "qos.cc"
#include "qos_flow.cc"
#endif // WITH_QOS
#ifdef SYSTEMlinux
#include "iwevent_client.cc"
#endif // SYSTEMlinux
#include "node_link_monitoring.cc"
#include "mt19937ar.cc"
#include "external_message.cc"
//#ifdef WITH_CXX_TIME_PROTOCOL
//#include "time_exchange.cc"
//#endif
#ifdef WITH_EXTENSION
#include "message_extension.cc"
#include "message_conversion.cc"
#endif

//---------------------------------------------------------------------------
