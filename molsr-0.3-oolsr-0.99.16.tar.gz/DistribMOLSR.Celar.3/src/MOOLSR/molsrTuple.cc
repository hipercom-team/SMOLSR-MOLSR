//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "tuple.h"
#include "molsrNode.h"


void writeExpireTime(ostream& out, Time currentTime, Time expireTime);
//{ 
//  if(expireTime < currentTime) out << "-";
//  else if (expireTime > currentTime) out << "+";
//  else out << "=";
//  out << "/" << expireTime;
//}
//---------------------------------------------------------------------------
void MCTreeSet::write(std::ostream& out)
{

  Time currentTime = node->getCurrentTime();
   bool isFirst = true;
  for(MCTreeSet::TupleIterator it = this->getIter();
      !it.isDone(); it.next()) 
    {
      if (!isFirst) out << ";";
      else isFirst = false;
      
      MCTuple* mcTuple=it.getCurrent();
      out << "SourceTreeAddress="<< mcTuple->MT_source_addr 
	  << " " << "MulticastGroupAddress="<<mcTuple->MT_group_addr;
      if(mcTuple->MT_parent_addr.isNull())
	out << " " << "ParentAddress=" << "Null";
      else
	out << " " << "ParentAddress=" << mcTuple->MT_parent_addr;
      
      writeExpireTime(out, currentTime, mcTuple->MT_source_time);

      out << "SonsAddresses -> [";

      for(std::map<Address,Time,AddressLess>::iterator itSon = mcTuple->MT_list_sons.begin();itSon != mcTuple->MT_list_sons.end();itSon++)
	{
	  
	  out << "~" << itSon->first << " ";
	  writeExpireTime(out, currentTime,itSon->second);
	}
      out << "]" ;
    }
}
//---------------------------------------------------------------------------
void MCLocalSet::write(std::ostream& out)
{
 Time currentTime = node->getCurrentTime();
   bool isFirst = true;
  for(MCLocalSet::TupleIterator itSource = this->getIter();
      !itSource.isDone(); itSource.next()) 
    {
       if (!isFirst) out << ";";
       else isFirst = false;
       MCLocal* localSource=itSource.getCurrent();
       
       out << "AddressTuple="<<localSource->L_source_addr << " ";
       
       writeExpireTime(out, currentTime, localSource->L_time_out);
       
       out << "GroupAddresses ->[";
	for(std::map<Address,Time,AddressLess>::iterator 
	      itGroup = localSource->L_group_n_timeout.begin(); 
	    itGroup != localSource->L_group_n_timeout.end(); itGroup++)
	  {
	    out << "~"<< itGroup->first << " ";
	    writeExpireTime(out,currentTime,itGroup->second);
	  }
       out << "]";
    }
}
//---------------------------------------------------------------------------
 MCLocal* MCLocalSet::findFirst(Address source,Address group)
  {
    MCLocal* mcLocal;
    if(!(mcLocal = findFirst(source)))
      mcLocal = findFirst(node->getMainAddress());
    
    if(mcLocal)
      // for(std::list<>::iterator it=mcLocal->L_group_n_timeout.begin();
      //     it!=mcLocal->L_group_n_timeout.end();it++)
      //	{
      //	  if(it->first==group)
      //	    return mcLocal;
      //	}
      if(!(mcLocal->L_group_n_timeout.find(group)==mcLocal->L_group_n_timeout.end()))
	return mcLocal;
    
    return NULL;
  }

//---------------------------------------------------------------------------
