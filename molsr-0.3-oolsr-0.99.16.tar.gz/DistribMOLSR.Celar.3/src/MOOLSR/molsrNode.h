//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
//-----------------------------MOLSR Messages---------------------------------
//---------------------------------------------------------------------------

#include "base.h"
#include "address.h"
#include "packet.h"

#include <list>
using std::list;

//---------------------------------------------------------------------------
#include "tuple.h"
#include "node.h"
#include "general.h"
#include "protocol_config.h"
#include "log.h"
#include "protocol_tuple.h"
//#include "molsrTuple.h"
#include "molsrMsg.h"
#include "molsrMdfpMsg.h"
//#include "mdfpCom.h"
#include "mdfp_generic.h"
#ifdef WITH_MULTICAST_ENCAPSULATION
#include "general_encapsulation.h"
#endif
//---------------------------------------------------------------------------
// Variable should be put in src/gen_protocol_config.h
//SC_INTERVAL   4.0

//SC_HOLD_TIME  12.0

//CP_INTERVAL   5.0
//CP_HOLD_TIME  15.0


//LEAVE_INTERVAL  0
//LEAVE_HOLD_TIME 0

// Variable should be put in include/general.h  for example  
// check the message type for SMOLSR
//SC_MESSAGE    11
//CP_MESSAGE    12
//LEAVE_MESSAGE 13 

#ifdef WITH_MULTICAST_ENCAPSULATION
class EMMessage;
#endif


class MolsrNode;




//---------------------------------------------------------------------------
class MolsrNode : public Node
{

 public:
  MolsrNode() :Node(),
               mcTreeTable(this),localSourceTable(this),
	       localClientTable(this),mdfp(NULL) {  }

  virtual ~MolsrNode() {}

  MCTreeSet mcTreeTable; //The tree entries

  MCLocalSet localSourceTable; // Local Source table
  
  MCLocalSet localClientTable; // Local Client table
 

  // Add, Delete, Update, Lookup (source, group, parent,sons)
  //delete parent ==> delete the MCTree entry
  //delete a son ==> send a leave message if it is the last son, and stop sending
  //the periodic confirm messages
  
/// [Confirm Parent] This method is called when a Confirm Parent message should
  /// be generated.
  
  void eventConfirmParentGeneration();

  void processConfirmParentMessage(ConfParentLeaveMessage * message);

  //Could we generate a packet directly or everything is based on events and scheduler?
 

  void confirmParentLeaveImmediatGeneration(MCTuple* mcTuple,MessageType msgType, double msgInterval, double msgHoldTime);
  
  void processLeaveMessage(ConfParentLeaveMessage * message);

  /// [Source Claim] This method is called when a Source Claim message should
  /// be generated.
  void eventSourceClaimGeneration();
  void sourceClaimImmediatGeneration(Address localSourceAddress, Address groupAddress);
  void processSourceClaimMessage(SourceClaimMessage * message);  
 
  //MDFP communication
  void processLeaveNewLocalSrcClientMessage(LeaveNewLocalSrcClientMessage *message);
  Message* generateMIDInformationForMDFP(); //move this to MolsrNODE
  Message* generateMCTREEInformationForMDFP();//move this to MolsrNODE
  Message* generateSMOLSRInformationForMDFP();

  void generateInformationForMDFP();
  void startMDFPInformationGeneration();
  //MDFP communication

#ifdef WITH_MULTICAST_ENCAPSULATION
  
  bool shouldForwardEMMessage(EMMessage* message); //
#endif
  
  void updateMCTreeTable();

  void startSourceClaimBase();

  void startConfirmParentBase();

  void processLocalClientMulticastJoin(Address localClientAddress, Address groupAddress);
  void processLocalMulticastSource(Address localSourceAddress, Address groupAddress);
  void processLocalClientMulticastLeave(Address localClientAddress, Address groupAddress);
  void processLocalMulticastSourceLeave(Address localSourceAddress, Address groupAddress);

  virtual void configure(IScheduler* aBaseScheduler, 
		 AddressFactory* aAddressFactory,
		 PacketManager* aPacketManager,
		 INetworkConfigurator* aNetworkConfigurator,
		 ProtocolConfig* aProtocolConfig,
		 std::vector<ISystemIface*>& aSystemIfaceList,
		 Log* aLog);

  virtual void computeRoutingTable();

  virtual void start();

  virtual void performTupleExpiration(); //XXX TODO

  virtual void getNextExpireTime(Time& nextExpireTime, bool& hasExpireTime); //XXX TODO

  virtual void logState(ostream& out);

  void configureMDFP(IMDFP *aBaseMDFP){mdfp=aBaseMDFP;}
  //MDFPCom * mdfpCom;
   IMDFP *mdfp;

};
