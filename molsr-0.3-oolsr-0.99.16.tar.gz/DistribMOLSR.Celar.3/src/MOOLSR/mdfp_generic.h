//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
#ifndef _IMDFP_H
#define _IMDFP_H
//---------------------------------------------------------------------------
#include "base.h"
#include "address.h"
#include "packet.h"
#include "scheduler_generic.h"


class IMDFP
{
 public:
  virtual void start()=0;
  virtual void mdfpPackAndSend(Message *midMessage,Message *mcTreeMessage)=0;
  virtual void sendMDFPInformation(MemoryBlock* packet)=0;
  virtual void processRecvMDFPInformation()=0;
  
};

#endif // _IMDFP_H
