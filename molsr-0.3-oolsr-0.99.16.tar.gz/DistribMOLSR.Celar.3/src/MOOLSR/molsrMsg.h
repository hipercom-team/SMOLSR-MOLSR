//-----------------------------------------------------------------*- c++ -*-
//                                MOOLSR
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "base.h"
#include "address.h"
#include "packet.h"
//#include "molsrNode.h"
#include <list>
using std::list;


class MolsrNode;


//---------------------------------------------------------------------------
class SourceClaimMessage: public IMessageContent  //Source Claim message
{
 public:
  Address source_addr;
  std::list<Address> list_group_addr;

  virtual IMessageContent* clone()
    {
      SourceClaimMessage* result = new SourceClaimMessage;
      result->header = header->clone(false); 
      result->header->content = result;
      result->source_addr = source_addr;
      std::insert_iterator< std::list<Address> > ii(result->list_group_addr,
						  result->list_group_addr.begin());
      std::copy(list_group_addr.begin(), list_group_addr.end(), ii);

      return result;
    }
  virtual void write(std::ostream& out) const
    {
      out << "SourceClaim " << source_addr
	<< " MulticastGroupAddresses=";
    for(std::list<Address>::const_iterator it = list_group_addr.begin();
	it != list_group_addr.end(); it++) {
      if (it != list_group_addr.begin()) out << ",";
      out << (*it);
    }
    }
};


class SourceClaimSpecification
{
public:
  typedef SourceClaimMessage MessageContent;
  typedef Address MessageItem;
  static int getContentHeaderSize(int addressSize){ return addressSize; }
  static int getItemSize(int addressSize) { return addressSize; }
  static void process(Node* node, MessageContent* m);
  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer) 
  { 
    result->source_addr=buffer.popAddress();
  }

  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { 
    result->list_group_addr.push_back( buffer.popAddress() );
   
  }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer) 
  { 
    buffer.packAddress(m->source_addr);
  }

  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { 
    buffer.packAddress(item); 
   
  }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->list_group_addr; }
};

typedef GenericMessageHandler<SourceClaimSpecification> SourceClaimMessageHandler;


//---------------------------------------------------------------------------
class ParentTree
{
 public:
  Address parent_addr;
  Address group_addr;
  Address source_addr;
};
class ConfParentLeaveMessage: public IMessageContent  //Confirm Parent message
{
public:
  std::list<ParentTree> parent_list;
  
  
  virtual IMessageContent* clone()
  {
    ConfParentLeaveMessage* result = new ConfParentLeaveMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    
    std::insert_iterator< std::list<ParentTree> > ii(result->parent_list,
						     result->parent_list.begin());
    std::copy(parent_list.begin(), parent_list.end(), ii);
    
    return result;
  }
  virtual void write(std::ostream& out) const
  {
    out << messageTypeToString(header->messageType)<< ": ";
	//	<< " Parent address, group address, source address";
    for(std::list<ParentTree>::const_iterator it = parent_list.begin();
	it != parent_list.end(); it++) {
      if (it != parent_list.begin()) out << ",";
      out << "ParentAddress=" << (*it).parent_addr <<" " 
	  << "MulticastGroupAddress="<<(*it).group_addr <<" " 
	  << "SourceTreeAddress="<<(*it).source_addr;
    }
  } 
};




class ConfParentLeaveSpecification
{
public:
  typedef ConfParentLeaveMessage MessageContent;
  typedef ParentTree MessageItem;
  static int getContentHeaderSize(int addressSize) { return 0; }
  static int getItemSize(int addressSize) { return 3*addressSize; }
  static void process(Node* node, MessageContent* m);
  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer) { }

  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { 
    ParentTree entry;
   
    entry.parent_addr = buffer.popAddress();
    entry.group_addr = buffer.popAddress();
    entry.source_addr = buffer.popAddress();

    result-> parent_list.push_back( entry ); 
  }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer) { }
  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { 
    buffer.packAddress(item.parent_addr); 
    buffer.packAddress(item.group_addr); 
    buffer.packAddress(item.source_addr); 
  }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->parent_list; }
};


typedef GenericMessageHandler<ConfParentLeaveSpecification> ConfParentLeaveMessageHandler;


//---------------------------------------------------------------------------
