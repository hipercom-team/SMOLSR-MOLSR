//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Code developped for Mesh Point simulations for 802.11s
//---------------------------------------------------------------------------

#include "node_ap.h"

#define lMeshAP lMeshPoint 

//---------------------------------------------------------------------------

#ifdef WITH_ASSOCIATION_STAT

#define AP_STAT(x) do { x } while(0)

//static long statGeneratedEmptyMessage = 0;
//static long statGeneratedDifferentialSet = 0;
//static long statGeneratedFullSet = 0;

static long statRecordedRequest = 0;

static long statDefaultForwarding = 0;

static long statUnicastDroppedTTL = 0;
static long statUnicastDroppedRoute = 0;
static long statUnicastForwarded = 0;
static long statUnicastForwardedAsBroadcast = 0;
static long statUnicastIgnored = 0;
static long statUnicastArrived = 0;

static long statLABAProcessed = 0;
static long statLABCAProcessed = 0;
static long statABBRProcessed = 0;

static long statLABAGenerated = 0;
static long statLABCAGenerated = 0;
static long statABBRGenerated = 0;
static long statABBRGeneratedNoRoute = 0;

//static long statBroadcastPseudoLost = 0;

static long statImplicitDisassociate = 0; // when a message is received
// from another Mesh Point which has associated one of the node's
// associated stated
//static long statStationAdd = 0;
//static long statStationRemove = 0;
//static long statStationUpdate = 0;

static long statConsistentChecksum = 0;
static long statInconsistentChecksum = 0;
//static long statMissingBlockRequest = 0;


#else // !defined(WITH_ASSOCIATION_STAT):

#define AP_STAT(x) do { /* do nothing */ } while(0)

#endif // WITH_ASSOCIATION_STAT

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void StationInfo::write(ostream& out)
{
  out << address;
  //out << "@" << blockIndex;
  out << ":" << stationSeqNum;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void LocalAssociationTuple::write(ostream& out)
{
    out << LA_station_address << ",#" << LA_station_sequence_number
	<<",b" << block->LA_block_index;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void writeBinary(ostream& out, unsigned int data, int nbBit)
{
  for (int i=0; i<nbBit; i++) {
    if ( (data & (1<<i)) != 0 )
      out << "1";
    else out << "0";
  }
}

unsigned int AssociationBaseChecksum::getNetSize()
{
  return 
    //PacketBuffer::sizeUInt16() /* Key */
    //PacketBuffer::sizeUInt16() /* Nb block checksum */
    //+ PacketBuffer::sizeUInt32() /* block mask - XXX! a kludge */
    PacketBuffer::sizeUInt16() * nbBlock;  /* list of block checksum */
}

void AssociationBaseChecksum::popFromBuffer(PacketBuffer& buffer)
{
  //key = buffer.popUInt16();
  //nbBlock = buffer.popUInt16();
  //blockMask = buffer.popUInt32();
  nbBlock = 0;
  while (buffer.size() > 0) {
    blockChecksum[nbBlock] = buffer.popUInt16();
    nbBlock++;
  }
}

void AssociationBaseChecksum::packToBuffer(PacketBuffer& buffer)
{
  //buffer.pushUInt16(key);
  //buffer.pushUInt16(nbBlock);
  //buffer.pushUInt32(blockMask);
  for (int i=0; i<nbBlock; i++)
    buffer.pushUInt16(blockChecksum[i]);
}

void AssociationBaseChecksum::write(ostream& out)
{
  char keyStr[128]; // XXX: hardcoded limit.
  sprintf(keyStr, "%04x", key);
  out << "#=" << nbBlock << ",";
  out << "key=" << keyStr << ",";
  out << ",checksum=<";
  for (int i=0;i<nbBlock;i++) {
    if (i>0) out << ",";
    char checksumStr[128]; // XXX
    sprintf(checksumStr, "%04x", blockChecksum[i]);
    out << i << ":" << checksumStr;
  }
  out << ">";
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

using std::vector;

struct StringContentCompare
{
public:
  bool operator () (const string&x, const string&y) 
  { 
    assert( x.size() == y.size() );
    return memcmp(x.data(), y.data(), x.size()) < 0;
  }
};

typedef pair<Address,StationSeqNum> AddressAndSeqNum;

static BlockChecksum getChecksum(AddressFactory* addressFactory,
			 list<AddressAndSeqNum>& addressAndSeqNumList,
			 unsigned short key=0)
{
  vector<string> stationAddressStrList;
  for (ITER(std::list<AddressAndSeqNum>, it, addressAndSeqNumList)) {
    PacketBuffer entryBuffer(addressFactory);
    entryBuffer.packAddress((*it).first);
    entryBuffer.pushUInt16((*it).second);
    entryBuffer.rewind();
    stationAddressStrList.push_back(entryBuffer.popAllString());
  }

  std::sort(stationAddressStrList.begin(), stationAddressStrList.end(),
	    StringContentCompare());
  
  string allAddressStr;

  PacketBuffer keyBuffer(addressFactory);
  keyBuffer.pushUInt16(key);
  allAddressStr += keyBuffer.popAllString();

  for (ITER(std::vector<string>, it, stationAddressStrList))
    allAddressStr += (*it); // XXX: slow

  string md5Hash = getMD5(allAddressStr);

  assert( md5Hash.size() > sizeof(BlockChecksum) );
  BlockChecksum result = ((unsigned char)md5Hash[0]) << 8
    | ((unsigned char)md5Hash[1]);
  
  return result;
}

BlockChecksum LocalAssociationBaseBlock::getChecksum
(AddressFactory* addressFactory, unsigned int key)
{
  list<AddressAndSeqNum> addressAndSeqNumList;
  for (ITER(std::list<LocalAssociationTuple*>, it, associationList)) {
    AddressAndSeqNum item ((*it)->LA_station_address,
			   (*it)->LA_station_sequence_number);
    addressAndSeqNumList.push_back(item);
  }
  return ::getChecksum(addressFactory, addressAndSeqNumList, key);
}

void LocalAssociationBaseBlock::write(ostream& out)
{
  out << LA_block_index <<": ";
  bool isFirst = true;
  for (ITER(std::list<LocalAssociationTuple*>, it, associationList)) {
    if (!isFirst) out << "; ";
    else isFirst = false;
    out << *(*it);
  }
}

//---------------------------------------------------------------------------

void LocalAssociationBaseBlock::clear(AssociationBase* associationBase)
{
  list<LocalAssociationTuple*> associationListCopy = associationList;
  for (ITER(std::list<LocalAssociationTuple*>, it, associationListCopy)) {
    associationBase->removeAndDelete(*it);
  }
  assert( associationList.empty() );
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

AssociationBaseChecksum* AssociationBase::getChecksum(unsigned short key)
{
  AssociationBaseChecksum* result = new AssociationBaseChecksum;
  result->nbBlock = getNbBlock();
  result->key = key;
  for (int i=0; i<result->nbBlock; i++) {
    result->blockChecksum[i] = block[i].getChecksum(node->getAddressFactory(),
					    result->key);
  }
  return result;
}

int AssociationBase::getNbBlock()
{
  int result = 0;
  for (ITER(std::list<LocalAssociationTuple*>, it, associationList)) {
    int blockIndex = (*it)->block->getIndex();
    if (blockIndex+1 > result)
      result = blockIndex+1;
  }
  return result;
}

//--------------------------------------------------

LocalAssociationTuple* AssociationBase::findStationByAddress(Address address)
{
  for (ITER(std::list<LocalAssociationTuple*>, it, associationList))
    if ((*it)->LA_station_address == address)
      return *it;
  return NULL; // not found
}

void AssociationBase::write(ostream& out)
{
  //out << "address=" << meshAPAddress;
  out << " content=(";
  bool isFirst = true;
  for (int i=0; i<MAX_NB_BLOCK; i++) {
    if (!block[i].associationList.empty()) {
      if (!isFirst) out << ", ";
      else isFirst = false;
      block[i].write(out);
    }
  }
  out << ")";
}

LocalAssociationBaseBlock* AssociationBase::getBlock(int blockIndex)
{ 
  assert( inrange(0, blockIndex, MAX_NB_BLOCK) );
  return &(block[blockIndex]); 
}

void AssociationBase::add(LocalAssociationTuple* associationTuple, 
			  int blockIndex)
{
  associationList.push_back(associationTuple);
  LocalAssociationBaseBlock* block = getBlock(blockIndex);
  block->add(associationTuple);
}

void AssociationBase::disassociate(LocalAssociationTuple* associationTuple)
{
  removeAndDelete(associationTuple);
}

void AssociationBase::removeAndDelete(LocalAssociationTuple* associationTuple)
{
  LocalAssociationBaseBlock* block = associationTuple->block;
  block->forget(associationTuple);
  associationList.remove(associationTuple);
  delete associationTuple;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void LocalAssociationBase::performAssociateStation
(Address stationAddress,  StationSeqNum stationSeqNum) 
{
  assert( findStationByAddress(stationAddress) == NULL ); // should not be
  // already associated to this mesh point

  LocalAssociationTuple* associationTuple 
    = new LocalAssociationTuple(stationAddress);
  associationTuple->LA_station_sequence_number = stationSeqNum;
  associationTuple->block = NULL;
#if 1
  int blockIndex = _findBlockIndex();
#else
  // here, same address is put in same block, always
  assert( MAX_NB_BLOCK < (1<<8) );
  unsigned char* rawAddress = (unsigned char*) stationAddress.getRawAddress();
  int blockIndex = 0;
  for (int i = 0; i<stationAddress.getNetSize(); i++)
    blockIndex |= rawAddress[i];
  blockIndex = blockIndex % MAX_NB_BLOCK;
#endif  

  add(associationTuple, blockIndex);

  D(*node->log, lMeshAP,
    node->getRealTime() << " [mesh-ap-associate] " << node->getMainAddress()
    << " " << (*associationTuple) << endl);
}

int LocalAssociationBase::_findBlockIndex()
{
#if 0 //XXX
  BlockIndexAndTime* recordedMapping 
    = recordedBlockIndexTable.get(stationAddress, NULL);
  if (recordedMapping != NULL 
      && (node->getCurrentTime() - recordedMapping.second)
      <  protocolConfig->blockMappingExpirationDelay) {
    return recordedMapping.second; // XXX:
  }
#endif
  vector<int> blockCount(MAX_NB_BLOCK, 0);
  
  for (ITER(std::list<LocalAssociationTuple*>, it, associationList)) {
    assert( inrange(0, (*it)->block->LA_block_index, MAX_NB_BLOCK) );
    blockCount[(*it)->block->LA_block_index]++;
  }
  
  int maxBlockCount = node->getProtocolConfig()->maxStationPerBlock;
  int bestIndex = -1;
  int bestCount = -1;
  for (int i=0;i<MAX_NB_BLOCK;i++) {
    if ((blockCount[i] < maxBlockCount)
	&& ((bestIndex < 0)
	    || (bestIndex >=0) && (blockCount[i] > bestCount))) {
      bestIndex = i;
      bestCount = blockCount[i];
    }
  }
  return bestIndex; // Note: might be -1 if no room left
}

void LocalAssociationBase::performDisassociateStation(Address stationAddress)
{
  LocalAssociationTuple* associationTuple 
    = findStationByAddress(stationAddress);
  assert( associationTuple != NULL ); // it must be already associated
  D(*node->log, lMeshAP,
    node->getRealTime() << " [mesh-ap-disassociate] "
    << node->getMainAddress() << " " << (*associationTuple) << endl);
  disassociate(associationTuple);
}

void LocalAssociationBase::recordRequest(int blockIndex)
{
  AP_STAT( statRecordedRequest ++; );
  recordedRequest[blockIndex] = true;
}


void LocalAssociationBase::write(ostream& out)
{
  out << "requested_block_index=(";
  bool isFirst = true;
  for (unsigned int i=0;i<recordedRequest.size(); i++) {
    if (recordedRequest[i]) {
      if (isFirst) isFirst = false;
      else out << ",";
      out << i;
    }
  }
  out << ")";
  AssociationBase::write(out);
}


//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void GlobalAssociationTuple::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();
  out << GA_station_address << ":" << GA_station_sequence_number << "@"
      << GA_AP_address << "/b" << GA_block_index << " ";
  writeExpireTime(out, currentTime, GA_expiration_time);
}

//--------------------------------------------------

GlobalAssociationTuple* 
GlobalAssociationBase::getBestGlobalAssociation(Address stationAddress)
{
  GlobalAssociationTuple* bestAssociation = NULL;
  BeginOptimizedSearch(GlobalAssociationTuple,) {
    if (current->GA_station_address == stationAddress) {
      if (bestAssociation == NULL
	  || isStationSeqNumGreater(current->GA_station_sequence_number,
			  bestAssociation->GA_station_sequence_number))
	bestAssociation = current; 
    }
  } EndSearch(bestAssociation);
}

void GlobalAssociationBase::write(ostream& out)
{
   bool isFirst = true;
   for(GlobalAssociationBase::TupleIterator it = getIter(); 
       !it.isDone(); it.next()) {
     if (!isFirst) out << ";";
     else isFirst = false;
     (it.getCurrent())->write(out);
   }
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

IMessageContent* LABAMessage::clone()
{
  LABAMessage* result = new LABAMessage(addressFactory);
  result->nbBlock = nbBlock;
  result->blockInfoList = blockInfoList;
  result->header = header->clone(false);
  result->header->content = result;
  return result;
}

void LABAMessage::write(ostream& out) const
{
  out << "LABA #block=" << nbBlock << " ";
  bool isFirst = true;
  for (ITER(std::list<BlockInfo>, it, 
	    const_cast< list<BlockInfo>& >(blockInfoList))) {
    if (!isFirst) out << ";";
    else isFirst = false;
    out << "b" << (*it).blockIndex << "=";

    bool isFirstStation = true;    
    for (ITER(std::list<StationInfo>, staIt, 
	      const_cast<std::list<StationInfo>& >((*it).stationInfoList))) {
      if (!isFirstStation) out << ",";
      else isFirstStation = false;
      out << (*staIt).address << ":" << (*staIt).stationSeqNum;
    }
  }
  out << "";
}

//--------------------------------------------------

void LABAMessageHandler::processMessage(/*borrowed*/ Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  LABAMessage* labaMessage = dynamic_cast<LABAMessage*>(messageContent);
  node->processLABAMessage(labaMessage);
}

void LABAMessageHandler::considerForwardMessage
(/*borrowed*/ Message* message, string& info)
{ 
  AP_STAT( statDefaultForwarding++; );
  node->getPacketManager()->defaultForwardingMessage(message, info);
}

IMessageContent* 
LABAMessageHandler::parseMessageContent(Message* message)
{
  LABAMessage* result 
    = new LABAMessage(node->getAddressFactory());
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());  

  result->nbBlock = buffer.popUInt16();
  while (buffer.size()>0) {
    BlockInfo blockInfo;
    blockInfo.blockIndex = buffer.popUInt16();
    int size = buffer.popUInt16();
    
    size -= buffer.sizeUInt16()+buffer.sizeUInt16(); // the values just popped
    PacketBuffer rawBlockMessage;
    buffer.popSubBuffer(size, rawBlockMessage);
    while (rawBlockMessage.size() > 0) {
      StationInfo stationInfo;
      stationInfo.address = rawBlockMessage.popAddress();
      stationInfo.stationSeqNum = rawBlockMessage.popUInt16();
      blockInfo.stationInfoList.push_back(stationInfo);
    }
    result->blockInfoList.push_back(blockInfo);
  }
  delete message->packedContent; // XXX: this can be factored
  message->packedContent = NULL;
  message->content = result;
  result->header = message;
  return result;
}

static const int BlockMessageHeaderSize = 
        2   // [block index]
      + 2;  // [block message size]

static int getBlockMessageSize(int addressSize, int nbAddress)
{
  return BlockMessageHeaderSize
  + (nbAddress
     * (addressSize + 2)); // [associated station address] [sta seq num]
}


void LABAMessageHandler::packMessageContent
(IMessageContent* message, int maximumMessageSize,
 MemoryBlock*& packedResult, IMessageContent*& messageRemainingResult,
 PackingInfo& packingInfo)
{
  LABAMessage* m = dynamic_cast<LABAMessage*>(message);
  int addressSize = node->getAddressFactory()->getAddressSize();

  PacketBuffer buffer;
  int initialPos = buffer.getPosition();
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message->header);

  buffer.pushUInt16(m->nbBlock);
  //XXX Intra-Block splitting is not supported
  
  list<BlockInfo> blockInfoList = m->blockInfoList;
  while(!blockInfoList.empty()) {
    BlockInfo& blockInfo = blockInfoList.front();
    int size = getBlockMessageSize(addressSize,
				   blockInfo.stationInfoList.size());
    int freeSpace = maximumMessageSize - buffer.getSizeFrom(initialPos);
    if (freeSpace < size)
      break; // must split message
    // Add block to the current message
    buffer.pushUInt16(blockInfo.blockIndex);
    buffer.pushUInt16(size);
    for (ITER(std::list<StationInfo>, stationIt, blockInfo.stationInfoList)) {
      StationInfo& stationInfo = (*stationIt);
      buffer.packAddress(stationInfo.address);
      buffer.pushUInt16(stationInfo.stationSeqNum);
    } 
    blockInfoList.pop_front();
  }

  if (blockInfoList.size() > 0) {
    // The message has been split
    LABAMessage* newLABA = dynamic_cast<LABAMessage*>(message->clone());
    messageRemainingResult = newLABA;
    newLABA->blockInfoList = blockInfoList;
    newLABA->header->messageSize = -1; // because no longer valid
    newLABA->header->minMessageSize = -1;
  } else messageRemainingResult = NULL;
  
  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  packedResult = buffer.getContent();
}

void LABAMessageHandler::adjustMessageSize(IMessageContent* message)
{
  LABAMessage* m = dynamic_cast<LABAMessage*>(message);
  int addressSize = node->getAddressFactory()->getAddressSize();

  int contentSize = 2; // [nb blocks]
  int minContentSize = 2;
  bool hasMinContentSize = false;
  for (ITER(std::list<BlockInfo>, it, m->blockInfoList)) {
    int blockSize = getBlockMessageSize(addressSize, 
					(*it).stationInfoList.size());
    contentSize += blockSize;
    if (!hasMinContentSize) {
      hasMinContentSize = true;
      minContentSize += blockSize;
    }
  }

  m->header->messageSize = 
    MessageHeaderWithoutAddressSize + addressSize // message header
    + contentSize;
  m->header->minMessageSize = 
    MessageHeaderWithoutAddressSize + addressSize // message header
    + minContentSize;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

IMessageContent* LABCAMessage::clone()
{
  LABCAMessage* result = new LABCAMessage(addressFactory);
  result->blockChecksumList = blockChecksumList;
  result->header = header->clone(false);
  result->header->content = result;
  return result;
}

void LABCAMessage::write(ostream& out) const
{
  out << "LABCA";
  bool isFirst = true;
  int index = 0;
  for (ITER(std::vector<BlockChecksum>, it, 
	    const_cast< vector<BlockChecksum>& >(blockChecksumList))) {
    if (!isFirst) out << ";";
    else { out << " " ; isFirst = false; }
    char tmpStr[128];    //XXX
    int printSize = snprintf(tmpStr, sizeof(tmpStr), "%04x", (*it));
    assert( printSize < (int)sizeof(tmpStr) );
    out << "b" << index << ":" << tmpStr;
    index++;
  }
  out << "";
}

//--------------------------------------------------

void LABCAMessageHandler::processMessage(/*borrowed*/ Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  LABCAMessage* labcaMessage = dynamic_cast<LABCAMessage*>(messageContent);
  node->processLABCAMessage(labcaMessage);
}

void LABCAMessageHandler::considerForwardMessage
(/*borrowed*/ Message* message, string& info)
{ 
  AP_STAT( statDefaultForwarding++; );
  node->getPacketManager()->defaultForwardingMessage(message, info);
}

IMessageContent* 
LABCAMessageHandler::parseMessageContent(Message* message)
{
  LABCAMessage* result
    = new LABCAMessage(node->getAddressFactory());
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());
  
  while (buffer.size()>0) {
    BlockChecksum blockChecksum = buffer.popUInt16();
    result->blockChecksumList.push_back(blockChecksum);
  }
  message->setContent(result); //XXX: this may be wrong!
  return result;
}

void LABCAMessageHandler::packMessageContent
(IMessageContent* message, int maximumMessageSize,
 MemoryBlock*& packedResult, IMessageContent*& messageRemainingResult,
 PackingInfo& packingInfo)
{
  LABCAMessage* m = dynamic_cast<LABCAMessage*>(message);

  PacketBuffer buffer;
  //int initialPos = buffer.getPosition();
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message->header);

  //XXX! Block splitting is not supported
  for (ITER(std::vector<BlockChecksum>, it, m->blockChecksumList)) {
    buffer.pushUInt16((*it));
  }
  messageRemainingResult = NULL;
  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  packedResult = buffer.getContent();
}

void LABCAMessageHandler::adjustMessageSize(IMessageContent* message)
{
  LABCAMessage* m = dynamic_cast<LABCAMessage*>(message);
  int addressSize = node->getAddressFactory()->getAddressSize();

  int contentSize = m->blockChecksumList.size()
    * 2; // [block checksum]
  m->header->messageSize = 
    MessageHeaderWithoutAddressSize + addressSize // message header
    + contentSize;
  m->header->minMessageSize = m->header->messageSize; // cannot be split
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

IMessageContent* ABBRMessage::clone()
{
  ABBRMessage* result = new ABBRMessage(addressFactory);
  result->destinationAPAddress = destinationAPAddress;
  result->nextHopAddress = nextHopAddress;
  result->blockIndexList = blockIndexList;
  result->header = header->clone(false);
  result->header->content = result;
  return result;
}

void ABBRMessage::write(ostream& out) const
{
  out << "ABBR dest=" << destinationAPAddress << " next=" << nextHopAddress 
      << " ";
  bool isFirst = true;
  for (ITER(std::list<int>, it, const_cast< list<int>& >(blockIndexList))) {
    if (!isFirst) out << ";";
    else isFirst = false;
    out << "b" << (*it); 
  }
  out << "";
}

//--------------------------------------------------

void ABBRMessageHandler::processMessage(/*borrowed*/ Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  ABBRMessage* abbrMessage = dynamic_cast<ABBRMessage*>(messageContent);
  node->processABBRMessage(abbrMessage);
}

void ABBRMessageHandler::considerForwardMessage
(/*borrowed*/ Message* message, string& info)
{ 
  ABBRMessage* m = dynamic_cast<ABBRMessage*>(message->content);
  D(*node->log, lMeshAP, node->getRealTime() 
    << " [consider-forward-abbr-message] "
    << node->getMainAddress() << " " << *message << endl);

  if (m->destinationAPAddress == node->getMainAddress()) {
    // Nothing to do, this message is at destination
    AP_STAT( statUnicastArrived++; );
    D(*node->log, lMeshAP, node->getRealTime() << " [abbr-message] " 
      << node->getMainAddress() << " unicast destination" << endl);

  } else if (node->isOneOfOurIfaceAddress(m->nextHopAddress)) {
    // This node is a forwarder, so decrease ttl and resend it
    D(*node->log, lMeshAP, node->getRealTime() << " [abbr-message] " 
	<< node->getMainAddress() << " unicast forward" << endl);

    int ttl = message->timeToLive;
    if (ttl == 0) {
      AP_STAT( statUnicastDroppedTTL++; );
      D(*node->log, lMeshAP, node->getRealTime() << " [abbr-message] " 
	<< node->getMainAddress() << " dropped ttl" << endl);
      // probably a loop (or implementation bug)
      Warn("XXX!! warning dropped message because of TTL"); 
      return;
    } else ttl--;

    //--- This is an 'unicast' message, need to find the next hop
    Address destinationAPAddress = m->destinationAPAddress;
    assert(!destinationAPAddress.isNull());
    RoutingTuple* routingTuple = node->getRoute(destinationAPAddress);
    if (routingTuple == NULL) {
      // can't find the next hop: drop the message
      AP_STAT( statUnicastDroppedRoute++; );
      D(*node->log, lMeshAP, node->getRealTime() << " [abbr-message] " 
	<< node->getMainAddress() 
	<< " dropped unknown=" << destinationAPAddress << endl);
      Warn("Dropped 'pseudo-unicast' message");
      return;
    }

    //--- Now forward it
    ABBRMessage* forwardedMessage = dynamic_cast<ABBRMessage*>(m->clone());
    OLSRIface* iface = node->getIfaceByAddress(routingTuple->R_iface_addr);
    assert( iface != NULL );
    forwardedMessage->nextHopAddress = routingTuple->R_next_addr;
    forwardedMessage->header->timeToLive = ttl;
    forwardedMessage->header->hopCount++;
    forwardedMessage->header->maxTime = node->getCurrentTime();

    AP_STAT( statUnicastForwarded++; );
    D(*node->log, lMeshAP, node->getRealTime() << " [abbr-message] "
      << node->getMainAddress() << " " << (*forwardedMessage) << endl);
    node->sendMessage(iface, forwardedMessage->header);
    
  } else if (node->ifaceToMainAddress(message->sendIfaceAddress) 
	     == m->nextHopAddress) {
    // This was a broadcast ABBR message, use MPR-flooding
    AP_STAT( statUnicastForwardedAsBroadcast++; );
    D(*node->log, lMeshAP, node->getRealTime() << " [abbr-message] " 
      << node->getMainAddress() << " mpr-forward" << endl);
    node->getPacketManager()->defaultForwardingMessage(message, info);

  } else {
    // This message is for another Mesh AP and for another forwarder
    AP_STAT( statUnicastIgnored++; );
    D(*node->log, lMeshAP, node->getRealTime() << " [abbr-message] " 
	<< node->getMainAddress() << " unicast ignored" << endl);
  }
}

IMessageContent* ABBRMessageHandler::parseMessageContent(Message* message)
{
  ABBRMessage* result
    = new ABBRMessage(node->getAddressFactory());
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());
  
  result->destinationAPAddress = buffer.popAddress();
  result->nextHopAddress = buffer.popAddress();

  while (buffer.size()>0) {
    int blockIndex = buffer.popUInt16();
    result->blockIndexList.push_back(blockIndex);
  }
  message->setContent(result); //XXX: this may be wrong!
  return result;
}

void ABBRMessageHandler::packMessageContent
(IMessageContent* message, int maximumMessageSize,
 MemoryBlock*& packedResult, IMessageContent*& messageRemainingResult,
 PackingInfo& packingInfo)
{
  ABBRMessage* m = dynamic_cast<ABBRMessage*>(message);

  PacketBuffer buffer;
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message->header);

  //XXX! splitting is not supported
  buffer.packAddress(m->destinationAPAddress);
  buffer.packAddress(m->nextHopAddress);
  for (ITER(std::list<int>, it, m->blockIndexList))
    buffer.pushUInt16((*it));

  messageRemainingResult = NULL;
  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  packedResult = buffer.getContent();
}

void ABBRMessageHandler::adjustMessageSize(IMessageContent* message)
{
  ABBRMessage* m = dynamic_cast<ABBRMessage*>(message);
  int addressSize = node->getAddressFactory()->getAddressSize();

  int contentSize = 
    addressSize   // [destinationAddress]
    + addressSize // [nextHopAddress]
    + (m->blockIndexList.size()
       * 2); // [block index]
  m->header->messageSize = 
    MessageHeaderWithoutAddressSize + addressSize // message header
    + contentSize;
  m->header->minMessageSize = m->header->messageSize; // cannot be split
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

MeshAPNode::MeshAPNode() 
  : Node(), globalAssociationBase(this), localAssociationBase(this),
    blockChangeCount(0), blockRequestCount(0), fullMode(true)
{}

//--------------------------------------------------

void MeshAPNode::start()
{
  LABAMessageHandler*  labaMessageHandler  = new LABAMessageHandler(this);
  LABCAMessageHandler* labcaMessageHandler = new LABCAMessageHandler(this);
  ABBRMessageHandler*  abbrMessageHandler  = new ABBRMessageHandler(this);
  packetManager->addMessageHandler(LABA_MESSAGE,  labaMessageHandler);
  packetManager->addMessageHandler(LABCA_MESSAGE, labcaMessageHandler);
  packetManager->addMessageHandler(ABBR_MESSAGE,  abbrMessageHandler);
  ParentMeshAPNode::start();
  startLocalAssociationBaseAdvertisement();
}

//--------------------------------------------------

void MeshAPNode::processLABAMessage(LABAMessage* message)
{
  Message* header = message->header;
  Address meshAPAddress = header->originatorAddress;
  Address sendMainAddress = ifaceToMainAddress(header->sendIfaceAddress);
  if (!isSymmetricNeighbor(sendMainAddress))
    return; // we will get a symmetric one... avoid processing it several times

  AP_STAT( statLABAProcessed++; );
  D(*log, lMeshAP, getRealTime() << " [process-laba-message] "
    << getMainAddress() << " " << *message << endl);

  Time currentTime = getCurrentTime();
  Time validityTime = header->getValidityTime();
  Time expirationTime = currentTime + validityTime;

  AddressMap<bool> visitedAddress;
  vector<bool> visitedBlock(MAX_NB_BLOCK, true);
  
  for (ITER(std::list<BlockInfo>, it, message->blockInfoList)) {
    int blockIndex = (*it).blockIndex;
    if (blockIndex >= MAX_NB_BLOCK) {
      Warn("Block index " << blockIndex << " too big in message " << *message);
      continue;
    }
    visitedBlock[blockIndex] = true;
    for (ITER(std::list<StationInfo>, staIt, (*it).stationInfoList)) {
      Address stationAddress = (*staIt).address;
      StationSeqNum stationSeqNum = (*staIt).stationSeqNum;

      // Global Association Base Population
      visitedAddress.add(stationAddress, true);
      GlobalAssociationTuple* globalAssociation 
	= globalAssociationBase.findFirst_APAndStation(meshAPAddress, 
						       stationAddress);
      if (globalAssociation != NULL) {
	if (isStationSeqNumGreaterOrEqual
	    (stationSeqNum, globalAssociation->GA_station_sequence_number)) {
	  // Step 3.1: update
	  globalAssociation->GA_station_sequence_number = stationSeqNum;
	  globalAssociation->GA_block_index = blockIndex;
	  globalAssociation->GA_expiration_time = expirationTime;
	  globalAssociation->update();
	} else {
	  // Step 3.2: ignore
	}
      } else {
	// Step 3.3
	globalAssociation = new GlobalAssociationTuple(this);
	globalAssociation->GA_AP_address = meshAPAddress;
	globalAssociation->GA_station_address = stationAddress;
	globalAssociation->GA_block_index = blockIndex;
	globalAssociation->GA_station_sequence_number = stationSeqNum;
	globalAssociation->GA_expiration_time = expirationTime;
	globalAssociationBase.add(globalAssociation);
	globalAssociation->update();
      }

      // Local Association Base Population
      LocalAssociationTuple* localAssociation = 
	localAssociationBase.findStationByAddress(stationAddress);
      if (localAssociation != NULL 
	  && isStationSeqNumGreater
	  (stationSeqNum, localAssociation->LA_station_sequence_number)) {
	// Indirect detection of disassociation
	AP_STAT( statImplicitDisassociate++; );
	int blockIndex = localAssociation->block->LA_block_index;
	localAssociationBase.disassociate(localAssociation);
	notifyBlockChange(blockIndex, false);
      }	
    }    
  }

  // Global Association Block cleaning:
  // Delete the list of not renewed global association base information
  list<GlobalAssociationTuple*> obsoleteAssociationList;
  for (GlobalAssociationBase::TupleIterator it=globalAssociationBase.getIter();
       !it.isDone(); it.next()) {
    GlobalAssociationTuple* globalAssociation = it.getCurrent();
    if (globalAssociation->GA_AP_address == meshAPAddress) {
      bool isObsolete = 
	visitedBlock[globalAssociation->GA_block_index]
	&& !visitedAddress.get(globalAssociation->GA_station_address, false);
      isObsolete |= (globalAssociation->GA_block_index 
		     >= message->nbBlock);
      if (isObsolete)
	obsoleteAssociationList.push_back(globalAssociation);
    }
  }
  for (ITER(std::list<GlobalAssociationTuple*>, it, obsoleteAssociationList))
    globalAssociationBase.removeAndDelete(*it);
}

//---------------------------------------------------------------------------

void MeshAPNode::processLABCAMessage(LABCAMessage* message)
{
  Message* header = message->header;
  Address meshAPAddress = header->originatorAddress;
  Address sendMainAddress = ifaceToMainAddress(header->sendIfaceAddress);
  if (!isSymmetricNeighbor(sendMainAddress))
    return; // we will get a symmetric one... avoid processing it several times

  AP_STAT( statLABCAProcessed++; );
  D(*log, lMeshAP, getRealTime() << " [process-labca-message] "
    << getMainAddress() << " " << *message << endl);

  Time currentTime = getCurrentTime();
  Time validityTime = header->getValidityTime();
  Time expirationTime = currentTime + validityTime;

  int nbBlock = message->blockChecksumList.size();
  if (nbBlock > MAX_NB_BLOCK) {
    Warn("Too many blocks (" << nbBlock << ") in LABCA message: " << *message);
  }

  // Get the list of station associated with each block
  vector< list<AddressAndSeqNum> > stationInfoPerBlock(nbBlock);
  list<GlobalAssociationTuple*> obsoleteAssociationList;
  for (GlobalAssociationBase::TupleIterator it=globalAssociationBase.getIter();
       !it.isDone(); it.next()) {
    GlobalAssociationTuple* globalAssociation = it.getCurrent();
    if (!(globalAssociation->GA_AP_address == meshAPAddress))
      continue;
    int blockIndex = globalAssociation->GA_block_index;
    if (blockIndex < nbBlock) {
      // expiration time should be updated (step 1)
      globalAssociation->GA_expiration_time = expirationTime;

      AddressAndSeqNum stationInfo;
      stationInfo.first = globalAssociation->GA_station_address;      
      stationInfo.second = globalAssociation->GA_station_sequence_number;
      stationInfoPerBlock[blockIndex].push_back(stationInfo);
    } else {
      // entry should be removed (step 2)
      obsoleteAssociationList.push_back(globalAssociation);
    }
  }

  // Actually remove the obsolete entry (as in step 2)
  for (ITER(std::list<GlobalAssociationTuple*>, it, obsoleteAssociationList))
    globalAssociationBase.removeAndDelete(*it);

  // Now verify the checksums of the blocks...
  list<int> incorrectBlockIndexList;
  for (int blockIndex=0; blockIndex<nbBlock; blockIndex++) {
    BlockChecksum blockChecksum = 
      ::getChecksum(getAddressFactory(),
		    stationInfoPerBlock[blockIndex]);
    if (message->blockChecksumList[blockIndex] != blockChecksum) {
      incorrectBlockIndexList.push_back(blockIndex);
      AP_STAT( statInconsistentChecksum++; );
    } else {
      AP_STAT( statConsistentChecksum++; );
    }
  }

  if (incorrectBlockIndexList.size() > 0)
    sendABBRMessage(meshAPAddress, incorrectBlockIndexList);
}

//--------------------------------------------------

void MeshAPNode::sendABBRMessage(Address meshAPAddress,
				 list<int>& blockIndexList)
{
  assert( blockIndexList.size() > 0 ); // (not necessary for here anyway)

  // Find destination address, and next hop
  OLSRIface* iface = NULL;
  Address nextHopAddress = getMainAddress(); // convention: mpr-flooding
  if (!protocolConfig->useBroadcastABBR) {
    RoutingTuple* routingTuple = getRoute(meshAPAddress);
    if (routingTuple == NULL) {
      // can't find the next hop: drop the message
      AP_STAT( statABBRGeneratedNoRoute++; );
      D(*log, lMeshAP, getRealTime() << " [generate-message] " 
	<< getMainAddress() << " dropped unknown=" << meshAPAddress << endl);
      return;
    }
    iface = getIfaceByAddress(routingTuple->R_iface_addr);
    assert( iface != NULL );
    nextHopAddress = routingTuple->R_next_addr;
  }

  // Create ABBR message
  ABBRMessage* m = new ABBRMessage(addressFactory);
  m->destinationAPAddress = meshAPAddress;
  m->nextHopAddress = nextHopAddress;
  m->blockIndexList = blockIndexList;

  // Create Message header
  Message* message = new Message
    (ABBR_MESSAGE,
     0 /*toMantissaExponentByte(0)*/, // vtime
     getMainAddress(), // originator address
     MaxTTL, // ttl
     0); // hop count

  m->header = message;
  message->content = m;
  message->maxTime = getCurrentTime();

  // Send it
  AP_STAT( statABBRGenerated++; );  
  D(*log, lMeshAP, getRealTime() << " [generate-abbr] "
    << getMainAddress() << " " << (*message) << endl);
  sendMessage(iface, message);
}

//--------------------------------------------------

void MeshAPNode::processABBRMessage(ABBRMessage* message)
{
  // [we don't check if previous hop is symmetrical]
  if (!(message->destinationAPAddress == getMainAddress()))
    return; 

  AP_STAT( statABBRProcessed++; );
  D(*log, lMeshAP, getRealTime() << " [process-abbr-message] "
    << getMainAddress() << " " << *message << endl);

  for (ITER(std::list<int>, it, message->blockIndexList)) {
    localAssociationBase.recordRequest( *it );
    blockRequestCount++;
  }
  notifyEndProcessABBRMessage(message->header->originatorAddress);
}

//---------------------------------------------------------------------------

void MeshAPNode::performAssociateStation(Address stationAddress, 
					 StationSeqNum stationSeqNum)
{ 
  LocalAssociationTuple* associationTuple 
    = localAssociationBase.findStationByAddress(stationAddress);

  if (associationTuple != NULL) {
    int blockIndex = associationTuple->block->LA_block_index;
    localAssociationBase.removeAndDelete(associationTuple);
    notifyBlockChange(blockIndex, false);
  }
  localAssociationBase.performAssociateStation(stationAddress, 
					       stationSeqNum); 
  associationTuple 
    = localAssociationBase.findStationByAddress(stationAddress);
  assert(associationTuple != NULL);
  notifyBlockChange(associationTuple->block->LA_block_index, true);
}

void MeshAPNode::performDisassociateStation(Address stationAddress)
{ 
  LocalAssociationTuple* associationTuple 
    = localAssociationBase.findStationByAddress(stationAddress);

  if (associationTuple != NULL) {
    int blockIndex = associationTuple->block->LA_block_index;
    localAssociationBase.performDisassociateStation(stationAddress);
    notifyBlockChange(blockIndex, false);
  }
}

bool MeshAPNode::getAssociation(Address stationAddress,
				Address& resultMeshAP,
				StationSeqNum& resultStationSeqNum)
{
  
  GlobalAssociationTuple* globalAssociation 
    = globalAssociationBase.getBestGlobalAssociation(stationAddress);
  LocalAssociationTuple* localAssociation 
    = localAssociationBase.findStationByAddress(stationAddress);
  
  if (globalAssociation != NULL) {
    resultMeshAP = globalAssociation->GA_AP_address;
      resultStationSeqNum = globalAssociation->GA_station_sequence_number;
  }
  
  if ( (globalAssociation == NULL && localAssociation != NULL)
       || (globalAssociation != NULL && localAssociation != NULL 
	   && isStationSeqNumGreater
	   (localAssociation->LA_station_sequence_number,
	    globalAssociation->GA_station_sequence_number))) {
    resultMeshAP = getMainAddress();
    resultStationSeqNum = localAssociation->LA_station_sequence_number;
  }
  return !resultMeshAP.isNull();
}

//---------------------------------------------------------------------------

void MeshAPNode::logState(ostream& out, bool noEnd)
{
  Node::logState(out, true);
  logAssociationTable(out);
  if (!noEnd) {
    out << getRealTime() << " [state-end] " << getMainAddress() << endl;
  }
}

//---------------------------------------------------------------------------

void MeshAPNode::logAssociationTable(ostream& out)
{
  out << getRealTime() << " [local-association-base] " << getMainAddress()
      << " " << localAssociationBase << endl;
  out << getRealTime() << " [global-assocation-base] " << getMainAddress()
      << " " << globalAssociationBase << endl;
}

//---------------------------------------------------------------------------

void MeshAPNode::startLocalAssociationBaseAdvertisement()
{
  Time delay = 
    _startDelay(0, protocolConfig->labaGenerationInterval);
  addGenerationEvent(getCurrentTime() + delay, getCurrentTime()+delay, 
		     &Node::eventLABGeneration, 
		     "local-association-advertisement-generation");
}

//---------------------------------------------------------------------------

// [returns -1 if no block, hence #blocks == maxBlockIndex+1 ]
int AssociationBase::getMaxBlockIndex()
{
  int maxBlockIndex = -1;
  for (ITER(std::list<LocalAssociationTuple*>, it, associationList))
    maxBlockIndex = myMax(maxBlockIndex, (*it)->block->LA_block_index);
  return maxBlockIndex;
}

static int sumListInt(list<int>& valueList)
{
  int result = 0;
  for (ITER(std::list<int>, it, valueList))
    result += (*it);
  return result;
}


void MeshAPNode::sendLABAMessage(list<BlockInfo>& blockInfoList, int nbBlock)
{
  // Create LABA message
  LABAMessage* m = new LABAMessage(addressFactory);
  m->nbBlock = nbBlock;
  m->blockInfoList = blockInfoList;

  // Create Message header
  Time expirationTime = protocolConfig->labaExpirationRelativeTime
    * protocolConfig->labaGenerationInterval;
  Message* message = new Message
    (LABA_MESSAGE,
     toMantissaExponentByte(expirationTime), // vtime
     getMainAddress(), // originator address
     MaxTTL, // ttl
     0); // hop count

  m->header = message;
  message->content = m;
  message->maxTime = getCurrentTime();

  // Send it
  AP_STAT( statLABAGenerated++; );  
  D(*log, lMeshAP, getRealTime() << " [generate-laba] "
    << getMainAddress() << " " << (*message) << endl);
  sendMessage(NULL, message);
}

void MeshAPNode::sendLABCAMessage(int nbBlock)
{
  // Compute the checksums of each set
  vector<BlockChecksum> blockChecksumList(nbBlock);
  for (int blockIndex=0; blockIndex<nbBlock; blockIndex++) {
    BlockChecksum blockChecksum = localAssociationBase.block[blockIndex]
      .getChecksum(getAddressFactory(), 0);
    blockChecksumList[blockIndex] = blockChecksum;
  }

  // Create LABCA message
  LABCAMessage* m = new LABCAMessage(addressFactory);
  m->blockChecksumList = blockChecksumList;

  // Create Message header
  Time expirationTime = protocolConfig->labaExpirationRelativeTime
    * protocolConfig->labaGenerationInterval;
  Message* message = new Message
    (LABCA_MESSAGE,
     toMantissaExponentByte(expirationTime), // vtime
     getMainAddress(), // originator address
     MaxTTL, // ttl
     0); // hop count

  m->header = message;
  message->content = m;
  message->maxTime = getCurrentTime();

  // Send it
  AP_STAT( statLABCAGenerated++; );  
  D(*log, lMeshAP, getRealTime() << " [generate-labca] "
    << getMainAddress() << " " << (*message) << endl);
  sendMessage(NULL, message);
}


void MeshAPNode::eventLABGeneration()
{
  updateCurrentTime();
  preEvent("gen-LAB-advertisement");

  Time interval = protocolConfig->labaGenerationInterval;
  double minDelay = interval - protocolConfig->MAXJITTER;
  if(minDelay <0) minDelay = 0;
  addGenerationEvent(getCurrentTime() + minDelay,
		     getCurrentTime() + interval,
		     &Node::eventLABGeneration,
		     "local-association-advertisement-generation");

  // First update the counters
  //if (blockChangeCount == 0 && blockRequestCount == 0)
  //noChangeGenerationCount++;

  blockChangeCountList.push_back(blockChangeCount);
  if ((int)blockChangeCountList.size() > protocolConfig->nbGenerationSampling)
    blockChangeCountList.pop_front();
  blockRequestCountList.push_back(blockRequestCount);
  if ((int)blockRequestCountList.size() > protocolConfig->nbGenerationSampling)
    blockRequestCountList.pop_front();
  blockChangeCount = 0;
  blockRequestCount = 0;

  int cumulBlockChangeCount = sumListInt(blockChangeCountList);
  int cumulBlockRequestCount = sumListInt(blockRequestCountList);
  
  if (fullMode) {
    if (cumulBlockChangeCount <= protocolConfig->minLABChange
	&& cumulBlockRequestCount <= protocolConfig->minLABRequest)
      fullMode = false;
  } else {
    if (cumulBlockChangeCount >= protocolConfig->maxLABChange
	|| cumulBlockRequestCount >= protocolConfig->maxLABRequest)
      fullMode = true;
  }

  int nbBlock = localAssociationBase.getMaxBlockIndex()+1;
  vector< list<StationInfo> > stationPerBlock(nbBlock);
  vector<bool> shouldSendBlock(nbBlock);

  for (int i=0; i<nbBlock; i++) {
    shouldSendBlock[i] = localAssociationBase.recordedRequest[i];
    localAssociationBase.recordedRequest[i] = false;
  }
  for (ITER(std::list<LocalAssociationTuple*>, it,
	    localAssociationBase.associationList)) {
    int blockIndex = (*it)->block->LA_block_index;    
    if (fullMode || shouldSendBlock[blockIndex]) {
      StationInfo stationInfo;
      stationInfo.address = (*it)->LA_station_address;
      stationInfo.stationSeqNum = (*it)->LA_station_sequence_number;
      stationPerBlock[blockIndex].push_back(stationInfo);
    }
  }
  
  list<BlockInfo> blockInfoList;
  for (int i=0; i<nbBlock; i++) {
    if (fullMode || shouldSendBlock[i]) {
      BlockInfo blockInfo;
      blockInfo.blockIndex = i;
      blockInfo.stationInfoList = stationPerBlock[i];
      blockInfoList.push_back(blockInfo);
    } else {
      assert( stationPerBlock[i].size() == 0 );
    }
  }
  
  if (fullMode || blockInfoList.size() > 0) {
    sendLABAMessage(blockInfoList, nbBlock);
  }
  if (!fullMode || (int)blockInfoList.size() < nbBlock) {
    sendLABCAMessage(nbBlock);
  }

  postEvent("gen-LAB-advertisment");
}

//---------------------------------------------------------------------------

void MeshAPNode::performTupleExpiration()
{
  //cerr << "performTupleExpiration " << getMainAddress() << " "
  //     << globalEventCounter << " " << getCurrentTime() << endl;
  globalAssociationBase.removeAndDeleteExpired( getCurrentTime() );
  ParentMeshAPNode::performTupleExpiration();
}

void MeshAPNode::getNextExpireTime(Time& nextExpireTime, bool& hasExpireTime)
{
  ParentMeshAPNode::getNextExpireTime(nextExpireTime, hasExpireTime);
  updateMinExpireTime(getCurrentTime(), nextExpireTime, 
		      hasExpireTime, globalAssociationBase);
  //cerr << "getNextExpireTime " << getMainAddress() << " "
  //     << globalEventCounter << " " << getCurrentTime()
  //     << ": " << nextExpireTime << "(" << hasExpireTime << ")" << endl;
}

//---------------------------------------------------------------------------

void MeshAPNode::notifyBlockChange(int blockIndex, bool isAssociation)
{
  if (isBlockChanged.count(blockIndex) == 0) 
    isBlockChanged[blockIndex] = true;
  blockChangeCount++;
}

//---------------------------------------------------------------------------

void MeshAPNode::notifyEndProcessABBRMessage(Address originatorAddress)
{ /* do nothing */ }

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

#ifndef WITH_ASSOCIATION_STAT
string getAssociationStat()
{ Fatal("WITH_ASSOCIATION_STAT was not defined"); return ""; }
#else //defined(WITH_ASSOCIATION_STAT):

#define ADtoR(x) r += Repr(#x << "=" << x << "\n");
string getAssociationStat()
{
  string r="";

  ADtoR(statRecordedRequest);

  ADtoR(statDefaultForwarding);

  ADtoR(statUnicastDroppedTTL);
  ADtoR(statUnicastDroppedRoute);
  ADtoR(statUnicastForwarded);
  ADtoR(statUnicastForwardedAsBroadcast);
  ADtoR(statUnicastIgnored);
  ADtoR(statUnicastArrived);
  //ADtoR(statBroadcastPseudoLost);

  ADtoR(statLABAProcessed);
  ADtoR(statLABAGenerated);
  ADtoR(statLABCAProcessed);
  ADtoR(statLABCAGenerated);
  ADtoR(statABBRProcessed);
  ADtoR(statABBRGenerated);
  ADtoR(statABBRGeneratedNoRoute);


  ADtoR(statImplicitDisassociate);
  //ADtoR(statStationAdd);
  //ADtoR(statStationRemove);
  //ADtoR(statStationUpdate);

  ADtoR(statConsistentChecksum);
  ADtoR(statInconsistentChecksum);
  //ADtoR(statMissingBlockRequest);

  return r;
}
#undef ADtoR

#endif // WITH_ASSOCIATION_STAT

//---------------------------------------------------------------------------

