//---------------------------------------------------------------------------
//                             OOLSR
//              Yasser Toor, projet Hipercom, INRIA Rocquencourt
//      Nicolas Grzeskowiak, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// System calls for Cygwin/Windows
//---------------------------------------------------------------------------

#include <winsock2.h>
#include <windows.h>
#include <ws2tcpip.h>
#include "iphlpapi.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef UNDER_CE
#include <sys/types.h>
#endif

#ifdef UNDER_CE
#define strdup _strdup
#endif

#include "general.h"
#include "address.h"
#include "network_generic.h"

#include "scheduler_simulation.h"
#include "scheduler_unix.h"


//---------------------------------------------------------------------------

// XXX: why in this file ?
#ifdef WITH_HTTPSERVER // XXX: this is a hack

#include "http_support.h"

#include "html_support.cc" // XXX:  rename


IHTTPServer* httpServer = NULL;
extern IHTTPServer* makeHTTPServer();

#include "node.h" // XXX
void startHTTPServer(IOScheduler* scheduler, Node* node)
{
  httpServer = makeHTTPServer();
  httpServer->open(scheduler, node->getProtocolConfig()->httpAdminPort,
		   new ProtocolHTTPVisitor(node) /*XXX: leak*/);
}
#else // !WITH_HTTPSERVER
void startHTTPServer(IOScheduler* scheduler, Node* node)
{ /* do nothing */ }
#endif // WITH_HTTPSERVER

//---------------------------------------------------------------------------


//
// See also:
// http://www.ietf.org/rfc/rfc3542.txt
//

//---------------------------------------------------------------------------

class CygwinLowLevel
{
public:
  static void setSocketReuseAddr(int sd)
  {
    int on = 1;
    if (setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (char*)&on, /* was void* */
		   sizeof (on)) < 0)
      Fatal(" setsockopt SO_REUSEADDR: " << strerror(errno));
  }

  static void setSocketBroadcast(int sd)
  {
    int on = 1;
    if (setsockopt(sd, SOL_SOCKET, SO_BROADCAST, (char*)&on,
		   sizeof (on)) < 0)
      Fatal(" setsockopt SO_BROADCAST: " << strerror(errno));
  }
};

#define STR_IP_BROADCAST "255.255.255.255" // XXX: defined twice

//---------------------------------------------------------------------------

class CygwinIPv4LowLevel : public CygwinLowLevel
{
public:


  //  &ipv6Address.sin6_addr

  typedef sockaddr_in SystemAddress;

  static int getAddressSize()
  { return 4; }  // static const int AddressSize = 4; // XXX: correct one

  static void* systemAddressToRawAddress(SystemAddress& systemAddress) {
    assert( systemAddress.sin_family == AF_INET );
    assert( sizeof(systemAddress.sin_addr) == getAddressSize() );
    return &systemAddress.sin_addr;
  }

  static void rawAddressToSystemAddress(void* rawAddress, 
					SystemAddress& resultAddress)
  {
    memset(&resultAddress, 0, sizeof(resultAddress));
    resultAddress.sin_family = AF_INET;
    memcpy(&resultAddress.sin_addr, rawAddress, getAddressSize());
  }

  static void reprAddress(SystemAddress& address, char* result)
  { 
    //inet_ntop(AF_INET, &address.sin_addr, result, 4096 /*XXX!*/); 
    strcpy(result, inet_ntoa(address.sin_addr));
  }

  static int makeUDPSocket()
  {
    int sd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sd < 0)
      Fatal(" socket(PF_INET6, SOCK_DGRAM, 0): " << strerror(errno));
    return sd;
  }

  static void strToAddress(SystemAddress& sockAddress, char* strGroupAddress)
			     
  {
    memset(&sockAddress, 0, sizeof(sockAddress));
    sockAddress.sin_family = AF_INET;

    if (strGroupAddress == NULL)
      sockAddress.sin_addr.s_addr = INADDR_ANY; // XXX
    else sockAddress.sin_addr.s_addr = inet_addr(strGroupAddress); 
  }

  static void setAddressPort(SystemAddress& sockAddress, int udpPort)
  { sockAddress.sin_port = htons(udpPort); }

  static void joinMulticastGroup(int sd, int ifaceIndex /* unused */, 
				 SystemAddress& ifaceAddress,
				 char* strGroupAddress)
  {
    if ( string(strGroupAddress) == STR_IP_BROADCAST) {
      // we don't actually "join" in this case
      setSocketBroadcast(sd);
      //char* tmpIfaceName = strdup(ifaceName.c_str());
      //      setsockopt(sd, SOL_SOCKET, SO_BINDTODEVICE, tmpIfaceName,
      //	 strlen(tmpIfaceName)+1);
      //free(tmpIfaceName);

      return; 
    }


    //XXX: use ip_mreq_source and imr_address for IGMPv3
    struct ip_mreq mreq; // not mreqn

    memset (&mreq, 0, sizeof (mreq));
    //inet_pton(AF_INET, strGroupAddress, &mreq.imr_multiaddr);
    mreq.imr_multiaddr.s_addr = inet_addr(strGroupAddress);
    mreq.imr_interface = ifaceAddress.sin_addr;

    
    if(setsockopt(sd, IPPROTO_IP, IP_ADD_MEMBERSHIP,
		  (char *) &mreq, sizeof (mreq)) < 0)
      Fatal(" setsockopt IP_ADD_MEMBERSHIP: " << strerror(errno) );
  }

  // http://www.tldp.org/HOWTO/Multicast-HOWTO-6.html
  static void setSocketMulticastDefaultIface(int sd, int ifaceIndex,
					     SystemAddress& ifaceAddress)
  {
    // XXX: int ifaceIndex
    if (setsockopt(sd, IPPROTO_IP, IP_MULTICAST_IF, 
		   (char*)&ifaceAddress.sin_addr,
		   sizeof(ifaceAddress.sin_addr)) < 0)
      Fatal(" setsockopt IP_MULTICAST_IF: " << strerror(errno) );
  }

  //XXX: redundant with IPv6, should be templatized
  static void socketBind(int sd, SystemAddress& address)
  {
    address.sin_addr.s_addr = INADDR_ANY; // XXX!! kludge
    int status = bind(sd, (struct sockaddr*)&address, sizeof(address));
    if (status < 0)
      Fatal("socketBind: " << strerror(errno));
  }

  static int socketRecv(int sd, void* buffer, int bufferSize,
			SystemAddress& recvAddress)
  {
    socklen_t socketSize = sizeof(recvAddress);
    int status = recvfrom(sd, (char*)buffer, bufferSize, /*flags*/ 0,
			  (struct sockaddr*)&recvAddress, &socketSize);
    if(status <0) { // XXX: warning
      Warn("error in recvfrom: " << strerror(errno));
      return status;
    } else {
      return status;
    }
  }

  static void socketSend(int sd, void* data, int dataSize, 
			SystemAddress& sendAddress)
  {
    if(sendto(sd, (char*)data, dataSize, 0, (sockaddr*)&sendAddress,
	      sizeof(sendAddress)) <0)
      Fatal(" sendto: " << strerror(errno) );// XXX: not fatal
  }
};

//---------------------------------------------------------------------------

template <class LowLevel>
class LinuxAddressFactory : public AddressFactory
{
public:

  typedef typename LowLevel::SystemAddress SystemAddress;

  LinuxAddressFactory() : AddressFactory(LowLevel::getAddressSize())
  {}

  Address makeAddress(SystemAddress& systemAddress) 
  { return Address(this, LowLevel::systemAddressToRawAddress(systemAddress)); }

  void makeSystemAddress(Address address, SystemAddress& result)
  { LowLevel::rawAddressToSystemAddress(address.getRawAddress(), result); }

  virtual void write(ostream& out, const Address& address)
  {
    typename LowLevel::SystemAddress systemAddress;
    LowLevel::rawAddressToSystemAddress(address.getRawAddress(),
					systemAddress);
    char strAddress[4096]; // XXX
    LowLevel::reprAddress(systemAddress, strAddress);
    out << strAddress;
  }
};

typedef LinuxAddressFactory<CygwinIPv4LowLevel> CygwinIPv4AddressFactory;

//---------------------------------------------------------------------------

#define OLSR_PORT 698 // XXX: not really

template<class LowLevel>
class CygwinSystemIface : public ISystemIface, public IFdHandler
{
public:
  IOScheduler* scheduler;
  LinuxAddressFactory<LowLevel>* addressFactory;
  IPacketReceiver* packetReceiver;
  Address address;
  char* strOutputAddress;

  CygwinSystemIface(char* aIfaceName, Address aAddress, int aIfaceIndex,
		   IOScheduler* aScheduler,
		   LinuxAddressFactory<LowLevel>* aFactory,
		   char* aStrOutputAddress, IfaceConfig* aIfaceConfig)
    : address(aAddress), packetReceiver(NULL), scheduler(aScheduler),
      addressFactory(aFactory), ifaceIndex(aIfaceIndex), name(aIfaceName)
  {
    ifaceSocket = -1;
    associatedIface = NULL;
    strOutputAddress = strdup(aStrOutputAddress);
    ifaceConfig = aIfaceConfig; // from ISystemIface
  }

  virtual void openSocket(IPacketReceiver* aPacketReceiver)
  {
    packetReceiver = aPacketReceiver;
    // Create output socket.
    ifaceSocket = LowLevel::makeUDPSocket(); //ipv6MakeUDPSocket();
    typename LowLevel::SystemAddress ifaceSystemAddress;
    addressFactory->makeSystemAddress(address, ifaceSystemAddress);

    // XXX: Windows: must bind before joining multicast group
    typename LowLevel::SystemAddress anyOLSRPortAddress;
    addressFactory->makeSystemAddress(address, anyOLSRPortAddress);
    //LowLevel::strToAddress(anyOLSRPortAddress, NULL);
    LowLevel::setAddressPort(anyOLSRPortAddress, OLSR_PORT);
    LowLevel::socketBind(ifaceSocket, anyOLSRPortAddress);


    LowLevel::setSocketReuseAddr(ifaceSocket);
    LowLevel::setSocketMulticastDefaultIface(ifaceSocket, ifaceIndex, 
					     ifaceSystemAddress);
    LowLevel::joinMulticastGroup(ifaceSocket, ifaceIndex, ifaceSystemAddress,
				 strOutputAddress);
    LowLevel::strToAddress(sendSystemAddress, strOutputAddress);
    LowLevel::setAddressPort(sendSystemAddress, OLSR_PORT);


    scheduler->addFdHandler(this, NULL);
  }
  
  virtual void sendPacket(Address destinationAddress, MemoryBlock* packet) 
  {
    assert( destinationAddress.isNull() );
    LowLevel::socketSend(ifaceSocket, packet->data, packet->size, 
			 sendSystemAddress);
    delete packet; // XXX: check memory is freed
  }

  virtual int getMTU()
  { return ifaceConfig->mtu; }

  virtual Address getAddress()
  { return address; }


  // IFdHandler
  virtual FileDescriptor getFileDescriptor() { return ifaceSocket; }
  virtual bool waitingForInput() { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; } // XXX:  check
  virtual void handleInput()
  {
    const int MaxBufferSize = 65536; // XXX: not inline
    octet* buffer = new octet[MaxBufferSize]; 
    typename LowLevel::SystemAddress recvAddress;
    int maxSize = MaxBufferSize;
    int status = LowLevel::socketRecv(ifaceSocket, buffer, 
				      maxSize, recvAddress);
    if(status > 0) { // XXX: what if == 0, closed?
      MemoryBlock* packet = new MemoryBlock(buffer, status, true);
      packetReceiver->evReceivePacket
	(packet, addressFactory->makeAddress(recvAddress), 
	 this->associatedIface);
    }
    delete buffer;
  }

  virtual void handleOutput() { Fatal("Impossible call"); }
  virtual void handleExcept() { Fatal("Impossible call"); }

  // borrowed
  char* getName() { return name; }

  int getIfaceIndex() { return ifaceIndex; }

protected:
  typename LowLevel::SystemAddress sendSystemAddress;

  int ifaceSocket;
  int ifaceIndex;
  char* name; // system name of the interface
};

//---------------------------------------------------------------------------

#if 0
void
int on;
  on=6;
  if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &on, sizeof (on)) < 0)
    Fatal("setsockopt SO_PRIORITY: " << strerror(errno));

#endif

//---------------------------------------------------------------------------


//----------------------------------------------------------------------------
// If returned status is NO_ERROR, then pIpRouteTab points to a routing
// table.
//----------------------------------------------------------------------------

DWORD ///XXX: clean-up
MyGetIpForwardTable(PMIB_IPFORWARDTABLE* pIpRouteTab, BOOL fOrder)
{
  DWORD status = NO_ERROR;
  DWORD statusRetry = NO_ERROR;
  DWORD dwActualSize = 0;
  PMIB_IPFORWARDTABLE pTempIpRouteTab=NULL;

  status = GetIpForwardTable(pTempIpRouteTab,&dwActualSize,fOrder);
  if (status == NO_ERROR)
    return status;
  else if (status == ERROR_INSUFFICIENT_BUFFER) {
    pTempIpRouteTab = (PMIB_IPFORWARDTABLE) malloc(dwActualSize);
    assert(pTempIpRouteTab);
    statusRetry = GetIpForwardTable(pTempIpRouteTab, &dwActualSize, fOrder);
    *pIpRouteTab = pTempIpRouteTab;
    return statusRetry;
  } else {
    printf("Error: Unknown Error [%d]\n",status);
    return status;
  }
}


//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

//typedef LinuxAddressFactory<LinuxIPv4LowLevel> LinuxIPv4AddressFactory;

class CygwinIPv4NetworkConfigurator : public INetworkConfigurator
{
public:

  CygwinIPv4NetworkConfigurator(CygwinIPv4AddressFactory* aAddressFactory)
    : addressFactory(aAddressFactory) { }


  /// Add one route in the kernel
  virtual void addRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric)
  {
    sockaddr_in destSysAddr;
    sockaddr_in gatewaySysAddr;
    CygwinSystemIface<CygwinIPv4LowLevel>* ipv4Iface 
      = (CygwinSystemIface<CygwinIPv4LowLevel>*) iface;
    addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
    addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);

    DWORD dwStatus;
    MIB_IPFORWARDROW routeEntry; // ip routing entry
    PMIB_IPADDRTABLE pIpAddrTable = NULL; // ip addr table

    memset(&routeEntry,0,sizeof(MIB_IPFORWARDROW));
    routeEntry.dwForwardDest = destSysAddr.sin_addr.s_addr;
  
    if (!(destIpAddress == gatewayAddress))
      routeEntry.dwForwardNextHop = gatewaySysAddr.sin_addr.s_addr;
    else routeEntry.dwForwardNextHop = destSysAddr.sin_addr.s_addr;
      routeEntry.dwForwardIfIndex = ipv4Iface->getIfaceIndex();

#if 0
      if(destination->rt_dst==INADDR_ANY)
	routeEntry.dwForwardMask = inet_addr(NETMASK_DEFAULT);
      else
	routeEntry.dwForwardMask = inet_addr((char *)NETMASK_HOST);
#else
      // XXX: only one host:
      routeEntry.dwForwardMask = 0xffffffff; // XXX! constant.
#endif
      
      routeEntry.dwForwardMetric1 = metric + 1;
      routeEntry.dwForwardProto = 0; //XXX!! [PROTO_IP_LOCAL;]
      routeEntry.dwForwardMetric2 = -1;
      routeEntry.dwForwardMetric3 = -1;
      routeEntry.dwForwardMetric4 = -1;
    
      dwStatus = SetIpForwardEntry(&routeEntry);
      if (dwStatus != NO_ERROR)
	Fatal(" SetIPForwardEntry: " << GetLastError());
  }
  
  /// Remove one route from the kernel
  virtual void removeRoute(ISystemIface* iface, Address destIpAddress,
			   Address gatewayAddress, Address netMaskAddress, 
			   int metric)
  {
    sockaddr_in destSysAddr;
    sockaddr_in gatewaySysAddr;
    CygwinSystemIface<CygwinIPv4LowLevel>* ipv4Iface 
      = (CygwinSystemIface<CygwinIPv4LowLevel>*) iface;
#if 0
    addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
    addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
    int status = KERN_del_route_IPV4(skfd, 
				     &destSysAddr.sin_addr,
				     &gatewaySysAddr.sin_addr,
				     0, 
				     0, //0xffffffffu, // XXX! real mask
				     metric, ipv4Iface->getName());
    if (status < 0)
      Fatal("KERN_del_route: "); // XXX: not fatal
#endif
    DWORD dwStatus, dwDelStatus, i;
    PMIB_IPFORWARDTABLE pIpRouteTab = NULL; // Ip routing table
    MIB_IPFORWARDROW routeEntry;            // Ip routing table row entry
    DWORD dwForwardDest = 0;
    BOOL fDeleted = FALSE;

    addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
    addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
    
    memset(&routeEntry, 0, sizeof(MIB_IPFORWARDROW));
    dwForwardDest = destSysAddr.sin_addr.s_addr;
    dwStatus = MyGetIpForwardTable(&pIpRouteTab, TRUE);

    if (dwStatus == NO_ERROR) {
      for (int i = 0; i < pIpRouteTab->dwNumEntries; i++) {
	if (dwForwardDest == pIpRouteTab->table[i].dwForwardDest) {
	  memcpy(&routeEntry, &(pIpRouteTab->table[i]),
		 sizeof(MIB_IPFORWARDROW));
	  dwDelStatus = DeleteIpForwardEntry(&routeEntry); 
	  if (dwDelStatus != NO_ERROR)
	    Fatal("DeleteIpForwardEntry: "<<GetLastError());//XXX!not fatal
	}
	free(pIpRouteTab); // XXX: GlobalFree ?
      } 
    } else Fatal("Error: Could not get the IP forward table: " 
		   << GetLastError());
  }
  
  CygwinIPv4AddressFactory* addressFactory;
};


void startWinSock2()
{
  int err;
  WORD wVersionRequested;
  WSADATA wsaData;
  
  // open winsock //
  wVersionRequested = MAKEWORD( 2, 2 );
  err = WSAStartup( wVersionRequested, &wsaData );
  if ( err != 0 ) {
    printf("Error: WSAStartup failed with error %d\n", WSAGetLastError());
    exit(1);
  }
  if ( LOBYTE( wsaData.wVersion ) != 2 ||
       HIBYTE( wsaData.wVersion ) != 2 ) 
    {
      WSACleanup( );
      if (err == SOCKET_ERROR) {
	printf("WSACleanup failed with error %d\n", WSAGetLastError());
      }
      exit(1);
    }
  // winsock ok //
}


class CygwinIPv4SystemFactory : public ISystemFactory
{
public:
  int skfd;

  CygwinIPv4SystemFactory() 
  {
    startWinSock2();
    baseScheduler = new SimulationScheduler;
    scheduler = new IOScheduler(baseScheduler);
    baseScheduler->setTime(scheduler->getTime());
    networkConfigurator = new CygwinIPv4NetworkConfigurator(&addressFactory);
  }

  virtual AddressFactory* getAddressFactory() 
  { return &addressFactory; }

  virtual ISystemIface* getIfaceByName(ProtocolConfig* protocolConfig, 
				       const string name, IfaceConfig* ifaceConfig);

  virtual INetworkConfigurator* getNetworkConfigurator()
  { return networkConfigurator; }

  virtual IScheduler* getScheduler()
  { return scheduler; }
  
  virtual void visitNode(Node* node)
  { startHTTPServer(scheduler, node); }

protected:
  CygwinIPv4AddressFactory addressFactory;
  CygwinIPv4NetworkConfigurator* networkConfigurator;
  IOScheduler* scheduler;
  SimulationScheduler* baseScheduler;
};

ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig)
{ return new CygwinIPv4SystemFactory; }

ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig)
{ return NULL; }

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

#if 0
  // XXX! should be in a helper module
  //turn ip forwarding on
  if (!initialized ) {
    memset(&Overlapped,0, sizeof(OVERLAPPED));
    Overlapped.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (EnableRouter(&Handle, &Overlapped) != ERROR_IO_PENDING) 
      printf("Error: Could not turn IP forwarding on\n");
    initialized = 1;
  }
  if (GetIpStatistics(&lstats) != NO_ERROR) 
    printf("Error: Could not turn IP forwarding on\n");
  lstats.dwForwarding = MIB_IP_FORWARDING; //start forwarding
  if (SetIpStatistics(&lstats) != NO_ERROR) 
    printf("Error: Could not turn IP forwarding on\n");
#endif


//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------


#define MAX_INTERFACES	1024

ISystemIface* CygwinIPv4SystemFactory::getIfaceByName
(ProtocolConfig* protocolConfig, const string name, IfaceConfig* ifaceConfig)
{
  INTERFACE_INFO* ifo = new INTERFACE_INFO[MAX_INTERFACES]; // list of interfaces 
    // (allocated because CE has limited stack)
  unsigned long size_of_ifo = sizeof(INTERFACE_INFO);
  unsigned long br=0;
  u_long i;
  DWORD Err,AdapterInfoSize,s;
  PIP_ADAPTER_INFO pAdapterInfo,pAdapt;
  DWORD Nb_i,For_i,Save,Nbinterf = 0;
  struct sockaddr_in *sin;
  char * ip_addr;
  char c[2];
  struct interf_name *nt;

  MIB_IPSTATS lstats;	
  OVERLAPPED	Overlapped;
  HANDLE		Handle;

  
#if 0
  // get interfaces list
  memset(&ifo[0],0,sizeof(ifo));
  Err=WSAIoctl(s, SIO_GET_INTERFACE_LIST, NULL, 0,
	       &ifo[0], sizeof(ifo), &br, NULL, NULL);
  if (Err!=0)
    Fatal("Error: GET_INTERFACE_LIST failed with error " << WSAGetLastError());
#endif

  // get ip adapater info
  // Enumerate all of the adapter specific information using the IP_ADAPTER_INFO structure.
  // Note:  IP_ADAPTER_INFO contains a linked list of adapter entries.
  //
  AdapterInfoSize = 0;
  if ((Err = GetAdaptersInfo(NULL, &AdapterInfoSize)) != 0)
    if (Err != ERROR_BUFFER_OVERFLOW)
      Fatal("Error: GetAdaptersInfo sizing failed with error" << Err);


  // Allocate memory from sizing information
  pAdapterInfo = (PIP_ADAPTER_INFO) GlobalAlloc(GPTR, AdapterInfoSize);
  if (pAdapterInfo == NULL)
    Fatal("Error:  Memory allocation error in PIP_ADAPTER_INFO\n");

  // Get actual adapter information
  if ((Err = GetAdaptersInfo(pAdapterInfo, &AdapterInfoSize)) != 0)
    Fatal("Error: GetAdaptersInfo failed with error" << Err);

  // Number of interfaces
  Nb_i=br/size_of_ifo;

  //give name and index to good interfaces
  //ip_addr=inet_ntoa(sin->sin_addr);
  
  int ifaceIndex = -1;
  char* ifaceDescription = NULL;
  Address ifaceAddress;

  pAdapt = pAdapterInfo;
  while (pAdapt)
    {
      if (name == "" || name == "show") {
	cerr << "Interface #" << pAdapt->Index << ":"  << endl
		  << "  name: " << pAdapt->AdapterName << endl
		  << "  desc: " << pAdapt->Description << endl 
		  << "  ip: " << pAdapt->IpAddressList.IpAddress.String 
		  << endl;
      } else if (atoi(name.c_str()) == pAdapt->Index || name == "auto") {
        ifaceDescription= strdup(pAdapt->Description); // XXX
	ifaceIndex = pAdapt->Index;
	sockaddr_in tmpAddress;
	memset(&tmpAddress, 0, sizeof(tmpAddress));
	tmpAddress.sin_family = AF_INET;
	tmpAddress.sin_addr.s_addr = 
	  inet_addr(pAdapt->IpAddressList.IpAddress.String);
	ifaceAddress = addressFactory.makeAddress(tmpAddress);
      }
#if 0
      if ((strcmp(ip_addr,pAdapt->IpAddressList.IpAddress.String))==0)
	{
	  ifp->int_name = (char *)malloc(strlen(pAdapt->Description) + 1);
	  if (ifp->int_name == 0)
	    Fatal("Out of memory");
	  strcpy(ifp->int_name, pAdapt->Description);
	  ifp->int_index = pAdapt->Index;
	  break;
	}
#endif
      pAdapt = pAdapt->Next;
    }

  if (ifaceIndex<0)
    Exit("Cannot find interface with name='" << name <<"'");
    
  delete ifo;

  return new 
    CygwinSystemIface<CygwinIPv4LowLevel>
    ( (char*)/*XXX*/name.c_str(), ifaceAddress,
      ifaceIndex,
      scheduler, &addressFactory,
      (char*)/*XXX*/protocolConfig->ipv4MulticastAddress.c_str(),
      ifaceConfig);
}

//---------------------------------------------------------------------------

ISystemFactory* getSystemFactory()
{ return new CygwinIPv4SystemFactory; }

//---------------------------------------------------------------------------
