//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//     $Id: daemon_core.cc,v 1.42 2006/02/14 13:49:58 rodolaki Exp $
//---------------------------------------------------------------------------
// The main OLSR daemon
//---------------------------------------------------------------------------

#include "base.h"

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#include "mystream.h"
#include <vector>

#if !defined(SYSTEMwindows)
#include <unistd.h> // for fork (XXX: move to system_linux.cc)
#include <errno.h> // ... ditto
#endif

//---------------------------------------------------------------------------

#include "general.h"
#include "log.h"
#include "scheduler_unix.h"
#include "node.h"
#include "network_generic.h"
#include "network_linux.h"
#include "protocol_config.h"

#ifdef MOOLSR
#include "molsrNode.h"
#include "mdfpCom.h"
#endif

#ifdef MOST
#include "mostMdfpCom.h"
#endif //MOST

#include "node_inheritance.h"

//---------------------------------------------------------------------------

extern ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig);
extern ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig);

#ifdef WITH_QOS
extern IPacketCounter* makePacketCounter(string aIfaceName,
					 string aTCLocation,
					 string aSyntaxTcCmd1,
					 string aSyntaxTcCmd2,
					 string aSyntaxTcCmd3,
					 int    aQosQosTcHandle,
					 int    aQosOlsrTcHandle,
					 int    aQosBeTcHandle);
#endif //WITH_QOS

#ifndef WITH_IPV4
#ifndef WITH_IPV6
#error Check that you have created the file Makefile.private (see README)
#endif // WITH_IPV6
#endif // WITH_IPV4

#ifndef UNDER_CE
int main(int argc, char** argv)
#else
int startOLSR(int argc, char** argv)
#endif
{
  //int i;
  //int nbIface = argc-1;
  cerr.precision(15);
  cout.precision(15);

  if(argc <= 1) {
    cerr << "Syntax: " << argv[0] 
	      << " [options...] with options:" << endl;
    cerr << " -f <config file>: reads a configuration file " << endl;
    cerr << " -i <iface name>: use interface <iface name> (repeat if there are several ifaces)" << endl;
    cerr << " --use-ipv4 : use IPv4" << endl;
    cerr << " --use-ipv6 : use IPv6" << endl;
    cerr << " --<parameter name> <parameter value>" << endl;
    cerr << " --<command> [<command args> ...]" << endl;
    cerr << " --on <iface name> <iface parameter name>"
                 " <iface parameter value>" << endl;
    exit(EXIT_FAILURE);
  }

  ConfigParser parser;
  Log* log = new Log;
  ProtocolConfig* protocolConfig = new ProtocolConfig;
  parser.parseArgList(*protocolConfig, *log, argv+1, argc-1);

  if(protocolConfig->ipv4 && protocolConfig->ipv6) 
    protocolConfig->ipv4 = false; // IPv6 take precedence

  if (protocolConfig->onlyParseConfig) {
    cout << "# Configuration output:" << endl;
    exit(EXIT_SUCCESS);
  }

  //--------------------------------------------------
  
  ISystemFactory* systemFactory = NULL;

  if (protocolConfig->ipv6) {
    systemFactory = getIPv6SystemFactory(protocolConfig);
    if (systemFactory == NULL)
      Exit("Cannot use IPv6, check that your binary supports it");
  } else if (protocolConfig->ipv4) {
    systemFactory = getIPv4SystemFactory(protocolConfig);
    if (systemFactory == NULL)
      Exit("Cannot use IPv4, check that your binary supports it");
  } else Exit("Neither ipv4 nor ipv6 are defined in configuration.");
#ifdef MOOLSR
    MolsrNode* node = new MolsrNode;
    IMDFP *mdfp=new MDFPCom(node,systemFactory->getScheduler(),2700,2699);
    node->configureMDFP(mdfp);

    // XXX: MOLSR should be optional and node should be new ClassNode
#warning QoS/Security are not activated in.

#else
  Node* node = new ClassNode;
#endif
 
  PacketManager* packetManager = new PacketManager(node);

  std::list<ISystemIface*> systemIfaceList;

  typedef std::map<string,GeneratedIfaceConfig*> IfaceNameToConfig;
  for(IfaceNameToConfig::iterator it = protocolConfig->ifaceConfig.begin();
      it != protocolConfig->ifaceConfig.end(); it++) {
    string ifaceName = (*it).first;
    GeneratedIfaceConfig* ifaceConfig = (*it).second;
    ISystemIface* systemIface = 
      systemFactory->getIfaceByName(protocolConfig,
				    ifaceName.c_str(), ifaceConfig);
    if(systemIface == NULL)
      Exit("Cannot find a usable interface with name '" 
	   << ifaceName.c_str() 
	   << "' (check you have site-local address when using ipv6)\n");
    if (ifaceName != protocolConfig->mainIface)
      systemIfaceList.push_back(systemIface);
    else systemIfaceList.push_front(systemIface);
    systemIface->openSocket(node);
  }
  
  std::vector<ISystemIface*> systemIfaceVector;
  for (std::list<ISystemIface*>::iterator it = systemIfaceList.begin();
       it != systemIfaceList.end(); it++)
    systemIfaceVector.push_back(*it);

  if(protocolConfig->ifaceConfig.begin()
     == protocolConfig->ifaceConfig.end()) {
    Exit("No interfaces have been given for running OOLSR");
  }
  
#ifndef NOLOG
  if(!protocolConfig->noLog) {
    if (globalLog == NULL) { // XXX: should be done elsewhere
      // XXX: not implemented
      //globalLog = new Log;
      //globalLog->out = createLogFile(protocolConfig->logFileName,
      //				     "global");
    }
    Address address = //Address(systemFactory->getAddressFactory(), 
      systemIfaceVector[0]->getAddress();
    log->out = createLogFile(protocolConfig->logFileName,
			     toText(address));
  }
#endif

#ifndef SYSTEMwindows
  if(!protocolConfig->noFork) {
    // Daemonize (from olsrdv7)
    // XXX: not windows compatible
    pid_t childPid = fork();
    if (childPid != 0)  
      exit(EXIT_SUCCESS);
    close(0);
    close(1);
    close(2);
    setsid();
  }
#else
#endif

#ifdef MOST
  MostNode* mostNode = dynamic_cast<MostNode*>(node);
  if (mostNode != NULL) {
    IMDFP *mdfp=new MDFPCom(mostNode,systemFactory->getScheduler(),2700,2699);
    mostNode->configureMDFP(mdfp);
  } else Warn("Cannot convert Node to MostNode");
#endif // MOST

  // Configure the node
  node->configure(systemFactory->getScheduler(),
		  systemFactory->getAddressFactory(),
		  packetManager, 
		  systemFactory->getNetworkConfigurator(),
		  protocolConfig,
		  systemIfaceVector,
		  log);
  
  // Open the external channels
  IExternalCommunicationManager* extComManager
    = systemFactory->getExternalCommunicationManager();
  node->setExternalCommunicationManager(extComManager);
#if 0
  for (ITER(std::list<ExternalChannelConfig>, it, 
	    protocolConfig->externalChannelList)) {
    ExternalChannelConfig channel = (*it);
    node->openExternalChannel(channel, extComManager);
  }
#endif
 
  node->start();

#ifdef WITH_QOS
  QosNode* qosNode = dynamic_cast<QosNode*>(node);
  if (qosNode != NULL) {
    qosNode->setPacketCounter(makePacketCounter(protocolConfig->mainIface,
						protocolConfig->qosTcLocation,
						protocolConfig->qosSyntaxTcCmd1,
						protocolConfig->qosSyntaxTcCmd2,
						protocolConfig->qosSyntaxTcCmd3,
						protocolConfig->qosQosTcHandle,
						protocolConfig->qosOlsrTcHandle,
						protocolConfig->qosBeTcHandle));
  } else Warn("Cannot convert Node to QosNode: no bandwidth statistics");
#endif // WITH_QOS

  systemFactory->visitNode(node);
  systemFactory->collectSignalEvents(node);
  systemFactory->getScheduler()->runUntilNoEvent();

  exit(EXIT_SUCCESS);
  return EXIT_SUCCESS;
}

//---------------------------------------------------------------------------
