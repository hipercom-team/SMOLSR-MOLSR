//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "message.h"

//---------------------------------------------------------------------------

void HelloMessageHandler::adjustMessageSize(IMessageContent* message)
{
  HelloMessage* m = dynamic_cast<HelloMessage*>(message);
  m->header->messageSize = internalGetMessageSize(m ,NULL);
  int addressSize = node->getAddressFactory()->getAddressSize();
  m->header->minMessageSize = 
    MessageHeaderWithoutAddressSize + addressSize // message header
    + HelloHeaderSize // hello header. And assuming non-empty HELLO:
    + HelloLinkMessageHeaderSize + addressSize; // at least one address
  if(m->header->messageSize < m->header->minMessageSize)
    m->header->minMessageSize = m->header->messageSize; // was an empty HELLO
}

void HelloMessageHandler::processMessage(/*borrowed*/ Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  HelloMessage* helloMessage = dynamic_cast<HelloMessage*>(messageContent);
  // `message' internals are modified so that content point to helloMessage
  // and thus this helloMessage is deleted when message is.
  D(*node->log, lMessage, node->getRealTime() 
    << " [process-message] " << node->getMainAddress() << " " 
    << (*message) << endl);
  node->processHelloMessage(helloMessage);
  delete helloMessage;
}

// Before: 
//    message0 = { packedContent=packetContent0, content = NULL, ... }
// Used to Return helloMessage, with:
//    helloMessage = { header = message0 }
//  and message0 = { packedContent = NULL (deleted), content = helloMessage}
// now modified to return helloMessage with:
//    helloMessage = { header = message1 }
//  and message1 = clone of message 0
IMessageContent* HelloMessageHandler::parseMessageContent(Message* message)
{
  HelloMessage* result = new HelloMessage;
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());
  // @@1690-1691
  result->reserved = buffer.popUInt16(); // @@1523
  result->htime = buffer.popUInt8(); // @@1523
  result->willingness = buffer.popUInt8(); // @@1523
  while(buffer.size()>0) {
    int linkCode = buffer.popUInt8(); // @@1525
    int reserved2 = buffer.popUInt8(); UNUSED(reserved2); // @@1525 - unused
    int size = buffer.popUInt16(); // @@1525
    
    size -= buffer.sizeUInt8()+buffer.sizeUInt8()
      +buffer.sizeUInt16(); // @@1602-1605
    PacketBuffer rawLinkMessage;
    buffer.popSubBuffer(size, rawLinkMessage);
    if (linkCode >= 15) // @@1598,1613
      continue;

    NeighborType neighborType = linkCodeToNeighborType(linkCode);
    LinkType linkType = linkCodeToLinkType(linkCode);
    if ((neighborType != NOT_NEIGH)
	&& (neighborType != SYM_NEIGH)
	&& (neighborType != MPR_NEIGH))
      continue; // @@1668-1671
    if (linkType == SYM_LINK && neighborType == NOT_NEIGH)
      continue; // @@1659-1666

    while(rawLinkMessage.size()>0) { // @@1600-1695
      LinkEntry entry; 
      entry.neighborType = neighborType;
      entry.linkType = linkType;
      entry.address = rawLinkMessage.popAddress(); // @@1607-1609

      result->linkList.push_back(entry);
    }
  }
#if 0
  delete message->packedContent;
  message->packedContent = NULL;
  message->content = result;
  result->header = message;
#endif
  result->header = message->clone(false);
  result->header->content = result;
  return result;
}


void HelloMessageHandler::packMessageContent
(IMessageContent* message, 
 int maximumMessageSize,
 MemoryBlock*& blockResult,
 IMessageContent*& messageRemainingResult,
 PackingInfo& packingInfo)
{
  HelloMessage* m = dynamic_cast<HelloMessage*>(message);

  PacketBuffer buffer;
  int initialPos = buffer.getPosition();
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message->header);

  buffer.pushUInt16(m->reserved); // @@XXX
  buffer.pushUInt8(m->htime); // @@XXX
  buffer.pushUInt8(m->willingness); // @@XXX
  
  list<Address> linkAddressList[LinkCodeLimit];

  int addressSize = node->getAddressFactory()->getAddressSize();

  int messageSize = internalGetMessageSize(m, linkAddressList);

  int addressListCount = -1; /*XXX!*/
  bool mustSplitMessage = false;
  for(int i=0;i<LinkCodeLimit;i++) {
    int linkCode = LinkCodeLimit-1 -i; // reverse: important codes first
    if(linkAddressList[linkCode].empty())
      continue;
    int freeSpace = maximumMessageSize - buffer.getSizeFrom(initialPos);
    if(freeSpace >=  HelloLinkMessageHeaderSize + addressSize ) {
      freeSpace -= HelloLinkMessageHeaderSize;
      /*int*/ addressListCount = linkAddressList[linkCode].size();
      if(freeSpace < addressSize * addressListCount) {
	addressListCount = freeSpace / addressSize;
	mustSplitMessage = true;
      }
      buffer.pushUInt8(linkCode); // @@1525
      buffer.pushUInt8(0); // @@XXX
      buffer.pushUInt16( addressListCount*addressSize 
			 +HelloLinkMessageHeaderSize ); 
      std::list<Address>::iterator it = linkAddressList[linkCode].begin();
      for (int j=0; j<addressListCount; j++) {
	assert( it != linkAddressList[linkCode].end() );
	std::list<Address>::iterator next = it;
	next++;

	buffer.packAddress(*it);

	linkAddressList[linkCode].erase(it);
	it = next;
      }
    } else mustSplitMessage = true;
  }

  assert( (mustSplitMessage && messageSize > maximumMessageSize)
	  || (!mustSplitMessage && messageSize <= maximumMessageSize));
  if (mustSplitMessage) {
    HelloMessage* newHello = dynamic_cast<HelloMessage*>(message->clone());
    messageRemainingResult = newHello;
    newHello->linkList.clear();
    newHello->header->messageSize = -1; // because no longer valid
    newHello->header->minMessageSize = -1;
    for(int i=0;i<LinkCodeLimit;i++) {
      for(std::list<Address>::iterator it = linkAddressList[i].begin();
	  it != linkAddressList[i].end(); it++) {
	LinkEntry entry;

	entry.linkType = linkCodeToLinkType(i);
	entry.neighborType = linkCodeToNeighborType(i);
	entry.address = (*it);
	newHello->linkList.push_back(entry);
      }
    }
  } else messageRemainingResult = NULL;

  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  blockResult = buffer.getContent();
}

int HelloMessageHandler::internalGetMessageSize(HelloMessage* m,
					std::list<Address>* resultList)
{
  // First count the different link types
  int linkCodeCount[LinkCodeLimit];
  for(int i=0;i<LinkCodeLimit;i++)
    linkCodeCount[i] =0;
  
  for(std::list<LinkEntry>::iterator it = m->linkList.begin();
      it != m->linkList.end(); it++) {
    int linkCode = linkAndNeighborToCode((*it).linkType, (*it).neighborType);
    linkCodeCount[linkCode] ++;
    if(resultList != NULL) 
      resultList[linkCode].push_back((*it).address);
  }

  int addressSize = node->getAddressFactory()->getAddressSize();

  // Now compute message size
  int messageSize = MessageHeaderWithoutAddressSize
    + addressSize + HelloHeaderSize;
  for(int i=0;i<LinkCodeLimit;i++)
    if(linkCodeCount[i]>0)
      messageSize += HelloLinkMessageHeaderSize 
	+ addressSize * linkCodeCount[i];

  return messageSize;
}

//---------------------------------------------------------------------------

#if 0
void MIDMessageHandler::considerForwardMessage(Message* message, 
					       string& info)
{ node->getPacketManager()->defaultForwardingMessage(message, info); } // @@XXX
#endif


void TCSpecification::process(Node* node, MessageContent* m)
{ node->processTCMessage(m); }

void MIDSpecification::process(Node* node, MessageContent* m)
{ node->processMIDMessage(m); }

void HNASpecification::process(Node* node, MessageContent* m)
{ node->processHNAMessage(m); }

//---------------------------------------------------------------------------
