//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// [The other, Python version of this protocol is no longer used]
//---------------------------------------------------------------------------

static const int FloatingPrecision = 20;

class MinEvaluator
{
public:
  MinEvaluator(int aMaxSample) : maxSample(aMaxSample)
  { currentMinValue = 0; }

  double get()
  { return currentMinValue; }

  void push(double currentTime, double value, double expireTime) 
  {
    removeExpired(currentTime);
    if ((int)valueList.size() == maxSample) {
      valueList.pop_front();
      expireTimeList.pop_front();
    }
    valueList.push_back(value);
    expireTimeList.push_back(expireTime);
    assert( valueList.begin() != valueList.end() );
    computeMinValue();
  }

  void computeMinValue()
  {
    if (valueList.begin() != valueList.end() ) {
      currentMinValue = *(valueList.begin());
      for (ITER(std::list<double>, it, valueList))
	if ((*it) < currentMinValue)
	  currentMinValue  = (*it);
    }
  }

  int isEmpty(double currentTime) 
  { 
    removeExpired(currentTime);
    return valueList.empty(); 
  }

  void write(ostream& out, double referenceTime = 0.0)
  {
    if (!valueList.empty()) {
      out << currentMinValue << "==min(";
      bool isFirst = true;
      std::list<double>::iterator eIt = expireTimeList.begin();
      for (ITER(std::list<double>, it, valueList)) {
	assert( eIt != expireTimeList.end() );
	if (!isFirst) out << ";";
	else isFirst = false;
	out << (*it) << "(/" << ((*eIt)-referenceTime) << ")";
	eIt++;
      }
      out << ")";
    } else out << "<no-value>";
  }

  void removeExpired(double currentTime)
  {
    bool changed = false;
    while(!valueList.empty()) {
      assert( !expireTimeList.empty() );
      if (expireTimeList.front() <= currentTime) {
	valueList.pop_front();
	expireTimeList.pop_front();
	changed = true;
      } else break;
    }
    if (changed) computeMinValue();
  }

protected:
  int maxSample;
  std::list<double> valueList;
  std::list<double> expireTimeList;
  double currentMinValue;
};

//---------------------------------------------------------------------------

class TimeOffsetTuple
{
public:
  TimeOffsetTuple() : minEvaluator(NULL), hasUpperBound(false) { }

  Time lastOriginatorTime;
  MinEvaluator* minEvaluator;

  Time upperBound;
  bool hasUpperBound;
};

//---------------------------------------------------------------------------

class TimeOffsetSet: public ExpiringMap<string, TimeOffsetTuple>
{
public:
  TimeOffsetSet(double aCheckInterval) 
    : ExpiringMap<string, TimeOffsetTuple>(aCheckInterval) { }


  // Template method
  virtual void notifyDelete(string& rawAddrStr)
  {
    if (content[rawAddrStr].value.minEvaluator != NULL)
      delete content[rawAddrStr].value.minEvaluator;
  }
};

//---------------------------------------------------------------------------

class TimeOffsetExchangeProtocol : public ByteMessageHandler
{
public:
  TimeOffsetExchangeProtocol(Node* aNode) 
    : ByteMessageHandler(aNode, TIME_PROTOCOL_MESSAGE) 
  { timeOffsetTable = NULL; }

  //--------------------------------------------------
  // Simple sending of a message
  //--------------------------------------------------
  
  //virtual void sendMessage(/*owned*/ MemoryBlock* data);
  
  //--------------------------------------------------
  // Simple receival of a message
  //--------------------------------------------------
  
  virtual void actuallyProcessMessage(/*borrowed*/ Message* message,
				      /*borrowed*/ MemoryBlock* packedHeader,
				      /*borrowed*/ MemoryBlock* block)
  {
    // Parse Message Content
    AddressFactory* addressFactory = node->getAddressFactory();

    PacketBuffer buffer(*block, addressFactory);
    try {
      Time senderTime = buffer.popDoubleAsFixed();
      Time hasMyTime = false;
      Time myTime = 0;
      bool hasOtherMyDiffTime = false;
      Time otherMyDiffTime = 0;

      D(*node->log, lTimeProtocol, node->getRealTime()
	<< " [time-protocol-process] " << node->getMainAddress() << " "
	<< message->originatorAddress << "@" << senderTime );
      
      while(buffer.size() > 0) {
	Address address = buffer.popAddress();
	Time otherTime = buffer.popDoubleAsFixed();
	bool hasDiffTime = false;
	Time otherDiffTime = -buffer.popOptDoubleAsFixed(hasDiffTime);

	if (address == node->getMainAddress()) {
	  hasMyTime = true;
	  myTime = otherTime;
	  hasOtherMyDiffTime = hasDiffTime;
	  otherMyDiffTime = otherDiffTime;
	  // true, -diffTime);
	  // XXX!!: break
	}
	D(*node->log, lTimeProtocol, " " << address << ":" << otherTime);
	if (hasDiffTime) {
	  D(*node->log, lTimeProtocol, "("<< otherDiffTime<< ")");
	}
      }
      D(*node->log, lTimeProtocol, endl);
      processMessageTimeInfo(message->originatorAddress, senderTime,
			     hasMyTime, myTime, 
			     hasOtherMyDiffTime, otherMyDiffTime);
      //processMessageTimeInfo(message->originatorAddress, senderTime,
      //false, 0.0, false, 0.0);

    } catch(PacketFormatError& error) { 
      string rawMessage((char*)block->data, block->size);
      Warn("Bad TimeOffsetExchange format: " << reprStr(rawMessage));
    }
  }

  //--------------------------------------------------
  //
  //--------------------------------------------------

  void processMessageTimeInfo(Address originatorAddress, Time senderTime,
			      bool hasOtherTime, Time otherTime,
			      bool hasDiffTime, Time upperDiffTime)
  {
    Time currentTime = node->getCurrentTime();
    timeOffsetTable->expire(currentTime);
    D(*node->log, lTimeProtocol, node->getRealTime()
      << " [time-protocol-process] " << node->getMainAddress() << " "
      << originatorAddress << "@" << senderTime << " recv[send="
      << senderTime);
    if (hasOtherTime) {
      D(*node->log, lTimeProtocol, ",other=" <<  otherTime);
    }
    if (hasDiffTime) {
      D(*node->log, lTimeProtocol, ",diff=" << upperDiffTime);
    }
    D(*node->log, lTimeProtocol, "]");

    string rawOrigAddress = originatorAddress.getRawStr();
    TimeOffsetTuple* timeOffsetTuple = timeOffsetTable->get(rawOrigAddress);
    //Time thisDiffLowerBound = currentTime - senderTime;
    Time thisDiffLowerBound = senderTime - currentTime;

    double expireTime = currentTime
      + node->getProtocolConfig()->timeProtocolHoldTime;

    //--------------------------------------------------
    // The previous, reinvent-the-wheel, algorithm:
#if 0
    // This originator was not know before: 
    if (timeOffsetTuple == NULL) {
      considerGratuitousGeneration();
      TimeOffsetTuple newOffsetTuple;
      newOffsetTuple.lastOriginatorTime = senderTime;
      newOffsetTuple.lowerBound = thisDiffLowerBound;
      newOffsetTuple.hasUpperBound = false;
      timeOffsetTable->set(expireTime, rawOrigAddress, newOffsetTuple);
      D(*node->log, lTimeProtocol, ", new" << endl);
      return;
    } else timeOffsetTable->refresh(expireTime, rawOrigAddress);

    // The originator was known, check that the senderTime is more recent
    if (senderTime <= timeOffsetTuple->lastOriginatorTime) {
      D(*node->log, lTimeProtocol, 
	", not-fresh-sender" << timeOffsetTuple->lastOriginatorTime << endl);
      return;
    }

    //timeOffsetTable->lowerBound = thisDiffLowerBound; // XXX!: hack

    // If the message doesn't include our time, stop here
    if (!hasOtherTime) {
      considerGratuitousGeneration();
      D(*node->log, lTimeProtocol, ", no-time-quote" << endl);
      return;
    }

    //timeOffsetTable->lowerBound = thisDiffLowerBound; // XXX: hack
    //timeOffsetTuple->lastOriginatorTime = senderTime;

    // If the message has too old of our time, stop here
    if (otherTime + node->getProtocolConfig()->timestampTolerance 
	<= currentTime || /*should not happen:*/ otherTime > currentTime ) {
      D(*node->log, lTimeProtocol, ", quote-old-time " << otherTime << endl);
      return;
    }

    //timeOffsetTable->upperBound = ZZZ; // XXX: hack

    // The originator was known, and the received message is a
    // fresh update: update the bounds taking with trust priority:
    // - timeDiffLowerBound
    // - upperDiffTime
    // - values in timeOffset
    if (hasDiffTime) {
      if (upperDiffTime < thisDiffLowerBound) {
	D(*node->log, lTimeProtocol, ", too-low-sender-higher-bound " 
	  << upperDiffTime << "<" << thisDiffLowerBound);
	upperDiffTime = thisDiffLowerBound;
      }
    }

    if (timeOffsetTuple->lowerBound > upperDiffTime) {
      D(*node->log, lTimeProtocol, ", too-high-stored-lower-bound " 
	<< timeOffsetTuple->lowerBound << ">" << upperDiffTime);
      timeOffsetTuple->lowerBound = upperDiffTime;
    }

    if (timeOffsetTuple->hasUpperBound) {
      if (timeOffsetTuple->upperBound < thisDiffLowerBound) {
	D(*node->log, lTimeProtocol, ", too-low-stored-upper-bound "
	  << timeOffsetTuple->upperBound << "<" << thisDiffLowerBound);
	timeOffsetTuple->upperBound = thisDiffLowerBound;
      }

      if (hasDiffTime && timeOffsetTuple->upperBound > upperDiffTime) {
	D(*node->log, lTimeProtocol, ", improved-upper-bound "
	  << upperDiffTime << "<" << timeOffsetTuple->upperBound);
	timeOffsetTuple->upperBound = upperDiffTime;
      }

    } else {
      if (hasDiffTime) {
	D(*node->log, lTimeProtocol, ", set-upper-bound "
	  << timeOffsetTuple->upperBound);
	timeOffsetTuple->hasUpperBound = true;
	timeOffsetTuple->upperBound = upperDiffTime;
      }
    }

    if (thisDiffLowerBound > timeOffsetTuple->lowerBound) {
      D(*node->log, lTimeProtocol, ", improved-lower-bound "
	<< thisDiffLowerBound << ">" << timeOffsetTuple->lowerBound);
      timeOffsetTuple->upperBound = thisDiffLowerBound;
    }

    D(*node->log, lTimeProtocol, " -> [" << timeOffsetTuple->lowerBound <<",");
    if (timeOffsetTuple->hasUpperBound) {
      D(*node->log, lTimeProtocol, timeOffsetTuple->upperBound);
    }
    D(*node->log, lTimeProtocol, "]" << endl);
#endif

    //--------------------------------------------------
    // The new algorithm based on NTP ideas

    // If not tuple was received, throw message
    if (timeOffsetTuple == NULL) {
      considerGratuitousGeneration();
      TimeOffsetTuple newOffsetTuple;
      newOffsetTuple.minEvaluator 
	= new MinEvaluator(node->getProtocolConfig()->timeProtocolMaxSample);
      newOffsetTuple.lastOriginatorTime = senderTime;
      //newOffsetTuple.lowerBound = thisDiffLowerBound;
      //newOffsetTuple.hasUpperBound = false;
      timeOffsetTable->set(expireTime, rawOrigAddress, newOffsetTuple);
      D(*node->log, lTimeProtocol, ", new" << endl);
      return;
    } else timeOffsetTable->refresh(expireTime, rawOrigAddress);

    // The originator was known, check that the senderTime is more recent
    if (senderTime <= timeOffsetTuple->lastOriginatorTime) {
      D(*node->log, lTimeProtocol, 
	", not-fresh-sender" << timeOffsetTuple->lastOriginatorTime << endl);
      return;
    }
    
    // If the message doesn't include our time, stop here
    if (!hasOtherTime) {
      considerGratuitousGeneration();
      D(*node->log, lTimeProtocol, ", no-time-quote" << endl);
      return;
    }

    // This message was sufficiently recent, update the associated 
    // timeOffsetTuple
    timeOffsetTuple->minEvaluator->push
      (currentTime, thisDiffLowerBound,
       currentTime + node->getProtocolConfig()->timeProtocolHoldTime);
    D(*node->log, lTimeProtocol, ", dT=" << thisDiffLowerBound <<endl);

    // also update the upperBound if present:
    if (hasDiffTime) {
      timeOffsetTuple->hasUpperBound = true;
      timeOffsetTuple->upperBound = upperDiffTime;
      D(*node->log, lTimeProtocol, ", otherDT=" <<  upperDiffTime <<endl);
    }

    D(*node->log, lTimeProtocol, "]" <<endl);
  }

  Time getAbsoluteNetTime()
  {
    Time currentTime = node->getCurrentTime();
    Time bestOffset = 0.0; // this node

    typedef ExpiringMap<string,TimeOffsetTuple>::ExpireKeyValue
      ExpireKeyValue;
    typedef std::list< ExpireKeyValue > TimeOffsetInfoList;
    TimeOffsetInfoList contentList;
    timeOffsetTable->getContent(contentList);
    for (ITER(TimeOffsetInfoList, it, contentList)) {
      if (!(*it).value.minEvaluator->isEmpty(currentTime)) {
	Time offset = (*it).value.minEvaluator->get();
	if (offset < bestOffset)
	  offset = bestOffset;
      }
    }
    return bestOffset + currentTime;
  }

  void considerGratuitousGeneration()
  { }

  //--------------------------------------------------
  //
  //--------------------------------------------------

  void start()
  {
    assert( timeOffsetTable == NULL );
    timeOffsetTable = new TimeOffsetSet(1.0);
  }

  //--------------------------------------------------
  //
  //--------------------------------------------------

  bool checkTimeOffsetWithOther(Time currentTime, string rawAddress, 
				Time otherTime, Time toleratedMargin)
  {
    const double epsilon = 1e-3; // 1 ms
    AddressFactory* addressFactory = node->getAddressFactory();
    Address address(addressFactory, (void*)rawAddress.data());
    D(*node->log, lTimeProtocol, "(time-protocol-check: " << otherTime << " ");
    TimeOffsetTuple* timeOffsetTuple = timeOffsetTable->get(rawAddress);
    if (timeOffsetTuple != NULL 
	&& !timeOffsetTuple->minEvaluator->isEmpty(currentTime)
	&& timeOffsetTuple->hasUpperBound) {
      //return -timeOffsetTuple->lowerBound; // our bound is more trusted
      Time lowerBound = timeOffsetTuple->minEvaluator->get();
      Time upperBound = timeOffsetTuple->upperBound;
      if ( upperBound + epsilon < lowerBound ) {
	D(*node->log, lTimeProtocol, "upper-lower-inconsistent "
	  << lowerBound << "/" << upperBound << ") ");
	return false;
      }

      if ( upperBound - lowerBound >= 
	   node->getProtocolConfig()->timeProtocolMaxRtt) {
	D(*node->log, lTimeProtocol, "rtt-too-big "
	  << lowerBound << "/" << upperBound << ") ");
	return false;
      }

      //Time minTime = currentTime + lowerBound - toleratedMargin;
      //Time maxTime = currentTime + upperBound + toleratedMargin;
      Time otherMinTime = otherTime - lowerBound;
      Time otherMaxTime = otherTime - upperBound;	
      //bool result = (minTime <= otherTime) && (otherTime <= maxTime);
      bool result = (otherMaxTime <= currentTime + toleratedMargin) 
	&& (otherMinTime >= currentTime - toleratedMargin);

      //D(*node->log, lTimeProtocol, minTime << "<=" << otherTime << "<=" 
      //<< maxTime << ":" << (result?"yes":"no") << ") ");
      D(*node->log, lTimeProtocol, currentTime - toleratedMargin << "<=" 
	<< otherMinTime << "/" << otherMaxTime << "<=" 
	<< currentTime + toleratedMargin << ":" << (result?"yes":"no") <<") ");
      return result;	    
    } else {
      if (timeOffsetTuple == NULL) {
	D(*node->log, lTimeProtocol, "no-tuple) ");
      } else if (timeOffsetTuple->minEvaluator->isEmpty(currentTime)) {
	D(*node->log, lTimeProtocol, "no-min-time) ");
      } else if (!timeOffsetTuple->hasUpperBound) {
	D(*node->log, lTimeProtocol, "no-upper-bound) ");
      }
      return false;
    }
  }

  //--------------------------------------------------
  //
  //--------------------------------------------------

  void generateMessage()
  {
    D(*node->log, lTimeProtocol, node->getRealTime() 
      << " [time-protocol-generate] " << node->getMainAddress() << " ");
    Time currentTime = node->getCurrentTime();

    typedef ExpiringMap<string,TimeOffsetTuple>::ExpireKeyValue
      ExpireKeyValue;
    //typedef std::list< ExpireKeyValue > TimeOffsetInfoList;
    AddressFactory* addressFactory = node->getAddressFactory();
    PacketBuffer buffer(addressFactory);
    buffer.packDoubleAsFixed(node->getCurrentTime());
    D(*node->log, lTimeProtocol, node->getCurrentTime()<<" ");
    std::list< ExpireKeyValue > contentList;
    timeOffsetTable->getContent(contentList);
    bool isFirst = 1;
    for (ITER(std::list< ExpireKeyValue >, it, contentList)) {
      string& rawAddrStr = (*it).key;
      buffer.packData((void*)rawAddrStr.data(), rawAddrStr.size());
      buffer.packDoubleAsFixed((*it).value.lastOriginatorTime);
      TimeOffsetTuple& t = (*it).value;
      if (t.minEvaluator != NULL && !t.minEvaluator->isEmpty(currentTime))
	buffer.packOptDoubleAsFixed(t.minEvaluator->get(), true);
      else buffer.packOptDoubleAsFixed(0.0, false);

      Address address(addressFactory, (void*)rawAddrStr.data());
      if (!isFirst) { D(*node->log, lTimeProtocol, ";"); }
      else isFirst = false;
      D(*node->log, lTimeProtocol, address << "/"
	<< (*it).value.lastOriginatorTime);
      if (t.minEvaluator != NULL && !t.minEvaluator->isEmpty(currentTime)) {
	D(*node->log, lTimeProtocol, "/" << t.minEvaluator->get());
      }
    }
    buffer.rewind();
    MemoryBlock* packet = buffer.getContent();
#if 0
    string strPacket((char*)packet->data, packet->size); // XXX: inefficient
    D(*node->log, lTimeProtocol, reprStr(strPacket) << endl);
#endif
    D(*node->log, lTimeProtocol, endl);
    sendMessage(packet);
  }

  virtual void write(ostream& out) 
  {
    //out << node->getRealTime() << " [table-time-offset] " << getMainAddress()
    //<< ": "
    int originalPrecision = out.precision();
    out.precision(FloatingPrecision);

    typedef ExpiringMap<string,TimeOffsetTuple>::ExpireKeyValue
      ExpireKeyValue;
    typedef std::list< ExpireKeyValue > TimeOffsetInfoList;
    
    Time currentTime = node->getCurrentTime();    
    bool isFirst = true;
    //std::list< pair<string,Time> > contentList;
    TimeOffsetInfoList contentList;
    timeOffsetTable->getContent(contentList);
    for (ITER(TimeOffsetInfoList, it, contentList)) {
      string addressStr = (*it).key;
      //Time offsetTime = (*it).value;
      Time expireTime = (*it).expireTime;
      AddressFactory* addressFactory = node->getAddressFactory();
      Address address(addressFactory, (void*)addressStr.data());
      if (!isFirst) out << ",";
      else isFirst = false;

      out << address << ": " << (*it).value.lastOriginatorTime
	  << ",";
      //<< (*it).value.lowerBound;
      (*it).value.minEvaluator->write(out);
      if ((*it).value.hasUpperBound)
	out << " upper=" << (*it).value.upperBound;
      //} else out << "-INF";
      out << " ";
      writeExpireTime(out, currentTime, expireTime);
    }
    
    out << endl;
    out.precision(originalPrecision);
  }

  virtual vector< vector<string>*>* getTimeOffsetTableContent()
  {
    vector<vector<string>*>* result = new vector<vector<string>*>;

    // build header
    vector< string >* headerContent = new vector< string >;
    headerContent->push_back("address");
    headerContent->push_back("lastOriginatorTime");
    headerContent->push_back("minEvaluator");
    headerContent->push_back("upperBound");
    headerContent->push_back("expireTime");
    result->push_back(headerContent);

    typedef ExpiringMap<string,TimeOffsetTuple>::ExpireKeyValue
      ExpireKeyValue;
    typedef std::list< ExpireKeyValue > TimeOffsetInfoList;

    Time currentTime = node->getCurrentTime();    
    TimeOffsetInfoList contentList;
    timeOffsetTable->getContent(contentList);
    for (ITER(TimeOffsetInfoList, it, contentList)) {
      string addressStr = (*it).key;
      Time expireTime = (*it).expireTime;
      AddressFactory* addressFactory = node->getAddressFactory();
      Address address(addressFactory, (void*)addressStr.data());

      vector< string >* content = new vector< string >;

      ostringstream tmpStr1; tmpStr1 << address;
      content->push_back(tmpStr1.str());
      ostringstream tmpStr2;
      tmpStr2.precision(FloatingPrecision);
      tmpStr2 << (*it).value.lastOriginatorTime;
      content->push_back(tmpStr2.str());
      ostringstream minEvaluatorStr;
      minEvaluatorStr.precision(FloatingPrecision);
      (*it).value.minEvaluator->write(minEvaluatorStr, currentTime);
      content->push_back(minEvaluatorStr.str());
      if ((*it).value.hasUpperBound) {
	ostringstream tmpStr3; 
	tmpStr3.precision(FloatingPrecision);
	tmpStr3 << ((*it).value.upperBound);
	content->push_back(tmpStr3.str());
      } else { content->push_back("[-]"); }

      ostringstream expireTimeStr;
      expireTimeStr.precision(FloatingPrecision);
      writeRelativeExpireTime(expireTimeStr, currentTime, expireTime);
      content->push_back(expireTimeStr.str());

      result->push_back(content);
    }
    return result;
  }

  virtual ~TimeOffsetExchangeProtocol()
  { 
    if (timeOffsetTable!= NULL)
      delete timeOffsetTable;
  }

protected:
  TimeOffsetSet* timeOffsetTable;
};

//---------------------------------------------------------------------------
