//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include <memory>

#include "base.h"

#include "general.h"
#include "address.h"
#include "protocol_tuple.h"
#include "packet.h"
#include "message.h"
#include "node.h"
#include "node_link_monitoring.h"

#ifdef MULTICAST_RESEARCH
#include "SYMulti/gma_message.h"
#include "SYMulti/mi_message.h"
#endif

#ifdef WITH_EXTENSION
#include "message_extension.h"
#endif

#ifdef MOOLSR
#include "MOOLSR/molsrMsg.h"
#include "MOOLSR/molsrMdfpMsg.h"
template class GenericMessageHandler<SourceClaimSpecification>;
template class GenericMessageHandler<ConfParentLeaveSpecification>;
template class GenericMessageHandler<MCTreeSpecification>;
template class GenericMessageHandler<LeaveNewLocalSrcClientSpecification>;
#endif //MOOLSR

//---------------------------------------------------------------------------

int nbTCReceived = 0;

const int SequenceNumberLimit = (1<<16); // 16 bits: XXX draft reference

//---------------------------------------------------------------------------

bool DuplicateTuple::isInIfaceList(Address ifaceAddress) {
  for(std::list<Address>::iterator it = D_iface_list.begin();
      it != D_iface_list.end();it++)
    if (*it == ifaceAddress) return true;
  return false;
}

//---------------------------------------------------------------------------

// XXX! redefined elsewhere
ostream& operator << (ostream& out, DuplicateTuple& t)
{
  out << t.D_addr << " seq=" << t.D_seq_num << " retrans=" 
      << t.D_retransmitted << " iface=(";
  bool isFirst = true;
  for(std::list<Address>::iterator it = t.D_iface_list.begin();
      it != t.D_iface_list.end(); it++) {
    if (!isFirst) out <<",";
    else isFirst = false;
    out << (*it);
  }
  out << ") " << t.D_time;
  return out;
}

//---------------------------------------------------------------------------

Message* Message::clone(bool withContent)
{
  Message* result = new Message(messageType, vtime, 
				originatorAddress, 
				timeToLive, hopCount);
  result->messageSequenceNumber = messageSequenceNumber;
  result->sendIfaceAddress = sendIfaceAddress;
  result->recvIfaceAddress = recvIfaceAddress;
  result->origin = origin;
  result->messageSize = messageSize;
  result->minMessageSize = minMessageSize;
  result->maxTime = maxTime;
  result->destinationAddress = destinationAddress;
  if (packedContent != NULL)
    result->packedContent = packedContent->clone();
  else { assert (result->packedContent == NULL) ; }
  if (packedHeader != NULL)
    result->packedHeader = packedHeader->clone();
  else { assert (result->packedHeader == NULL) ; }
  if (content != NULL && withContent)
    result->content = content->clone();
  else { assert (result->content == NULL) ; }
#ifdef WITH_EXTENSION
  if (messageTLVSet != NULL)
    result->messageTLVSet = messageTLVSet->clone();
  else { assert (result->messageTLVSet == NULL) ; }
#endif // WITH_EXTENSION
#ifdef WITH_SECURITY
  result->checkStatus = checkStatus;
#endif // WITH_SECURITY
  return result;
}

//---------------------------------------------------------------------------

//export
template <class MessageSpecification>
void GenericMessageHandler<MessageSpecification>
::adjustMessageSize(IMessageContent* message)
{
  MessageContent* m = dynamic_cast<MessageContent*>(message);
  int addressSize = node->getAddressFactory()->getAddressSize();
  int itemSize = MessageSpecification::getItemSize(addressSize);

  m->header->messageSize =
    MessageHeaderWithoutAddressSize + addressSize // message header
    + MessageSpecification::getContentHeaderSize(addressSize) // content header
    + itemSize * MessageSpecification::getList(m).size(); // content
  
  m->header->minMessageSize = 
    MessageHeaderWithoutAddressSize + addressSize // message header
    + HelloHeaderSize // hello header. And assuming non-empty TC:
    + HelloLinkMessageHeaderSize + itemSize; // at least one item
  
  if(m->header->messageSize < m->header->minMessageSize)
    m->header->minMessageSize = m->header->messageSize; // was an empty mes.
}

//export 
template <class MessageSpecification>
void GenericMessageHandler<MessageSpecification>
::processMessage(/*borrowed*/ Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  MessageContent* fullMessage = dynamic_cast<MessageContent*>(messageContent);
  D(*node->log, lMessage, node->getRealTime() 
    << " [process-message] " << node->getMainAddress() << " " 
    << (*fullMessage) << endl);
  MessageSpecification::process(node, fullMessage);
  delete fullMessage; 
  // BEFORE UPDATE, NO LONGER TRUE: Why deleted here and not in HELLOs:
  // fullMessage->header is a clone of message->result here
  // while message is made to point to helloMessage in HELLOs
}

// Before: 
//    message0 = { packedContent=packetContent0, content = NULL, ... }
// Return messageContent, with:
//    messageContent = { header = message1 }
//  and message1 = clone of message0

template <class MessageSpecification>
IMessageContent* GenericMessageHandler<MessageSpecification>
::parseMessageContent(/*borrowed*/ Message* message)
{
  MessageContent* result = new MessageContent;
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());
  MessageSpecification::parseMessageContentHeader(result, buffer);
  while (buffer.size() > 0)
    MessageSpecification::parseMessageItem(result, buffer);
  result->header = message->clone(false);
  result->header->content = result; // XXX!! long missing line, corrected
  return result;
}

//export
template <class MessageSpecification>
void GenericMessageHandler<MessageSpecification>::packMessageContent
(IMessageContent* message, 
 int maximumMessageSize,
 MemoryBlock*& blockResult,
 IMessageContent*& messageRemainingResult,
 PackingInfo& packingInfo)
{
  MessageContent* m = dynamic_cast<MessageContent*>(message);
  MessageContent* newTC = NULL;
  int addressSize = node->getAddressFactory()->getAddressSize();
  int itemSize = MessageSpecification::getItemSize(addressSize);

  if(maximumMessageSize < m->header->messageSize) {
    newTC = dynamic_cast<MessageContent*>( m->clone() );
    MessageSpecification::getList(newTC).clear(); // XXX: inefficient
    newTC->header->messageSize = -1; // because no longer valid
    newTC->header->minMessageSize = -1;
  } else newTC = NULL;
  messageRemainingResult = newTC;

  PacketBuffer buffer;
  int initialPosition = buffer.getPosition();
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message->header);
  
  MessageSpecification::packMessageContentHeader(m, buffer);
  
  MessageItemList& itemList = MessageSpecification::getList(m);
  MessageItemList* newItemList = (newTC == NULL) ? NULL
    : &(MessageSpecification::getList(newTC));
  for(typename MessageItemList::iterator it = itemList.begin(); 
      it != itemList.end(); it++)
    if (buffer.getSizeFrom(initialPosition) + itemSize < maximumMessageSize)
      MessageSpecification::packMessageItem(*it, buffer);
    else { assert(newItemList != NULL); newItemList->push_back(*it); }

  assert( (newTC == NULL) || newItemList->size()>0 );

  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  blockResult = buffer.getContent(); //buffer.popBlock(buffer.size());
}

//---------------------------------------------------------------------------

//export 
template <class MessageSpecification>
void GenericMessageHandler<MessageSpecification>
::considerForwardMessage(Message* message, string& info)
{ node->getPacketManager()->defaultForwardingMessage(message, info); } // @@XXX

//---------------------------------------------------------------------------

Message::~Message() 
{
  if (content != NULL) {
    content->destroy(false);
    delete content;
    //content = NULL;
  }
  if (packedHeader != NULL) {
    delete packedHeader;
  }
  if (packedContent != NULL) {
    delete packedContent;
    //packedContent = NULL;
  }
#ifdef WITH_EXTENSION
  if (messageTLVSet != NULL) {
    delete messageTLVSet;
  }
#endif // WITH_EXTENSION
}

//--------------------------------------------------

int Message::getMessageSize()
{ 
  if(messageSize <0 && packedContent != NULL)
    messageSize = packedContent->size
      + MessageHeaderWithoutAddressSize
      + originatorAddress.getNetSize();
  assert(messageSize>=0);
  return messageSize;
}

void Message::setContent(IMessageContent* newContent)
{
  Warn("use of obsoleted function (because of errors)");
  // XXX:
  //  newContent->header->content should be set to newContent
  //  there is no need to remove packedContent
  //  header can be cloned
  if (packedContent != NULL) {
    delete packedContent;
    packedContent = NULL;
  }
  content = newContent;
  newContent->header = this;
}

//---------------------------------------------------------------------------

PacketManager::PacketManager(Node* aNode) : node(aNode)
{
  messageRewriter = NULL;
  for(int i=0;i<MessageTypeLimit;i++)
    messageHandler[i] = NULL;

  messageHandler[HELLO_MESSAGE] = new HelloMessageHandler(node);
  messageHandler[TC_MESSAGE]    = new TCMessageHandler(node);
  messageHandler[MID_MESSAGE]   = new MIDMessageHandler(node);
  messageHandler[HNA_MESSAGE]   = new HNAMessageHandler(node);

#ifdef MULTICAST_RESEARCH
  messageHandler[GMA_MESSAGE] = new GMAMessageHandler(node);
  messageHandler[MI_MESSAGE] = new MIMessageHandler(node);
#endif
  
  nextMessageSequenceNumber = 0; // XXX: can be random

  queue = new std::list<MessageAndIface>;
}

void PacketManager::addMessageHandler(unsigned int messageType,
				      IMessageHandler* handler)
{
  assert( inrange(0u, messageType, (unsigned int)MessageTypeLimit) );
  messageHandler[messageType] = handler;
}

int PacketManager::getMessageHeaderSize()
{ return MessageHeaderWithoutAddressSize 
    + node->getAddressFactory()->getAddressSize(); }


const int MessageSequenceNumberLimit =(1<<16);

int PacketManager::allocateMessageSequenceNumber()
{
  int result = nextMessageSequenceNumber;
  nextMessageSequenceNumber++;
  if(nextMessageSequenceNumber>= MessageSequenceNumberLimit)
    nextMessageSequenceNumber = 0;
  return result;
}



void PacketManager::processPacket(Address sendIfaceAddress,
				  Address recvIfaceAddress,
				  MemoryBlock* rawPacket)
{
  PacketBuffer packet(*rawPacket, node->getAddressFactory());
  std::auto_ptr<MemoryBlock> rawPacketTmp(rawPacket);
  rawPacket = NULL;
  std::list<Message*> messageList;
  int packetSequenceNumber;

  hasNetTime = false;
  lastNetTime = 0.0;

  try { 

    parsePacket(packet, messageList, packetSequenceNumber,
		sendIfaceAddress, recvIfaceAddress); 

#ifdef WITH_STAT
    node->statisticSet->ensure(sendIfaceAddress)->packetCount.add(1);
#endif

    // Link monitoring
#ifdef LINK_MONITORING
    if (node->getProtocolConfig()->useSignalMonitoring ||
	node->getProtocolConfig()->useHysteresisMonitoring)

      processLinkMonitoring(sendIfaceAddress, recvIfaceAddress, 
			    packetSequenceNumber);
#endif

    int messageIndex = -1;
    
    //for(std::list<Message*>::iterator it=messageList.begin();
    //it!=messageList.end();it++) {
    //Message* m = messageList.front();
    while (!messageList.empty()) {
      std::auto_ptr<Message> m(messageList.front());
      messageList.pop_front();
      messageIndex++;

      //--- Only for logging purposes:
      string info = "";
#ifndef NOLOG
      if ((node->log->lMulticast) && node->log->out != NULL 
	  && m->messageType == node->getProtocolConfig()->multicastType) {
	ostringstream strHeader;
	writeMessage(strHeader, *m, false);
	PktD(*node->log, info, m.get(), node->getRealTime()
	     << " [received-message] " << node->getMainAddress() << " " 
	     << strHeader.str().c_str()
	     << " content=" << format3UInt(m->packedContent->data) << " ");
      } else if (node->log->lPacketProcessing) {
	PktD(*node->log, info, m.get(), node->getRealTime()
	     << " [received-message] "
	     << node->getMainAddress() << " "
	     << *m << " ");
      }
#endif
      //---

      // Processing - step 2 - @@928-932
      if(m->timeToLive <= 0 // @@928-929
	 || m->originatorAddress == node->getMainAddress()) { // @@929-931
	PktDEnd(*node->log, info, m.get(), endl);
	continue; // @@931-932
      }

      D(*node->log, lMessage, node->getRealTime() 
	<< " [message] " << node->getMainAddress() << " #" << messageIndex
	<< " "<< (*m) << endl);

      // Extra implementation related step
      assert( 0 <= m->messageType && m->messageType < MessageTypeLimit );
      IMessageHandler* handler = messageHandler[m->messageType];
      PktD(*node->log, info, m, "handler=" << (handler != NULL) << " ");

      // simple statistic:
      if (m->messageType == TC_MESSAGE)
	nbTCReceived ++;

      // Processing - step 3 - XXX@@
      DuplicateTuple* duplicateTuple = 
	node->duplicateSet.findFirst_Address_MessageSequenceNumber
	(m->originatorAddress, m->messageSequenceNumber); // @@936-940
      if (duplicateTuple == NULL) {
	PktD(*node->log, info, m, " no-duplicate-tuple ");
	if (handler != NULL) {
	  handler->processMessage(m.get()); // step 3.2 - @@945-947
	} else { /* do nothing */ } // a message we don't know how to process
      } else { 
	// do nothing - step 3.1 - @@942-943
	PktD(*node->log, info, m, " duplicate=[" << (*duplicateTuple) << "] ");
      } 
      
      // Extensions: as part of the non-standard processing, a duplicate
      // tuple might have been created, so search again for a duplicate
      // tuple.
      DuplicateTuple* newDuplicateTuple = 
	node->duplicateSet.findFirst_Address_MessageSequenceNumber
	(m->originatorAddress, m->messageSequenceNumber);
      assert( (newDuplicateTuple != NULL)
	      || ((newDuplicateTuple == NULL) && (duplicateTuple == NULL)) );
      duplicateTuple = newDuplicateTuple;

      if (handler != NULL && handler->shouldPureFlood()) {
	// Non standard processing: if pure flooding should be used
	ensureRetransmitMessage(m.get(), info);
      } else {

	// Processing - step 4 - XXX@@
	if (duplicateTuple != NULL && duplicateTuple->D_retransmitted) {
	  // added as an extension, but changes nothing to the end result,
	  // only is a clearer bail-out
	  PktD(*node->log, info, m, " already-retransmitted");
	} else if (duplicateTuple != NULL  // step 4.1 - @@961-969
		   && duplicateTuple->isInIfaceList(m->recvIfaceAddress)) {
	  /* do nothing */ // @@971-972
	  PktD(*node->log, info, m.get(), " already-processed ");

#ifdef WITH_SECURITY
	} else if (node->getProtocolConfig()->incorrectForwardingAttack) {
	  /* security attack: don't forward messages */
	  PktD(*node->log, info, m.get(), " forward-attack ");
#endif /* WITH_SECURITY */
	} else {
	  if (handler != NULL) // step 4.2.1 - @@976-980
	    handler->considerForwardMessage(m.get(), info);
	  else defaultForwardingMessage(m.get(), info);// step 4.2.2 - @@
	}
	PktDEnd(*node->log, info, m.get(), endl);
	//delete m;
      }
    }

  } catch(PacketFormatError& error) { 

#ifndef SYSTEMlinux
    &error;
#endif
    Warn("Message format error, event=#"<<Node::globalEventCounter
	 <<" sendIface="<<sendIfaceAddress
	 <<" recvIface="<<recvIfaceAddress
	 <<" packet_content=" << (*rawPacketTmp.get()));
    UNUSED(error);
    while (!messageList.empty()) {
      std::auto_ptr<Message> m(messageList.front());
      messageList.pop_front();
    }
    return;
  }
}

int nbTCForwarded = 0;

void PacketManager::defaultForwardingMessage(Message* m, string& info)
{
#ifdef WITH_SECURITY
  bool shouldUseNetTime = node->getProtocolConfig()->usePacketTimestamp
    && hasNetTime;
#endif

  // Default forwarding algorithm - step 1 - @@992-995
  if (!node->isSymmetricNeighbor(node->ifaceToMainAddress
				 (m->sendIfaceAddress))) {
    PktD(*node->log, info, m, "not-sym");
    return; // @@992-995
  }
  PktD(*node->log, info, m, "sym");

  // Default forwarding algorithm - step 2 - @@997-1016
  DuplicateTuple* duplicateTuple = 
    node->duplicateSet.findFirst_Address_MessageSequenceNumber
    (m->originatorAddress, m->messageSequenceNumber); // @@999-1001
  if (duplicateTuple != NULL) {
    if (!duplicateTuple->D_retransmitted // @@1003-1016
	&& ((!duplicateTuple->isInIfaceList(m->recvIfaceAddress)
#ifdef WITH_SECURITY
	     && !shouldUseNetTime) // XXX! interoperability
	    || (shouldUseNetTime && lastNetTime < duplicateTuple->netTime))
#endif // WITH_SECURITY
	    ) { /* do nothing yet: will consider for forwarding */ }
    else {
      if (duplicateTuple->D_retransmitted)
	{ PktD(*node->log, info, m, ",already-retransmitted"); }
      if (duplicateTuple->isInIfaceList(m->recvIfaceAddress))
	{ PktD(*node->log, info, m, ",in-iface-list"); }

      return; // stop processing - @@1003-1004
    } 
  } else { /* do nothing */ } // step 3 - @@1018-1019


  // Default forwarding algorithm - step 4 - @@1026-1029
  bool fromMPRSelector = node->isMPRSelector
    (node->ifaceToMainAddress(m->sendIfaceAddress));
  bool willRetransmit =  fromMPRSelector && m->timeToLive > 1;
  
  if (fromMPRSelector) 
    { PktD(*node->log, info, m, ",from-mpr"); }

  // Default forwarding algorithm - step 5 - @@
  if (duplicateTuple != NULL) { // @@1031

    duplicateTuple->D_time = node->getCurrentTime() 
      + node->getProtocolConfig()->DUP_HOLD_TIME; // @@1035
    duplicateTuple->D_iface_list.push_back(m->recvIfaceAddress); // @@1037-1038
    if (willRetransmit) // @@1040=1041
      duplicateTuple->D_retransmitted = true; 
#ifdef WITH_SECURITY
    if (shouldUseNetTime) {
      duplicateTuple->hasNetTime = true;
      duplicateTuple->netTime = lastNetTime;
    }
#endif
    duplicateTuple->update();

    PktD(*node->log, info, m, ",from-other-iface");

  } else { // @@1043

    duplicateTuple = new DuplicateTuple;
    duplicateTuple->D_addr = m->originatorAddress; // @@1045
    duplicateTuple->D_seq_num = m->messageSequenceNumber; // @@1047
    duplicateTuple->D_time = node->getCurrentTime()
      + node->getProtocolConfig()->DUP_HOLD_TIME; // @@1049
    duplicateTuple->D_iface_list.push_back(m->recvIfaceAddress); // @@1051
    duplicateTuple->D_retransmitted = willRetransmit; // @@1053-1054
#ifdef WITH_SECURITY
    duplicateTuple->hasNetTime = shouldUseNetTime;
    duplicateTuple->netTime = lastNetTime;
#endif // WITH_SECURITY
    node->duplicateSet.add(duplicateTuple);

  }

  if (!willRetransmit)
    return; // @@1056-1057

  PktD(*node->log, info, m, ",retransmit");

  Message* newMessage = m->clone();
  m->timeToLive --; // @@1059
  m->hopCount ++; // @@1061
  sendPackedMessageToAll(newMessage); // @@1071-1073
  if (newMessage->messageType == TC_MESSAGE)
    nbTCForwarded++;
}

#if 0
// XXX: TODO
bool PacketManager::wasRetransmitted(Message* m)
{
  DuplicateTuple* duplicateTuple = 
    node->duplicateSet.findFirst_Address_MessageSequenceNumber
    (m->originatorAddress, m->messageSequenceNumber); // @@999-1001
  return 
}
#endif 

void PacketManager::ensureRetransmitMessage(Message* m, string& info)
{
  PktD(*node->log, info, m, "ensure-retransmit,");
  
  DuplicateTuple* duplicateTuple = 
    node->duplicateSet.findFirst_Address_MessageSequenceNumber
    (m->originatorAddress, m->messageSequenceNumber); // @@999-1001
  
  // The message has been processed: put it in the duplicate table in
  // any case.
  if (duplicateTuple == NULL) {
    duplicateTuple = new DuplicateTuple;
    duplicateTuple->D_addr = m->originatorAddress; // @@1045
    duplicateTuple->D_seq_num = m->messageSequenceNumber; // @@1047
    duplicateTuple->D_time = node->getCurrentTime()
      + node->getProtocolConfig()->DUP_HOLD_TIME; // @@1049
    //duplicateTuple->D_iface_list.push_back(m->recvIfaceAddress);
    duplicateTuple->D_retransmitted = false; // @@1053-1054
    node->duplicateSet.add(duplicateTuple);
    
    PktD(*node->log, info, m, "no-duplicate,");
  } else {
    PktD(*node->log, info, m, "with-duplicate,");
  }
  
  // Forward it if it has not been retransmitted and function says
  // it should be.
  if (!duplicateTuple->D_retransmitted) { 
    PktD(*node->log, info, m, "do-retransmit");
    Message* newMessage = m->clone();
    newMessage->timeToLive --; // @@1059
    newMessage->hopCount ++; // @@1061
    node->getPacketManager()->sendPackedMessageToAll(newMessage); // @@1071-1073
    duplicateTuple->D_retransmitted = true;
  } else {
    PktD(*node->log, info, m, "already-retransmitted,");
  }
}

void PacketManager::parsePacket(PacketBuffer& packet,
				std::list<Message*>& messageList,
				int& packetSequenceNumber,
				Address sendIfaceAddress,
				Address recvIfaceAddress)
{
  int addressSize = node->getAddressFactory()->getAddressSize();
  int packetSizeLimit = MessageHeaderWithoutAddressSize
    + addressSize;
  if (packet.size()<packetSizeLimit) {
    packet.raiseWarning("packet absolutly too short");
    D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
      << node->getMainAddress() << " packet dropped, size "
      << packet.size() << " lower than minimum " << packetSizeLimit
      << endl);
    return; // @@921-923
  }
  int packetLength = packet.popUInt16(); // @@743
  packetSequenceNumber = packet.popUInt16(); // @@743

  packetLength -= PacketHeaderSize;
  // XXX!!! what do we do if there is a size mismatch, Mr RFC ?
  if(packetLength > packet.size()) {
    packet.raiseError("packet too short, field "
		      "'Packet Length' > actual packet size");
    D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
      << node->getMainAddress() << " packet dropped, size "
      << packet.size() << " different from advertised length " << packetLength
      << endl);
    return;
  }
  if(packetLength < packet.size()) {
    D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
      << node->getMainAddress() << " cropped packet too long, size "
      << packet.size() << " greater than advertised length " << packetLength
      << endl);
    packet.raiseWarning("packet too long, field 'Packet Length'"
			" < actual packet size");
    packet.crop(packetLength);
  }

  bool finished = false;
  while(packet.size() > 0 && !finished) {
    Message* message = popMessage(packet, sendIfaceAddress, recvIfaceAddress);
    if(message == NULL)
      finished = true; /// XXX: might still return the first messages
    else messageList.push_back(message);
  }
}

#ifdef LINK_MONITORING

void PacketManager::processLinkMonitoring(Address sendIfaceAddress,
					  Address recvIfaceAddress, 
					  int packetSequenceNumber)
{
  // Discard packets'infos from this node
  if ( node->ifaceToMainAddress(sendIfaceAddress) == 
       node->getMainAddress() )
    
    return;
	   
 HeardIfaceTuple* heardIfaceTuple = 
    node->heardIfaceSet.findThisLink(sendIfaceAddress, recvIfaceAddress); 

  bool shouldAdd = false;
  Time currentTime = node->getCurrentTime();

  if (heardIfaceTuple == NULL)
    {
      heardIfaceTuple = new HeardIfaceTuple(node, sendIfaceAddress,
					    recvIfaceAddress, 
					    packetSequenceNumber);
      
      shouldAdd = true;
    }
#ifdef LINK_IWEVENT_MONITORING
  else
    if (heardIfaceTuple->H_last_packetSequenceNumber == 
	heardIfaceTuple->H_SignalInit_packetSequenceNumber)
      // The tuple has just been created by the signal monitoring process.
      {
	// Reset this field, to match the value we set when that proccess
	// created the tuple.
	heardIfaceTuple->H_last_packetSequenceNumber = packetSequenceNumber;
      }
#endif

  heardIfaceTuple->updateExpireTime(currentTime);

  if ( node->getProtocolConfig()->useHysteresisMonitoring )

    heardIfaceTuple->setLinkQuality(packetSequenceNumber, 1);
    
#ifdef LINK_SIGNAL_MONITORING

  if ( node->getProtocolConfig()->useSignalMonitoring)
    {
      OLSRIface* iface = node->getIfaceByAddress(recvIfaceAddress);
      int signal = iface->getSignalLevel(sendIfaceAddress);
      // For interfaces on which we can't collect signal infos
      // set signal field to an acceptable value.
      if (signal == NON_WIRELESS_IFACE_SIGNAL)
	signal = node->getSignalThresholdHigh() + 10;

      heardIfaceTuple->setLinkQuality(-1, signal);
    }

#endif
  
  if (shouldAdd)
    {
#ifdef LINK_IWEVENT_MONITORING
      // For interfaces on which we can't collect signal infos
      // set signal field to an acceptable value.
      if ((node->getProtocolConfig())->useSignalMonitoring) 
	heardIfaceTuple->setLinkQuality(-1, node->getSignalThresholdHigh() + 10);
#endif

      node->heardIfaceSet.add(heardIfaceTuple);
    }
}
#endif


Message* PacketManager::popMessage(PacketBuffer& packet,
				   Address sendIfaceAddress,
				   Address recvIfaceAddress)
{
  int addressSize = node->getAddressFactory()->getAddressSize();
  int messageHeaderSize = MessageHeaderWithoutAddressSize + addressSize;

  MemoryBlock* packedHeader = packet.peekBlock(messageHeaderSize);

  int messageType = packet.popUInt8(); // @@745
  int vtime = packet.popUInt8(); // @@745
  int messageSize = packet.popUInt16(); // @@745

  Address originatorAddress = packet.popAddress(); // @@747

  int timeToLive = packet.popUInt8(); // @@749
  int hopCount = packet.popUInt8(); // @@749
  int messageSequenceNumber = packet.popUInt16(); // @@749

  if (messageSize < messageHeaderSize) {
    D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
      << node->getMainAddress() << " message dropped, size "
      << messageSize << " lower than minimum " << messageHeaderSize
      << endl);
    packet.raiseError("impossible message size: too small");
    return NULL;
  } 

#ifdef WITH_EXTENSION
#warning Parsing of Message TLV (as) blocks of data (IPackedTLV) \
         could be done here
  // XXX: maybe should look getMessageHandler(type)->hasTLV() or better
  // dynamic_cast<MessageWithTLVHandler*>(); if (handler!=NULL)
#endif

  MemoryBlock* packedContent = 
    packet.popBlock(messageSize - messageHeaderSize);
  Message* result = new Message((MessageType)messageType, vtime, 
				originatorAddress, 
				timeToLive, hopCount);
  result->messageSequenceNumber = messageSequenceNumber;
  result->origin = ReceivedMessage;
  result->packedHeader = packedHeader;
  result->packedContent = packedContent;
  result->messageSize = messageSize;
  result->minMessageSize = messageSize;
  result->sendIfaceAddress = sendIfaceAddress;
  result->recvIfaceAddress = recvIfaceAddress;
  return result;
}

//---------------------------------------------------------------------------

// Strategy: send all the messages which demand to be sent, in a
// FIFO way.
void PacketManager::sendUpToTime(Time limitTime)
{
  // Get message limit (in the FIFO queue)
  std::list<MessageAndIface>::iterator limitIt = queue->end();
  for(std::list<MessageAndIface>::iterator it = queue->begin();
      it != queue->end(); it++) {
    if ((*it).message->maxTime <= limitTime )
      limitIt = it;
  }
  if(limitIt == queue->end()) //possible only if limitIt wasn't changed in loop
    return; // no message to send

  // Be sure that all interfaces have a packet buffer (XXX: move)
  // XXX! ensureIfaceWithBuffer();  --(looks ok, they all have now I think)

  // Get minimum MTU
  int minMTU = getIfaceMinMTU();
  
  std::list<MessageAndIface>::iterator it = queue->begin();
  bool finished = false;
  do {
    OLSRIface* iface = (*it).iface;
    Message* message =(*it).message;
    finished = (it == limitIt);
    std::list<MessageAndIface>::iterator last = it;
    it++;
    queue->erase(last);

    assert( message->minMessageSize > 0 );
    assert( message->messageSize > 0 );

    if (iface == NULL) {
      // note: NULL means "all interfaces"
      if (message->minMessageSize > minMTU) {
	// The message cannot go on at least one iface: dropped on all ifaces.
	Warn("Message dropped, min possible size greater than min MTU");
	D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
	  << node->getMainAddress() << " message dropped, min possible size "
	  << message->minMessageSize << "greater than min MTU " << minMTU
	  << endl);
	delete message;
      } else genericAppendMessage(NULL, message, minMTU);

    } else {
      int ifaceMTU = iface->getMTU();
      if (message->minMessageSize > ifaceMTU) {
	// The message cannot go on the iface
	Warn("Message dropped, min possible size greater than iface MTU");
	D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
	  << node->getMainAddress() << " message dropped, min possible size "
	  << message->minMessageSize << "greater than iface MTU " << ifaceMTU
	  << endl);
	delete message;
      } else genericAppendMessage(iface, message, ifaceMTU);
    }
  } while(!finished);

  // Now send all the pending packets on the interfaces.
  std::list<OLSRIface*>* ifaceList = node->getIfaceList();
  for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end(); it++)
    (*it)->flushPacket();
}


void PacketManager::genericAppendMessage(OLSRIface* iface,
					 Message* message, int minMTU)
{
  if (iface != NULL)
    iface->ensureSameDestinationAddress(message->destinationAddress);
  else { assert(message->destinationAddress.isNull()); }

  if(message->packedContent != NULL) {
    // Message was already packed
    appendPackedMessage(iface, message);
    return;
  }

  ProtocolConfig* protocolConfig = node->getProtocolConfig();
  int freeSpace = (iface == NULL) 
    ? getIfaceMinFreeSpace()
    : iface->getFreeSpace();
  double proportionLimit = (iface == NULL)
    ? protocolConfig->globalSplittingProportionLimit
    : iface->getConfig()->localSplittingProportionLimit;

  MemoryBlock* newBlock = NULL;
  Message* newMessage = NULL;
  
  PackingInfo packingInfo;
  packingInfo.iface = iface;

  if( message->messageSize > freeSpace ) {
    // too big - now consider splitting...
    bool canSplit = message->minMessageSize <= freeSpace;
    canSplit = canSplit &&
      ((minMTU * protocolConfig->freeSpaceSplittingProportionLimit)
       <= freeSpace); // must be enough room
    // packet must be big enough (to worth it):
    canSplit = canSplit &&((minMTU * proportionLimit) <= message->messageSize);

    if(canSplit) {
      // "canSplit to match free space", that is
      packMessage(message, freeSpace, newBlock, newMessage, packingInfo);
    } else {
      // split only using minMTU
      packMessage(message, minMTU, newBlock, newMessage, packingInfo);
    }
	 
  } else {
    packMessage(message, freeSpace, newBlock, newMessage, packingInfo);
    assert(newMessage == NULL);
  }

  Address destinationAddress = message->destinationAddress;
  delete message;
  message = NULL;

  if (newBlock != NULL) {
    if (iface == NULL) {
      assert( destinationAddress.isNull() );
      appendBlockOnAllIface(newBlock);
    } else iface->appendBlock(destinationAddress, newBlock);
    delete newBlock;
  } else {
    Warn("Packet packing (splitting) failed");
  }

  if (newMessage !=NULL)
    genericAppendMessage(iface, newMessage, minMTU); 
    //appendBlockOnAllIface(iface, newMessage->packedContent);
}

void PacketManager::appendBlockOnAllIface(MemoryBlock* block) // borrowed
{
  std::list<OLSRIface*>* ifaceList = node->getIfaceList();
  for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end(); it++)
    (*it)->appendBlock(NullAddress, block);
}

// Design note: here, when a packet is forwarded, the message header
// is rewritten, but not the content.
void PacketManager::appendPackedMessage(OLSRIface* iface, Message* message)
{
  assert(message->content == NULL);
  assert(message->packedContent != NULL);

  // Pack and prepend message header, to already packed message content
  PacketBuffer buffer; 
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message);
  buffer.packBlock(message->packedContent);
  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  MemoryBlock* blockResult = buffer.getContent(); 

  // now send it.
  if(iface == NULL) {
    assert( message->destinationAddress.isNull() );
    appendBlockOnAllIface(blockResult);
  } else iface->appendBlock(message->destinationAddress, blockResult);
  delete blockResult;
  delete message;
}

int PacketManager::getIfaceMinMTU()
{
  int minMTU = -1;
  std::list<OLSRIface*>* ifaceList = node->getIfaceList();
  for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end(); it++)
    if((*it)->getMTU() < minMTU || minMTU<0)
      minMTU = (*it)->getMTU();
  return minMTU;
}

int PacketManager::getIfaceMinFreeSpace()
{
  int minMTU = -1;
  std::list<OLSRIface*>* ifaceList = node->getIfaceList();
  for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end(); it++)
    if((*it)->getMTU() < minMTU || minMTU<0)
      minMTU = (*it)->getMTU();
  return minMTU;
}

void PacketManager::packMessage(Message* message, int maximumMessageSize,
				MemoryBlock*& newBlock, 
				Message*& newMessage, PackingInfo& packingInfo)
{
  assert(message->content != NULL);
  assert(message->packedContent == NULL);
  IMessageHandler* handler = messageHandler[message->messageType];
  assert(handler != NULL);
  
  IMessageContent* newMessageContent = NULL;
  handler->packMessageContent(message->content, maximumMessageSize,
			      newBlock, newMessageContent, packingInfo);
  if(newMessageContent != NULL) {
    newMessage = newMessageContent->header;
    handler->adjustMessageSize(newMessage->content);
  } else newMessage = NULL;
}

void PacketManager::sendOneMessage(OLSRIface* iface, Message* message)
{
  assert(message->content != NULL);
  if(!node->isRunning()) {
    delete message;
    return;
  }

  message->content->header = message; // 
  message->origin = GeneratedMessage;

  if (messageRewriter != NULL)
    message = messageRewriter->rewrite(message);

  IMessageHandler* handler = messageHandler[message->messageType];
  assert(handler != NULL);  
  handler->adjustMessageSize(message->content);

  D(*node->log, lPacketProcessing, node->getRealTime() << " [queued-message] " 
    << node->getMainAddress() << " ");
  if (iface != NULL) { D(*node->log, lPacketProcessing, iface->getAddress()); }
  else { D(*node->log, lPacketProcessing, "<all iface>"); }
  D( *node->log, lPacketProcessing, 
     " " << messageTypeToString(message->messageType));
  D(*node->log, lPacketProcessing, " " << (*message) << endl);

  MessageAndIface messageAndIface;
  messageAndIface.message = message;
  messageAndIface.iface = iface;
  queue->push_back(messageAndIface);
}

//---------------------------------------------------------------------------

Address OLSRIface::getAddress()
{ return iface->getAddress(); }

string OLSRIface::getName() { return iface->getIfaceName(); }

int OLSRIface::getIndex() { return iface->getIndex(); }

#ifdef LINK_IWEVENT_MONITORING
int OLSRIface::getSignalFileDescriptor() 
{ return iface->getSignalFileDescriptor(); }
#endif

int OLSRIface::getMTU()
{ return iface->getMTU(); }

void OLSRIface::sendPacket(Address destinationAddress, MemoryBlock* packet)
{ iface->sendPacket(destinationAddress, packet); }

// The use of the destinationAddress is not 
void OLSRIface::flushPacket()
{
  if (buffer == NULL) 
    prepareBuffer();
  buffer->rewind();
  if (buffer->size() == PacketHeaderSize) {
#ifndef MOST
    Warn("Tried to send empty packet, ignored.");
#endif
    delete buffer;
    buffer = NULL;
    return; // empty packet (non-valid to send in any case @@XXX)
  }
  int size = buffer->size(); // - PacketHeaderSize;
  int packetSequenceNumber = allocateSequenceNumber();
  buffer->pushUInt16(size);
  buffer->pushUInt16(packetSequenceNumber);
  buffer->rewind();
  MemoryBlock* packet = buffer->popBlock(buffer->size());

  D(*(node->log), lPacketProcessing, node->getRealTime() << " [send-packet] "
    << node->getMainAddress() << " " << iface->getAddress() << " " 
    << packetSequenceNumber << " " << size << " " << (*packet) << endl);
#ifdef WITH_SECURITY
  SecurityNode* securityNode = dynamic_cast<SecurityNode*>(node);
  if (securityNode != NULL) {
    packet = securityNode->updatePacketBeforeSend(packet);
  }
#endif
  sendPacket(lastDestinationAddress, packet);
  delete buffer;
  buffer = NULL;
}

//---------------------------------------------------------------------------

// work-around g++-2.95.4:
typedef PacketManager::PositionInfo PacketManagerPositionInfo;

//PacketManager::PositionInfo 
PacketManagerPositionInfo
PacketManager::packMessageHeader(PacketBuffer& buffer, Message* m)
{
  PositionInfo result;
  result.messageStartPosition = buffer.getPosition();
  buffer.pushUInt8(m->messageType); // @@XXX
  buffer.pushUInt8(m->vtime);
  result.sizeFieldPosition = buffer.getPosition();
  //printf("packMessageHeader-BP1\n");
  buffer.pushUInt16(0); // size: 0 for now, overwriting later
  buffer.packAddress(m->originatorAddress);
  buffer.pushUInt8(m->timeToLive);
  buffer.pushUInt8(m->hopCount);
  if(m->messageSequenceNumber == NoMessageSequenceNumber) {
    assert( m->origin == GeneratedMessage );
    m->messageSequenceNumber= allocateMessageSequenceNumber();
  }
  //printf("packMessageHeader-BP2\n");
  buffer.pushUInt16(m->messageSequenceNumber);
  return result;
}

//---------------------------------------------------------------------------

void PacketManager::adjustPackedMessageSize(PacketBuffer& buffer,
					    PositionInfo info)
{
  int actualSize = buffer.getSizeFrom(info.messageStartPosition);
  int endPosition = buffer.getPosition();
  buffer.setPosition(info.sizeFieldPosition);
  buffer.pushUInt16(actualSize);
  buffer.setPosition(endPosition);
}

//---------------------------------------------------------------------------

void PacketManager::notifyMessageQueuing()
{
  if (node->getProtocolConfig()->immediateMessageTransmission)
    sendUpToTime(TimeNever);
}

//---------------------------------------------------------------------------

void IMessageContent::destroy(bool deleteHeader)
{
  if(deleteHeader && header != NULL) {
    header->content = NULL; // avoid delete loop
    delete header;
  }
  header = NULL;
}

//---------------------------------------------------------------------------
//typedef GenericMessageHandler<ConfParentLeaveSpecification> ConfParentLeaveMessageHandler;
//typedef GenericMessageHandler<SourceClaimSpecification> SourceClaimMessageHandler;


//---------------------------------------------------------------------------

void writeMessage(ostream& out, const Message& m, bool withContent)
{
  out << "MSG[type=" << messageTypeToString(m.messageType) << "(" 
      << m.messageType << ") vtime=" << fromMantissaExponentByte(m.vtime)
      << "(" << m.vtime << ") size=" << m.messageSize << " origin="
      << m.originatorAddress << " ttl=" << m.timeToLive 
      << " hop=" << m.hopCount
      << " mseq=" << m.messageSequenceNumber << " minSize=" << m.minMessageSize
      << " sendAddress="  << m.sendIfaceAddress << " recvAddress="
      << m.recvIfaceAddress;
  if (withContent) {
    if(m.content != NULL)
      out << " content=(" << *m.content <<")";
    else if (m.packedContent != NULL)
      out << " packedContent=(" << *m.packedContent << ")";
  }
  out << "]";
}

//---------------------------------------------------------------------------

void PacketManager::write(ostream& out)
{
  out << "nseq=" << nextMessageSequenceNumber << " queue=(";
  bool isFirst = true;
  for (ITER(std::list<MessageAndIface>, it, *queue)) {
    if (isFirst) isFirst = false;
    else out << ",";
    OLSRIface* iface = (*it).iface;
    Message* message =(*it).message;
    out << (*message) << "[";
    if (iface == NULL) out << "<ALL>";
    else out << iface->getAddress();
    out << "]";
  }
  out << ")";
}

//---------------------------------------------------------------------------
