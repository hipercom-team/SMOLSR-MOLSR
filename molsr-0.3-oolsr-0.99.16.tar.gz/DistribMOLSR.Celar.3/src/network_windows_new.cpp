//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

//#include "base.h"

#include <assert.h>

#include <winsock2.h>
#include <windows.h>
#include <ws2tcpip.h>
#include <iptypes.h>
#include <iphlpapi.h>

#include <stdlib.h>
#include <stdio.h>

//#include <list>
//#include <string>
//#include <sstream>
//#include <iostream.h>

//using std::list;
//using std::string;

//#include <Rtmv2.h>

//#include "general.h"
//#include "log.h"

//class ostream {
//};


 //void OpenFileExample (void)
//{
  // End of OpenFileExample code

#define Warn(x) 1 //assert(1)
#define Fatal(x) 0 // assert(0)


//----------------------------------------------------------------------------
// If returned status is NO_ERROR, then pIpRouteTab points to a routing
// table.
//----------------------------------------------------------------------------

DWORD
MyGetIpForwardTable(PMIB_IPFORWARDTABLE* pIpRouteTab, BOOL fOrder)
{
  DWORD status = NO_ERROR;
  DWORD statusRetry = NO_ERROR;
  DWORD dwActualSize = 0;
  PMIB_IPFORWARDTABLE pTempIpRouteTab=NULL;

  status = GetIpForwardTable(pTempIpRouteTab,&dwActualSize,fOrder);
  if (status == NO_ERROR)
    return status;
  else if (status == ERROR_INSUFFICIENT_BUFFER) {
    pTempIpRouteTab = (PMIB_IPFORWARDTABLE) malloc(dwActualSize);
    assert(pTempIpRouteTab);
    statusRetry = GetIpForwardTable(pTempIpRouteTab, &dwActualSize, fOrder);
    *pIpRouteTab = pTempIpRouteTab;
    return statusRetry;
  } else {
    Warn("Unknown error in GetIpForwardTable: " << status);
    return status;
  }
}

//---------------------------------------------------------------------------
/// Add one route in the kernel

#warning cygwinAddRoute was fixed in network_cygwin.cc
void cygwinAddRoute(sockaddr_in& destSysAddr,
		    sockaddr_in& gatewaySysAddr,
		    int metric)
{
  //addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
  //addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
  

  DWORD dwStatus;
  MIB_IPFORWARDROW routeEntry; // ip routing entry
  //XXX:remove: PMIB_IPADDRTABLE pIpAddrTable = NULL; // ip addr table
  
  memset(&routeEntry,0,sizeof(MIB_IPFORWARDROW));
  routeEntry.dwForwardDest = destSysAddr.sin_addr.s_addr;
  
  if (!(destSysAddr.sin_addr.s_addr == gatewaySysAddr.sin_addr.s_addr))
    routeEntry.dwForwardNextHop = gatewaySysAddr.sin_addr.s_addr;
  else routeEntry.dwForwardNextHop = destSysAddr.sin_addr.s_addr;
  routeEntry.dwForwardIfIndex = 0; //getCygwinIfaceIndex(iface);
  
#if 0
  if(destination->rt_dst==INADDR_ANY)
    routeEntry.dwForwardMask = inet_addr(NETMASK_DEFAULT);
  else
    routeEntry.dwForwardMask = inet_addr((char *)NETMASK_HOST);
#else
  // XXX: only one host:
  routeEntry.dwForwardMask = 0xffffffff; // XXX! constant.
#endif
  
  routeEntry.dwForwardMetric1 = metric + 1;
  routeEntry.dwForwardProto = 0; //XXX!! [PROTO_IP_LOCAL;]
  routeEntry.dwForwardMetric2 = (DWORD)-1; //XXX
  routeEntry.dwForwardMetric3 = (DWORD)-1; //XXX
  routeEntry.dwForwardMetric4 = (DWORD)-1; //XXX
  
  dwStatus = SetIpForwardEntry(&routeEntry);
  if (dwStatus != NO_ERROR)
     assert( 0 );
    //Fatal(" SetIPForwardEntry: " << GetLastError());

}

#warning cygwinRemoveRoute was fixed in network_cygwin.cc
/// Remove one route from the kernel
void cygwinRemoveRoute(sockaddr_in& destSysAddr,
		               sockaddr_in& gatewaySysAddr,
		               int metric)
{
  //sockaddr_in destSysAddr;
  //sockaddr_in gatewaySysAddr;

  DWORD dwStatus, dwDelStatus;
  PMIB_IPFORWARDTABLE pIpRouteTab = NULL; // Ip routing table
  MIB_IPFORWARDROW routeEntry;            // Ip routing table row entry
  DWORD dwForwardDest = 0;
  //BOOL fDeleted = FALSE;
  
  //addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
  //addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
  
  memset(&routeEntry, 0, sizeof(MIB_IPFORWARDROW));
  dwForwardDest = destSysAddr.sin_addr.s_addr;
  dwStatus = MyGetIpForwardTable(&pIpRouteTab, TRUE);
  
  if (dwStatus == NO_ERROR) {
    for (unsigned int i = 0; i < pIpRouteTab->dwNumEntries; i++) {
      if (dwForwardDest == pIpRouteTab->table[i].dwForwardDest) {
	memcpy(&routeEntry, &(pIpRouteTab->table[i]),
	       sizeof(MIB_IPFORWARDROW));
	dwDelStatus = DeleteIpForwardEntry(&routeEntry); 
	if (dwDelStatus != NO_ERROR)
	  exit(0);
	  //Fatal("DeleteIpForwardEntry: "<<GetLastError());//XXX!not fatal
      }
    } 
    if (pIpRouteTab != NULL)
      free(pIpRouteTab);
  } else exit(0);
  //Fatal("Error: Could not get the IP forward table: " 
	//       << GetLastError());
}

//---------------------------------------------------------------------------

#if 0
  // XXX! should be in a helper module
  //turn ip forwarding on
  if (!initialized ) {
    memset(&Overlapped,0, sizeof(OVERLAPPED));
    Overlapped.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (EnableRouter(&Handle, &Overlapped) != ERROR_IO_PENDING) 
      printf("Error: Could not turn IP forwarding on\n");
    initialized = 1;
  }
  if (GetIpStatistics(&lstats) != NO_ERROR) 
    printf("Error: Could not turn IP forwarding on\n");
  lstats.dwForwarding = MIB_IP_FORWARDING; //start forwarding
  if (SetIpStatistics(&lstats) != NO_ERROR) 
    printf("Error: Could not turn IP forwarding on\n");
#endif

//---------------------------------------------------------------------------

void startWinSock2()
{
  int err;
  WORD wVersionRequested;
  WSADATA wsaData;
  
  // open winsock //
  wVersionRequested = MAKEWORD( 2, 2 );
  err = WSAStartup( wVersionRequested, &wsaData );
  if ( err != 0 ) {
    printf("Error: WSAStartup failed with error %d\n", WSAGetLastError());
    exit(1);
  }
  if ( LOBYTE( wsaData.wVersion ) != 2 ||
       HIBYTE( wsaData.wVersion ) != 2 ) 
    {
      WSACleanup( );
      if (err == SOCKET_ERROR) {
	printf("WSACleanup failed with error %d\n", WSAGetLastError());
      }
      exit(1);
    }
  // winsock ok //
}

//---------------------------------------------------------------------------


#define MAX_INTERFACES	1024
INTERFACE_INFO ifo[MAX_INTERFACES]; // list of interfaces


//ISystemIface* CygwinIPv4SystemFactory::getIfaceByName
//(ProtocolConfig* protocolConfig, const string name, IfaceConfig* ifaceConfig)
void showIface()
{
  unsigned long size_of_ifo = sizeof(INTERFACE_INFO);
  unsigned long br=0;
  u_long i;
  DWORD Err,AdapterInfoSize,s;
  PIP_ADAPTER_INFO pAdapterInfo,pAdapt;
  DWORD Nb_i,For_i,Save,Nbinterf = 0;
  struct sockaddr_in *sin;
  char * ip_addr;
  char c[2];
  struct interf_name *nt;

  MIB_IPSTATS lstats;	
  OVERLAPPED	Overlapped;
  HANDLE		Handle;


  HANDLE hFile;

  //startWinSock2();
#if 0
  hFile = CreateFile (TEXT("\\MYFILE.TXT"),   // Open MYFILE.TXT
                      GENERIC_READ,           // Open for reading
                      FILE_SHARE_READ,        // Share for reading
                      NULL,                   // No security
                      OPEN_EXISTING,          // Existing file only   ////// Right here and if doesnt exist youll get the error so yeah you can use it
                      FILE_ATTRIBUTE_NORMAL,  // Normal file
                      NULL);                  // No template file

  if (hFile == INVALID_HANDLE_VALUE)
  {
    // Your error-handling code goes here.
    return;
  }
#endif

  
#if 0
  // get interfaces list
  memset(&ifo[0],0,sizeof(ifo));
  Err=WSAIoctl(s, SIO_GET_INTERFACE_LIST, NULL, 0,
	       &ifo[0], sizeof(ifo), &br, NULL, NULL);
  if (Err!=0)
    Fatal("Error: GET_INTERFACE_LIST failed with error " << WSAGetLastError());
#endif

  FILE* out = fopen("result.txt", "w");

  // get ip adapater info
  // Enumerate all of the adapter specific information using the IP_ADAPTER_INFO structure.
  // Note:  IP_ADAPTER_INFO contains a linked list of adapter entries.
  //
  AdapterInfoSize = 0;
  if ((Err = GetAdaptersInfo(NULL, &AdapterInfoSize)) != 0)
    if (Err != ERROR_BUFFER_OVERFLOW)
      Fatal("Error: GetAdaptersInfo sizing failed with error" << Err);


  // Allocate memory from sizing information
  pAdapterInfo = (PIP_ADAPTER_INFO) GlobalAlloc(GPTR, AdapterInfoSize);
  if (pAdapterInfo == NULL)
    Fatal("Error:  Memory allocation error in PIP_ADAPTER_INFO\n");

  // Get actual adapter information
  if ((Err = GetAdaptersInfo(pAdapterInfo, &AdapterInfoSize)) != 0)
    Fatal("Error: GetAdaptersInfo failed with error" << Err);

  // Number of interfaces
  Nb_i=br/size_of_ifo;

  //give name and index to good interfaces
  //ip_addr=inet_ntoa(sin->sin_addr);
  
  int ifaceIndex = -1;
  char* ifaceDescription = NULL;
  //Address ifaceAddress;

  //string name = "show";

  pAdapt = pAdapterInfo;
  while (pAdapt)
    {
      if (1 /*name == "" || name == "show"*/) {
#if 0
	std::cerr << "Interface #" << pAdapt->Index << ":"  << std::endl
		  << "  name: " << pAdapt->AdapterName << std::endl
		  << "  desc: " << pAdapt->Description << std::endl 
		  << "  ip: " << pAdapt->IpAddressList.IpAddress.String 
		  << std::endl;
      } else if (atoi(name.c_str()) == pAdapt->Index) {
        ifaceDescription= strdup(pAdapt->Description); // XXX
#endif
    fprintf(out, "Interface#%d name: %s dest:%s ip:%s \n",
	pAdapt->Index,pAdapt->AdapterName,pAdapt->Description,
	pAdapt->IpAddressList.IpAddress.String
	);

	ifaceIndex = pAdapt->Index;
	sockaddr_in tmpAddress;
	memset(&tmpAddress, 0, sizeof(tmpAddress));
	tmpAddress.sin_family = AF_INET;
	tmpAddress.sin_addr.s_addr = 
	  inet_addr(pAdapt->IpAddressList.IpAddress.String);
	//ifaceAddress = addressFactory.makeAddress(tmpAddress);
      }
#if 0
      if ((strcmp(ip_addr,pAdapt->IpAddressList.IpAddress.String))==0)
	{
	  ifp->int_name = (char *)malloc(strlen(pAdapt->Description) + 1);
	  if (ifp->int_name == 0)
	    Fatal("Out of memory");
	  strcpy(ifp->int_name, pAdapt->Description);
	  ifp->int_index = pAdapt->Index;
	  break;
	}
#endif
      pAdapt = pAdapt->Next;
    }

  if (ifaceIndex<0)
    Fatal("Cannot find interface etc xXXX");

  fclose(out);    
//#endif
}

//---------------------------------------------------------------------------
