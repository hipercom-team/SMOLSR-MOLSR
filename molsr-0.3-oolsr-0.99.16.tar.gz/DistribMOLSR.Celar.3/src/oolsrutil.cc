#include "network_windows_new.cpp"

int main(int argc, char** argv)
{
  showIface();
}
