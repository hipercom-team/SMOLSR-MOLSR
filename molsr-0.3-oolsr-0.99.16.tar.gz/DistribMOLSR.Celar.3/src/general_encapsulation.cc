//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Management of Multicast Encapsulated packets
//---------------------------------------------------------------------------

#include "general_encapsulation.h"

//---------------------------------------------------------------------------

void nodeMulticastEncapsulate(PPA_PluginNode pluginNode,
			      PPA_Address destinationMulticastAddress,
			      PPA_Packet packet /* owned*/)
{
#if defined(MULTICAST_RESEARCH) || defined(MOOLSR) 
  //MemoryBlock memoryBlock(packet.size);
  //PacketBuffer packetBuffer();
  Node* node = (Node*)pluginNode;
  assert( node->getProtocolConfig()->multicastType >= 0 );
  Message* message = new Message
    ((MessageType)node->getProtocolConfig()->multicastType, // Message Type 
     0, // not used
     node->getMainAddress(), // Originator @@835-836
     MaxTTL, // ttl,
     0); // hop count, @@868

  EMMessage* emMessage = new EMMessage;
  emMessage->packet = new MemoryBlock((octet*)packet.data, packet.size, true);
  Address destinationAddress(node->getAddressFactory(),
			     destinationMulticastAddress);
  emMessage->destinationAddress = destinationAddress;
  message->content = emMessage;
  message->maxTime = node->getCurrentTime();
  node->getPacketManager()->sendOneMessage(NULL, message);
  free(packet.data);
#elif defined MOST
  MostNode* node = (MostNode*)pluginNode;
  assert( node->getProtocolConfig()->multicastType >= 0 );
  Address multicastAddress(node->getAddressFactory(),
			   destinationMulticastAddress);
  if(!node->mostLogicalNeighborTable.findFirst(multicastAddress)) {
    free(packet.data);
    return;
  }
  
  int messageSequenceNumber 
    = node->getPacketManager()->allocateMessageSequenceNumber();
  //forward identical messages to all logical neighbors
  mostLogicalNeighborSet::TupleIterator it;
  for(it = node->mostLogicalNeighborTable.getIter(multicastAddress);
      !it.isDone(); it.next())
    {
      mostLogicalNeighborTuple* tuple = it.getCurrent();
      //emulate hopCount in next unicast transmission (not always real count)
      int hopCount = 0;
      if(node->currentRoutingTable->
	 findFirst_Destination(tuple->neighbor_addr) != NULL) {
        RoutingTuple* routingTuple = node->currentRoutingTable->
          findFirst_Destination(tuple->neighbor_addr);
        hopCount =  routingTuple->R_dist-1;
      }  //hopCount=0 if currently neighbor not reachable

      //hopcount and ttl modified for data collection
      Message* message = new Message
	((MessageType)node->getProtocolConfig()->multicastType, 
	 0, // not used
	 node->getMainAddress(), 
	 MaxTTL, //not really used
	 hopCount);
      message->messageSequenceNumber = messageSequenceNumber;
      message->destinationAddress = (tuple->neighbor_addr);
      EMMessage* emMessage = new EMMessage;
      emMessage->packet = new MemoryBlock((octet*)packet.data, 
				          packet.size, true);
      emMessage->destinationAddress = multicastAddress;
      message->content = emMessage;
      message->maxTime = node->getCurrentTime();
      node->sendMessageInUnicast(message);
    } 
  free(packet.data);
#endif
}
#ifdef MOOLSR
typedef void (MolsrNode::*NodeMulticastOperation)
  (Address ifaceAddress,Address multicastAddress);
#elif defined MOST
typedef void (MostNode::*NodeMulticastOperation)
  (Address ifaceAddress,Address multicastAddress);
#else
typedef void (Node::*NodeMulticastOperation)(Address multicastAddress);
#endif

extern "C"
void nodeMulticastOperation(PPA_PluginNode pluginNode,
			    PPA_Address ppaMulticastAddress,
			    NodeMulticastOperation method)
{
#ifdef MOOLSR
 MolsrNode* node = (MolsrNode*)pluginNode;
 Address multicastAddress(node->getAddressFactory(), ppaMulticastAddress);
 //(node->*method)(NullAddress ,multicastAddress);
 // Means that we join the multicast group for all sources!!
  (node->*method)(node->getMainAddress(),multicastAddress);
#elif defined MOST
  MostNode* node = (MostNode*)pluginNode;
  Address multicastAddress(node->getAddressFactory(), ppaMulticastAddress);
  (node->*method)(node->getMainAddress(),multicastAddress);
#else
  Node* node = (Node*)pluginNode;
  Address multicastAddress(node->getAddressFactory(), ppaMulticastAddress);
  (node->*method)(multicastAddress);
#endif
}

extern "C"
void nodeMulticastJoinGroup(PPA_PluginNode pluginNode,
			    PPA_Address ppaMulticastAddress)
{ 

#ifdef MOOLSR
   nodeMulticastOperation(pluginNode, ppaMulticastAddress, 
			  &MolsrNode::processLocalClientMulticastJoin);
#elif defined MOST
   nodeMulticastOperation(pluginNode, ppaMulticastAddress,
                          &MostNode::processLocalClientMulticastJoinSim);
#elif defined MULTICAST_RESEARCH   
   nodeMulticastOperation(pluginNode, ppaMulticastAddress, 
			 &Node::processMulticastJoinGroup);
#endif
}

extern "C"
void nodeMulticastLeaveGroup(PPA_PluginNode pluginNode,
			     PPA_Address ppaMulticastAddress)
{ 
#ifdef MOOLSR
  nodeMulticastOperation(pluginNode, ppaMulticastAddress,
			 &MolsrNode::processLocalClientMulticastLeave);
#elif defined MOST
  nodeMulticastOperation(pluginNode, ppaMulticastAddress,
                         &MostNode::processLocalClientMulticastLeaveSim);
#elif defined MULTICAST_RESEARCH
  nodeMulticastOperation(pluginNode, ppaMulticastAddress,
			 &Node::processMulticastLeaveGroup);
#endif
}

extern "C"
void nodeMulticastSenderJoin(PPA_PluginNode pluginNode,
			     PPA_Address ppaMulticastAddress)
{ 

#ifdef MOOLSR
  nodeMulticastOperation(pluginNode, ppaMulticastAddress, 
			 &MolsrNode::processLocalMulticastSource); 
#elif defined MOST
  nodeMulticastOperation(pluginNode, ppaMulticastAddress, 
			 &MostNode::processLocalMulticastSourceSim);
#elif MULTICAST_RESEARCH   
  nodeMulticastOperation(pluginNode, ppaMulticastAddress, 
			 &Node::processMulticastSenderJoin); 
#endif
}

extern "C"
void nodeMulticastSenderLeave(PPA_PluginNode pluginNode,
			      PPA_Address ppaMulticastAddress)
{
#ifdef MOOLSR
  nodeMulticastOperation(pluginNode, ppaMulticastAddress, 
			 &MolsrNode::processLocalMulticastSourceLeave); 
#elif defined MOST
  nodeMulticastOperation(pluginNode, ppaMulticastAddress, 
			 &MostNode::processLocalMulticastSourceLeaveSim);
#elif defined MULTICAST_RESEARCH   
  nodeMulticastOperation(pluginNode, ppaMulticastAddress, 
			 &Node::processMulticastSenderLeave); 
#endif
}



//---------------------------------------------------------------------------
