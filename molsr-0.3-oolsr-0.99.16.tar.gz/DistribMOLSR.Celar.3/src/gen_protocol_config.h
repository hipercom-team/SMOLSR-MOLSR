//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//---------------------------------------------------------------------------
// Parts of this file automatically were generated
// Template: template_protocol_config.h
// Date: Thu Mar 23 14:06:31 2006
// User: root
// Command: generateProtocolConfig.py
//---------------------------------------------------------------------------
// DO NOT MODIFY THIS FILE - CHANGES COULD BE LOST
// - SINCE IT WAS AUTOMATICALLY GENERATED
//---------------------------------------------------------------------------

#ifndef _GEN_PROTOCOL_CONFIG_H
#define _GEN_PROTOCOL_CONFIG_H

//---------------------------------------------------------------------------

using std::string;

#include <map>
#include <string>
#include <vector>
#include "mystream.h"
#include <list>

//#include "address.h"
#include "general.h"

//---------------------------------------------------------------------------

class ExternalChannelConfig
{
public:
  string name;
  //int    messageType;
  int    channelIn;
  int    channelOut;
  //FloodingMode floodingMode;
};

//---------------------------------------------------------------------------

#ifdef WITH_SECURITY
class AuthenticationMethod
{
public:
  string name;
  string parameter;
  int authInfo;
};
#endif

//---------------------------------------------------------------------------

class ParseError
{
public: 
  ParseError(string aError) : error(aError) {}
  string error;
};

#define ThrowParseError(x) \
    BeginMacro \
      ostringstream message; \
      message << x; \
      throw (ParseError(message.str())); \
    EndMacro

static inline bool parseBool(string data)
{ return atoi(data.c_str())>0; }

static inline string parseString(string data)
{ return data; }

static inline int parseInt(string data)
{ 
  char* info=NULL;
  int result = strtol(data.c_str(), &info, 0);
  if (*info != '\0')
    ThrowParseError("Cannot parse integer: " << data);
  else return result;
}
//{ return atoi(data.c_str()); }

static inline double parseFloat(string data)
{ return atof(data.c_str()); /* XXX: error handling */ }

extern std::vector<string> stringSplit(string aLine, string charSet);

static inline std::list< std::pair<string,string> > parseHNAList(string data)
{ 
  std::list< std::pair<string,string> > result;
  string dashSeparator = "/";
  string semiColonSeparator = ",";

  std::vector<string> hnaStrList = stringSplit(data, semiColonSeparator);
  for (std::vector<string>::iterator it = hnaStrList.begin();
       it != hnaStrList.end();it++) {
    std::vector<string> oneHNA = stringSplit((*it), dashSeparator);
    assert (oneHNA.size() == 2);
    result.push_back( std::pair<string,string> (oneHNA[0], oneHNA[1]) );
  }
  return result;
}

static inline ostream& operator << 
  (ostream& out, std::list< std::pair< string, string> > data)
{
  bool isFirst = true;
  out << "(";
  for (std::list< std::pair< string, string> >::iterator it = data.begin();
       it != data.end(); it++) {
    if (!isFirst) 
      out << ", ";
    else isFirst = false;
    out << (*it).first << "/" << (*it).second ;
  }
  out << ")";
  return out;
}
					 

//--------------------------------------------------

class GeneratedLog
{
public:
  bool lAction;
  bool lWarning;
  bool lEvent;
  bool lEventStrategy;
  bool lPacket;
  bool lMessage;
  bool lPacketContent;
  bool lState;
  bool lPacketProcessing;
  bool lExpiration;
  bool lConfig;
  bool lRoute;
  bool lMulticast;
  bool lMeshPoint;
  bool lAutoConf;
  bool lSecurity;
  bool lQos;
  bool lExternal;
  bool lTimeProtocol;
  bool lConversion;
  bool lData;
  bool lMost;


  GeneratedLog() { setDefaultValue(); }

  void setDefaultValue() {
    lAction = 0;
    lWarning = 0;
    lEvent = 1;
    lEventStrategy = 1;
    lPacket = 1;
    lMessage = 1;
    lPacketContent = 1;
    lState = 1;
    lPacketProcessing = 1;
    lExpiration = 1;
    lConfig = 1;
    lRoute = 1;
    lMulticast = 1;
    lMeshPoint = 1;
    lAutoConf = 1;
    lSecurity = 1;
    lQos = 1;
    lExternal = 1;
    lTimeProtocol = 1;
    lConversion = 1;
    lData = 1;
    lMost = 1;

  }

  void setAllDefaultValue(bool value) {
    lAction = value;
    lWarning = value;
    lEvent = value;
    lEventStrategy = value;
    lPacket = value;
    lMessage = value;
    lPacketContent = value;
    lState = value;
    lPacketProcessing = value;
    lExpiration = value;
    lConfig = value;
    lRoute = value;
    lMulticast = value;
    lMeshPoint = value;
    lAutoConf = value;
    lSecurity = value;
    lQos = value;
    lExternal = value;
    lTimeProtocol = value;
    lConversion = value;
    lData = value;
    lMost = value;

  }

  void write(ostream& out) const
  {
    out  << "log-action " << lAction  << "; "  << "log-warning " << lWarning  << "; "  << "log-event " << lEvent  << "; "  << "log-event-strategy " << lEventStrategy  << "; "  << "log-packet " << lPacket  << "; "  << "log-message " << lMessage  << "; "  << "log-packet-content " << lPacketContent  << "; "  << "log-state " << lState  << "; "  << "log-packet-processing " << lPacketProcessing  << "; "  << "log-expiration " << lExpiration  << "; "  << "log-config " << lConfig  << "; "  << "log-route " << lRoute  << "; "  << "log-multicast " << lMulticast  << "; "  << "log-mesh-point " << lMeshPoint  << "; "  << "log-auto-conf " << lAutoConf  << "; "  << "log-security " << lSecurity  << "; "  << "log-qos " << lQos  << "; "  << "log-external " << lExternal  << "; "  << "log-time-protocol " << lTimeProtocol  << "; "  << "log-conversion " << lConversion  << "; "  << "log-data " << lData  << "; "  << "log-most " << lMost ;
  }
};

//--------------------------------------------------

class GeneratedIfaceConfig
{
public:
  GeneratedIfaceConfig() { setDefaultValue(); }

  double localSplittingProportionLimit;
  int mtu;


  void setDefaultValue() {
    localSplittingProportionLimit = 0.3;
    mtu = 1024;

  }

  string parseData(std::vector<string>& data) {
    if (data.size() < 2) return "not enough arguments";
    else if (data[0] == "local-splitting-proportion-limit") {
      localSplittingProportionLimit = parseFloat(data[1]);
    } else if (data[0] == "mtu") {
      mtu = parseInt(data[1]);
    }  else {
      return "Cannot parse XXX";
    }
    return "";
  }

  void write(ostream& out) const
  {
    out  << "local-splitting-proportion-limit " << localSplittingProportionLimit  << "; "  << "mtu " << mtu ;
  }
};

#define REPR_PARAM(result, name) \
  BeginMacro \
    vector<string>* info = new vector<string>; \
    ostringstream tmp; tmp << name; \
    info->push_back(""#name); \
    info->push_back(tmp.str()); \
    result->push_back(info); \
  EndMacro

class GeneratedProtocolConfig
{
public:
  GeneratedProtocolConfig() { setDefaultValue(); }

  double HELLO_INTERVAL;
  double REFRESH_INTERVAL;
  double TC_INTERVAL;
  double MID_INTERVAL;
  double HNA_INTERVAL;
  double NEIGHB_HOLD_TIME;
  double TOP_HOLD_TIME;
  double DUP_HOLD_TIME;
  double MID_HOLD_TIME;
  double HNA_HOLD_TIME;
  double MAXJITTER;
  int willingness;
  int tc_redundancy;
  int mpr_coverage;
  int multicastType;
  double strategyInterval;
  double heardIfaceExpireTime;
  double hyst_threshold_high;
  double hyst_threshold_low;
  double hyst_scaling;
  int signal_threshold_high;
  int signal_threshold_low;
  bool useHysteresisMonitoring;
  bool useSignalMonitoring;
  bool delayGeneration;
  double freeSpaceSplittingProportionLimit;
  double globalSplittingProportionLimit;
  bool immediateMessageTransmission;
  string mainIface;
  bool ipv4;
  bool ipv6;
  string logFileName;
  bool onlyParseConfig;
  bool noLog;
  double startTime;
  double stopTime;
  bool noRouteCalculation;
  bool fastRouteCalculation;
  double routeCalculationStartTime;
  bool randomInitialSeqNum;
  bool noFork;
  int udpPort;
  int httpAdminPort;
  string ipv6MulticastAddress;
  string ipv6AddressFilter;
  string ipv4MulticastAddress;
  bool noRouteSetup;
  bool ignoreRouteSetupError;
  std::list< std::pair<string,string> > hnaList;
  double clockOffset;
  string randomSeed;
  int eventBreakpoint;
  double startLogTime;
  bool nuAutoConf;
  int MAX_TC_DIFF_SEQ_NUM;
  double MAX_MESSAGE_RATE;
  double NODE_STATE_HOLD_TIME;
  double CONFLICT_HOLD_TIME;
  double NODE_FAMILIAR_TIME;
  double MAX_MPR_REMEMBER_TIME;
  double MIN_TC_FAMILIARITY_RATE;
  bool autoConfInteroperate;
  int autoConfPrefixLength;
  int autoConfAlgorithm;
  double autoConfIncrementProbability;
  string autoConfIpv4Prefix;
  string autoConfIpv4InitialAddress;
  string autoConfIpv6Prefix;
  string autoConfIpv6InitialAddress;
  bool autoConfHashHello;
  bool autoConfNoState;
  double autoConfHelloStateDuration;
  double autoConfTopologyStateDuration;
  string keptAddress;
  bool autoConfContaminationAvoidance;
  bool autoConfUseR10R11;
  string ipRoutePath;
  string iptablesPath;
  double SC_INTERVAL;
  double SC_HOLD_TIME ;
  double CP_INTERVAL;
  double CP_HOLD_TIME;
  double LEAVE_INTERVAL;
  double LEAVE_HOLD_TIME;
  bool MOLSRMODE;
  double MOST_JOIN_INTERVAL;
  double MOST_JOIN_HOLD_TIME;
  double MOST_UPDATE_INTERVAL;
  double MOST_NEIGHBOR_HOLD_TIME;
  double MOST_TRANSITION_PERIOD;
  double MDFP_INTERVAL;
  double GMA_INTERVAL;
  double MEMBERSHIP_VALID_TIME;
  double labaGenerationInterval;
  double labaExpirationRelativeTime;
  double messageNonProcessingRate;
  bool sendFullAssociationTable;
  bool cheatGetMeshPointOfStation;
  int maxStationPerBlock;
  bool useBroadcastABBR;
  int nbGenerationSampling;
  int maxLABChange;
  int maxLABRequest;
  int minLABChange;
  int minLABRequest;
  bool useQos;
  double qosHoldTime;
  bool qosUseBestEffortRoute;
  double qosMediumBandwidth;
  double qosMediumMacDelay;
  double qosUnicastRate;
  double qosBroadcastRate;
  double qosUnicastMacDelay;
  double qosBroadcastMacDelay;
  double qosFamousAlpha;
  string qosTcLocation;
  int qosTcHyst;
  double qosMediumCapacity;
  string qosSyntaxTcCmd1;
  string qosSyntaxTcCmd2;
  string qosSyntaxTcCmd3;
  int qosBeTcHandle;
  int qosQosTcHandle;
  int qosOlsrTcHandle;
  double qosMinPacketCounterDelay;
  bool useAuthentication;
  bool useTimeProtocol;
  double timestampTolerance;
  bool checkTimeStamp;
  double timeProtocolGenerationInterval;
  double timeProtocolHoldTime;
  int timeProtocolMaxSample;
  double timeProtocolMaxRtt;
  bool incorrectForwardingAttack;
  bool useConversion;
  bool useOLSR;
  double timeSchedulingMargin;
  bool usePacketTimestamp;


  void setDefaultValue() {
    HELLO_INTERVAL = 2.0;
    REFRESH_INTERVAL = 2.0;
    TC_INTERVAL = 5.0;
    MID_INTERVAL = 5.0;
    HNA_INTERVAL = 5.0;
    NEIGHB_HOLD_TIME = 6.0;
    TOP_HOLD_TIME = 15.0;
    DUP_HOLD_TIME = 30.0;
    MID_HOLD_TIME = 15.0;
    HNA_HOLD_TIME = 15.0;
    MAXJITTER = 0.5;
    willingness = 3;
    tc_redundancy = 0;
    mpr_coverage = 1;
    multicastType = -1;
    strategyInterval = 0.05;
    heardIfaceExpireTime = 8.0;
    hyst_threshold_high = 0.8;
    hyst_threshold_low = 0.3;
    hyst_scaling = 0.5;
    signal_threshold_high = -27;
    signal_threshold_low = -36;
    useHysteresisMonitoring = 1;
    useSignalMonitoring = 1;
    delayGeneration = 0;
    freeSpaceSplittingProportionLimit = 0.5;
    globalSplittingProportionLimit = 0.5;
    immediateMessageTransmission = 0;
    mainIface = "";
    ipv4 = 1;
    ipv6 = 0;
    logFileName = "tmp/olsr.%s";
    onlyParseConfig = 0;
    noLog = 1;
    startTime = -1.0;
    stopTime = -1.0;
    noRouteCalculation = 0;
    fastRouteCalculation = 0;
    routeCalculationStartTime = 0.0;
    randomInitialSeqNum = 0;
    noFork = 0;
    udpPort = 698;
    httpAdminPort = 11698;
    ipv6MulticastAddress = "ff02::1";
    ipv6AddressFilter = "2010:3:505:1::/64";
    ipv4MulticastAddress = "255.255.255.255";
    noRouteSetup = 0;
    ignoreRouteSetupError = 1;
    clockOffset = 0;
    eventBreakpoint = -1;
    startLogTime = -1;
    nuAutoConf = 0;
    MAX_TC_DIFF_SEQ_NUM = 16;
    MAX_MESSAGE_RATE = 10.0;
    NODE_STATE_HOLD_TIME = 300.0;
    CONFLICT_HOLD_TIME = 6.0;
    NODE_FAMILIAR_TIME = 10.0;
    MAX_MPR_REMEMBER_TIME = 12.0;
    MIN_TC_FAMILIARITY_RATE = 0.5;
    autoConfInteroperate = 1;
    autoConfPrefixLength = 16;
    autoConfAlgorithm = 0;
    autoConfIncrementProbability = 0.5;
    autoConfHashHello = 0;
    autoConfNoState = 0;
    autoConfHelloStateDuration = 6.0;
    autoConfTopologyStateDuration = 15.0;
    autoConfContaminationAvoidance = 1;
    autoConfUseR10R11 = 1;
    ipRoutePath = "/sbin/ip";
    iptablesPath = "/sbin/iptables";
    SC_INTERVAL = 5.0;
    SC_HOLD_TIME  = 15.0;
    CP_INTERVAL = 5.0;
    CP_HOLD_TIME = 15.0;
    LEAVE_INTERVAL = 1;
    LEAVE_HOLD_TIME = 1;
    MOLSRMODE = 0;
    MOST_JOIN_INTERVAL = 5.0;
    MOST_JOIN_HOLD_TIME = 15.0;
    MOST_UPDATE_INTERVAL = 2.0;
    MOST_NEIGHBOR_HOLD_TIME = 3.0;
    MOST_TRANSITION_PERIOD = 1.0;
    MDFP_INTERVAL = 0.5;
    GMA_INTERVAL = 3;
    MEMBERSHIP_VALID_TIME = 9;
    labaGenerationInterval = 5.0;
    labaExpirationRelativeTime = 3.0;
    messageNonProcessingRate = 0.0;
    sendFullAssociationTable = 1;
    cheatGetMeshPointOfStation = 0;
    maxStationPerBlock = 10;
    useBroadcastABBR = 0;
    nbGenerationSampling = 5;
    maxLABChange = 1;
    maxLABRequest = 1;
    minLABChange = 0;
    minLABRequest = 0;
    useQos = 0;
    qosHoldTime = 30.0;
    qosUseBestEffortRoute = 0;
    qosMediumBandwidth = 11000000.0;
    qosMediumMacDelay = 0.0003;
    qosUnicastRate = 11000000.0;
    qosBroadcastRate = 2000000.0;
    qosUnicastMacDelay = 0.00084;
    qosBroadcastMacDelay = 0.00078;
    qosFamousAlpha = 2.17;
    qosTcLocation = "/sbin/tc";
    qosTcHyst = 20;
    qosMediumCapacity = 11000.0;
    qosSyntaxTcCmd1 = " qdisc change dev ";
    qosSyntaxTcCmd2 = " parent 1:3 handle 30:0 tbf rate ";
    qosSyntaxTcCmd3 = "kbit buffer 5000 limit 2000";
    qosBeTcHandle = 48;
    qosQosTcHandle = 32;
    qosOlsrTcHandle = 16;
    qosMinPacketCounterDelay = 1.0;
    useAuthentication = 0;
    useTimeProtocol = 0;
    timestampTolerance = 15.0;
    checkTimeStamp = 1;
    timeProtocolGenerationInterval = 5.0;
    timeProtocolHoldTime = 100.0;
    timeProtocolMaxSample = 10;
    timeProtocolMaxRtt = 1.0;
    incorrectForwardingAttack = 0;
    useConversion = 0;
    useOLSR = 1;
    timeSchedulingMargin = 0.01;
    usePacketTimestamp = 0;

  }

  string parseData(GeneratedLog& log, std::vector<string>& data) {
    if (data.size() < 2) return "not enough arguments";
    else if (data[0] == "hello-interval") {
      HELLO_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "refresh-interval") {
      REFRESH_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "tc-interval") {
      TC_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "mid-interval") {
      MID_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "hna-interval") {
      HNA_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "neighb-hold-time") {
      NEIGHB_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "top-hold-time") {
      TOP_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "dup-hold-time") {
      DUP_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "mid-hold-time") {
      MID_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "hna-hold-time") {
      HNA_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "maxjitter") {
      MAXJITTER = parseFloat(data[1]);
    } else if (data[0] == "willingness") {
      willingness = parseInt(data[1]);
    } else if (data[0] == "tc-redundancy") {
      tc_redundancy = parseInt(data[1]);
    } else if (data[0] == "mpr-coverage") {
      mpr_coverage = parseInt(data[1]);
    } else if (data[0] == "multicast-type") {
      multicastType = parseInt(data[1]);
    } else if (data[0] == "strategy-interval") {
      strategyInterval = parseFloat(data[1]);
    } else if (data[0] == "heard-iface-expire-time") {
      heardIfaceExpireTime = parseFloat(data[1]);
    } else if (data[0] == "hyst-threshold-high") {
      hyst_threshold_high = parseFloat(data[1]);
    } else if (data[0] == "hyst-threshold-low") {
      hyst_threshold_low = parseFloat(data[1]);
    } else if (data[0] == "hyst-scaling") {
      hyst_scaling = parseFloat(data[1]);
    } else if (data[0] == "signal-threshold-high") {
      signal_threshold_high = parseInt(data[1]);
    } else if (data[0] == "signal-threshold-low") {
      signal_threshold_low = parseInt(data[1]);
    } else if (data[0] == "use-hysteresis-monitoring") {
      useHysteresisMonitoring = parseBool(data[1]);
    } else if (data[0] == "use-signal-monitoring") {
      useSignalMonitoring = parseBool(data[1]);
    } else if (data[0] == "delay-generation") {
      delayGeneration = parseBool(data[1]);
    } else if (data[0] == "free-space-splitting-proportion-limit") {
      freeSpaceSplittingProportionLimit = parseFloat(data[1]);
    } else if (data[0] == "global-splitting-proportion-limit") {
      globalSplittingProportionLimit = parseFloat(data[1]);
    } else if (data[0] == "immediate-message-transmission") {
      immediateMessageTransmission = parseBool(data[1]);
    } else if (data[0] == "main-iface") {
      mainIface = parseString(data[1]);
    } else if (data[0] == "ipv4") {
      ipv4 = parseBool(data[1]);
    } else if (data[0] == "ipv6") {
      ipv6 = parseBool(data[1]);
    } else if (data[0] == "log-file-name") {
      logFileName = parseString(data[1]);
    } else if (data[0] == "only-parse-config") {
      onlyParseConfig = parseBool(data[1]);
    } else if (data[0] == "no-log") {
      noLog = parseBool(data[1]);
    } else if (data[0] == "start-time") {
      startTime = parseFloat(data[1]);
    } else if (data[0] == "stop-time") {
      stopTime = parseFloat(data[1]);
    } else if (data[0] == "no-route-calculation") {
      noRouteCalculation = parseBool(data[1]);
    } else if (data[0] == "fast-route-calculation") {
      fastRouteCalculation = parseBool(data[1]);
    } else if (data[0] == "route-calculation-start-time") {
      routeCalculationStartTime = parseFloat(data[1]);
    } else if (data[0] == "random-initial-seq-num") {
      randomInitialSeqNum = parseBool(data[1]);
    } else if (data[0] == "no-fork") {
      noFork = parseBool(data[1]);
    } else if (data[0] == "udp-port") {
      udpPort = parseInt(data[1]);
    } else if (data[0] == "http-admin-port") {
      httpAdminPort = parseInt(data[1]);
    } else if (data[0] == "ipv6-multicast-address") {
      ipv6MulticastAddress = parseString(data[1]);
    } else if (data[0] == "ipv6-address-filter") {
      ipv6AddressFilter = parseString(data[1]);
    } else if (data[0] == "ipv4-multicast-address") {
      ipv4MulticastAddress = parseString(data[1]);
    } else if (data[0] == "no-route-setup") {
      noRouteSetup = parseBool(data[1]);
    } else if (data[0] == "ignore-route-setup-error") {
      ignoreRouteSetupError = parseBool(data[1]);
    } else if (data[0] == "hna-list") {
      hnaList = parseHNAList(data[1]);
    } else if (data[0] == "clock-offset") {
      clockOffset = parseFloat(data[1]);
    } else if (data[0] == "random-seed") {
      randomSeed = parseString(data[1]);
    } else if (data[0] == "log-action") {
      log.lAction = parseBool(data[1]);
    } else if (data[0] == "log-warning") {
      log.lWarning = parseBool(data[1]);
    } else if (data[0] == "log-event") {
      log.lEvent = parseBool(data[1]);
    } else if (data[0] == "log-event-strategy") {
      log.lEventStrategy = parseBool(data[1]);
    } else if (data[0] == "log-packet") {
      log.lPacket = parseBool(data[1]);
    } else if (data[0] == "log-message") {
      log.lMessage = parseBool(data[1]);
    } else if (data[0] == "log-packet-content") {
      log.lPacketContent = parseBool(data[1]);
    } else if (data[0] == "log-state") {
      log.lState = parseBool(data[1]);
    } else if (data[0] == "log-packet-processing") {
      log.lPacketProcessing = parseBool(data[1]);
    } else if (data[0] == "log-expiration") {
      log.lExpiration = parseBool(data[1]);
    } else if (data[0] == "log-config") {
      log.lConfig = parseBool(data[1]);
    } else if (data[0] == "log-route") {
      log.lRoute = parseBool(data[1]);
    } else if (data[0] == "log-multicast") {
      log.lMulticast = parseBool(data[1]);
    } else if (data[0] == "log-mesh-point") {
      log.lMeshPoint = parseBool(data[1]);
    } else if (data[0] == "log-auto-conf") {
      log.lAutoConf = parseBool(data[1]);
    } else if (data[0] == "log-security") {
      log.lSecurity = parseBool(data[1]);
    } else if (data[0] == "log-qos") {
      log.lQos = parseBool(data[1]);
    } else if (data[0] == "log-external") {
      log.lExternal = parseBool(data[1]);
    } else if (data[0] == "log-time-protocol") {
      log.lTimeProtocol = parseBool(data[1]);
    } else if (data[0] == "log-conversion") {
      log.lConversion = parseBool(data[1]);
    } else if (data[0] == "log-data") {
      log.lData = parseBool(data[1]);
    } else if (data[0] == "log-most") {
      log.lMost = parseBool(data[1]);
    } else if (data[0] == "event-breakpoint") {
      eventBreakpoint = parseInt(data[1]);
    } else if (data[0] == "start-log-time") {
      startLogTime = parseFloat(data[1]);
    } else if (data[0] == "nu-auto-conf") {
      nuAutoConf = parseBool(data[1]);
    } else if (data[0] == "max-tc-diff-seq-num") {
      MAX_TC_DIFF_SEQ_NUM = parseInt(data[1]);
    } else if (data[0] == "max-message-rate") {
      MAX_MESSAGE_RATE = parseFloat(data[1]);
    } else if (data[0] == "node-state-hold-time") {
      NODE_STATE_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "conflict-hold-time") {
      CONFLICT_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "node-familiar-time") {
      NODE_FAMILIAR_TIME = parseFloat(data[1]);
    } else if (data[0] == "max-mpr-remember-time") {
      MAX_MPR_REMEMBER_TIME = parseFloat(data[1]);
    } else if (data[0] == "min-tc-familiarity-rate") {
      MIN_TC_FAMILIARITY_RATE = parseFloat(data[1]);
    } else if (data[0] == "auto-conf-interoperate") {
      autoConfInteroperate = parseBool(data[1]);
    } else if (data[0] == "auto-conf-prefix-length") {
      autoConfPrefixLength = parseInt(data[1]);
    } else if (data[0] == "auto-conf-algorithm") {
      autoConfAlgorithm = parseInt(data[1]);
    } else if (data[0] == "auto-conf-increment-probability") {
      autoConfIncrementProbability = parseFloat(data[1]);
    } else if (data[0] == "auto-conf-ipv4-prefix") {
      autoConfIpv4Prefix = parseString(data[1]);
    } else if (data[0] == "auto-conf-ipv4-initial-address") {
      autoConfIpv4InitialAddress = parseString(data[1]);
    } else if (data[0] == "auto-conf-ipv6-prefix") {
      autoConfIpv6Prefix = parseString(data[1]);
    } else if (data[0] == "auto-conf-ipv6-initial-address") {
      autoConfIpv6InitialAddress = parseString(data[1]);
    } else if (data[0] == "auto-conf-hash-hello") {
      autoConfHashHello = parseBool(data[1]);
    } else if (data[0] == "auto-conf-no-state") {
      autoConfNoState = parseBool(data[1]);
    } else if (data[0] == "auto-conf-hello-state-duration") {
      autoConfHelloStateDuration = parseFloat(data[1]);
    } else if (data[0] == "auto-conf-topology-state-duration") {
      autoConfTopologyStateDuration = parseFloat(data[1]);
    } else if (data[0] == "kept-address") {
      keptAddress = parseString(data[1]);
    } else if (data[0] == "auto-conf-contamination-avoidance") {
      autoConfContaminationAvoidance = parseBool(data[1]);
    } else if (data[0] == "auto-conf-use-r10-r11") {
      autoConfUseR10R11 = parseBool(data[1]);
    } else if (data[0] == "ip-route-path") {
      ipRoutePath = parseString(data[1]);
    } else if (data[0] == "iptables-path") {
      iptablesPath = parseString(data[1]);
    } else if (data[0] == "sc-interval") {
      SC_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "-s-c--h-o-l-d--t-i-m-e ") {
      SC_HOLD_TIME  = parseFloat(data[1]);
    } else if (data[0] == "cp-interval") {
      CP_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "cp-hold-time") {
      CP_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "leave-interval") {
      LEAVE_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "leave-hold-time") {
      LEAVE_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "molsrmode") {
      MOLSRMODE = parseBool(data[1]);
    } else if (data[0] == "most-join-interval") {
      MOST_JOIN_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "most-join-hold-time") {
      MOST_JOIN_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "most-update-interval") {
      MOST_UPDATE_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "most-neighbor-hold-time") {
      MOST_NEIGHBOR_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "most-transition-period") {
      MOST_TRANSITION_PERIOD = parseFloat(data[1]);
    } else if (data[0] == "mdfp-interval") {
      MDFP_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "gma-interval") {
      GMA_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "membership-valid-time") {
      MEMBERSHIP_VALID_TIME = parseFloat(data[1]);
    } else if (data[0] == "laba-generation-interval") {
      labaGenerationInterval = parseFloat(data[1]);
    } else if (data[0] == "laba-expiration-relative-time") {
      labaExpirationRelativeTime = parseFloat(data[1]);
    } else if (data[0] == "message-non-processing-rate") {
      messageNonProcessingRate = parseFloat(data[1]);
    } else if (data[0] == "send-full-association-table") {
      sendFullAssociationTable = parseBool(data[1]);
    } else if (data[0] == "cheat-get-mesh-point-of-station") {
      cheatGetMeshPointOfStation = parseBool(data[1]);
    } else if (data[0] == "max-station-per-block") {
      maxStationPerBlock = parseInt(data[1]);
    } else if (data[0] == "use-broadcast-a-b-b-r") {
      useBroadcastABBR = parseBool(data[1]);
    } else if (data[0] == "nb-generation-sampling") {
      nbGenerationSampling = parseInt(data[1]);
    } else if (data[0] == "max-l-a-b-change") {
      maxLABChange = parseInt(data[1]);
    } else if (data[0] == "max-l-a-b-request") {
      maxLABRequest = parseInt(data[1]);
    } else if (data[0] == "min-l-a-b-change") {
      minLABChange = parseInt(data[1]);
    } else if (data[0] == "min-l-a-b-request") {
      minLABRequest = parseInt(data[1]);
    } else if (data[0] == "use-qos") {
      useQos = parseBool(data[1]);
    } else if (data[0] == "qos-hold-time") {
      qosHoldTime = parseFloat(data[1]);
    } else if (data[0] == "qos-use-best-effort-route") {
      qosUseBestEffortRoute = parseBool(data[1]);
    } else if (data[0] == "qos-medium-bandwidth") {
      qosMediumBandwidth = parseFloat(data[1]);
    } else if (data[0] == "qos-medium-mac-delay") {
      qosMediumMacDelay = parseFloat(data[1]);
    } else if (data[0] == "qos-unicast-rate") {
      qosUnicastRate = parseFloat(data[1]);
    } else if (data[0] == "qos-broadcast-rate") {
      qosBroadcastRate = parseFloat(data[1]);
    } else if (data[0] == "qos-unicast-mac-delay") {
      qosUnicastMacDelay = parseFloat(data[1]);
    } else if (data[0] == "qos-broadcast-mac-delay") {
      qosBroadcastMacDelay = parseFloat(data[1]);
    } else if (data[0] == "qos-famous-alpha") {
      qosFamousAlpha = parseFloat(data[1]);
    } else if (data[0] == "qos-tc-location") {
      qosTcLocation = parseString(data[1]);
    } else if (data[0] == "qos-tc-hyst") {
      qosTcHyst = parseInt(data[1]);
    } else if (data[0] == "qos-medium-capacity") {
      qosMediumCapacity = parseFloat(data[1]);
    } else if (data[0] == "qos-syntax-tc-cmd1") {
      qosSyntaxTcCmd1 = parseString(data[1]);
    } else if (data[0] == "qos-syntax-tc-cmd2") {
      qosSyntaxTcCmd2 = parseString(data[1]);
    } else if (data[0] == "qos-syntax-tc-cmd3") {
      qosSyntaxTcCmd3 = parseString(data[1]);
    } else if (data[0] == "qos-be-tc-handle") {
      qosBeTcHandle = parseInt(data[1]);
    } else if (data[0] == "qos-qos-tc-handle") {
      qosQosTcHandle = parseInt(data[1]);
    } else if (data[0] == "qos-olsr-tc-handle") {
      qosOlsrTcHandle = parseInt(data[1]);
    } else if (data[0] == "qos-min-packet-counter-delay") {
      qosMinPacketCounterDelay = parseFloat(data[1]);
    } else if (data[0] == "use-authentication") {
      useAuthentication = parseBool(data[1]);
    } else if (data[0] == "use-time-protocol") {
      useTimeProtocol = parseBool(data[1]);
    } else if (data[0] == "timestamp-tolerance") {
      timestampTolerance = parseFloat(data[1]);
    } else if (data[0] == "check-time-stamp") {
      checkTimeStamp = parseBool(data[1]);
    } else if (data[0] == "time-protocol-generation-interval") {
      timeProtocolGenerationInterval = parseFloat(data[1]);
    } else if (data[0] == "time-protocol-hold-time") {
      timeProtocolHoldTime = parseFloat(data[1]);
    } else if (data[0] == "time-protocol-max-sample") {
      timeProtocolMaxSample = parseInt(data[1]);
    } else if (data[0] == "time-protocol-max-rtt") {
      timeProtocolMaxRtt = parseFloat(data[1]);
    } else if (data[0] == "incorrect-forwarding-attack") {
      incorrectForwardingAttack = parseBool(data[1]);
    } else if (data[0] == "use-conversion") {
      useConversion = parseBool(data[1]);
    } else if (data[0] == "use-o-l-s-r") {
      useOLSR = parseBool(data[1]);
    } else if (data[0] == "time-scheduling-margin") {
      timeSchedulingMargin = parseFloat(data[1]);
    } else if (data[0] == "use-packet-timestamp") {
      usePacketTimestamp = parseBool(data[1]);
    }  else {
      return "Cannot parse XXX";
    }
    return "";
  }

  void write(ostream& out) const
  {
    out  << "hello-interval " << HELLO_INTERVAL  << "; "  << "refresh-interval " << REFRESH_INTERVAL  << "; "  << "tc-interval " << TC_INTERVAL  << "; "  << "mid-interval " << MID_INTERVAL  << "; "  << "hna-interval " << HNA_INTERVAL  << "; "  << "neighb-hold-time " << NEIGHB_HOLD_TIME  << "; "  << "top-hold-time " << TOP_HOLD_TIME  << "; "  << "dup-hold-time " << DUP_HOLD_TIME  << "; "  << "mid-hold-time " << MID_HOLD_TIME  << "; "  << "hna-hold-time " << HNA_HOLD_TIME  << "; "  << "maxjitter " << MAXJITTER  << "; "  << "willingness " << willingness  << "; "  << "tc-redundancy " << tc_redundancy  << "; "  << "mpr-coverage " << mpr_coverage  << "; "  << "multicast-type " << multicastType  << "; "  << "strategy-interval " << strategyInterval  << "; "  << "heard-iface-expire-time " << heardIfaceExpireTime  << "; "  << "hyst-threshold-high " << hyst_threshold_high  << "; "  << "hyst-threshold-low " << hyst_threshold_low  << "; "  << "hyst-scaling " << hyst_scaling  << "; "  << "signal-threshold-high " << signal_threshold_high  << "; "  << "signal-threshold-low " << signal_threshold_low  << "; "  << "use-hysteresis-monitoring " << useHysteresisMonitoring  << "; "  << "use-signal-monitoring " << useSignalMonitoring  << "; "  << "delay-generation " << delayGeneration  << "; "  << "free-space-splitting-proportion-limit " << freeSpaceSplittingProportionLimit  << "; "  << "global-splitting-proportion-limit " << globalSplittingProportionLimit  << "; "  << "immediate-message-transmission " << immediateMessageTransmission  << "; "  << "main-iface " << mainIface  << "; "  << "ipv4 " << ipv4  << "; "  << "ipv6 " << ipv6  << "; "  << "log-file-name " << logFileName  << "; "  << "only-parse-config " << onlyParseConfig  << "; "  << "no-log " << noLog  << "; "  << "start-time " << startTime  << "; "  << "stop-time " << stopTime  << "; "  << "no-route-calculation " << noRouteCalculation  << "; "  << "fast-route-calculation " << fastRouteCalculation  << "; "  << "route-calculation-start-time " << routeCalculationStartTime  << "; "  << "random-initial-seq-num " << randomInitialSeqNum  << "; "  << "no-fork " << noFork  << "; "  << "udp-port " << udpPort  << "; "  << "http-admin-port " << httpAdminPort  << "; "  << "ipv6-multicast-address " << ipv6MulticastAddress  << "; "  << "ipv6-address-filter " << ipv6AddressFilter  << "; "  << "ipv4-multicast-address " << ipv4MulticastAddress  << "; "  << "no-route-setup " << noRouteSetup  << "; "  << "ignore-route-setup-error " << ignoreRouteSetupError  << "; "  << "hna-list " << hnaList  << "; "  << "clock-offset " << clockOffset  << "; "  << "random-seed " << randomSeed  << "; "  << "event-breakpoint " << eventBreakpoint  << "; "  << "start-log-time " << startLogTime  << "; "  << "nu-auto-conf " << nuAutoConf  << "; "  << "max-tc-diff-seq-num " << MAX_TC_DIFF_SEQ_NUM  << "; "  << "max-message-rate " << MAX_MESSAGE_RATE  << "; "  << "node-state-hold-time " << NODE_STATE_HOLD_TIME  << "; "  << "conflict-hold-time " << CONFLICT_HOLD_TIME  << "; "  << "node-familiar-time " << NODE_FAMILIAR_TIME  << "; "  << "max-mpr-remember-time " << MAX_MPR_REMEMBER_TIME  << "; "  << "min-tc-familiarity-rate " << MIN_TC_FAMILIARITY_RATE  << "; "  << "auto-conf-interoperate " << autoConfInteroperate  << "; "  << "auto-conf-prefix-length " << autoConfPrefixLength  << "; "  << "auto-conf-algorithm " << autoConfAlgorithm  << "; "  << "auto-conf-increment-probability " << autoConfIncrementProbability  << "; "  << "auto-conf-ipv4-prefix " << autoConfIpv4Prefix  << "; "  << "auto-conf-ipv4-initial-address " << autoConfIpv4InitialAddress  << "; "  << "auto-conf-ipv6-prefix " << autoConfIpv6Prefix  << "; "  << "auto-conf-ipv6-initial-address " << autoConfIpv6InitialAddress  << "; "  << "auto-conf-hash-hello " << autoConfHashHello  << "; "  << "auto-conf-no-state " << autoConfNoState  << "; "  << "auto-conf-hello-state-duration " << autoConfHelloStateDuration  << "; "  << "auto-conf-topology-state-duration " << autoConfTopologyStateDuration  << "; "  << "kept-address " << keptAddress  << "; "  << "auto-conf-contamination-avoidance " << autoConfContaminationAvoidance  << "; "  << "auto-conf-use-r10-r11 " << autoConfUseR10R11  << "; "  << "ip-route-path " << ipRoutePath  << "; "  << "iptables-path " << iptablesPath  << "; "  << "sc-interval " << SC_INTERVAL  << "; "  << "-s-c--h-o-l-d--t-i-m-e  " << SC_HOLD_TIME   << "; "  << "cp-interval " << CP_INTERVAL  << "; "  << "cp-hold-time " << CP_HOLD_TIME  << "; "  << "leave-interval " << LEAVE_INTERVAL  << "; "  << "leave-hold-time " << LEAVE_HOLD_TIME  << "; "  << "molsrmode " << MOLSRMODE  << "; "  << "most-join-interval " << MOST_JOIN_INTERVAL  << "; "  << "most-join-hold-time " << MOST_JOIN_HOLD_TIME  << "; "  << "most-update-interval " << MOST_UPDATE_INTERVAL  << "; "  << "most-neighbor-hold-time " << MOST_NEIGHBOR_HOLD_TIME  << "; "  << "most-transition-period " << MOST_TRANSITION_PERIOD  << "; "  << "mdfp-interval " << MDFP_INTERVAL  << "; "  << "gma-interval " << GMA_INTERVAL  << "; "  << "membership-valid-time " << MEMBERSHIP_VALID_TIME  << "; "  << "laba-generation-interval " << labaGenerationInterval  << "; "  << "laba-expiration-relative-time " << labaExpirationRelativeTime  << "; "  << "message-non-processing-rate " << messageNonProcessingRate  << "; "  << "send-full-association-table " << sendFullAssociationTable  << "; "  << "cheat-get-mesh-point-of-station " << cheatGetMeshPointOfStation  << "; "  << "max-station-per-block " << maxStationPerBlock  << "; "  << "use-broadcast-a-b-b-r " << useBroadcastABBR  << "; "  << "nb-generation-sampling " << nbGenerationSampling  << "; "  << "max-l-a-b-change " << maxLABChange  << "; "  << "max-l-a-b-request " << maxLABRequest  << "; "  << "min-l-a-b-change " << minLABChange  << "; "  << "min-l-a-b-request " << minLABRequest  << "; "  << "use-qos " << useQos  << "; "  << "qos-hold-time " << qosHoldTime  << "; "  << "qos-use-best-effort-route " << qosUseBestEffortRoute  << "; "  << "qos-medium-bandwidth " << qosMediumBandwidth  << "; "  << "qos-medium-mac-delay " << qosMediumMacDelay  << "; "  << "qos-unicast-rate " << qosUnicastRate  << "; "  << "qos-broadcast-rate " << qosBroadcastRate  << "; "  << "qos-unicast-mac-delay " << qosUnicastMacDelay  << "; "  << "qos-broadcast-mac-delay " << qosBroadcastMacDelay  << "; "  << "qos-famous-alpha " << qosFamousAlpha  << "; "  << "qos-tc-location " << qosTcLocation  << "; "  << "qos-tc-hyst " << qosTcHyst  << "; "  << "qos-medium-capacity " << qosMediumCapacity  << "; "  << "qos-syntax-tc-cmd1 " << qosSyntaxTcCmd1  << "; "  << "qos-syntax-tc-cmd2 " << qosSyntaxTcCmd2  << "; "  << "qos-syntax-tc-cmd3 " << qosSyntaxTcCmd3  << "; "  << "qos-be-tc-handle " << qosBeTcHandle  << "; "  << "qos-qos-tc-handle " << qosQosTcHandle  << "; "  << "qos-olsr-tc-handle " << qosOlsrTcHandle  << "; "  << "qos-min-packet-counter-delay " << qosMinPacketCounterDelay  << "; "  << "use-authentication " << useAuthentication  << "; "  << "use-time-protocol " << useTimeProtocol  << "; "  << "timestamp-tolerance " << timestampTolerance  << "; "  << "check-time-stamp " << checkTimeStamp  << "; "  << "time-protocol-generation-interval " << timeProtocolGenerationInterval  << "; "  << "time-protocol-hold-time " << timeProtocolHoldTime  << "; "  << "time-protocol-max-sample " << timeProtocolMaxSample  << "; "  << "time-protocol-max-rtt " << timeProtocolMaxRtt  << "; "  << "incorrect-forwarding-attack " << incorrectForwardingAttack  << "; "  << "use-conversion " << useConversion  << "; "  << "use-o-l-s-r " << useOLSR  << "; "  << "time-scheduling-margin " << timeSchedulingMargin  << "; "  << "use-packet-timestamp " << usePacketTimestamp ;
  }

  vector<vector<string>*>* getTable() const
  {
    vector<vector<string>*>* result = new vector<vector<string>*>;
    vector<string>* header = new vector<string>;
    header->push_back("Param Name");
    header->push_back("Value");
    result->push_back(header);
    
    REPR_PARAM(result,HELLO_INTERVAL);
REPR_PARAM(result,REFRESH_INTERVAL);
REPR_PARAM(result,TC_INTERVAL);
REPR_PARAM(result,MID_INTERVAL);
REPR_PARAM(result,HNA_INTERVAL);
REPR_PARAM(result,NEIGHB_HOLD_TIME);
REPR_PARAM(result,TOP_HOLD_TIME);
REPR_PARAM(result,DUP_HOLD_TIME);
REPR_PARAM(result,MID_HOLD_TIME);
REPR_PARAM(result,HNA_HOLD_TIME);
REPR_PARAM(result,MAXJITTER);
REPR_PARAM(result,willingness);
REPR_PARAM(result,tc_redundancy);
REPR_PARAM(result,mpr_coverage);
REPR_PARAM(result,multicastType);
REPR_PARAM(result,strategyInterval);
REPR_PARAM(result,heardIfaceExpireTime);
REPR_PARAM(result,hyst_threshold_high);
REPR_PARAM(result,hyst_threshold_low);
REPR_PARAM(result,hyst_scaling);
REPR_PARAM(result,signal_threshold_high);
REPR_PARAM(result,signal_threshold_low);
REPR_PARAM(result,useHysteresisMonitoring);
REPR_PARAM(result,useSignalMonitoring);
REPR_PARAM(result,delayGeneration);
REPR_PARAM(result,freeSpaceSplittingProportionLimit);
REPR_PARAM(result,globalSplittingProportionLimit);
REPR_PARAM(result,immediateMessageTransmission);
REPR_PARAM(result,mainIface);
REPR_PARAM(result,ipv4);
REPR_PARAM(result,ipv6);
REPR_PARAM(result,logFileName);
REPR_PARAM(result,onlyParseConfig);
REPR_PARAM(result,noLog);
REPR_PARAM(result,startTime);
REPR_PARAM(result,stopTime);
REPR_PARAM(result,noRouteCalculation);
REPR_PARAM(result,fastRouteCalculation);
REPR_PARAM(result,routeCalculationStartTime);
REPR_PARAM(result,randomInitialSeqNum);
REPR_PARAM(result,noFork);
REPR_PARAM(result,udpPort);
REPR_PARAM(result,httpAdminPort);
REPR_PARAM(result,ipv6MulticastAddress);
REPR_PARAM(result,ipv6AddressFilter);
REPR_PARAM(result,ipv4MulticastAddress);
REPR_PARAM(result,noRouteSetup);
REPR_PARAM(result,ignoreRouteSetupError);
REPR_PARAM(result,hnaList);
REPR_PARAM(result,clockOffset);
REPR_PARAM(result,randomSeed);
REPR_PARAM(result,eventBreakpoint);
REPR_PARAM(result,startLogTime);
REPR_PARAM(result,nuAutoConf);
REPR_PARAM(result,MAX_TC_DIFF_SEQ_NUM);
REPR_PARAM(result,MAX_MESSAGE_RATE);
REPR_PARAM(result,NODE_STATE_HOLD_TIME);
REPR_PARAM(result,CONFLICT_HOLD_TIME);
REPR_PARAM(result,NODE_FAMILIAR_TIME);
REPR_PARAM(result,MAX_MPR_REMEMBER_TIME);
REPR_PARAM(result,MIN_TC_FAMILIARITY_RATE);
REPR_PARAM(result,autoConfInteroperate);
REPR_PARAM(result,autoConfPrefixLength);
REPR_PARAM(result,autoConfAlgorithm);
REPR_PARAM(result,autoConfIncrementProbability);
REPR_PARAM(result,autoConfIpv4Prefix);
REPR_PARAM(result,autoConfIpv4InitialAddress);
REPR_PARAM(result,autoConfIpv6Prefix);
REPR_PARAM(result,autoConfIpv6InitialAddress);
REPR_PARAM(result,autoConfHashHello);
REPR_PARAM(result,autoConfNoState);
REPR_PARAM(result,autoConfHelloStateDuration);
REPR_PARAM(result,autoConfTopologyStateDuration);
REPR_PARAM(result,keptAddress);
REPR_PARAM(result,autoConfContaminationAvoidance);
REPR_PARAM(result,autoConfUseR10R11);
REPR_PARAM(result,ipRoutePath);
REPR_PARAM(result,iptablesPath);
REPR_PARAM(result,SC_INTERVAL);
REPR_PARAM(result,SC_HOLD_TIME );
REPR_PARAM(result,CP_INTERVAL);
REPR_PARAM(result,CP_HOLD_TIME);
REPR_PARAM(result,LEAVE_INTERVAL);
REPR_PARAM(result,LEAVE_HOLD_TIME);
REPR_PARAM(result,MOLSRMODE);
REPR_PARAM(result,MOST_JOIN_INTERVAL);
REPR_PARAM(result,MOST_JOIN_HOLD_TIME);
REPR_PARAM(result,MOST_UPDATE_INTERVAL);
REPR_PARAM(result,MOST_NEIGHBOR_HOLD_TIME);
REPR_PARAM(result,MOST_TRANSITION_PERIOD);
REPR_PARAM(result,MDFP_INTERVAL);
REPR_PARAM(result,GMA_INTERVAL);
REPR_PARAM(result,MEMBERSHIP_VALID_TIME);
REPR_PARAM(result,labaGenerationInterval);
REPR_PARAM(result,labaExpirationRelativeTime);
REPR_PARAM(result,messageNonProcessingRate);
REPR_PARAM(result,sendFullAssociationTable);
REPR_PARAM(result,cheatGetMeshPointOfStation);
REPR_PARAM(result,maxStationPerBlock);
REPR_PARAM(result,useBroadcastABBR);
REPR_PARAM(result,nbGenerationSampling);
REPR_PARAM(result,maxLABChange);
REPR_PARAM(result,maxLABRequest);
REPR_PARAM(result,minLABChange);
REPR_PARAM(result,minLABRequest);
REPR_PARAM(result,useQos);
REPR_PARAM(result,qosHoldTime);
REPR_PARAM(result,qosUseBestEffortRoute);
REPR_PARAM(result,qosMediumBandwidth);
REPR_PARAM(result,qosMediumMacDelay);
REPR_PARAM(result,qosUnicastRate);
REPR_PARAM(result,qosBroadcastRate);
REPR_PARAM(result,qosUnicastMacDelay);
REPR_PARAM(result,qosBroadcastMacDelay);
REPR_PARAM(result,qosFamousAlpha);
REPR_PARAM(result,qosTcLocation);
REPR_PARAM(result,qosTcHyst);
REPR_PARAM(result,qosMediumCapacity);
REPR_PARAM(result,qosSyntaxTcCmd1);
REPR_PARAM(result,qosSyntaxTcCmd2);
REPR_PARAM(result,qosSyntaxTcCmd3);
REPR_PARAM(result,qosBeTcHandle);
REPR_PARAM(result,qosQosTcHandle);
REPR_PARAM(result,qosOlsrTcHandle);
REPR_PARAM(result,qosMinPacketCounterDelay);
REPR_PARAM(result,useAuthentication);
REPR_PARAM(result,useTimeProtocol);
REPR_PARAM(result,timestampTolerance);
REPR_PARAM(result,checkTimeStamp);
REPR_PARAM(result,timeProtocolGenerationInterval);
REPR_PARAM(result,timeProtocolHoldTime);
REPR_PARAM(result,timeProtocolMaxSample);
REPR_PARAM(result,timeProtocolMaxRtt);
REPR_PARAM(result,incorrectForwardingAttack);
REPR_PARAM(result,useConversion);
REPR_PARAM(result,useOLSR);
REPR_PARAM(result,timeSchedulingMargin);
REPR_PARAM(result,usePacketTimestamp);
;
    
    return result;
  }

  ExternalChannelConfig* getChannelByName(string name)
  {
    for (ITER(std::list<ExternalChannelConfig>, it, externalChannelList)) {
      if ((*it).name == name)
	return &(*it);
    }
    return NULL;
  }

  std::map<string,GeneratedIfaceConfig*> ifaceConfig;
  std::list<ExternalChannelConfig> externalChannelList;
#ifdef WITH_SECURITY
  std::list<AuthenticationMethod> authMethodList;
#endif
};

//---------------------------------------------------------------------------

#endif /*_GEN_PROTOCOL_CONFIG_H*/
