//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
//  
//---------------------------------------------------------------------------

#include "mystream.h"

//--------------------------------------------------

#include "general.h"
#include "log.h"
#include "protocol_observer.h"
#include "protocol_tuple.h"
#include "node_link_monitoring.h"
#include "node.h"

#ifdef WITH_QOS
#include "node_inheritance.h"
#endif // WITH_QOS

//---------------------------------------------------------------------------

typedef pair<string, string> StringPair;

#define ADD2(x,y) \
    BeginMacro \
      if (!header) { \
        ostringstream fmt; \
        fmt << y; \
        result->push_back(fmt.str()); \
      } else result->push_back(x); \
    EndMacro

#define ADD(x) ADD2(""#x,t->x)

#define ADDTime2(x,y,now) ADD2((x),((y) - (now)))
#define ADDTime(x,now) ADD2(""#x,t->x - (now))
#define ADDNTime(x,now) ADD2(""#x,- t->x + (now))

//---------------------------------------------------------------------------

class LinkTupleSubject: public ITupleSubject
{
public:
  LinkTuple* t;

  LinkTupleSubject(LinkTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "LinkTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(L_neighbor_iface_addr);
    ADD(L_local_iface_addr);
    ADD2("link status", linkTypeToString(t->getStatus()));
    ADDTime(L_SYM_time, node->getCurrentTime());
    ADDTime(L_ASYM_time, node->getCurrentTime());
    ADDTime(L_time, node->getCurrentTime());

    ADDTime(L_LOST_LINK_time, node->getCurrentTime());
    ADD(L_link_pending);

    return result;
  }
};

class NeighborTupleSubject: public ITupleSubject
{
public:
  NeighborTuple* t;

  NeighborTupleSubject(NeighborTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "NeighborTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(N_neighbor_main_addr);
    ADD2("N_status", neighborStatusToString(t->N_status));
    ADD(N_willingness);

#ifdef WITH_QOS
    if (t != NULL && t->hasQosInfo) {
      ADD(qosLoad);
      ADD(beLoad);
      ADD(qosLab);
      ADD(beLab);
    } else {
      ADD2("qosLoad", "[-]");
      ADD2("beLoad", "[-]");
      ADD2("qosLab", "[-]");
      ADD2("beLab", "[-]");
    }      
#endif // WITH_QOS
    return result;
  }
};


class TwoHopNeighborTupleSubject: public ITupleSubject
{
public:
  TwoHopNeighborTuple* t;
  
  TwoHopNeighborTupleSubject(TwoHopNeighborTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "TwoHopNeighborTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(N_neighbor_main_addr);
    ADD(N_2hop_addr);
    ADDTime(N_time, node->getCurrentTime());

#ifdef WITH_QOS
    if (t != NULL && t->hasQosInfo) {
      ADD(qosLoad);
      ADD(beLoad);
      ADD(qosLab);
      ADD(beLab);
    } else {
      ADD2("qosLoad", "[-]");
      ADD2("beLoad", "[-]");
      ADD2("qosLab", "[-]");
      ADD2("beLab", "[-]");
    }      
#endif // WITH_QOS

    return result;
  }
};

class MPRSelectorTupleSubject: public ITupleSubject
{
public:
  MPRSelectorTuple* t;

  MPRSelectorTupleSubject(MPRSelectorTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "MPRSelectorTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(MS_addr);
    ADDTime(MS_time, node->getCurrentTime());
    return result;
  }
};

#ifdef WITH_QOS
class QosTopologyTupleSubject: public ITupleSubject {
public:
  QosTuple* t;

  QosTopologyTupleSubject(QosTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "QosTopologyTuple"; }

  vector< string >* getContent(Node* baseNode, bool header) 
  {
    QosNode* node = dynamic_cast<QosNode*>(baseNode);
    assert( node != NULL );
    vector< string >* result = new vector< string >;
    ADD(mainAddress);
    ADDTime(expireTime, node->getCurrentTime());
    ADD(qosANSN);
    //    ADD2("qos.qosLoad (not used)", t->qos.qosLoad);
    //    ADD2("qos.beLoad (not used)", t->qos.beLoad);
    ADD2("Min Qos LAB", t->qos.qosLab);
    ADD2("Min Be LAB", t->qos.beLab);

    ostringstream ifaceListOut;
    if (!header) {
      std::list<AddressAndQosInfo>::iterator it;
      for (it = t->neighborQosList.begin();
	   it != t->neighborQosList.end(); it++)
	ifaceListOut << "," << (it->address);
    } else ifaceListOut << ","; // unused
    string ifaceListStr = ifaceListOut.str();
    ifaceListStr.erase(0, 1);
    ADD2("MPR Selectors", ifaceListStr.c_str());

    return result;
  }
};

class QosContentiousTupleSubject: public ITupleSubject {
public:
  QosTuple* t;

  QosContentiousTupleSubject(QosTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "QosContentiousTuple"; }

  vector< string >* getContent(Node* baseNode, bool header) 
  {
    QosNode* node = dynamic_cast<QosNode*>(baseNode);
    assert( node != NULL );
    vector< string >* result = new vector< string >;
    ADD(mainAddress);
    ADDTime(expireTime, node->getCurrentTime());

    ADD2("qos.qosLoad", t->qos.qosLoad);
    ADD2("qos.beLoad", t->qos.beLoad);
    ADD2("qos.qosLab", t->qos.qosLab);
    ADD2("qos.beLab", t->qos.beLab);

    return result;
  }
};
#endif // WITH_QOS

class TopologyTupleSubject: public ITupleSubject
{
public:
  TopologyTuple* t;

  TopologyTupleSubject(TopologyTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "TopologyTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(T_dest_addr);
    ADD(T_last_addr);
    ADD(T_seq);
    ADDTime(T_time, node->getCurrentTime());

    return result;
  }
};

class IfaceAssociationTupleSubject: public ITupleSubject
{
public:
  IfaceAssociationTuple* t;

  IfaceAssociationTupleSubject(IfaceAssociationTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "IfaceAssociationTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(I_iface_addr);
    ADD(I_main_addr);
    ADDTime(I_time, node->getCurrentTime());
    return result;
  }
};


class HNATupleSubject: public ITupleSubject
{
public:
  HNATuple* t;

  HNATupleSubject(HNATuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "HNATuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(A_gateway_addr);
    ADD(A_network_addr);
    ADD(A_netmask);
    ADDTime(A_time, node->getCurrentTime());
    return result;
  }
};

class RoutingTupleSubject: public ITupleSubject
{
public:
  RoutingTuple* t;

  RoutingTupleSubject(RoutingTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "RoutingTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    const int BitPerByte = 8; // XXX: common
    vector< string >* result = new vector< string >;

    ADD(R_iface_addr);
    ADD(R_next_addr);
    ostringstream tmp;
    if (!header) {

      tmp << t->R_dest_addr;
      if (t->R_dest_mask_addr.isNull())
	tmp << "/" << t->R_dest_addr.getNetSize()*BitPerByte;
      else tmp << "/" << t->R_dest_mask_addr;
    }
    ADD2("R_dest_addr", tmp.str().c_str());
    ADD(R_dist);
    return result;
  }
};

class MPRSubject: public ITupleSubject
{
public:
  Address neighborMainAddress;

  MPRSubject(Address mprAddress) 
    : neighborMainAddress(mprAddress) {}

  virtual string getTupleName() { return "MPR"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD2("MPR main address", neighborMainAddress);
    return result;
  }
};


class DuplicateTupleSubject: public ITupleSubject
{
public:
  DuplicateTuple* t;

  DuplicateTupleSubject(DuplicateTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "DuplicateTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(D_addr);
    ADD(D_seq_num);
    ADD(D_retransmitted);
    ostringstream ifaceListOut;
    if (!header) {
      for(std::list<Address>::iterator it = t->D_iface_list.begin(); 
	  it != t->D_iface_list.end(); it++)
	ifaceListOut << "," << (*it);
    } else ifaceListOut << ","; // unused
    string ifaceListStr = ifaceListOut.str();
    ifaceListStr.erase(0, 1);
    ADD2("D_iface_list", ifaceListStr.c_str());
    ADDTime(D_time, node->getCurrentTime());
    return result;
  }
};

class HeardIfaceTupleSubject: public ITupleSubject
{
public:
  HeardIfaceTuple* t;

  HeardIfaceTupleSubject(HeardIfaceTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "HeardIfaceTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(H_remote_iface_addr);
    ADD(H_local_iface_addr);
    ADD2("lastPSeqNum", t->H_last_packetSequenceNumber);
    ADDTime(H_time, node->getCurrentTime());
    ADD2("signLinkQual", t->H_signalMonitoringInfo.linkQuality);
    ADD2("signLinkPending", t->H_signalMonitoringInfo.linkPending);
    if (t != NULL && t->H_signalMonitoringInfo.lostTime == TimeFutureNever) {
      ADD2("signLostTime","[Never]"); 
    } else {
      ADDTime2("signLostTime",
	       t->H_signalMonitoringInfo.lostTime, node->getCurrentTime());
    }
    ADD2("hystLinkQual", t->H_hysteresisMonitoringInfo.linkQuality);
    ADD2("hystLinkPending", t->H_hysteresisMonitoringInfo.linkPending); 
    if (t != NULL && t->H_hysteresisMonitoringInfo.lostTime == TimeFutureNever) {
      ADD2("hystLostTime","[Never]"); 
    } else {
      ADDTime2("hystLostTime",
	       t->H_hysteresisMonitoringInfo.lostTime, node->getCurrentTime());
    }
    return result;
  }
};

#ifdef WITH_STAT
class StatisticTupleSubject: public ITupleSubject
{
public:
  StatisticTuple* t;

  StatisticTupleSubject(StatisticTuple* aTuple) : t(aTuple) {}

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(S_main_addr);
    ADDNTime(S_time, node->getCurrentTime());
    ADD2("packetCount", (int)t->packetCount.total);
    ADD2("helloCount", (int)t->helloCount.total);
    ADD2("tcCount", (int)t->tcCount.total);
    ADD2("avgRouteAvail", 
	 t->routeAvailability.getMean(node->getCurrentTime()));
    ADD2("avgRouteLength",
	 t->routeLength.getMean(node->getCurrentTime()));
    return result;
  }
  virtual string getTupleName() { return "StatisticTuple"; }
};
#endif // WITH_STAT


#if 0
class ITupleSubject: public ITupleSubject
{
public:
  Tuple* t;

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD();
    return result;
  }
};
#endif

//---------------------------------------------------------------------------


template<class TupleSet, class TupleSubject>
vector<vector<string>*>* getTableContent(Node* node, TupleSet& tupleSet)
{
  vector<vector<string>*>* result = new vector<vector<string>*>;
  TupleSubject nullSubject(NULL);

  result->push_back(nullSubject.getContent(node, true));

  for (typename TupleSet::TupleIterator it = tupleSet.getIter(); 
       !it.isDone(); it.next()) {
    TupleSubject subject(it.getCurrent());
    result->push_back(subject.getContent(node, false));
  }

  return result;
} 

template<class CurrentNodeClass, class TupleSet, class TupleSubject>
vector<vector<string>*>* getTableContentDerived(CurrentNodeClass* node,
						TupleSet& tupleSet)
{
  vector<vector<string>*>* result = new vector<vector<string>*>;
  TupleSubject nullSubject(NULL);

  result->push_back(nullSubject.getContent(node, true));

  for (typename TupleSet::TupleIterator it = tupleSet.getIter(); 
       !it.isDone(); it.next()) {
    TupleSubject subject(it.getCurrent());
    result->push_back(subject.getContent(node, false));
  }

  return result;
} 


vector<vector<string>*>* getMPRTableContent(Node* node)
{
  vector<vector<string>*>* result = new vector<vector<string>*>;
  Address nullAddress;
  MPRSubject nullSubject(nullAddress);
  result->push_back(nullSubject.getContent(node, true));
  for (std::list<NeighborTuple*>::iterator it = node->mprList.begin();
       it != node->mprList.end(); it++) {
    MPRSubject subject((*it)->N_neighbor_main_addr);
    result->push_back(subject.getContent(node, false));
  }
  return result;
} 


//---------------------------------------------------------------------------

void DumpProtocolObserver::notifyTupleChange(string changeType,
					     ITupleSubject* subject)
{
  out << "[tuple] " << changeType.c_str() << " " 
      << subject->getTupleName().c_str() << "{" ;
  vector<string>* header = subject->getContent(node, true);
  vector<string>* data = subject->getContent(node, false);
  for (unsigned int i=0; i<data->size(); i++) {
    if (i!=0)
      out << "; ";
    out << (*header)[i] << "=" << (*data)[i];
  }
  out << "}" << endl;
  delete data;
}

//---------------------------------------------------------------------------

void Node::attach(IProtocolObserver* observer,
	    bool observeMajorTupleChange,
	    bool observeMinorTupleChange)
{
  observerList.push_back(observer);
}

void Node::detach(IProtocolObserver* observer)
{
  observerList.remove(observer);
}

vector<string>* Node::getTableNameList()
{
  vector<string>* result = new vector<string>;
  char* tableName[] = { 
    "Config",
    "Route", "Neighbor", "Link", "TwoHopNeighbor", "MPR", "MPRSelector", 
    "Topology", "MID", "HNA", "Duplicate", 
#ifdef LINK_MONITORING
 "HeardIface", 
#endif
#ifdef WITH_STAT
    "Statistics", 
#endif // WITH_STAT
    NULL
  };
  for (char** it = tableName; *it != NULL; it++)
    result->push_back(*it);
  return result;
}


//vector<vector<string>*>* Node::getConfigTable()
//{ return protocolConfig->getTable(); }

vector<vector<string>*>* Node::getTableContent(string name)
{
  if (name == "Config") 
    return protocolConfig->getTable();
  else if (name == "Neighbor") 
    return ::getTableContent<NeighborSet,NeighborTupleSubject>(this, neighborSet);
  else if (name == "Link")
    return ::getTableContent<LinkSet,LinkTupleSubject>(this, linkSet);
  else if (name == "TwoHopNeighbor")
    return ::getTableContent<TwoHopNeighborSet,
      TwoHopNeighborTupleSubject>(this, twoHopNeighborSet);
  else if (name == "MPRSelector")
    return ::getTableContent<MPRSelectorSet, 
      MPRSelectorTupleSubject>(this, mprSelectorSet);
  else if (name == "Topology")
    return ::getTableContent<TopologySet,TopologyTupleSubject>(this,
							       topologySet);
  else if (name == "MID")
    return ::getTableContent<IfaceAssociationSet,
      IfaceAssociationTupleSubject>(this, ifaceAssociationSet);
  else if (name == "HNA")
    return ::getTableContent<HNASet,
      HNATupleSubject>(this, hnaSet);
  else if (name == "Duplicate")
    return ::getTableContent<DuplicateSet,
      DuplicateTupleSubject>(this, duplicateSet);
  else if (name == "HeardIface") 
    return ::getTableContent<HeardIfaceSet,
      HeardIfaceTupleSubject>(this, heardIfaceSet);
  else if (name == "MPR")
    return ::getMPRTableContent(this);
  else if (name == "Route")
    return ::getTableContent<RoutingTable,
      RoutingTupleSubject>(this, *currentRoutingTable);
#ifdef WITH_STAT
  else if (name == "Statistics")
    return ::getTableContent<StatisticSet,
      StatisticTupleSubject>(this, *statisticSet);
#endif //WITH_STAT
  else return NULL;
}

//---------------------------------------------------------------------------
