//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "ou_general_part.h"

#include "security.h"
#include "packet.h"

//---------------------------------------------------------------------------

#ifdef WITH_BLS
#error Error WITH_HMAC and WITH_BLS are mutually exclusive options.
#endif //WITH_BLS

//---------------------------------------------------------------------------

#define AUTH_METHOD_NONE 0x0
#define AUTH_METHOD_BLS  0x1
#define AUTH_METHOD_HMAC 0x2

//---------------------------------------------------------------------------

const int AUTHENTICATED_HELLO_MESSAGE = 0xcc;
const int AUTHENTICATED_TC_MESSAGE    = 0xcd;
const int AUTHENTICATED_MID_MESSAGE   = 0xce;
const int AUTHENTICATED_HNA_MESSAGE   = 0xcf;

const int TIME_PROTOCOL_MESSAGE = 0xd0;
const int AUTHENTICATED_TIME_PROTOCOL_MESSAGE = 0xd1;

//---------------------------------------------------------------------------

#ifndef WITH_PYTHON_TIME_PROTOCOL
#include "time_protocol.cc"
#endif

//---------------------------------------------------------------------------

class IAuthenticationManager
{
public:
  virtual int getAuthDataSize() = 0;
  virtual int getAuthMethod() = 0;
  virtual string getAuthData(Address originatorAddress, string& data) = 0;
  virtual bool checkAuthData(Address originatorAddress, string& data,
			     string& authData) = 0;
  virtual ~IAuthenticationManager() {}
};

//---------------------------------------------------------------------------

#define HMAC_MD5_SIZE 16 /*bytes*/
#define TIMESTAMP_SIZE 4 /*bytes*/

string getKey(string aKey, unsigned int xorValue)
{
  if (aKey.size() < HMAC_MD5_SIZE) {
    for (int i = aKey.size(); i< HMAC_MD5_SIZE; i++)
      aKey += (char)0;
  } else if (aKey.size() > HMAC_MD5_SIZE) {
    aKey = getMD5(aKey);
  }
  string result(aKey.data(), aKey.size());
  //unsigned char* data = (unsigned char*)result.data();
  for (unsigned int i=0; i< result.size(); i++)
    result[i] = (char)(((unsigned char)result[i]) ^ xorValue);
  return result;
}

string getHMAC(string data, string hmacKey)
{
  string key1 = getKey(hmacKey, 0x36);
  string key2 = getKey(hmacKey, 0x5C);
  string result = getMD5(key2 + getMD5(key1 + data));
  return result;
}

class HmacMd5AuthenticationManager : public IAuthenticationManager
{
public:
  HmacMd5AuthenticationManager(Node* node, string aHmacKey) 
  { hmacKey = aHmacKey; }

  virtual int getAuthDataSize()
  { return HMAC_MD5_SIZE; }
  
  virtual int getAuthMethod()
  { return AUTH_METHOD_HMAC; }

  virtual string getAuthData(Address originatorAddress, string& data)
  { return getHMAC(hmacKey, data); }

  virtual bool checkAuthData(Address originatorAddress, string& data,
			      string& authData)
  {
    string tmpAuthData = getAuthData(originatorAddress, data);
    return authData == tmpAuthData;
  }

  virtual ~HmacMd5AuthenticationManager() {}

protected:
  string hmacKey;
};


class NullAuthenticationManager : public IAuthenticationManager
{
public:
  NullAuthenticationManager(Node* node, string unused) 
  { }

  virtual int getAuthDataSize()
  { return 0; }
  
  virtual int getAuthMethod()
  { return AUTH_METHOD_NONE; }

  virtual string getAuthData(Address originatorAddress, string& data)
  { return ""; }

  virtual bool checkAuthData(Address originatorAddress, string& data,
			      string& authData)
  { return true; }

  virtual ~NullAuthenticationManager() {}

protected:
};


//---------------------------------------------------------------------------

#ifdef WITH_BLS

#include "libec.h"

typedef EllipticCurve< FieldP<stdP> > Curve;
typedef Curve::F Field;
typedef Curve::Point Point;
typedef FieldP<stdP>::Elem Elem;

std::ostream& operator << (std::ostream& out, Point& point)
{ 
  out << "<" << point.x << "," << point.y << ">" ;
  return out;
}

#if 0
    signatureManager = NULL;
    ProtocolConfig* config = node->getProtocolConfig();
    if (config->ecParamFileName.size() > 0
	&& config->ecRequestFileName.size() > 0) {
      signatureManager = new SignatureManager<stdP>(config->ecParamFileName,
						    config->ecRequestFileName);
      signatureManager->updateSignatureList();
    }
#endif // WITH_BLS


#if 0
  SignatureManager<stdP>* signatureManager;
#endif // WITH_BLS


class BLSAuthenticationManager : public IAuthenticationManager
{
public:

  BLSAuthenticationManager(Node* node) 
  { hmacKey = node->getProtocolConfig()->hmacKey; }

  virtual int getAuthDataSize()
  { return BLS_SIZE; }
  
  virtual int getAuthMethod()
  { return AUTH_METHOD_BLS; }

  virtual string getAuthData(Address originatorAddress, string& data)

  virtual bool checkAuthData(Address originatorAddress, string& data,
			      string& authData)
  {
    string tmpAuthData = getAuthData(originatorAddress, data);
    return authData == tmpAuthData;
  }

  virtual ~HmacMd5AuthenticationManager() {}

  };

#endif // WITH_BLS

//---------------------------------------------------------------------------

void zeroHopField(string& initialData, int addressSize)
{
  assert( (int)initialData.size() > OLSR_OFFSET_TIME_TO_LIVE(addressSize) );
  assert( (int)initialData.size() > OLSR_OFFSET_HOP_COUNT(addressSize) );
  //MemoryBlock data((octet*)initialData.data(), initialData.size(), true);
  //PUT_U8_AT(data.data, OLSR_OFFSET_TIME_TO_LIVE(addressSize)+offset, 0);
  //PUT_U8_AT(data.data, OLSR_OFFSET_HOP_COUNT(addressSize)+offset, 0);
  initialData[OLSR_OFFSET_TIME_TO_LIVE(addressSize)] = 0;
  initialData[OLSR_OFFSET_HOP_COUNT(addressSize)] = 0;
  //return string((char*)data.data, data.size);
}

//---------------------------------------------------------------------------

const int MAX_MESSAGE = NO_MESSAGE; // == 0x100

class RecursiveMessageRewriter : public IMessageRewriter
{
public:

  std::map<int, IAuthenticationManager*> authManagerMap;
  Node* node;
  RecursiveMessageHandler* recursiveHandlerTable[MAX_MESSAGE];
  IMessageHandler* stdHandlerTable[MAX_MESSAGE];

  RecursiveMessageRewriter()
  {
    //authenticationManager = NULL;
    node = NULL;
    for (int i=0; i<MAX_MESSAGE;i++)
      recursiveHandlerTable[i] = NULL;
  }

  virtual ~RecursiveMessageRewriter() {}

  void install(Node* aNode)  {
    node = aNode;
    for (ITER(std::list<AuthenticationMethod>, it,
	      node->getProtocolConfig()->authMethodList)) {
      IAuthenticationManager* authenticationManager  = NULL;
      if ((*it).name == "hmac-md5") {
	authenticationManager
	  = new HmacMd5AuthenticationManager(node, (*it).parameter);
      } else if ((*it).name == "none") {
	authenticationManager 
	  = new NullAuthenticationManager(node, (*it).parameter);
      } else {
	Fatal("Unknown authentication method '" << (*it).name << "");
      }
      authManagerMap[(*it).authInfo] = authenticationManager;
    }

    addRecursiveHandler(HELLO_MESSAGE, 
	  (MessageType)AUTHENTICATED_HELLO_MESSAGE, false, true, true);
    addRecursiveHandler(TC_MESSAGE,
	  (MessageType)AUTHENTICATED_TC_MESSAGE, true, true, false);
    addRecursiveHandler(MID_MESSAGE,
	  (MessageType)AUTHENTICATED_MID_MESSAGE, true, true, false);
    addRecursiveHandler(HNA_MESSAGE,
	  (MessageType)AUTHENTICATED_HNA_MESSAGE, true, true, false);
    addRecursiveHandler((MessageType)TIME_PROTOCOL_MESSAGE,
	  (MessageType)AUTHENTICATED_TIME_PROTOCOL_MESSAGE, 
			true, false, false);
    node->getPacketManager()->messageRewriter = this;
  }

  void addRecursiveHandler(MessageType initialMessageType,
			   MessageType newMessageType,
			   bool shouldForward, bool shouldHaveTimestamp,
			   bool shouldHaveAddress)
  {
    PacketManager* packetManager = node->getPacketManager();
    IMessageHandler* previousHandler 
      = packetManager->getMessageHandler(initialMessageType);
    RecursiveMessageHandler* newHandler =
      new RecursiveMessageHandler(node, previousHandler, shouldForward, 
				  shouldHaveTimestamp, shouldHaveAddress,
				  initialMessageType, newMessageType, this);
    recursiveHandlerTable[(int)initialMessageType] = newHandler;
    packetManager->addMessageHandler((int)newMessageType, newHandler);

    stdHandlerTable[(int)initialMessageType] 
      = packetManager->getMessageHandler((int)initialMessageType);
    packetManager->addMessageHandler((int)initialMessageType, NULL);
  }

  virtual Message* rewrite(Message* message)
  {
    // XXX: should be methods of the RecursiveMessageHandler
    //assert ( inrange(0, (int)message->messageType, (int)MAX_MESSAGE) );
    RecursiveMessageHandler* recursiveHandler
      = recursiveHandlerTable[message->messageType];
    if (recursiveHandler == NULL) {
      Warn("Security: cannot rewrite message type " << message->messageType);
      return message;
    }
    assert( recursiveHandler != NULL );
    return makeRecursiveMessage(recursiveHandler, message);
  }

  Message* makeRecursiveMessage(RecursiveMessageHandler* handler, 
				Message* message)
  {
    MessageType messageType = handler->recursiveMessageType;
    Message* result = message->clone(false);
    result->messageType = messageType;
    result->origin = GeneratedMessage;
    RecursiveMessage* resultContent = new RecursiveMessage(message);
    resultContent->withAddress = handler->shouldHaveAddress;
    resultContent->withTimestamp = handler->shouldHaveTimestamp;
    resultContent->authOk = true;
    resultContent->messageType = message->messageType;
    result->content = resultContent;
    result->content->header = result;

    std::map<int, IAuthenticationManager*>::iterator 
      it = authManagerMap.find(0 /* XXX: message level*/);
    if (it != authManagerMap.end()) {
      IAuthenticationManager* authManager = (*it).second;
      string fillingData(getAuthInfoContentSize(authManager,resultContent), 
			 '\0');
      resultContent->authInfo = fillingData;
    }
    return result;
  }

  int getAuthInfoContentSize(IAuthenticationManager* authenticationManager,
			     RecursiveMessage* m)
  {
    int result = authenticationManager->getAuthDataSize();
    if (m->withTimestamp)
      result += TIMESTAMP_SIZE;
    if (m->withAddress) 
      result += node->getAddressFactory()->getAddressSize();
    return result;
  }

  bool checkTimeOffset(Time currentTime, Address otherAddress, 
		       Time otherTime, Time toleratedMargin)
  { 
#ifdef WITH_SECURITY
    SecurityNode* securityNode = dynamic_cast<SecurityNode*>(node);
    if (securityNode != NULL) {
      string rawAddressStr = otherAddress.getRawStr();
      return securityNode->checkTimeOffsetWithOther(currentTime, rawAddressStr,
						    otherTime,toleratedMargin);
    }
#endif
    //Time currentTime = node->getCurrentTime();
    return (currentTime - toleratedMargin <= otherTime 
	    && otherTime <= currentTime + toleratedMargin);
  }
};

//---------------------------------------------------------------------------

void RecursiveMessage::write(ostream& out) const
{
  out << "[Secure: type=" << messageType
      << (withAddress ? " with-iface-address" : " no-address")
      << (withTimestamp ? " with-timestamp" : " no-timestamp")
      << (authOk ? " auth-ok" : " auth-error")
      << " auth=(" << reprStr(authInfo) << ") ";
  out << *content;
  out << "]";
}

//---------------------------------------------------------------------------
  
RecursiveMessageHandler::RecursiveMessageHandler
(Node* aNode,
 IMessageHandler* aHandler,
 bool aShouldForward,
 bool aShouldHaveTimestamp,
 bool aShouldHaveAddress,
 MessageType aBaseMessageType,
 MessageType aRecursiveMessageType,
 RecursiveMessageRewriter* aRewriter)
{ 
  node = aNode;
  handler = aHandler;
  packetManager = node->getPacketManager();
  shouldForward = aShouldForward;
  shouldHaveTimestamp = aShouldHaveTimestamp;
  shouldHaveAddress = aShouldHaveAddress;
  rewriter = aRewriter;
  baseMessageType = aBaseMessageType;
  recursiveMessageType = aRecursiveMessageType;
}

void RecursiveMessageHandler::processMessage(/*borrowed*/ Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  RecursiveMessage* m = dynamic_cast<RecursiveMessage*>(messageContent);
  //IMessageHandler* myHandler 
  //= packetManager->getMessageHandler(m->messageType);
  if (m->authOk) message->checkStatus = MessageCheckedOk;
  else message->checkStatus = MessageCheckedBad;
  IMessageHandler* myHandler  = rewriter->stdHandlerTable[m->messageType];
  D(*node->log, lMessage, node->getRealTime()
    << " [process-message] " << node->getMainAddress() << " auth="
    << (m->authOk) << " handler=" << (myHandler != NULL) <<" "<< (*m) << endl);
  if (m->authOk && myHandler != NULL)
    myHandler->processMessage(m->content);
  delete messageContent;
}

void RecursiveMessageHandler::considerForwardMessage(/*borrowed*/ 
						     Message* message,
						     string& info)
{
  if (shouldForward) {
    IMessageHandler* myHandler = rewriter->stdHandlerTable[baseMessageType];
    assert( myHandler != NULL );

    if (message->checkStatus == MessageUnchecked) {
      // XXX: factor out
      IMessageContent* messageContent = parseMessageContent(message);
      RecursiveMessage* m = dynamic_cast<RecursiveMessage*>(messageContent);
      if (m->authOk) message->checkStatus = MessageCheckedOk;
      else message->checkStatus = MessageCheckedBad;
      delete messageContent;
    }
    if (message->checkStatus == MessageCheckedBad)
      return;
    assert( message->checkStatus == MessageCheckedOk );

    if (myHandler->shouldPureFlood())
      packetManager->ensureRetransmitMessage(message, info);
    else packetManager->defaultForwardingMessage(message, info);
  }
}

void RecursiveMessageHandler::packMessageContent
(IMessageContent* message,
 int maximumMessageSize,
 MemoryBlock*& packedResult,
 IMessageContent*& messageRemainingResult,
 PackingInfo& packingInfo)
{
  RecursiveMessage* m = dynamic_cast<RecursiveMessage*>(message);
  //IMessageHandler* myHandler 
  //= packetManager->getMessageHandler(m->messageType);
  IMessageHandler* myHandler  = rewriter->stdHandlerTable[m->messageType];
  MemoryBlock* intermediaryBlock = NULL;
  IMessageContent* intermediaryRemaining;
  myHandler->packMessageContent(m->content->content,
				maximumMessageSize - getOverhead(m->authInfo),
				intermediaryBlock, intermediaryRemaining,
				packingInfo);
  if (intermediaryBlock != NULL) {
    int addressSize = node->getAddressFactory()->getAddressSize();
    int messageHeaderSize = MessageHeaderWithoutAddressSize + addressSize;

    // Remove packed message header
    MemoryBlock* tmpBlock = intermediaryBlock;
    assert( intermediaryBlock->size >= messageHeaderSize );
    intermediaryBlock = new MemoryBlock
      (intermediaryBlock->data + messageHeaderSize,
       intermediaryBlock->size - messageHeaderSize, true);
    delete tmpBlock;

    // Pack our message header
    PacketBuffer buffer;
    PacketManager::PositionInfo info
      = packetManager->packMessageHeader(buffer, m->header);
    
    // Set the message size and get the message header as string
    assert( buffer.getPosition() == messageHeaderSize );
    buffer.setPosition(OLSR_OFFSET_MESSAGE_SIZE(addressSize));
    int estimatedMessageSize = messageHeaderSize 
      + SecureSubHeaderSize + intermediaryBlock->size 
      + SecureSubHeaderSize + m->authInfo.size();
    buffer.pushUInt16(estimatedMessageSize);
    buffer.setPosition(0);
    string rawHeader = buffer.popAllString();
    
    // Pack message sub-header and message content
    assert( m->content->messageType == m->messageType );
    buffer.pushUInt16(intermediaryBlock->size + SecureSubHeaderSize);
    buffer.pushUInt8(SecureHeaderTypeMessage);
    buffer.pushUInt8((int)m->messageType);

    buffer.packBlock(intermediaryBlock);
    delete intermediaryBlock;
    intermediaryBlock = NULL;

    // Pack security information
    buffer.pushUInt16(m->authInfo.size() + SecureSubHeaderSize);
    buffer.pushUInt8(SecureHeaderTypeAuthInfo);
    //buffer.pushUInt8(m->message->level); // XXX!!: another field
    unsigned int methodAndFlags = AUTH_METHOD_NONE;
    IAuthenticationManager* authenticationManager = NULL;
    if (rewriter->authManagerMap.find(0 /*m->content->level*/)
	!= rewriter->authManagerMap.end())
      authenticationManager 
	= (*(rewriter->authManagerMap.find(0 /*m->content->level*/))).second;
    if (authenticationManager != NULL)
      methodAndFlags = authenticationManager->getAuthMethod();
    if (m->withAddress)
      methodAndFlags |= SecureFlagWithAddress;
    if (m->withTimestamp)
      methodAndFlags |= SecureFlagWithTimestamp;
    buffer.pushUInt8(methodAndFlags);
    
    if (m->withTimestamp)
      buffer.pushUInt32((int)node->getCurrentTime());
    
    if (m->withAddress) {
      assert( packingInfo.iface != NULL );
      Address ifaceAddress = packingInfo.iface->getSystemIface()->getAddress();
      buffer.packAddress(ifaceAddress);
    }
    
    buffer.rewind();
    string rawFullMessage = buffer.popAllString();  
    //string rawFullMessage = rawHeader + rawMessage + rawTimestamp+rawAddress;
    zeroHopField(rawFullMessage, addressSize);
    
    if (authenticationManager != NULL)
      m->authInfo = authenticationManager->getAuthData
	(m->header->originatorAddress, rawFullMessage);
    
    buffer.packData(const_cast<char*>(m->authInfo.data()), m->authInfo.size());
    
    D(*node->log, lSecurity, node->getRealTime() << " [security] "
      << node->getMainAddress() << " M[" << m->header->originatorAddress << ":"
      << m->header->messageSequenceNumber << "] added-auth-info "
      //<< "message=(" << reprStr(rawHeader) << "/" << reprStr(rawMessage)
      //<< "/" << reprStr(rawTimestamp) << "/" << reprStr(rawAddress)
      << " full-message=(" << reprStr(rawFullMessage) // XXX: remove
      << ") auth-info=(" << reprStr(m->authInfo)
      //<< ")" 
      //<< " securityInfo=(" << reprStr(securityInfo) // XXX: remove
      << ")" 
      //<< " md5=" << getMD5(rawFullMessage) // XXX! remove
      << endl); 
    
    node->getPacketManager()->adjustPackedMessageSize
      (buffer, info); // (should be useless if everything is counted right)
    buffer.rewind();
    packedResult = buffer.getContent();
    assert( packedResult->size == estimatedMessageSize );
  }
  if (intermediaryRemaining != NULL) {
    Warn("XXX: message splitting unimplemented");
    //messageRemainingResult = new RecursiveMessage(intermediaryRemaining);
    //messageRemainingResult->data = m->data;
    delete intermediaryRemaining;
  }
  messageRemainingResult = NULL;
}


bool RecursiveMessageHandler::shouldPureFlood()
{
  if (rewriter->stdHandlerTable[baseMessageType] == NULL) return false;
  else return rewriter->stdHandlerTable[baseMessageType]->shouldPureFlood();
}


int RecursiveMessageHandler::getOverhead(string data)
{
  //int addressSize = node->getAddressFactory()->getAddressSize();
  int recursiveHeaderSize = 
    //No longer:MessageHeaderWithoutAddressSize + addressSize // message header
    + PacketBuffer::sizeUInt16()/*size*/ 
    + PacketBuffer::sizeUInt8() /*type=message content*/
    + PacketBuffer::sizeUInt8() /*message type*/
    
    + PacketBuffer::sizeUInt16()/*size*/ 
    + PacketBuffer::sizeUInt8() /*type=auth*/
    + PacketBuffer::sizeUInt8() /*auth method and flags*/
    + data.size(); // XXX: use some getAuthSize
  return recursiveHeaderSize;
}

void RecursiveMessageHandler::adjustMessageSize(IMessageContent* message)
{
  RecursiveMessage* m = dynamic_cast<RecursiveMessage*>(message);
  //IMessageHandler* handler = getMessageHandler(m); XXX:remove
  assert(m->content->messageType == m->messageType);
  //IMessageHandler* myHandler 
  //= packetManager->getMessageHandler(m->messageType);
  IMessageHandler* myHandler  = rewriter->stdHandlerTable[m->messageType];
  assert( myHandler != NULL );
  myHandler->adjustMessageSize(m->content->content);
  
  int overheadSize = getOverhead(m->authInfo);
  m->header->messageSize = m->content->messageSize + overheadSize;
  m->header->minMessageSize = m->content->minMessageSize + overheadSize;
}

// (XXX!: check leaks if not packet format is wrong)
IMessageContent* RecursiveMessageHandler::parseMessageContent
(/*borrowed*/ Message* message)
{
  int addressSize = node->getAddressFactory()->getAddressSize();
  D(*node->log, lSecurity, node->getRealTime() << " [security] " 
    << node->getMainAddress() << " M[" << message->originatorAddress << ":"
    << message->messageSequenceNumber << "] ");

  //--- Parse Message Content
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());
  unsigned short messageContentSize = buffer.popUInt16();
  unsigned char  reserved1          = buffer.popUInt8();
  unsigned char  messageType        = buffer.popUInt8();
  UNUSED(reserved1);
  messageContentSize -= SecureSubHeaderSize;

  Message* insideMessage = new Message;
  *insideMessage = *message;
  insideMessage->messageType = (MessageType)messageType;
  insideMessage->packedContent = buffer.popBlock(messageContentSize);
  insideMessage->packedHeader = NULL;
  insideMessage->content = NULL;

  RecursiveMessage* result = new RecursiveMessage(insideMessage);
  result->messageType = (MessageType)messageType;
  result->header = message->clone(false); // <-from TC/ XXX: which one is good?
  //message->setContent(result);          // <-from NodeAP
  
  //--- Parse Security Info.
  unsigned short securityInfoSize = buffer.popUInt16();
  unsigned char  reserved2        = buffer.popUInt8();
  //unsigned char  theLevel = buffer.popUInt8(); // XXX!!: fix this: elsewhere
  unsigned char  methodAndFlags   = buffer.popUInt8();
  //insideMessage->level = theLevel;
  UNUSED(reserved2);
  securityInfoSize -= SecureSubHeaderSize;
  MemoryBlock* securityInfoBlock = buffer.popBlock(securityInfoSize);
  string allSecurityInfo((char*)securityInfoBlock->data, 
			 securityInfoBlock->size);
  delete securityInfoBlock;

  //--- Update method and flags
  result->withAddress = ((methodAndFlags & SecureFlagWithAddress) != 0);
  result->withTimestamp = ((methodAndFlags & SecureFlagWithTimestamp) != 0);
  unsigned char method = methodAndFlags & SecureMethodMask;
  
  //--- Now perform checks

  // No authentication manager: no check
  IAuthenticationManager* authenticationManager = NULL;
  std::map<int, IAuthenticationManager*>::iterator 
    it = rewriter->authManagerMap.find(0 /*message->level*/);
  if (it != rewriter->authManagerMap.end())
    authenticationManager = (*it).second;
  
  if (authenticationManager == NULL) {
    D(*node->log, lSecurity, "auth-error=auth-not-set"
      //<< " (level=" << message->level << ")"
      << endl);
    result->authOk = true;
    return result;
  }

  // Check that the authentication method is supported
  if (method != authenticationManager->getAuthMethod()) {
    D(*node->log, lSecurity, "auth-error=bad-method "  << endl);
    result->authOk = false;
    return result;
  }

  // Check that the authentication field has proper size
  int optAddressSize = result->withAddress ? addressSize : 0;
  int optTimestampSize = result->withTimestamp ? TIMESTAMP_SIZE : 0;
  int securityInfoSizeCheck = optTimestampSize + optAddressSize
    + authenticationManager->getAuthDataSize();
  if (securityInfoSizeCheck != securityInfoSize) {
    D(*node->log, lSecurity, "auth-error=bad-security-size "
      << securityInfoSizeCheck
      << " (expected " << securityInfoSizeCheck << ") "  << endl);
    result->authOk = false;
    return result;
  }

  // Parse the security info fields
  assert(securityInfoSize == allSecurityInfo.size());
  char securityInfo[securityInfoSize];
  memcpy((void*)&securityInfo, allSecurityInfo.data(), securityInfoSize);

  // - authentication info
  int authInfoSize = authenticationManager->getAuthDataSize();
  string authInfoData(securityInfo + optTimestampSize + optAddressSize,
		      authInfoSize);

  // - timestamp
  unsigned int timeStamp = (result->withTimestamp
			    ? GET_U32(securityInfo + 0) : 0);

  // - address
  Address authSendIfaceAddress;
  if (result->withAddress) {
    authSendIfaceAddress = node->getAddressFactory()->peekAddress
      (securityInfo + optTimestampSize);
  }

  // - content + auxiliary authentication info
  assert(message->packedHeader != NULL);
  string rawHeader = string((char*)message->packedHeader->data,
			    message->packedHeader->size);
  int position = buffer.getPosition();
  buffer.rewind();
  string rawFullMessage = rawHeader 
    + buffer.popString(position - authInfoSize);

  // Check that the proper optional fields are present
  if (shouldHaveAddress && !result->withAddress) {
    D(*node->log, lSecurity, "auth-error=no-address"  << endl);
    result->authOk = false;
    return result;
  }
  if (shouldHaveTimestamp && node->getProtocolConfig()->checkTimeStamp
      && !result->withTimestamp) {
    D(*node->log, lSecurity, "auth-error=no-timestamp" << endl);
    result->authOk = false;
    return result;
  }

  // Perform checking of the source address
  if (shouldHaveAddress 
      && !(authSendIfaceAddress == message->sendIfaceAddress)) {
    D(*node->log, lSecurity, "auth-error=bad-iface-address "
      << " auth-iface-address=" << authSendIfaceAddress
      << " detected-iface-address=" << message->sendIfaceAddress
      << endl);
    result->authOk = false;
    return result;
  }

  // Perform checking of the timestamp
  if (shouldHaveTimestamp && node->getProtocolConfig()->checkTimeStamp) {
    //Time timeOffset = getTimeOffset(message->originatorAddress);
    Time tolerance = node->getProtocolConfig()->timestampTolerance;
    Time currentTime = node->getCurrentTime();

    //Time adjustedTimeStamp = timeStamp - timeOffset;
    //bool badTime = (adjustedTimeStamp < currentTime-tolerance 
    //|| adjustedTimeStamp > currentTime+tolerance) {
    if (!rewriter->checkTimeOffset(currentTime, 
				   message->originatorAddress, 
				   timeStamp, tolerance)) {
      D(*node->log, lSecurity, "auth-error=timestamp-range"
	<< " timestamp=" << timeStamp //<< " offset=" << timeOffset
	<< " diff=" << (timeStamp - currentTime) << endl);
      result->authOk = false;
      return result;
    }
  }

  // Perform checking of the authentication info (signature)
  assert( (int)rawFullMessage.size() >= OLSR_MESSAGE_HEADER_SIZE(addressSize));
  zeroHopField(rawFullMessage, addressSize);

  bool ok = authenticationManager->checkAuthData
    (message->originatorAddress, rawFullMessage, authInfoData);
  if (!ok) {
    D(*node->log, lSecurity, "auth-error=auth-info-check-failed"
      << " message=(" << reprStr(rawFullMessage)
      << ") auth-info=(" << reprStr(authInfoData) << ")" 
      //<< " md5=" << getMD5(rawFullMessage) // XXX! remove
      << endl);
    result->authOk = false;
    return result;
  }
  
  // All test passed: success
  result->authOk = true;
  D(*node->log, lSecurity, "auth-ok" << endl);
  
  return result;
}

//---------------------------------------------------------------------------

string RecursiveMessageHandler::getAuthInfoContent
(IAuthenticationManager* authenticationManager,
 RecursiveMessage* m, string& rawHeader,
 MemoryBlock* intermediaryBlock, PackingInfo& packingInfo)
{ 
  //IAuthenticationManager* authenticationManager = 
  //(IAuthenticationManager*) authManager;
  if (authenticationManager == NULL)
    return m->authInfo;

  int addressSize = node->getAddressFactory()->getAddressSize();

  // the message
  string rawMessage((char*)intermediaryBlock->data, intermediaryBlock->size);

  // the timestamp
  string rawTimestamp = "";
  if (m->withTimestamp) {
    ou_u32 netTimestamp;
    PUT_U32_AT(&netTimestamp, 
	       0, (int)(node->getCurrentTime()
			+ node->getProtocolConfig()->clockOffset));
    rawTimestamp = string((char*)&netTimestamp, SIZE_U32);
  }

  // the address
  string rawAddress = "";
  if (m->withAddress) {
    assert( packingInfo.iface != NULL );
    Address ifaceAddress = packingInfo.iface->getSystemIface()->getAddress();
    rawAddress = string((char*)ifaceAddress.getRawAddress(), addressSize);
  }
  
  string rawFullMessage = rawHeader + rawMessage + rawTimestamp + rawAddress;
  zeroHopField(rawFullMessage, addressSize);

  string authInfo = authenticationManager->getAuthData
    (m->header->originatorAddress, rawFullMessage);
  string securityInfo = "";
  if (m->withTimestamp)
    securityInfo += rawTimestamp;
  if (m->withAddress)
    securityInfo += rawAddress;
  securityInfo += authInfo;

  D(*node->log, lSecurity, node->getRealTime() << " [security] "
    << node->getMainAddress() << " M[" << m->header->originatorAddress << ":"
    << m->header->messageSequenceNumber << "] added-auth-info "
    << "message=(" << reprStr(rawHeader) << "/" << reprStr(rawMessage)
    << "/" << reprStr(rawTimestamp) << "/" << reprStr(rawAddress)
    << ") auth-info=(" << reprStr(authInfo) << ")" 
    << " rawFullMessage=(" << reprStr(rawFullMessage) // XXX: remove
    << " securityInfo=(" << reprStr(securityInfo) // XXX: remove
    << ")" << endl); 

  return securityInfo;
}

//---------------------------------------------------------------------------

void installRecursiveMessageRewriter(Node* node)
{
  if (node->getProtocolConfig()->useAuthentication) {
    RecursiveMessageRewriter* rewriter= new RecursiveMessageRewriter;
    rewriter->install(node);
  }
}

//---------------------------------------------------------------------------

class TimeExchangeMessageHandler : public ExternalMessageHandler
{
public:
  TimeExchangeMessageHandler(SecurityNode* aNode)
    : ExternalMessageHandler(aNode, TIME_PROTOCOL_MESSAGE, true),
  securityNode(aNode) { }

  void processExternalInfo(/*owned*/ MemoryBlock* block)
  { securityNode->processExternalInfo(block); }

protected:
  SecurityNode* securityNode;
};

//---------------------------------------------------------------------------

class PacketInfoMessageHandler : public ByteMessageHandler
{
public:
  PacketInfoMessageHandler(SecurityNode* aNode)
    : ByteMessageHandler(aNode, PACKET_INFO_MESSAGE), securityNode(aNode)
  { }

  virtual void actuallyProcessMessage(/*borrowed*/ Message* message,
				      /*borrowed*/ MemoryBlock* packedHeader,
				      /*borrowed*/ MemoryBlock* block);
  
  SecurityNode* securityNode;
};

//--------------------------------------------------

//#ifdef WITH_CXX_TIME_PROTOCOL
//#include "time_protocol.cc"
//#endif

void SecurityNode::startSecurity()
{
#ifndef WITH_PYTHON_TIME_PROTOCOL
  assert( timeProtocol == NULL );
  if (protocolConfig->useTimeProtocol) {
    timeProtocol = new TimeOffsetExchangeProtocol(this);
    packetManager->addMessageHandler(TIME_PROTOCOL_MESSAGE, timeProtocol);
    timeProtocol->start();
    Time delay = _startDelay(0,
			     protocolConfig->timeProtocolGenerationInterval);
    addGenerationEvent(getCurrentTime() + delay, getCurrentTime()+delay,
		       &Node::eventTimeProtocolGeneration, 
		       "time-protocol-generation");
  }
#else // !WITH_PYTHON_TIME_PROTOCOL
  timeExchangeHandler = NULL;
  ExternalChannelConfig* channel 
    = protocolConfig->getChannelByName("security-time-exchange");
  if (channel == NULL) {
    Warn("No security-time-exchange external-channel found in configuration");
    return;
  }
  
  if (externalCommunication == NULL) {
    Warn("No external communication manager, security-time-exchange"
	 " external-channel " "is not open");
    return;
  }

  timeExchangeHandler = new TimeExchangeMessageHandler(this);
  packetManager->addMessageHandler(TIME_PROTOCOL_MESSAGE,
				   timeExchangeHandler);
  IExternalMessageReceiver* extChannelOut =
    externalCommunication->open(channel->channelIn, channel->channelOut,
				timeExchangeHandler);
  timeExchangeHandler->setExternalMessageReceiver(extChannelOut);
#endif // WITH_PYTHON_TIME_PROTOCOL

  if (protocolConfig->usePacketTimestamp)
    packetManager->addMessageHandler(PACKET_INFO_MESSAGE, 
				     new PacketInfoMessageHandler(this));

  if (protocolConfig->authMethodList.size() > 0 
      /*&& protocolConfig->authMethod != "none"*/) {
    installRecursiveMessageRewriter(this);
  }
}

#ifdef WITH_PYTHON_TIME_PROTOCOL
void SecurityNode::processExternalInfo(/*owned*/ MemoryBlock* block)
{ 
  int addressSize = addressFactory->getAddressSize();
  int expectedSize = addressSize + 2*SIZE_U32;
  if (block->size == expectedSize) {
    Address receiverAddress(addressFactory, block->data);
    unsigned int * uPtr=(unsigned int*)(block->data + addressSize);
    signed int * ptr=(signed int*)(block->data + addressSize);
    double timeOffset // time is in fixed point
      = ptr[0] + ((double)uPtr[1])/((double)(1<<16))/((double)(1<<16));
    Time expireTime = getCurrentTime() + protocolConfig->timeProtocolHoldTime;
    D(*log, lTimeProtocol, getRealTime()
      << " [time-exchange] " << getMainAddress() << " set-offset "
      << receiverAddress << " " << timeOffset << endl);
    string rawAddress = receiverAddress.getRawStr();
    timeOffsetTable.set(expireTime, rawAddress, timeOffset);
  } else {
    Warn("Bad security-time-exchange external message, size = "
	 << block->size << " (expected: " << expectedSize << ")");
  }
  delete block;
}
#else
void SecurityNode::processExternalInfo(/*owned*/ MemoryBlock* block)
{ delete block; }
#endif // WITH_PYTHON_TIME_PROTOCOL

#ifndef WITH_PYTHON_TIME_PROTOCOL
bool SecurityNode::checkTimeOffsetWithOther(Time currentTime, 
					    string& rawAddress, Time otherTime,
					    Time toleratedMargin)
{
  // XXX! dangerous, don't return 0
  if (timeProtocol == NULL) {
    return (currentTime - toleratedMargin <= otherTime 
	    && otherTime <= currentTime + toleratedMargin);
  } else return timeProtocol->checkTimeOffsetWithOther
	   (currentTime, rawAddress, otherTime, toleratedMargin);
}
#endif // WITH_PYTHON_TIME_PROTOCOL

void SecurityNode::logState(ostream& out, bool noEnd)
{
  ParentSecurityNode::logState(out, true);
  //typedef ExpiringMap<Address, Time> ExpMapType;
  //typedef std::map<Address, ExpMapType::TimeAndValue> ExpMap;  
  //ExpMap& content = timeOffsetTable.getContent();

#ifdef WITH_PYTHON_TIME_PROTOCOL
  out << getRealTime() << " [table-time-offset] " << getMainAddress()
      << ": ";
  
  
  typedef ExpiringMap<string,Time>::ExpireKeyValue ExpireKeyValue;
  typedef std::list< ExpireKeyValue > TimeOffsetInfoList;
  
  Time currentTime = getCurrentTime();    
  bool isFirst = true;
  //std::list< pair<string,Time> > contentList;
  TimeOffsetInfoList contentList;
  timeOffsetTable.getContent(contentList);
  for (ITER(TimeOffsetInfoList, it, contentList)) {
    string addressStr = (*it).key;
    Time offsetTime = (*it).value;
    Time expireTime = (*it).expireTime;
    Address address(addressFactory, (void*)addressStr.data());
    if (!isFirst) out << ",";
    else isFirst = false;
    out << address << ":" << offsetTime << " ";
    writeExpireTime(out, currentTime, expireTime);
  }
  
  out << endl;

#else

  if (timeProtocol != NULL) {
    out << getRealTime() << " [time-protocol-state] " << getMainAddress() 
	<< " ";
    timeProtocol->write(out);
  }

#endif

  if (!noEnd) {
    out << getRealTime() << " [state-end] " << getMainAddress() << endl;
  }
}

//---------------------------------------------------------------------------

void SecurityNode::eventTimeProtocolGeneration()
{
#ifndef WITH_PYTHON_TIME_PROTOCOL
  if (timeProtocol != NULL) {
    double interval = protocolConfig->timeProtocolGenerationInterval;
    double minDelay = interval - protocolConfig->MAXJITTER;
    if(minDelay <0) minDelay = 0;
    addGenerationEvent(getCurrentTime() + minDelay,
		       getCurrentTime() + interval,
		       &Node::eventTimeProtocolGeneration,
		       "time-protocol-generation");

    timeProtocol->generateMessage();
  } else { Warn("timeProtocol == NULL"); }
#endif  
}

//---------------------------------------------------------------------------
// Packet timestamp as a message
//---------------------------------------------------------------------------

#define PACKET_INFO_SIZE (4+4)

const double power2_32 = ((double)(1<<16)) * ((double)(1<<16));

MemoryBlock* SecurityNode::updatePacketBeforeSend
(/*owned*/ MemoryBlock* packet)
{
#ifndef WITH_PYTHON_TIME_PROTOCOL
  if (!protocolConfig->usePacketTimestamp || timeProtocol == NULL)
    return packet;

  int addrSize = addressFactory->getAddressSize();
  int messageSize = 
    MessageHeaderWithoutAddressSize + addrSize + PACKET_INFO_SIZE ;

  MemoryBlock* result = new MemoryBlock(packet->size + messageSize);
  octet* data = result->data + PacketHeaderSize;

  PUT_U8_AT(data, OLSR_OFFSET_MESSAGE_TYPE(addrSize), PACKET_INFO_MESSAGE);
  PUT_U8_AT(data, OLSR_OFFSET_VTIME(addrSize), 0);
  PUT_U16_AT(data, OLSR_OFFSET_MESSAGE_SIZE(addrSize), messageSize);
  PUT_U8_AT(data, OLSR_OFFSET_TIME_TO_LIVE(addrSize), 1);
  PUT_U8_AT(data, OLSR_OFFSET_HOP_COUNT(addrSize), 0);
  unsigned int mssn = packetManager->allocateMessageSequenceNumber();
  PUT_U16_AT(data, OLSR_OFFSET_MESSAGE_SEQUENCE_NUMBER(addrSize), mssn);
  memcpy(data + OLSR_OFFSET_ORIGINATOR_ADDRESS(addrSize),
         getMainAddress().getRawAddress(), addrSize);

  Time myTime = timeProtocol->getAbsoluteNetTime();
  data += MessageHeaderWithoutAddressSize + addrSize;
  PUT_U32_AT(data, 0, (int)myTime);
  PUT_U32_AT(data, SIZE_U32, (int)((myTime-(int)myTime)*power2_32));

  memcpy(result->data, packet->data, PacketHeaderSize);
  memcpy(result->data + PacketHeaderSize + messageSize,
	 packet->data + PacketHeaderSize,
	 packet->size - PacketHeaderSize);
  PUT_U16_AT(result->data, 0, packet->size + messageSize);

  delete packet;
  return result;
#else
  return packet;
#endif
}


void PacketInfoMessageHandler::actuallyProcessMessage
(/*borrowed*/ Message* message,
 /*borrowed*/ MemoryBlock* packedHeader,
 /*borrowed*/ MemoryBlock* block)
{
  D(*securityNode->log, lSecurity, node->getRealTime()
    << " [security-packet] " << node->getMainAddress() << " ");

  if (block->size == PACKET_INFO_SIZE) {
    Time netTime =   GET_U32_AT(block->data, 0);
    netTime += GET_U32_AT(block->data, SIZE_U32) / power2_32;
    D(*securityNode->log, lSecurity, "net-time " << netTime << endl);
    node->getPacketManager()->setNetTime(netTime);
  } else {
    D(*securityNode->log, lSecurity, "bad-size " << block->size
      << " " << PACKET_INFO_SIZE << endl);
  }
} 

//--------------------------------------------------------------------------- 

void SecurityNode::getLevelList(vector<int>& result)
{
  std::map<int, bool> isIn;

  for (ITER(std::list<AuthenticationMethod>, it, 
	    protocolConfig->authMethodList)) {
    int level = (*it).authInfo;
    if (isIn.find(level) == isIn.end()) {
      result.push_back(level);
      isIn[level] = true;
    }
  }

  if (result.size() == 0) 
    result.push_back(0);
}

//---------------------------------------------------------------------------

vector<string>* SecurityNode::getTableNameList()
{
  vector<string>* result = ParentSecurityNode::getTableNameList();
  if (timeProtocol != NULL) {
    result->push_back("TimeProtocol");
  }
  return result;
}

vector<vector<string>*>* SecurityNode::getTableContent(string name)
{
  if (name == "TimeProtocol" && timeProtocol != NULL) {
    return timeProtocol->getTimeOffsetTableContent();
  } else return ParentSecurityNode::getTableContent(name);
}

//---------------------------------------------------------------------------

