//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// XXX: in state of limbo

#include "scheduler.h"
#include "network_generic.h"

//---------------------------------------------------------------------------

const int SimulationIfaceMTU = 1000;

//---------------------------------------------------------------------------

// XXX-: this should be templatized: IEventMethodCaller(...;
class SimulationIfaceReceiveEvent : public IEvent
{
public:

  SimulationIfaceReceiveEvent(SimulationIface* aIface, MemoryBlock* aPacket)
  { 
    iface = aIface; 
    packet = aPacket;
  }

  void handleEvent(void* data) 
  { iface->receivePacket(packet, iface->getAddress()); }

protected:
  SimulationIface* iface;
  MemoryBlock* packet;
};

//---------------------------------------------------------------------------

SimulationIface::SimulationIface(IScheduler* aScheduler,
				 IPacketReceiver* aReceiver,
				 Address aAddress)
{
  associatedIface = NULL;
  scheduler = aScheduler;
  receiver = aReceiver;
  address = aAddress;
}

void SimulationIface::sendPacket(MemoryBlock* packet)
{
  for(int i=0;destinationIfaceList.size();i++) {
    IEvent* event = new SimulationIfaceReceiveEvent(destinationIfaceList[i],
						    packet->clone());
    scheduler->addEvent(0.0 /* transmission delay */, event, NULL);
  }
  delete packet;
}

void SimulationIface::receivePacket(MemoryBlock* packet, 
				    Address sendIfaceAddress)
{ receiver->evReceivePacket(packet, sendIfaceAddress, associatedIface); }

int SimulationIface::getMTU()
{ return SimulationIfaceMTU; }

//---------------------------------------------------------------------------

