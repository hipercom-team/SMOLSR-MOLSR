//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             XXX YYY, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
