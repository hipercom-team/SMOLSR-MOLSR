//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "base.h"

#include "winsock2.h"

//#include <sys/timeb.h>
//#include <stdlib.h>

#include "general.h"
#include "log.h"

//---------------------------------------------------------------------------

double drawDouble(double maxValue)
{ 
  return maxValue*(rand()/((double)RAND_MAX)); // XXX: exclusive
}

#ifdef OLD
double getTimeOfDay()
{
  struct _timeb localTime;
  _ftime(&localTime);
  return localTime.time + localTime.timezone + localTime.millitm / 1000.0;
}
#endif

double systemTimeToDouble(SYSTEMTIME& systemTime)
{
  FILETIME fileTime; // in "number of 100-nanosecond intervals"
  SystemTimeToFileTime(&systemTime, & fileTime);
  ULARGE_INTEGER longTime;
  longTime.LowPart = fileTime.dwLowDateTime;
  longTime.HighPart = fileTime.dwHighDateTime;
  //return (pow(2.0,32)*fileTime.dwHighDateTime+(double)fileTime.dwLowDateTime)
  ///1.0e7;
  return (signed __int64) longTime.QuadPart / 1.0e7;
}

double getTimeOfDay()
{
  SYSTEMTIME epoch;
  epoch.wYear = 1970;
  epoch.wMonth = 1;
  epoch.wDayOfWeek = 5;
  epoch.wDay = 1;
  epoch.wHour = 0;
  epoch.wMinute = 0;
  epoch.wSecond = 0;
  epoch.wMilliseconds = 0;

  SYSTEMTIME systemTime;
  GetSystemTime(&systemTime);

  return systemTimeToDouble(systemTime) - systemTimeToDouble(epoch);
}

#ifdef UNDER_CE
Manip hex("hex");
Manip endl("endl");
Manip dec("dec");

int abort() { return 0; }
ofstream cout("cout.txt");
ofstream cerr("cerr.txt");

char* strerror(int errorCode)
{
  static char lastErrorCode[1024];
  sprintf(lastErrorCode, "%d", errorCode);
  return lastErrorCode;
}
#endif

//---------------------------------------------------------------------------
