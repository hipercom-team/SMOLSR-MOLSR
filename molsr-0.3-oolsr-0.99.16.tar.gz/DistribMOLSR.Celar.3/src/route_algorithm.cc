//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements route calculation algorithms
//---------------------------------------------------------------------------

#include "route_algorithm.h"

//---------------------------------------------------------------------------

void RouteAlgorithm::breadthFirst()
{
  std::list<int> grayNodeList = startingNodeList;
  
  for(int i=0; i<nbNode;i++) {
    nodeInfoArray[i].distance = MaxDistance;
  }

  int currentDistance = 0;
  while (!grayNodeList.empty()) {
    list<int> newGrayNodeList;

    for (std::list<int>::iterator it = grayNodeList.begin(); 
	it != grayNodeList.end(); it++) {

      int nodeIdx = *it;
      assert( inrange(0, *it, nbNode) );
      GraphNode& nodeInfo = (nodeInfoArray[nodeIdx]);

      nodeInfo.distance = currentDistance;

      //if (nodeInfo->neighborList.empty() == 0) continue; //XXX
      list<int>& neighborList = (nodeInfo.neighborList);
      if (neighborList.empty()) continue; // XXX
      for (std::list<int>::iterator otherIt = neighborList.begin();
	   otherIt != neighborList.end(); otherIt++) {
	int otherIdx = *otherIt;
	assert( inrange(0, otherIdx, nbNode) );
	if (!isReached(otherIdx)) {
	  GraphNode& otherNodeInfo = (nodeInfoArray[otherIdx]);

	  for (int i=0;i<myMin(2,currentDistance);i++)
	    otherNodeInfo.nextHop[i] = nodeInfo.nextHop[i];
	  if (currentDistance < 2)
	    otherNodeInfo.nextHop[currentDistance] = nodeIdx;
	  if (currentDistance == 0)
	    otherNodeInfo.nextHop[1] = otherIdx;

	  otherNodeInfo.distance = currentDistance+1;
	  newGrayNodeList.push_back(otherIdx);
	}
      }
    }
    currentDistance ++;
    grayNodeList = newGrayNodeList;
  }
}

//---------------------------------------------------------------------------
