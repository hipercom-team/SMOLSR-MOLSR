//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "mystream.h"

//--------------------------------------------------

#include "address.h"

//---------------------------------------------------------------------------
Address NullAddress;

int Address::getNetSize() const
{ return factory->addressSize; }

int Address::getMaxTextSize() const
{ return factory->addressSize*10; }

Address::Address(AddressFactory* aFactory, RawAddress address)
{
  factory = aFactory;
  addressIndex = factory->addAddress(address);
}

ostream& operator << (ostream& out, const Address& address)
{ address.write(out); return out; }

void Address::write(ostream& out) const
{ 
  if(factory!= NULL)
    factory->write(out, *this);
  else out << "(null address)";
}

void Address::toNet(void* data) const
{
  void* rawAddress = factory->getAddress(addressIndex);
  memcpy(data, rawAddress, factory->addressSize);
}

void Address::toText(char* data) const
{
  ostringstream out;
  write(out);
  assert( (int)strlen(out.str().c_str())+1 < getMaxTextSize() );
  strcpy(data, out.str().c_str());
}

RawAddress Address::getRawAddress() const
{ return factory->getAddress(addressIndex); }

string toText(Address address)
{
  int maxSize = address.getMaxTextSize();
  char* tmp = new char[maxSize+1];
  memset(tmp, 0, maxSize+1);
  address.toText(tmp);
  string result = tmp;
  delete [] tmp;
  return result;
}

//---------------------------------------------------------------------------
