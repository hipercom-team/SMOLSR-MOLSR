//---------------------------------------------------------------------------
//                             OOLSR
//              Yasser Toor, projet Hipercom, INRIA Rocquencourt
//      Nicolas Grzeskowiak, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// System calls for Cygwin
//---------------------------------------------------------------------------

#include <winsock2.h>
#include <windows.h>
#include <ws2tcpip.h> // XXX: for windows
#include <iptypes.h>
#include <iphlpapi.h>

//---------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <sys/socket.h> //+
#ifndef UNDER_CE
#include <sys/types.h>
#endif /* UNDER_CE */
//#include <netdb.h>
//#include <net/if.h>
//#include "linux
//#include <sys/select.h>

//#include <arpa/inet.h> // inet_pton


#include "general.h"
#include "address.h"
#include "network_generic.h"
//#include "network_linux.h"
#include "scheduler_simulation.h"
#include "scheduler_unix.h"

#ifdef UNDER_CE
#define strdup _strdup
#endif

//---------------------------------------------------------------------------

extern int getCygwinIfaceIndex(ISystemIface* iface);

//---------------------------------------------------------------------------

void startWinSock2()
{
  int err;
  WORD wVersionRequested;
  WSADATA wsaData;
  
  // open winsock //
  wVersionRequested = MAKEWORD( 2, 2 );
  err = WSAStartup( wVersionRequested, &wsaData );
  if ( err != 0 ) {
    printf("Error: WSAStartup failed with error %d\n", WSAGetLastError());
    exit(1);
  }
  if ( LOBYTE( wsaData.wVersion ) != 2 ||
       HIBYTE( wsaData.wVersion ) != 2 ) 
    {
      WSACleanup( );
      if (err == SOCKET_ERROR) {
	printf("WSACleanup failed with error %d\n", WSAGetLastError());
      }
      exit(1);
    }
  // winsock ok //
}


//----------------------------------------------------------------------------
// If returned status is NO_ERROR, then pIpRouteTab points to a routing
// table.
//----------------------------------------------------------------------------

DWORD ///XXX: clean-up
MyGetIpForwardTable(PMIB_IPFORWARDTABLE* pIpRouteTab, BOOL fOrder)
{
  DWORD status = NO_ERROR;
  DWORD statusRetry = NO_ERROR;
  DWORD dwActualSize = 0;
  PMIB_IPFORWARDTABLE pTempIpRouteTab=NULL;

  status = GetIpForwardTable(pTempIpRouteTab,&dwActualSize,fOrder);
  if (status == NO_ERROR)
    return status;
  else if (status == ERROR_INSUFFICIENT_BUFFER) {
    pTempIpRouteTab = (PMIB_IPFORWARDTABLE) malloc(dwActualSize);
    assert(pTempIpRouteTab);
    statusRetry = GetIpForwardTable(pTempIpRouteTab, &dwActualSize, fOrder);
    *pIpRouteTab = pTempIpRouteTab;
    return statusRetry;
  } else {
    Warn("Unknown error in GetIpForwardTable: " << status);
    return status;
  }
}

//---------------------------------------------------------------------------
/// Add one route in the kernel

void cygwinAddRoute(ISystemIface* iface, sockaddr_in& destSysAddr,
		    sockaddr_in& gatewaySysAddr, sockaddr_in& netMaskSysAddr,
		    int metric)
{
  //addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
  //addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
  
  DWORD dwStatus;
  MIB_IPFORWARDROW routeEntry; // ip routing entry
  //XXX:remove: PMIB_IPADDRTABLE pIpAddrTable = NULL; // ip addr table
  
  memset(&routeEntry,0,sizeof(MIB_IPFORWARDROW));
  routeEntry.dwForwardDest = destSysAddr.sin_addr.s_addr;
  
  if (!(destSysAddr.sin_addr.s_addr == gatewaySysAddr.sin_addr.s_addr))
    routeEntry.dwForwardNextHop = gatewaySysAddr.sin_addr.s_addr;
  else routeEntry.dwForwardNextHop = destSysAddr.sin_addr.s_addr;
  routeEntry.dwForwardIfIndex = getCygwinIfaceIndex(iface);
  
#if 0
  if (netMaskAddress.isNull()) {
    routeEntry.dwForwardMask = 0xffffffff; // XXX! constant.
  } else {
    routeEntry.dwForwardMask = XXX; // XXX! constant.
  }
#endif
  routeEntry.dwForwardMask = netMaskSysAddr.sin_addr.s_addr;
  
#if 0
  if(destination->rt_dst==INADDR_ANY)
    routeEntry.dwForwardMask = inet_addr(NETMASK_DEFAULT);
  else
    routeEntry.dwForwardMask = inet_addr((char *)NETMASK_HOST);
#else
  // XXX: only one host:

#endif
  
  routeEntry.dwForwardMetric1 = metric + 1;
  routeEntry.dwForwardProto = 0; //XXX!! [PROTO_IP_LOCAL;]
  routeEntry.dwForwardMetric2 = (DWORD)-1; //XXX
  routeEntry.dwForwardMetric3 = (DWORD)-1; //XXX
  routeEntry.dwForwardMetric4 = (DWORD)-1; //XXX
  
  dwStatus = SetIpForwardEntry(&routeEntry);
  if (dwStatus != NO_ERROR)
    Fatal(" SetIPForwardEntry: " << GetLastError());
}




/// Remove one route from the kernel
void cygwinRemoveRoute(ISystemIface* iface, sockaddr_in& destSysAddr,
		       sockaddr_in& gatewaySysAddr, 
		       sockaddr_in& netMaskSysAddr, 
		       int metric)
{
  DWORD dwStatus, dwDelStatus;
  PMIB_IPFORWARDTABLE pIpRouteTab = NULL; // Ip routing table
  MIB_IPFORWARDROW routeEntry;            // Ip routing table row entry
  DWORD dwForwardDest = 0;
  
  memset(&routeEntry, 0, sizeof(MIB_IPFORWARDROW));
  dwForwardDest = destSysAddr.sin_addr.s_addr;
  DWORD dwNetMask = netMaskSysAddr.sin_addr.s_addr;
  dwStatus = MyGetIpForwardTable(&pIpRouteTab, TRUE);
  
  if (dwStatus == NO_ERROR) {
    for (unsigned int i = 0; i < pIpRouteTab->dwNumEntries; i++) {
      if (dwForwardDest == pIpRouteTab->table[i].dwForwardDest
	  && dwNetMask == pIpRouteTab->table[i].dwForwardMask) {
	memcpy(&routeEntry, &(pIpRouteTab->table[i]),
	       sizeof(MIB_IPFORWARDROW));
	dwDelStatus = DeleteIpForwardEntry(&routeEntry); 
	if (dwDelStatus != NO_ERROR)
	  Fatal("DeleteIpForwardEntry: "<<GetLastError());//XXX!not fatal
      }

    } 
    if (pIpRouteTab != NULL)
      free(pIpRouteTab); // XXX: GlobalFree ?
  } else Fatal("Error: Could not get the IP forward table: " 
	       << GetLastError());
}




//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

#if 0
  // XXX! should be in a helper module
  //turn ip forwarding on
  if (!initialized ) {
    memset(&Overlapped,0, sizeof(OVERLAPPED));
    Overlapped.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (EnableRouter(&Handle, &Overlapped) != ERROR_IO_PENDING) 
      printf("Error: Could not turn IP forwarding on\n");
    initialized = 1;
  }
  if (GetIpStatistics(&lstats) != NO_ERROR) 
    printf("Error: Could not turn IP forwarding on\n");
  lstats.dwForwarding = MIB_IP_FORWARDING; //start forwarding
  if (SetIpStatistics(&lstats) != NO_ERROR) 
    printf("Error: Could not turn IP forwarding on\n");
#endif

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------


void cygwinAddRoute(ISystemIface* iface, 
		    sockaddr_in destSysAddr,
		    sockaddr_in gatewaySysAddr,
		    Address netMaskAddress, 
		    int metric)
{
  //addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
  //addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
  
  DWORD dwStatus;
  MIB_IPFORWARDROW routeEntry; // ip routing entry
  //XXX:remove PMIB_IPADDRTABLE pIpAddrTable = NULL; // ip addr table
  
  memset(&routeEntry,0,sizeof(MIB_IPFORWARDROW));
  routeEntry.dwForwardDest = destSysAddr.sin_addr.s_addr;
  
  if (!(destSysAddr.sin_addr.s_addr == gatewaySysAddr.sin_addr.s_addr))
    routeEntry.dwForwardNextHop = gatewaySysAddr.sin_addr.s_addr;
  else routeEntry.dwForwardNextHop = destSysAddr.sin_addr.s_addr;
  routeEntry.dwForwardIfIndex = getCygwinIfaceIndex(iface);
  
#if 0
  if(destination->rt_dst==INADDR_ANY)
    routeEntry.dwForwardMask = inet_addr(NETMASK_DEFAULT);
  else
    routeEntry.dwForwardMask = inet_addr((char *)NETMASK_HOST);
#else
  // XXX: only one host:
  routeEntry.dwForwardMask = 0xffffffff; // XXX! constant.
#endif
  
  routeEntry.dwForwardMetric1 = metric + 1;
  routeEntry.dwForwardProto = 0; //XXX!! [PROTO_IP_LOCAL;]
  routeEntry.dwForwardMetric2 = (DWORD)-1; //XXX
  routeEntry.dwForwardMetric3 = (DWORD)-1;
  routeEntry.dwForwardMetric4 = (DWORD)-1;
  
  dwStatus = SetIpForwardEntry(&routeEntry);
  if (dwStatus != NO_ERROR)
    Fatal(" SetIPForwardEntry: " << GetLastError());
}



//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------


#define MAX_INTERFACES	100

void cygwinGetIfaceByName(string name, 
			  ProtocolConfig* protocolConfig,
			  IfaceConfig* ifaceConfig,
			  sockaddr_in& ifaceAddress, 
			  int& ifaceIndex)
{
  //INTERFACE_INFO ifo[MAX_INTERFACES]; // list of interfaces
  unsigned long size_of_ifo = sizeof(INTERFACE_INFO);
  unsigned long br=0;
  //u_long i;
  DWORD Err,AdapterInfoSize,s;
  PIP_ADAPTER_INFO pAdapterInfo,pAdapt;
  DWORD Nb_i; //,For_i,Save,Nbinterf = 0;
  //struct sockaddr_in *sin;
  //char * ip_addr;
  //char c[2];
  //struct interf_name *nt;

  //MIB_IPSTATS lstats;	
  //OVERLAPPED	Overlapped;
  //HANDLE		Handle;

  
  if ((s = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    Fatal("Error: Socket failed with error: " << WSAGetLastError());
  
  
/* We will use 802.11b adhoc mode for this demo
  // get interfaces into adhoc demo mode
  // hifconfig... should be in C:
	system("C:\\hifconfig-wireless.exe 0 --network_type=3");
	system("C:\\hifconfig-wireless.exe 0 -S d");
*/ 
  
#if 0
  // get interfaces list
  memset(&ifo[0],0,sizeof(ifo));
  Err=WSAIoctl(s, SIO_GET_INTERFACE_LIST, NULL, 0,
	       &ifo[0], sizeof(ifo), &br, NULL, NULL);
  if (Err!=0)
    Fatal("Error: GET_INTERFACE_LIST failed with error " << WSAGetLastError());
#endif

  // get ip adapater info
  // Enumerate all of the adapter specific information using the IP_ADAPTER_INFO structure.
  // Note:  IP_ADAPTER_INFO contains a linked list of adapter entries.
  //
  AdapterInfoSize = 0;
  if ((Err = GetAdaptersInfo(NULL, &AdapterInfoSize)) != 0)
    if (Err != ERROR_BUFFER_OVERFLOW)
      Fatal("Error: GetAdaptersInfo sizing failed with error" << Err);


  // Allocate memory from sizing information
  pAdapterInfo = (PIP_ADAPTER_INFO) GlobalAlloc(GPTR, AdapterInfoSize);
  if (pAdapterInfo == NULL)
    Fatal("Error:  Memory allocation error in PIP_ADAPTER_INFO\n");

  // Get actual adapter information
  if ((Err = GetAdaptersInfo(pAdapterInfo, &AdapterInfoSize)) != 0)
    Fatal("Error: GetAdaptersInfo failed with error" << Err);

  // Number of interfaces
  Nb_i=br/size_of_ifo;

  //give name and index to good interfaces
  //ip_addr=inet_ntoa(sin->sin_addr);

  ifaceIndex = -1;
  char* ifaceDescription = NULL;

  pAdapt = pAdapterInfo;
  while (pAdapt)
    {
      if (name == "" || name == "show") {
	cerr << "Interface #" << pAdapt->Index << ":"  << endl
		  << "  name: " << pAdapt->AdapterName << endl
		  << "  desc: " << pAdapt->Description << endl 
		  << "  ip: " << pAdapt->IpAddressList.IpAddress.String 
		  << endl;
      } else if (atoi(name.c_str()) == (int)pAdapt->Index) {
        ifaceDescription= strdup(pAdapt->Description); // XXX
	ifaceIndex = pAdapt->Index;
	sockaddr_in tmpAddress;
	memset(&tmpAddress, 0, sizeof(tmpAddress));
	tmpAddress.sin_family = AF_INET;
	tmpAddress.sin_addr.s_addr = 
	  inet_addr(pAdapt->IpAddressList.IpAddress.String);
	ifaceAddress = tmpAddress; 
      }
#if 0
      if ((strcmp(ip_addr,pAdapt->IpAddressList.IpAddress.String))==0)
	{
	  ifp->int_name = (char *)malloc(strlen(pAdapt->Description) + 1);
	  if (ifp->int_name == 0)
	    Fatal("Out of memory");
	  strcpy(ifp->int_name, pAdapt->Description);
	  ifp->int_index = pAdapt->Index;
	  break;
	}
#endif
      pAdapt = pAdapt->Next;
    }

  if (ifaceIndex<0)
    Fatal("Cannot find interface etc xXXX");
}

//---------------------------------------------------------------------------
