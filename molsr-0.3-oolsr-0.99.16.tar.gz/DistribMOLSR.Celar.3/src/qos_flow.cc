//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This part performs the route computation
//---------------------------------------------------------------------------

#include "qos.h"
#include "qos_flow.h"

//---------------------------------------------------------------------------


bool QosNode::computeFlowRoute(QosFlow& flow)
{
  if (protocolConfig->qosUseBestEffortRoute) {
    return _computeBestEffortFlowRoute(flow);
  } else {
    return _computeQosFlowRoute(flow);
    //    Fatal("XXX! QoS route computation not implemented yet");
    //    return false;
  }
}

//---------------------------------------------------------------------------
