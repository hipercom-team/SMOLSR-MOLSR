//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//              mostly derived from MOOLSR mdfpCom.h/mdfpCom.cc
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//            Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004-2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

#include <errno.h>

#include "mystream.h"

#include "protocol-plugin-api.h"

#include "address.h"
#include "packet.h"
#include "external_message.h"

#include "scheduler_unix.h"

#include "external_com_socket.h"

//---------------------------------------------------------------------------

// Communicate in and out to another process with some UDP sockets

class SocketExternalCommunication : public IExternalMessageReceiver,
				    public IFdHandler
{
protected:
  IOScheduler *scheduler;
  Node *node;

  IExternalMessageReceiver* receiver;

  int sockFd;
  int portIn;
  int portOut;
  sockaddr_in ipv4AddrIn;
  sockaddr_in ipv4AddrOut; 

public:
  SocketExternalCommunication(Node *aNode, IOScheduler* aIOScheduler, 
			      int aPortIn, int aPortOut,
			      IExternalMessageReceiver* aReceiver)
    : node(aNode)
  {
    portIn = aPortIn; 
    portOut = aPortOut;
    scheduler = aIOScheduler;
    sockFd = -1;
    receiver = aReceiver;
  }

  virtual ~SocketExternalCommunication() { close(sockFd); }

  //--------------------------------------------------
  // IFdHandler methods
  //--------------------------------------------------
  virtual FileDescriptor getFileDescriptor() { return sockFd; }
  virtual bool waitingForInput()  { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; }
  
  virtual void handleExcept() { Fatal("Impossible handleExcept"); }  
  virtual void handleOutput() { Fatal("Impossible handleOutput"); }

  virtual void handleInput() 
  { recvAndProcessData(); }

  //--------------------------------------------------
  // IExternalMessageReceiver methods
  //--------------------------------------------------
  virtual void handleMessage(/*borrowed*/ MemoryBlock* message)
  { sendData(message->data, message->size); }

  //--------------------------------------------------
  // Own methods
  //--------------------------------------------------

  virtual void open()
  {
    initSockAddr(&ipv4AddrIn, INADDR_LOOPBACK, portIn);
    initSockAddr(&ipv4AddrOut, INADDR_LOOPBACK, portOut);

    sockFd = socket(PF_INET, SOCK_DGRAM, 0);
    if (sockFd < 0)
      Fatal("Cannot create socket: " << strerror(errno));

    // Set REUSEADDR
    int on = 1;
    if (setsockopt(sockFd, SOL_SOCKET, SO_REUSEADDR, (void*)&on,
		   sizeof(on)) < 0)
      Fatal("Cannot setsockopt SO_REUSEADDR on  socket:" << strerror(errno));

    // Bind to address
    if (bind(sockFd, (struct sockaddr*)&ipv4AddrIn, sizeof(ipv4AddrIn)) <0)
      Fatal("Cannot bind socket: " << strerror(errno));

    scheduler->addFdHandler(this, NULL);
  }

  virtual int sendData(void* data, int dataSize)
  {
    if(sendto(sockFd, data, dataSize, 0, 
	      (sockaddr*)&ipv4AddrOut, sizeof(ipv4AddrOut)) <0) {
      Warn(" sendto: " << strerror(errno) );
      return 0;
    } else return 1;
  }

  virtual void recvAndProcessData()
  {
    octet data[65536]; // XXX: not inline
    int dataSize = sizeof(data);
    sockaddr_in  recvAddress;
    socklen_t socketSize = sizeof(recvAddress);
    int status = recvfrom(sockFd, data, dataSize, /*flags*/ 0,
			  (struct sockaddr*)&recvAddress, &socketSize);
    if(status <0) {
      Warn("error in recvfrom: " << strerror(errno));
    } else {
      MemoryBlock* packet = new MemoryBlock(data, status, true);
      receiver->handleMessage(packet);
      delete packet;
    }
  }

  virtual void initSockAddr(sockaddr_in *ipv4Addr, unsigned int addr, int port)
  {
    memset(ipv4Addr, 0, sizeof(sockaddr_in));
    ipv4Addr->sin_family = AF_INET;
    ipv4Addr->sin_addr.s_addr = htonl(addr);
    ipv4Addr->sin_port = htons(port);
  }
};

//---------------------------------------------------------------------------

IExternalMessageReceiver* 
SocketExternalComManager::open(int channelIn, int channelOut,
			       IExternalMessageReceiver* receiver)
{
  SocketExternalCommunication* result = new
    SocketExternalCommunication(node, scheduler, channelIn, channelOut,
				receiver);
  result->open();
  return result;
}

//---------------------------------------------------------------------------
