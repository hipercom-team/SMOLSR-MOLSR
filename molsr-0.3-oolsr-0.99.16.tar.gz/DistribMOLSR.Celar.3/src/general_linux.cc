//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include <sys/time.h>
#include <stdio.h>

#include "general.h"

//---------------------------------------------------------------------------

 /// Draw a random number (double) between 0 (incl.) and maxValue (excl.)
double drawDouble(double maxValue)
{ return drand48()*maxValue; }

static double timeOffset = 0.0;

double getTimeOfDay()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  double result = tv.tv_sec + timeOffset;
  if (result < 0) {
    // Hack for some machines with bad bios/and year = 1905
    timeOffset = -result + 1;
    Warn("Negative time: using offset for time =" << timeOffset << endl);
    result = tv.tv_sec + timeOffset;
  }
  return result + tv.tv_usec/1e6;
}

//---------------------------------------------------------------------------
