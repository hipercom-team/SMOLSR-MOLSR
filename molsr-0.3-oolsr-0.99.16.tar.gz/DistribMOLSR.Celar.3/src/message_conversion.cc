//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//            Geraud Allard, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2005 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Conversion of OLSRv1 messages <-> OLSRv2 messages
//---------------------------------------------------------------------------

class HelloV2MessageHandler: public MessageWithTLVHandler
{
public:

  HelloV2MessageHandler(NodeWithConversion* aNode) 
    : MessageWithTLVHandler(aNode), nodeWithConversion(aNode)
  { }
  
  virtual void reallyProcessMessage(Message& message);

  virtual ~HelloV2MessageHandler() {}
protected:
  NodeWithConversion* nodeWithConversion;
};

//---------------------------------------------------------------------------

void NodeWithConversion::start()
{
  //LABAMessageHandler*  labaMessageHandler  = new LABAMessageHandler(this);
  //packetManager->addMessageHandler(HELLOv2_MESSAGE,  ...);
  //packetManager->addMessageHandler(TCv2_MESSAGE,  ...);
  ParentNodeWithConversion::start();
}

MessageWithTLV* NodeWithConversion::convertHELLOToV2(Message* message)
{
#warning How information is written in the log usually:
  D(*log, lConversion, getRealTime() << " [conversion] " << getMainAddress()
    << " converting message: " << (*message) << endl);

  assert ( message->content != NULL );
  HelloMessage* m = dynamic_cast<HelloMessage*>(message->content);
  assert ( m != NULL );

  // Create new message
  Message* header = message->clone(false);
  if (header->messageTLVSet == NULL) // XXX: should be more automatic?
    header->messageTLVSet = new MessageTLVSet;
  header->messageType = HELLOv2_MESSAGE;
  MessageWithTLV* newM = new MessageWithTLV;
  newM->header = header;
  newM->header->content = newM;

  // Update content
  header->messageTLVSet->addTLV(new U16TLV(MessageTLVTypeWillingness,
					   m->willingness));
#warning actual HELLOv1 -> HELLOv2 conversion not implemented
  // XXX!!! there a TLV defined for htime?
  //header->messageTLVSet->addTLV(MessaHTime, new U16TLV(m->htime));
  // 

  return newM;
}

HelloMessage* NodeWithConversion::convertHELLOToV1(Message* message)
{
  assert ( message->content != NULL );
  MessageWithTLV* m = dynamic_cast<MessageWithTLV*>(message->content);
  assert ( m != NULL );

  // Create new message
  Message* header = message->clone(false);
  MessageWithTLV* newM = new MessageWithTLV;
  newM->header = header;
  newM->header->content = newM;
  
#warning actual HELLOv2 -> HELLOv1 conversion not implemented 
  //HelloMessage* helloMessage = new HelloMessage;
  return NULL;
}

//---------------------------------------------------------------------------

void HelloV2MessageHandler::reallyProcessMessage(Message& message)
{ 
  HelloMessage* helloMessage = nodeWithConversion->convertHELLOToV1(&message);
  node->processHelloMessage(helloMessage);
  delete helloMessage;
}

//---------------------------------------------------------------------------

void NodeWithConversion::sendMessage(OLSRIface* iface,
				     /*owned*/Message* message)
{ 
  if (protocolConfig->useConversion 
      && message->messageType ==  HELLO_MESSAGE) {
    MessageWithTLV* messageWithTLV = convertHELLOToV2(message);
    delete message;
    message = messageWithTLV->header;
  }
  ParentNodeWithConversion::sendMessage(iface, message);
}

//---------------------------------------------------------------------------
