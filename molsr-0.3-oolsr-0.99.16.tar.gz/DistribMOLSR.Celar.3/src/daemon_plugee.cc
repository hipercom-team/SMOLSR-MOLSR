//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// The main OLSR daemon
//---------------------------------------------------------------------------

#error this file is no longer used. see daemon_core.cc instead.

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#include <dlfcn.h>

// socket&IPv6:
//#include <sys/socket.h>
//#include <sys/types.h>
//#include <netdb.h>
//#include <net/if.h>
//#ifdef WITH_IPV6
//#include <ifaddrs.h>
//#endif // WITH_IPV6

//#include <arpa/inet.h> // inet_pton

#include "mystream.h"
#include <vector>

//---------------------------------------------------------------------------

#include "protocol-plugin-api.h"

//---------------------------------------------------------------------------

#include "scheduler_unix.h"
#include "node.h"
#include "network_generic.h"
#include "network_linux.h"
#include "scheduler_simulation.h"

//---------------------------------------------------------------------------

std::list<ISystemIface*> systemIfaceList;

ISystemFactory* systemFactory;

ISystemIface* findSystemIfaceByAddress(Address address)
{
  for(std::list<ISystemIface*>::iterator it = systemIfaceList.begin();
      it != systemIfaceList.end(); it++)
    if((*it)->getAddress() == address)
      return *it;
  return NULL;
}

//---------------------------------------------------------------------------

const int IfaceMtu = 1000; // XXX!

PPA_PlugeeApi myApi;

PPA_PluginApi* pluginApi;

//IOScheduler* scheduler = NULL;

static int sendSocket = -1;

void sendPacket(PPA_PlugeeNode simSrcNode,
		PPA_Address srcAddress, /* of one of iface */
		PPA_Address dstAddress,
		PPA_Packet packet)
{
  assert( simSrcNode == NULL );
  Address realSrcAddress = Address(systemFactory->getAddressFactory(), 
				   srcAddress);
  Address realDstAddress = Address(systemFactory->getAddressFactory(), 
				   dstAddress);
  // XXX: check dst address
  ISystemIface* systemIface = findSystemIfaceByAddress(realSrcAddress);
  assert( systemIface != NULL );
  MemoryBlock* realPacket = new MemoryBlock((octet*)packet.data, 
					    packet.size, true);
  systemIface->sendPacket(realPacket);
  free(packet.data);
}

int configureRoute(PPA_PlugeeNode simSrcNode,
		   /* borrowed: */
		   PPA_Route* route,
		   int flags /* add or delete */)
{ 
  INetworkConfigurator* netConfig = systemFactory->getNetworkConfigurator();

  Address localIfaceAddr = Address(systemFactory->getAddressFactory(),
				   route->localInterfaceAddress);
  Address nextHopIfaceAddr = Address(systemFactory->getAddressFactory(),
				     route->nextHopInterfaceAddress);
  Address destAddr = Address(systemFactory->getAddressFactory(),
			     route->destinationAddress);
  ISystemIface* iface = findSystemIfaceByAddress(localIfaceAddr);
  Address nullAddress; // XXX!
  assert( iface != NULL );

  if(flags == PPA_ADD_ROUTE) {
    netConfig->addRoute(iface, destAddr, nextHopIfaceAddr, nullAddress, 
			route->distance);
  } else if (flags == PPA_DEL_ROUTE) {
    netConfig->removeRoute(iface, destAddr, nextHopIfaceAddr, nullAddress, 
			   route->distance);
  } else Fatal("Unknown route action, flags=" << flags);
}

// common[
class SimulationEvent : public IEvent
{
public:
  SimulationEvent(PPA_CallbackFunction aFunction,
		  void* aData1, void* aData2, void* aData3)
    : function(aFunction), data1(aData1), data2(aData2), data3(aData3)
  {}

  virtual void handleEvent(void* data)
  { function(data1, data2, data3); }

protected:
  PPA_CallbackFunction function;
  void* data1; void* data2; void* data3;
};

void scheduleAt(double relativeTime,
		PPA_CallbackFunction function,
		void* data1, void* data2, void* data3)
{ 
  systemFactory->getScheduler()->addEvent(relativeTime, 
		      new SimulationEvent(function, data1, data2, data3),
		      NULL);
}

double getCurrentTime()
{ return systemFactory->getScheduler()->getTime(); }

// ]common

void getBroadcastAddress(PPA_Address resultAddress)
{ 
  //memcpy(resultAddress, &broadcastAddress, sizeof(resultAddress)); 
  memset(resultAddress, 0, sizeof(resultAddress)); // XXX!
}

//---------------------------------------------------------------------------
// XXX:
bool findIfaceByName(char* name, struct sockaddr_in6& result, int&);
int openSocket(unsigned int ifaceIndex);
//---------------------------------------------------------------------------

PPA_PluginNode pluginNode;

class PlugeePacketReceiver : public IPacketReceiver
{
public:
  PlugeePacketReceiver(Address aRecvIfaceAddress) :
    recvIfaceAddress(aRecvIfaceAddress) { }

  virtual void evReceivePacket(MemoryBlock* packet,
                               Address sendIfaceAddress,
                               OLSRIface* recvIface)
  {
    PPA_Packet ppaPacket;
    ppaPacket.data = malloc(packet->size);
    memcpy(ppaPacket.data, packet->data, packet->size);
    ppaPacket.size = packet->size;
    assert( recvIface == NULL );
    pluginApi->nodeReceiveFunction(pluginNode,
				   sendIfaceAddress.getRawAddress(),
				   recvIfaceAddress.getRawAddress(),
				   ppaPacket);
  }

protected:
  Address recvIfaceAddress;
};

PlugeePacketReceiver** packetReceiver;

//---------------------------------------------------------------------------

extern ISystemFactory* getSystemFactory();

int main(int argc, char** argv)
{
  int i;
  int nbIface = argc-1;

  cerr.precision(15);
  cout.precision(15);

  if(argc <= 1) {
    cerr << "Syntax: %s <interface 1> ....<interface n>" << endl;
    exit(EXIT_FAILURE);
  }

  //--------------------------------------------------

  systemFactory = getSystemFactory();

  //--------------------------------------------------

  //SimulationScheduler* baseScheduler = new SimulationScheduler;
  //scheduler = new IOScheduler(baseScheduler);

  PPA_PlugeeApi* simulatorApi = &myApi;
  simulatorApi->sendPacketFunction          = sendPacket;
  simulatorApi->configureRouteFunction      = configureRoute;
  simulatorApi->scheduleAtFunction          = scheduleAt;
  simulatorApi->getBroadcastAddressFunction = getBroadcastAddress;
  simulatorApi->getCurrentTimeFunction      = getCurrentTime;
  simulatorApi->addressSize                 
    = systemFactory->getAddressFactory()->getAddressSize();

  loadPlugin(NULL, simulatorApi, &pluginApi); // XXX
  //loadPlugin(fileName);

  PPA_Address* addressList = new PPA_Address[nbIface];
  packetReceiver = new PlugeePacketReceiver* [nbIface];

  for(int i=0;i<argc-1;i++) {
    ISystemIface* systemIface = systemFactory->getIfaceByName(argv[i+1]);
    if(systemIface == NULL)
      Fatal("Cannot find a usable interface with name '" << argv[i+1] << "'");
    systemIfaceList.push_back(systemIface);
    addressList[i] = systemIface->getAddress().getRawAddress();
    packetReceiver[i] = new PlugeePacketReceiver(systemIface->getAddress());
    systemIface->openSocket(packetReceiver[i]);
  }

  int mtu = IfaceMtu;
 
  pluginNode = 
    pluginApi->createNodeFunction( /* plugeeNode */ NULL,
				   nbIface, 
				   addressList,
				   &mtu);
  
  pluginApi->nodeStartFunction(pluginNode);
  
  systemFactory->getScheduler()->runUntilNoEvent();

  exit(EXIT_SUCCESS);
}

//---------------------------------------------------------------------------
