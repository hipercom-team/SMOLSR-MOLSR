
//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
#include "definition.h"

//---------------------------------------------------------------------------
struct igmpProcMLine * process_igmp_line(char *chaine)
{
  struct igmpProcMLine *igmpEntry;

  
  igmpEntry=(struct igmpProcMLine*)malloc(sizeof(struct igmpProcMLine));

  sscanf(chaine,"\t\t\t\t%081X %5d %d:%081X\t\t%d",
	 &igmpEntry->multiaddr, &igmpEntry->users,&igmpEntry->tm_running, 
	 &igmpEntry->expires, &igmpEntry->reporter);

  //  printf("\t\t\t\t%08lX %5d %d:%08lX\t\t%d\n",igmpEntry->multiaddr, 
  //	 igmpEntry->users,igmpEntry->tm_running, igmpEntry->expires, 
  //	 igmpEntry->reporter);

  
  
  return igmpEntry;
  
}

//---------------------------------------------------------------------------
struct igmpProcIface *process_igmp_iface(char *chaine)
{
  struct igmpProcIface *igmpIface;
    
  //printf("%s",chaine);
	  
  igmpIface=(struct igmpProcIface *)malloc(sizeof(struct igmpProcIface));
  igmpIface->next=NULL;
  igmpIface->mlist=NULL;
  
  sscanf(chaine,"%d\t%s: %5d",
	 &igmpIface->ifindex,&igmpIface->name,&igmpIface->mc_count);

  //printf("%d\t%-10s: %5d\n",igmpIface->ifindex,igmpIface->name,igmpIface->mc_count);

  return igmpIface;
   
}
//---------------------------------------------------------------------------
void freeIgmpContent(struct igmpProcIface *igmpProcContent)
{
  struct igmpProcIface *igmpHead;

  struct igmpProcMLine *igmpLine;

  while(igmpProcContent!=NULL)
    {      
      while(igmpProcContent->mlist!=NULL)
	{
	  igmpLine=igmpProcContent->mlist;
	  igmpProcContent->mlist=igmpLine->next;
	  free(igmpLine);
	}
      igmpHead=igmpProcContent;
      igmpProcContent=igmpHead->next;
      free(igmpHead);
    }

}
//---------------------------------------------------------------------------
 struct igmpProcIface * get_igmp_info()
{
  FILE *igmpFD;
  int charSize=255;
  char chaine[charSize];
  struct igmpProcIface *igmpProcContent=NULL;
  struct igmpProcIface *igmpIface;
  struct igmpProcMLine *igmpLine;

  if((igmpFD=fopen("/proc/net/igmp","r"))==NULL)
    {
      //return errno;
      return NULL;
    }

  
  fgets(chaine,charSize,igmpFD);

  
  while((fgets(chaine,charSize,igmpFD))!=NULL)
    {
      if(memcmp(&chaine[0],"\t",1))
	{
	  
	  igmpIface=process_igmp_iface(chaine);
	  igmpIface->next=igmpProcContent;
	  igmpProcContent=igmpIface;
	
	}
      else
	{
	  igmpLine=process_igmp_line(chaine);
	  igmpLine->next=igmpProcContent->mlist;
	  igmpProcContent->mlist=igmpLine;
	  
	}
      
    }
  
  //freeIgmpContent(igmpProcContent);

  fclose(igmpFD);

  return (igmpProcContent);
}
//---------------------------------------------------------------------------
