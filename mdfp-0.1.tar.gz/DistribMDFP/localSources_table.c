//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------


#include "definition.h"

struct SourceLocalhash       sourceLocaltable[HASHSIZE];
struct timeval hold_time_sourceLocal;
double sourceLocal_hold_time = SOURCE_LOCAL_HOLD_TIME;
/*------------------------------------------------------------------------*/


void mdfp_delete_SourceLocal_table(struct SourceLocal_entry *srcLocal_entry)
{
  
  mdfp_remque((struct mdfp_qelem *)srcLocal_entry);
  free((void *)srcLocal_entry);

}


/*------------------------------------------------------------------------*/


struct SourceLocal_entry *mdfp_insert_SourceLocal_table(struct message_header *message)
{
  u_int32_t hash;
  struct SourceLocalhash   *srcLocal_hash;
  struct SourceLocal_entry *srcLocal_message;
  //char action[200];
  
  srcLocal_message = (struct SourceLocal_entry *)malloc(sizeof(*srcLocal_message));

 
  memcpy(&srcLocal_message->srcLocal_addr, &message->originator, 
	 sizeof(message->originator));  
  memcpy(&srcLocal_message->srcLocal_group, &message->destination_addr, 
	 sizeof(message->destination_addr));
  
  timeradd(&globalVar.now, &hold_time_sourceLocal, &srcLocal_message->srcLocal_timer);
  //printf("timeout for New source %ld\n",srcLocal_message->srcLocal_timer.tv_sec);
  mdfp_hashing(&srcLocal_message->srcLocal_addr, &hash);
  srcLocal_message->srcLocal_hash = hash;
  srcLocal_hash = &sourceLocaltable[hash & HASHMASK];

  //sprintf(action, "MSG Seq Num %d INSERTED IN DUPLI-TABLE.\n Originator",
  //	  dup_message->duplicate_seq);

  // TRACE_ACTION(action, &dup_message->duplicate_addr, (Iface *)NULL, 
  //	       &dup_message->duplicate_timer);

  mdfp_insque((struct mdfp_qelem *)srcLocal_message, 
	      (struct mdfp_qelem *)srcLocal_hash);

  return(srcLocal_message);
  /*  if (schedule_dup_del) {
      schedule_dup_del = 0;
      schedule_event(DUPLI_DEL, &events_head);
      }
  */
}

/*------------------------------------------------------------------------*/

struct SourceLocal_entry \
 *mdfp_lookup_SourceLocal_table(struct message_header *message)
{
  struct SourceLocal_entry *srcLocal_message;
  struct SourceLocalhash   *srcLocal_hash;
  u_int32_t               hash;

  mdfp_hashing(&message->originator, &hash);
  
  srcLocal_hash = &sourceLocaltable[hash & HASHMASK];
  
  for(srcLocal_message = srcLocal_hash->srcLocal_forw;
      srcLocal_message != (struct SourceLocal_entry *)srcLocal_hash;
      srcLocal_message = srcLocal_message->srcLocal_forw)
    {
      
      if(srcLocal_message->srcLocal_hash != hash)
	continue;

      if ( (!memcmp(&srcLocal_message->srcLocal_addr, &message->originator,
		     sizeof(message->originator)) )
	  &&(!memcmp(&srcLocal_message->srcLocal_group, 
		     &message->destination_addr,sizeof(message->destination_addr)) ))

	  return (srcLocal_message);
    }
  return (NULL);
}


/*------------------------------------------------------------------------*/


void mdfp_release_SourceLocal_table()
{
  u_int8_t               index;
  struct SourceLocalhash   *srcLocal_hash;
  struct SourceLocal_entry *srcLocal_message;
  struct SourceLocal_entry *srcLocal_message_tmp;

  for(index = 0; index < HASHSIZE; index++)
    {
      srcLocal_hash = &sourceLocaltable[index];
      srcLocal_message = srcLocal_hash->srcLocal_forw;
      while(srcLocal_message != (struct SourceLocal_entry *)srcLocal_hash)
	{
	  srcLocal_message_tmp = srcLocal_message;
	  srcLocal_message = srcLocal_message->srcLocal_forw;
	  //XXX ADD send Local Source Leave MSG to MOLSR(srcLocal_message_tmp)
	  if(globalMDFP.molsrInfo.mainAddress)
	    mdfp_tell_MOLSR_NewLeave_localSource(srcLocal_message_tmp,LEAVE_SOURCE);
	  mdfp_delete_SourceLocal_table(srcLocal_message_tmp);
	}
    }
}


/*------------------------------------------------------------------------*/


void mdfp_time_out_SourceLocal_table()
{
  u_int8_t               index;
  struct SourceLocalhash   *srcLocal_hash;
  struct SourceLocal_entry *srcLocal_message;
  struct SourceLocal_entry *srcLocal_message_tmp;
  //struct timeval          nearest_timer;
  // int                     existing_elem = 0;

  // TRACE_ACTION(" ######### DUPLICATE TIME OUT.", NULL, NULL, NULL);

  //timeradd(&globalVar.now, &hold_time_sourceLocal, &nearest_timer);
  
  for(index = 0; index < HASHSIZE; index++)
    {
      srcLocal_hash = &sourceLocaltable[index];
      srcLocal_message = srcLocal_hash->srcLocal_forw;
      while(srcLocal_message != (struct SourceLocal_entry *)srcLocal_hash)
	{

	  if( mdfp_timed_out(&srcLocal_message->srcLocal_timer) )
	    {
	      srcLocal_message_tmp = srcLocal_message;
	      srcLocal_message = srcLocal_message->srcLocal_forw;
	      //XXX ADD send Local Source Leave MSG to MOLSR(srcLocal_message_tmp)
	      mdfp_tell_MOLSR_NewLeave_localSource(srcLocal_message_tmp,LEAVE_SOURCE);
	     
	      mdfp_delete_SourceLocal_table(srcLocal_message_tmp);
	    }
	  else
	    {
	      // if( timercmp(&nearest_timer, &dup_message->duplicate_timer, >) )
	      //	memcpy(&nearest_timer, &dup_message->duplicate_timer,
	      //       sizeof(nearest_timer));
	      srcLocal_message = srcLocal_message->srcLocal_forw;
	    }
	    
	  //existing_elem = 1;
	}
    }

  /* if( !existing_elem )
     schedule_dup_del = 1;
     else {
     struct timeval tp;
     timersub(&nearest_timer, &globalVar.now, &tp);
     
     schedule_event_with_timer(DUPLI_DEL, &tp, &events_head);
     }
  */

  // TRACE_ACTION("           END TIME OUT. #########", NULL, NULL, NULL);

}


/*------------------------------------------------------------------------*/
 int mdfp_process_localSource_updates(struct message_header *msgh)
{
      //XXX Check if the local source table contains this source address
      //update timer each time we send a packet !!!
      // In this case we must not send any packets!!!
      //otherwise insert a new entry for this source, and
      //we must notify MOLSR to initiate Source Claim messages

  struct SourceLocal_entry * srcLocal_message;

  srcLocal_message=mdfp_lookup_SourceLocal_table(msgh);

  if(srcLocal_message)
    {
      timeradd(&globalVar.now, &hold_time_sourceLocal, &srcLocal_message->srcLocal_timer);
      //printf("timeout source %d\n",srcLocal_message->srcLocal_timer.tv_sec);
      return 1;
    }
  else
    {
      //printf("New source %d\n");
      srcLocal_message=mdfp_insert_SourceLocal_table(msgh);
      //XXX ADD send Local Source NEW MSG to MOLSR(srcLocal_message)
      mdfp_tell_MOLSR_NewLeave_localSource(srcLocal_message,NEW_SOURCE);
      return 0;
    }
}

/*------------------------------------------------------------------------*/
void mdfp_tell_MOLSR_NewLeave_localSource(struct SourceLocal_entry * srcLocal_message,unsigned int type)
{
  struct mdfp *mdfpPacket;
  unsigned int packLen;
  struct MDFPMsg *mdfpMsg;
  struct LeaveNewLocalSrcClient *clientMsg;

  packLen=globalMDFP.mhSize+globalMDFP.phSize+sizeof(struct LeaveNewLocalSrcClient);
  mdfpPacket=(struct mdfp *)malloc(packLen);
  mdfpMsg=mdfpPacket->msg;
  fill_local_mdfp_header(mdfpPacket,packLen,type);

  clientMsg=(struct LeaveNewLocalSrcClient*)mdfpMsg->payload;

  clientMsg->srcCli=srcLocal_message->srcLocal_addr;
  clientMsg->group=srcLocal_message->srcLocal_group;
send_to_network( globalCom.olsrComSocket,(char *)mdfpPacket,packLen,globalCom.olsrComAddressTo);
}
/*------------------------------------------------------------------------*/

void mdfp_tell_MOLSR_localSourceContent()
{
 u_int8_t               index;
  struct SourceLocalhash   *srcLocal_hash;
  struct SourceLocal_entry *srcLocal_message;
  
  
  
  for(index = 0; index < HASHSIZE; index++)
    {
      srcLocal_hash = &sourceLocaltable[index];
      srcLocal_message = srcLocal_hash->srcLocal_forw;
      while(srcLocal_message != (struct SourceLocal_entry *)srcLocal_hash)
	{
	  mdfp_tell_MOLSR_NewLeave_localSource(srcLocal_message,NEW_SOURCE);
	  srcLocal_message = srcLocal_message->srcLocal_forw;
	}
	    
	  
    }
}

/*------------------------------------------------------------------------*/
