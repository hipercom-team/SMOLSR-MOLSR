//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
/*
 * This Copyright notice is in French. An English summary is given
 * but the referee text is the French one.
 *
 * Copyright (c) 2000, 2001, 2002, 2003
 *   Adokoe.Plakoo@inria.fr, INRIA Rocquencourt,
 *   Anis.Laouiti@inria.fr, INRIA Rocquencourt.
 *   Cedric.Adjih@inria.fr, INRIA Rocquencourt.
 *
 * Ce logiciel informatique est disponible aux conditions
 * usuelles dans la recherche, c'est-�-dire qu'il peut
 * �tre utilis�, copi�, modifi�, distribu� � l'unique
 * condition que ce texte soit conserv� afin que
 * l'origine de ce logiciel soit reconnue.
 * Le nom de l'Institut National de Recherche en Informatique
 * et en Automatique (INRIA), ou d'une personne morale
 * ou physique ayant particip� � l'�laboration de ce logiciel ne peut
 * �tre utilis� sans son accord pr�alable explicite.
 * 
 * Ce logiciel est fourni tel quel sans aucune garantie,
 * support ou responsabilit� d'aucune sorte.
 * Certaines parties de ce logiciel sont d�riv�es de sources developpees par
 * University of California, Berkeley et ses contributeurs couvertes 
 * par des copyrights.
 * This software is available with usual "research" terms
 * with the aim of retain credits of the software. 
 * Permission to use, copy, modify and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and the name of INRIA, or any contributor not be used in advertising
 * or publicity pertaining to this material without the prior explicit
 * permission. The software is provided "as is" without any
 * warranties, support or liabilities of any kind.
 * This product includes software developed by the University of
 * California, Berkeley and its contributors protected by copyrights.
 *
 */
#include "definition.h"
/*------------------------------------------------------------------------*/

/* 
 * Checks different conditions (see the MDFP specication) and return:
 * 0 if the message must be dropped
 * 1 if the message must be processed (DATA_MULTICAST_MESSAGE)
 * 2 if the message must be forwarded
 */

int mdfp_parser(struct message_header *message)
{
  if(!olsr_configured_iface(&message->interface_reception))
    {
      if(globalVar.trace)
	trace_message_header(globalVar.traceFD,message,"RDI");
      return 0;
    }
  else
    if (message->ttl <= 0)
      {
	if(globalVar.trace)
	  trace_message_header(globalVar.traceFD,message,"RDT");
	return 0;
      }
    else     
      if ( mdfp_lookup_duplicate_table(message) ||(olsr_configured_iface(&message->originator)))
	//XXX Should we check if the message was originated from one of our
	//interfaces
	{
	  if(globalVar.trace)
	    trace_message_header(globalVar.traceFD,message,"RDD");
	  return 0;
	}
      else
	if (message->msg_type == DATA_MULTICAST_MESSAGE)
	  // if (1==olsr_is_sym_neighbor(&message->source_addr))    
	    {
	      mdfp_insert_duplicate_table(message);
	      if(mdfp_forward_message(message))
		{
		   if(globalVar.trace)
		     trace_message_header(globalVar.traceFD,message,"RAR");
		  return 2;
		}
	      if(globalVar.trace)
		trace_message_header(globalVar.traceFD,message,"RAN");
	      return 1;
	    }
  
  return 0;
  
	  
}

/*------------------------------------------------------------------------*/

int mdfp_forward_message(struct message_header *message)
{
  
  
  message->hop_count ++;
  message->ttl --;  
  
  if(message->ttl > 0)
    if(globalVar.forwardingMode==MOLSRMODE)
      return( mdfp_lookup_valid_parent_mcTreeTable(message) );
    else
      return(mdfp_smolsr_lookup_forward(message));
  else
    return 0;
  
}
/*------------------------------------------------------------------------*/

int  mdfp_lookup_valid_parent_mcTreeTable(struct message_header *message)
{
  ip_addr parent=0;
  int i;

  if(!olsr_configured_iface(&message->originator))
    parent=message->source_addr;

  for(i=0;i<globalMDFP.molsrInfo.mcEntryNumber;i++)
    {
      if((globalMDFP.molsrInfo.mcTreeTable[i].sourceAddr==message->originator)&&
	 (globalMDFP.molsrInfo.mcTreeTable[i].groupAddr==message->destination_addr)&&
	 (globalMDFP.molsrInfo.mcTreeTable[i].parentAddr==parent))
	return 1;
    }
  return 0;

}
/*------------------------------------------------------------------------*/

int  mdfp_smolsr_lookup_forward(struct message_header *message)
{
  ip_addr parent=0;
  int i;

  if(!olsr_configured_iface(&message->originator))
    parent=message->source_addr;

  for(i=0;i<globalMDFP.molsrInfo.mcEntryNumber;i++)
    {
      if(globalMDFP.molsrInfo.mcTreeTable[i].parentAddr==parent)
	return 1;
    }
  return 0;

}
/*------------------------------------------------------------------------*/

void ip_header_extraction(struct message_header *msgh, ipq_packet_msg_t *m)
{
  /*
    extract the IP header informations
  */
  
  struct iphdr *ipHeader;
  if (!msgh)
    return;
  ipHeader=(struct  iphdr *)m->payload;
  memcpy(&msgh->source_addr,&ipHeader->saddr,sizeof(ip_addr));
  memcpy(&msgh->destination_addr,&ipHeader->daddr,sizeof(ip_addr));
  memcpy(&msgh->originator,&ipHeader->saddr,sizeof(ip_addr));
  
}
/*------------------------------------------------------------------------*/
void mdfp_header_extraction(struct message_header *msgh, ipq_packet_msg_t *m)
{
  /*
    extract the MDFP header informations
  */

  struct iphdr *ipHeader;

  struct MDFPMsg *mdfpMsg;
  
  if (!msgh)
    return;
  
  ipHeader=(struct  iphdr *)m->payload;
  mdfpMsg=(struct MDFPMsg *)(m->payload+sizeof(struct iphdr)+sizeof(struct udphdr)+globalMDFP.phSize);
  
  memcpy(&msgh->source_addr,&ipHeader->saddr,sizeof(ip_addr));
   memcpy(&msgh->destination_addr,&ipHeader->daddr,sizeof(ip_addr));

  memcpy(&msgh->originator, &mdfpMsg->origaddr,sizeof(ip_addr));
  msgh->msg_seq_number = ntohs(mdfpMsg->msgseqnum);
  msgh->hop_count =  mdfpMsg->hopcnt;
  msgh->ttl =  mdfpMsg->ttl;
  /*
    this is needed to check if the packet is received from an interface running 
    Olsr. 
  */
  msgh->interface_reception=get_iface_addr_by_name(globalCom.configuredIfaces,m->indev_name);
  
  msgh->msg_type = mdfpMsg->msgtype;
}
/*------------------------------------------------------------------------*/
int olsr_configured_iface(ip_addr *address)
{
  /*
    return 1 if the given address is in my list of configured interfaces
  */
  int i;
  if(globalMDFP.molsrInfo.mainAddress==NULL)
    return 0;
  if(0==memcmp(address,globalMDFP.molsrInfo.mainAddress,sizeof(ip_addr)))
    return 1;
  for(i=0;i<globalMDFP.molsrInfo.ifaceNumber;i++)
    {
      if(0==memcmp(address,&globalMDFP.molsrInfo.listIface[i],sizeof(ip_addr)))
	return 1;
    }
  return 0;
}

/*------------------------------------------------------------------------*/
void extract_iface_inf_from_olsr_packet(struct MDFPMsg *msgHeader)
{
  /*
    extracts the OLSR information of configured interfaces, main address, 
    and the MCTree table. those information are sent from the OLSR/MOLSR 
    daemon locally to MDFP.
  */
  int molsrStartUp=0;
 
  
  switch (msgHeader->msgtype)
    {
   
    case IFACE_MSG: 
      {
	if(!globalMDFP.molsrInfo.mainAddress)
	  molsrStartUp=1;
	globalMDFP.molsrInfo.mainAddress=&msgHeader->origaddr;
	globalMDFP.molsrInfo.listIface=(ip_addr *)((char *)msgHeader+globalMDFP.mhSize);
	globalMDFP.molsrInfo.ifaceNumber=(((char *)msgHeader+ntohs(msgHeader->msgsize))-(char *)globalMDFP.molsrInfo.listIface)/sizeof(ip_addr);
	break;
      }
    case MCTREE_MSG:
      {
	globalVar.forwardingMode=MOLSRMODE;
	globalMDFP.molsrInfo.mcTreeTable=(struct MCTreeEntry *)((char *)msgHeader+globalMDFP.mhSize);

	globalMDFP.molsrInfo.mcEntryNumber=(((char *)msgHeader+ntohs(msgHeader->msgsize))-(char *)globalMDFP.molsrInfo.mcTreeTable)/sizeof(struct MCTreeEntry);
	break;
      }
    case SMOLSR_MSG:
      {
	
	globalVar.forwardingMode=SMOLSRMODE;
	
	globalMDFP.molsrInfo.mcTreeTable=(struct MCTreeEntry *)((char *)msgHeader+globalMDFP.mhSize);
	
	globalMDFP.molsrInfo.mcEntryNumber=(((char *)msgHeader+ntohs(msgHeader->msgsize))-(char *)globalMDFP.molsrInfo.mcTreeTable)/sizeof(struct MCTreeEntry);
	break;
      }
    default: //error
    }
  

  //Sends the content of the local sources and local clients tables 
  // as New messages
  if(molsrStartUp)
    {
      mdfp_tell_MOLSR_localClientContent();
      mdfp_tell_MOLSR_localSourceContent();
    }
	
}
