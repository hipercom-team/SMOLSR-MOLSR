//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
#define MAXMSGSIZE  1450

#define OLSR_IFACE_INFO_HOLD_TIME  6
#define TIMER_PERIOD  2
#define MOLSRMODE     1
#define SMOLSRMODE    2

struct molsr_information{
  ip_addr *mainAddress;            /* main address used by OLSR/MOLSR*/
  ip_addr *listIface;             /* pointer to the list of OLSR/MOLSR 
				     configured interfaces */
  int ifaceNumber;                 /* number of interfaces */

  struct MCTreeEntry *mcTreeTable;/* pointer to the list of 
				     multicast tree table */
  int  mcEntryNumber;             /* number of entries in the 
				     multicast table */
  struct timeval timeOut;         /* timeOut before which the 
				     data is valid*/
  struct timeval holdTime;        /* the hold time value*/
};

struct global_MDFP  /* structure for global variable */
{
  
  u_int16_t   packseqnum;     /* the packet sequence number */
  u_int16_t   msgseqnum;      /* the message sequence number */
  int          phSize;              /* the size of the packet header */
  int          mhSize;              /* the size of the message header*/
  struct molsr_information molsrInfo; /* OLSR/MOLSR information, see described 
				       structure*/
  char buffer[MAXMSGSIZE+1];        /* contains the information received 
				       from OLSR/MOLSR*/ 
};
/*------------------------------------------------------------------------*/

struct global_Com
{
  int sockFd;                          /* descriptor of the socket used 
					  to send encapsulated data packet */
  int olsrComSocket;                   /* descriptor of the socket used to 
					  communicate with OLSR/MOLSR daemon*/
  struct sockaddr *addressIn;          /* sockaddr with 0.0.0.0 address bound 
					  to sockFd*/
  struct sockaddr *addressTo;          /* sockaddr with 255.255.255.255 
					  address to broadcast data */
  struct sockaddr *olsrComAddress;     /* sockaddr with 127.0.0.1 address 
					  bound to  olsrComSocket*/
  struct sockaddr *olsrComAddressTo;   /* sockaddr used to send data to 
					  MOLSR/OLSR daemon*/
  struct ipq_handle *handle;           /* handle to communicate with netfilter*/
  struct interfaces *configuredIfaces; /* list of configured interfaces on 
					  this machine*/
}; 
struct global_Var
{
  IOScheduler ioscheduler;
  struct timeval schedulerTimeOut; /* contains the period after which the select shoud return */
  struct timeval nextTimeOutEvent; /* contains the exact time for execution of the next event */
  struct timeval now; /* contain the actual time */
  struct timeval timerPeriod; 
  FILE * traceFD;                           /* file Descriptor  for trace */
  int    trace;
  int    forwardingMode;                     /* 
						forwardingMode =1 for MOLSR mode and 
						= 2 for SMOLSR 
					     */
};

extern struct global_MDFP globalMDFP;
extern struct global_Com globalCom;
extern struct global_Var globalVar;

void destroy_handle(struct ipq_handle *handle);
struct sockaddr * get_sockaddr(unsigned int port,const char * addrString);
int open_socket(struct sockaddr * address);
void print_packet_info(ipq_packet_msg_t *m);
void fill_mdfp_header(struct mdfp *mdfp_msg,unsigned int msgSize,struct message_header *msgHeader);
int encapsulate_packet (int sockFd,char * payload,int len ,struct sockaddr *address,struct message_header *msgHeader);
int mdfp_multicast_routing(int sockFd, char *payload, int len, struct sockaddr *address,struct message_header *msgHeader);
int send_to_network(int sockFd, char *payload, int len, struct sockaddr *address);
int encapsulate_forward(int sockFd,struct mdfp *mdfpPacket,int len ,struct sockaddr *address,struct message_header *msgHeader);
int ipip_encapsulation(ipq_packet_msg_t *m, char **data);
//char *decapsulate_packet(char *smolsr_msg, ipq_packet_msg_t *m, char **data_packet);
int decapsulate_packet(char **mdfp_msg,ipq_packet_msg_t *m, char **data_packet);
int local_multicast_packet(ipq_packet_msg_t *m,char **data);
int check_udp_port(ipq_packet_msg_t *m,unsigned int port);
int check_destination(char *data);
void nf_ip_local_out_process(ipq_packet_msg_t *m);
void nf_ip_local_in_process(ipq_packet_msg_t *m);
void netfilter_call_back(IOSchedulerEntry *entry);
void inOutSocket_call_back(IOSchedulerEntry* entry);
void olsrComSocket(IOSchedulerEntry* entry);
void init_global_molsr_information();
