//-------------------------------------------------------------------*- c -*-
////                                SMOLSR
////         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
////          
////  Copyright 2003-2004 Institut National de Recherche en Informatique et
////  en Automatique.  All rights reserved.  Distributed only with permission.
////---------------------------------------------------------------------------
/*
 * This Copyright notice is in French. An English summary is given
 * but the referee text is the French one.
 *
 * Copyright (c) 2000, 2001, 2002, 2003 
 *     Adokoe.Plakoo@inria.fr, INRIA Rocquencourt,
 *     Anis.Laouiti@inria.fr, INRIA Rocquencourt.
 *     Cedric.Adjih@inria.fr, INRIA Rocquencourt.
 *
 * Ce logiciel informatique est disponible aux conditions
 * usuelles dans la recherche, c'est-�-dire qu'il peut
 * �tre utilis�, copi�, modifi�, distribu� � l'unique
 * condition que ce texte soit conserv� afin que
 * l'origine de ce logiciel soit reconnue.
 * Le nom de l'Institut National de Recherche en Informatique
 * et en Automatique (INRIA), ou d'une personne morale
 * ou physique ayant particip� � l'�laboration de ce logiciel ne peut
 * �tre utilis� sans son accord pr�alable explicite.
 * 
 * Ce logiciel est fourni tel quel sans aucune garantie,
 * support ou responsabilit� d'aucune sorte.
 * Certaines parties de ce logiciel sont d�riv�es de sources developpees par
 * University of California, Berkeley et ses contributeurs couvertes 
 * par des copyrights.
 * This software is available with usual "research" terms
 * with the aim of retain credits of the software. 
 * Permission to use, copy, modify and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and the name of INRIA, or any contributor not be used in advertising
 * or publicity pertaining to this material without the prior explicit
 * permission. The software is provided "as is" without any
 * warranties, support or liabilities of any kind.
 * This product includes software developed by the University of
 * California, Berkeley and its contributors protected by copyrights.
 *
 *	
 */
#include <errno.h>

#ifndef _UNIX_IO_SCHEDULER_H
#define _UNIX_IO_SCHEDULER_H


/*---------------------------------------------------------------------------*/

#define IORead   0x0  /* for read */
#define IOWrite  0x1  /* */
#define IOExcept 0x2  /* */

#define IOEntryNone   0x00ca00    /* nothing */
#define IOEntryFD    0x10 /* file descriptor */
#define IOEntryPoll  0x20 /* */

#define IOEntryNoFD (-1)

struct s_IOSchedulerEntry;

typedef int (*IOSchedulerGetFD)(struct s_IOSchedulerEntry*);
typedef void (*IOSchedulerCallBack)(struct s_IOSchedulerEntry*);

typedef int IOEntryID;
#define IOEntryNoID (-1)

typedef struct timeval OLSRTime; /* XXX: should be in system */
OLSRTime get_clock();

typedef struct s_IOSchedulerEntry {
  /* Configuration: used by caller and by scheduler */
  int type;
  int fd[3]; /* used only with entry == IOEntryFD */
  IOSchedulerGetFD getFDFunc[3]; /* used only with entry == IOEntryPoll */
  IOSchedulerCallBack callBackFunc[3];


  /* Internal data used by scheduler only */
  IOEntryID id;
  int lastFD[3];
  unsigned int creation_iteration_count;

  /* Data used by caller only */
  void *data; /* not used by the scheduler */
} IOSchedulerEntry;

typedef struct s_IOScheduler {
  int count;
  IOSchedulerEntry *entry;
  OLSRTime last_clock; /* taken as close to the select's return as possible */
  int should_block_alarm;
  unsigned int iteration_count; /* number of select(2) that have been done */
} IOScheduler;

void ioscheduler_entry_init(IOSchedulerEntry* self, int type);

void ioscheduler_init(IOScheduler *self);
IOEntryID ioscheduler_add(IOScheduler *self, IOSchedulerEntry entry);
void ioscheduler_remove(IOScheduler *self, IOEntryID entry_id);
int ioscheduler_schedule(IOScheduler *self, OLSRTime* time_out);


void ioscheduler_start_processing(IOScheduler *self, sigset_t* osigset);
void ioscheduler_stop_processing(IOScheduler *self, sigset_t* sigset);

#endif /*_UNIX_IO_SCHEDULER_H*/
