//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
/*
 * This Copyright notice is in French. An English summary is given
 * but the referee text is the French one.
 *
 * Copyright (c) 2000, 2001, 2002, 2003
 *   Adokoe.Plakoo@inria.fr, INRIA Rocquencourt,
 *   Anis.Laouiti@inria.fr, INRIA Rocquencourt.
 *   Cedric.Adjih@inria.fr, INRIA Rocquencourt.
 *
 * Ce logiciel informatique est disponible aux conditions
 * usuelles dans la recherche, c'est-�-dire qu'il peut
 * �tre utilis�, copi�, modifi�, distribu� � l'unique
 * condition que ce texte soit conserv� afin que
 * l'origine de ce logiciel soit reconnue.
 * Le nom de l'Institut National de Recherche en Informatique
 * et en Automatique (INRIA), ou d'une personne morale
 * ou physique ayant particip� � l'�laboration de ce logiciel ne peut
 * �tre utilis� sans son accord pr�alable explicite.
 * 
 * Ce logiciel est fourni tel quel sans aucune garantie,
 * support ou responsabilit� d'aucune sorte.
 * Certaines parties de ce logiciel sont d�riv�es de sources developpees par
 * University of California, Berkeley et ses contributeurs couvertes 
 * par des copyrights.
 * This software is available with usual "research" terms
 * with the aim of retain credits of the software. 
 * Permission to use, copy, modify and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and the name of INRIA, or any contributor not be used in advertising
 * or publicity pertaining to this material without the prior explicit
 * permission. The software is provided "as is" without any
 * warranties, support or liabilities of any kind.
 * This product includes software developed by the University of
 * California, Berkeley and its contributors protected by copyrights.
 *
 *	$Id: message.h,v 1.2 2004/11/02 09:58:13 laouiti Exp $
 */



struct message_header{
  /* source addr is the interface 
     which sent this message */
  ip_addr        source_addr;
  ip_addr        originator;
  ip_addr        destination_addr;
  u_int16_t      msg_seq_number;
  u_int8_t          hop_count;
  u_int8_t           ttl;
  ip_addr        interface_reception;
  u_int8_t           msg_type;

};

#define        MAX_SEQUENCE_NUMBER 0xffff

/* S1 greater than S2 */

#define greater_than(S1, S2) \
( ( ( S1 > S2) && ((S1 - S2) <= (MAX_SEQUENCE_NUMBER / 2)) ) \
|| \
  ( (S2 > S1) && ((S1 - S2) > (MAX_SEQUENCE_NUMBER / 2)) ) )
#define OLSRMAINTYPE_MAX    4


int mdfp_parser(struct message_header *);

int mdfp_forward_message(struct message_header *);

void mdfp_header_extraction(struct message_header *msgh, ipq_packet_msg_t *m);

void extract_iface_inf_from_olsr_packet(struct MDFPMsg *msgHeader);

int olsr_configured_iface(ip_addr *address);

int  mdfp_lookup_valid_parent_mcTreeTable(struct message_header *message);

void ip_header_extraction(struct message_header *msgh, ipq_packet_msg_t *m);
