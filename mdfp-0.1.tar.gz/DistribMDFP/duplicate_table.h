//-------------------------------------------------------------------*- c -*-
//                                MDFP
//         Anis LAOUITI, projet Hipercom, INRIA Rocquencourt
//          
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
/*
 * This Copyright notice is in French. An English summary is given
 * but the referee text is the French one.
 *
 * Copyright (c) 2000, 2001, 2002, 2003
 *   Adokoe.Plakoo@inria.fr, INRIA Rocquencourt,
 *   Anis.Laouiti@inria.fr, INRIA Rocquencourt.
 *   Cedric.Adjih@inria.fr, INRIA Rocquencourt.
 *
 * Ce logiciel informatique est disponible aux conditions
 * usuelles dans la recherche, c'est-�-dire qu'il peut
 * �tre utilis�, copi�, modifi�, distribu� � l'unique
 * condition que ce texte soit conserv� afin que
 * l'origine de ce logiciel soit reconnue.
 * Le nom de l'Institut National de Recherche en Informatique
 * et en Automatique (INRIA), ou d'une personne morale
 * ou physique ayant particip� � l'�laboration de ce logiciel ne peut
 * �tre utilis� sans son accord pr�alable explicite.
 * 
 * Ce logiciel est fourni tel quel sans aucune garantie,
 * support ou responsabilit� d'aucune sorte.
 * Certaines parties de ce logiciel sont d�riv�es de sources developpees par
 * University of California, Berkeley et ses contributeurs couvertes 
 * par des copyrights.
 * This software is available with usual "research" terms
 * with the aim of retain credits of the software. 
 * Permission to use, copy, modify and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and the name of INRIA, or any contributor not be used in advertising
 * or publicity pertaining to this material without the prior explicit
 * permission. The software is provided "as is" without any
 * warranties, support or liabilities of any kind.
 * This product includes software developed by the University of
 * California, Berkeley and its contributors protected by copyrights.
 *
 *	$Id: duplicate_table.h,v 1.2 2004/11/02 09:58:13 laouiti Exp $
 */


#define DUPLICATE_HOLD_TIME  15

struct duplicate_entry {
  struct          duplicate_entry *duplicate_forw;
  struct          duplicate_entry *duplicate_back;
  u_int32_t       duplicate_hash;
  ip_addr         duplicate_addr;
  u_int16_t       duplicate_seq;	
  struct timeval  duplicate_timer;	
};


struct duplicatehash {
  struct duplicate_entry *duplicate_forw;
  struct duplicate_entry *duplicate_back;
};

extern struct duplicatehash       duplicatetable[];

extern struct timeval hold_time_duplicate;
extern double duplicate_hold_time ;
void mdfp_delete_duplicate_table(struct duplicate_entry *);

void mdfp_insert_duplicate_table(struct message_header *);

struct duplicate_entry 
*mdfp_lookup_duplicate_table(struct message_header *);

void mdfp_release_duplicate_table();

void mdfp_time_out_duplicate_table();
